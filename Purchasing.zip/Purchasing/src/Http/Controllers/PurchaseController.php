<?php

namespace Modules\Purchasing\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Purchasing\Models\PurchaseRequest;
use Modules\Purchasing\Models\PurchaseRequestItem;
use Modules\Inventory\Models\Material;
use App\Models\Department;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PurchaseController extends Controller
{
    public function index()
    {
        $requests = PurchaseRequest::withPermission('purchase')
            ->with(['requester', 'department', 'approver'])
            ->withCount('items')
            ->orderByRaw("FIELD(priority, 'High', 'Normal', 'Low')")
            ->latest()
            ->paginate(15);

        return view('purchasing::purchase.requests.index', compact('requests'));
    }

    public function create(Request $request)
    {
        $preSelectedMaterialId = $request->query('material_id'); 

        $materials = Material::select('id', 'name', 'sku', 'unit', 'cas_no')->get();
        $managers = User::where('id', '!=', Auth::id())->get();
        $departments = Department::all(); 
        $userDepartment = Auth::user()->department; 

        return view('purchasing::purchase.requests.create', compact('materials', 'userDepartment', 'managers', 'preSelectedMaterialId', 'departments'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'request_date' => 'required|date',
            'department_id' => 'required|exists:departments,id',
            'approver_id' => 'required|exists:users,id',
            'requested_by_date' => 'required|date|after_or_equal:request_date',
            'priority' => 'required',
            'items' => 'required|array|min:1', 
            'items.*.material_id' => 'required|exists:materials,id',
            'items.*.quantity' => 'required|numeric|min:0.0001',
        ], [
            'request_date.required' => 'Lütfen talep tarihini belirtiniz.',
            'approver_id.required' => 'Lütfen onaylayacak yöneticiyi seçiniz.',
            'requested_by_date.required' => 'Lütfen termin tarihini belirtiniz.',
            'requested_by_date.after_or_equal' => 'Termin tarihi, talep tarihinden eski olamaz.',
            'items.required' => 'Lütfen listeye en az bir malzeme ekleyiniz.',
            'items.min' => 'Lütfen listeye en az bir malzeme ekleyiniz.',
            'department_id.required' => 'Departman bilgisi alınamadı, lütfen sayfayı yenileyip tekrar deneyin.',
            'items.*.material_id.required' => 'Seçilen malzemelerden biri hatalı.',
            'items.*.quantity.required' => 'Lütfen tüm malzemeler için miktar giriniz.',
            'items.*.quantity.min' => 'Miktar 0 dan büyük olmalıdır.',
        ]);

        try {
            DB::beginTransaction();

            $dateStr = now()->format('Ymd');
            $branchId = session('active_branch_id');
            // Aynı şubeden eşzamanlı taleplerde sayaç değerini seri hale getir.
            DB::table('branches')->where('id', $branchId)->lockForUpdate()->first();
            $count = DB::table('purchase_requests')
                ->where('branch_id', $branchId)
                ->whereDate('created_at', today())
                ->where('request_no', 'like', 'REQ-' . $dateStr . '-B' . $branchId . '-%')
                ->count() + 1;
            // Şube kodu global UNIQUE alanında şubeler arası çakışmayı önler.
            $reqNo = 'REQ-' . $dateStr . '-B' . $branchId . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

            $approver = User::findOrFail($request->approver_id);
            $purchaseRequest = PurchaseRequest::create([
                'request_no' => $reqNo,
                'request_date' => $request->request_date,
                'requester_id' => Auth::id(),
                'department_id' => $request->department_id,
                'approver_id' => $request->approver_id,
                'requested_by_date' => $request->requested_by_date,
                'priority' => $request->priority,
                'reason' => $request->reason,
                'status' => 'Pending',
            ]);

            foreach ($request->items as $item) {
                PurchaseRequestItem::create([
                    'purchase_request_id' => $purchaseRequest->id,
                    'material_id' => $item['material_id'],
                    'quantity' => $item['quantity'],
                    'unit' => $item['unit'] ?? 'Adet',
                    'technical_specifications' => $item['specs'] ?? null,
                ]);
            }

            DB::commit();

            $notificationSent = true;
            try {
                $approver->notify(new \App\Notifications\PurchaseRequestApprovalNotification($purchaseRequest->fresh(), Auth::user()));
            } catch (\Throwable $notificationError) {
                $notificationSent = false;
                \Illuminate\Support\Facades\Log::warning('Satınalma onay bildirimi gönderilemedi.', [
                    'request_id' => $purchaseRequest->id,
                    'approver_id' => $approver->id,
                    'error' => $notificationError->getMessage(),
                ]);
            }

            $message = 'Satın alma talebi oluşturuldu. No: ' . $reqNo;
            if ($notificationSent) {
                $message .= ' Onaylayıcıya uygulama bildirimi ve varsa e-posta gönderildi.';
            } else {
                $message .= ' Ancak onaylayıcı bildirimi gönderilemedi; sistem kayıtlarına bakınız.';
            }
            return redirect()->route('admin.purchase.requests.index')->with($notificationSent ? 'success' : 'warning', $message);

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Kayıt sırasında hata oluştu: ' . $e->getMessage())->withInput();
        }
    }

    public function show($id)
    {
        $req = PurchaseRequest::withPermission('purchase')->with(['requester', 'department', 'items.material', 'approver'])->findOrFail($id);
        return view('purchasing::purchase.requests.show', compact('req'));
    }

    public function edit($id)
    {
        $req = PurchaseRequest::withPermission('purchase')->with('items.material')->findOrFail($id);
        
        if ($req->status != 'Pending' && !Auth::user()->isAdmin()) {
            return back()->with('error', 'Sadece "Onay Bekleyen" talepler düzenlenebilir.');
        }

        $materials = Material::select('id', 'name', 'sku', 'unit', 'cas_no')->get();
        $managers = User::where('id', '!=', Auth::id())->get();
        $departments = Department::all();
        $userDepartment = Auth::user()->department;
        $branches = Auth::user()->isAdmin()
            ? DB::table('branches')->orderBy('name')->get()
            : collect();

        return view('purchasing::purchase.requests.edit', compact('req', 'materials', 'managers', 'departments', 'userDepartment', 'branches'));
    }

    public function update(Request $request, $id)
    {
        $req = PurchaseRequest::withPermission('purchase')->findOrFail($id);

        if ($req->status != 'Pending' && !Auth::user()->isAdmin()) {
            abort(403, 'Sadece onay bekleyen talepleri düzenleyebilirsiniz.');
        }

        $validationRules = [
            'request_date' => 'required|date',
            'approver_id' => 'required|exists:users,id',
            'requested_by_date' => 'required|date|after_or_equal:request_date',
            'items' => 'required|array|min:1',
            'items.*.item_id' => 'nullable|integer',
            'items.*.material_id' => 'required|exists:materials,id',
            'items.*.quantity' => 'required|numeric|min:0.0001',
        ];
        if (Auth::user()->isAdmin()) {
            $validationRules['branch_id'] = 'required|exists:branches,id';
        }
        $request->validate($validationRules);

        $targetBranchId = Auth::user()->isAdmin()
            ? (int) $request->input('branch_id', $req->branch_id)
            : (int) $req->branch_id;
        $oldItems = $req->items()->get();
        $oldItemIds = $oldItems->pluck('id')->map(fn ($id) => (int) $id);
        $submittedItemIds = collect($request->input('items'))
            ->pluck('item_id')->filter()->map(fn ($id) => (int) $id)->unique()->values();

        // Satır kimlikleri başka bir talebe ait olamaz; teklif ve mal kabul bağlantıları bu ID'lere bağlıdır.
        if ($submittedItemIds->diff($oldItemIds)->isNotEmpty()) {
            return back()->withInput()->withErrors(['items' => 'Talep kalemlerinden biri bu talebe ait değil.']);
        }

        $removedItemIds = $oldItemIds->diff($submittedItemIds);
        if ($removedItemIds->isNotEmpty() && DB::table('purchase_offer_items')->whereIn('purchase_request_item_id', $removedItemIds)->exists()) {
            return back()->withInput()->withErrors(['items' => 'Teklif veya mal kabul kaydı bulunan talep kalemleri silinemez. Önce bağlı işlem kayıtlarını düzenleyin.']);
        }

        try {
            DB::beginTransaction();

            $req->update([
                'request_date' => $request->request_date,
                'approver_id' => $request->approver_id,
                'requested_by_date' => $request->requested_by_date,
                'priority' => $request->priority,
                'reason' => $request->reason,
            ]);

            // Var olan kalemleri aynı ID ile güncelle; teklif/sipariş/mal kabul yabancı anahtarları korunur.
            foreach ($request->items as $item) {
                $itemData = [
                    'material_id' => $item['material_id'],
                    'quantity' => $item['quantity'],
                    'unit' => $item['unit'] ?? 'Adet',
                    'technical_specifications' => $item['specs'] ?? null,
                    'updated_at' => now(),
                ];

                if (!empty($item['item_id'])) {
                    DB::table('purchase_request_items')
                        ->where('id', (int) $item['item_id'])
                        ->where('purchase_request_id', $req->id)
                        ->update($itemData);
                } else {
                    DB::table('purchase_request_items')->insert($itemData + [
                        'purchase_request_id' => $req->id,
                        'branch_id' => $targetBranchId,
                        'created_at' => now(),
                    ]);
                }
            }

            if ($removedItemIds->isNotEmpty()) {
                DB::table('purchase_request_items')->whereIn('id', $removedItemIds)->delete();
            }

            $branchChanged = $targetBranchId !== (int) $req->branch_id;
            if ($branchChanged) {
                $offerIds = DB::table('purchase_offers')
                    ->where('purchase_request_id', $req->id)->pluck('id');
                $orderIds = DB::table('purchase_orders')
                    ->where('purchase_request_id', $req->id)->pluck('id');
                $deliveryIds = $orderIds->isEmpty()
                    ? collect()
                    : DB::table('purchase_deliveries')->whereIn('purchase_order_id', $orderIds)->pluck('id');

                // Tüm işlem zincirini aynı transaction içinde aktar; belgeler order_id ile ilişkilidir.
                DB::table('purchase_request_items')->where('purchase_request_id', $req->id)->update(['branch_id' => $targetBranchId]);
                DB::table('purchase_offers')->where('purchase_request_id', $req->id)->update(['branch_id' => $targetBranchId]);
                if ($offerIds->isNotEmpty()) {
                    DB::table('purchase_offer_items')->whereIn('purchase_offer_id', $offerIds)->update(['branch_id' => $targetBranchId]);
                }
                DB::table('purchase_orders')->where('purchase_request_id', $req->id)->update(['branch_id' => $targetBranchId]);
                if ($deliveryIds->isNotEmpty()) {
                    DB::table('purchase_deliveries')->whereIn('id', $deliveryIds)->update(['branch_id' => $targetBranchId]);
                    DB::table('purchase_delivery_items')->whereIn('purchase_delivery_id', $deliveryIds)->update(['branch_id' => $targetBranchId]);
                }
                DB::table('purchase_requests')->where('id', $req->id)->update(['branch_id' => $targetBranchId]);
            }

            DB::commit();
            if ($branchChanged) {
                return redirect()->route('admin.purchase.requests.index')
                    ->with('success', 'Talep ve ilişkili teklifler, siparişler, mal kabuller ve kalemleri hedef şubeye taşındı.');
            }
            return redirect()->route('admin.purchase.requests.show', $req->id)->with('success', 'Talep başarıyla güncellendi.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage())->withInput();
        }
    }

    public function destroy($id)
    {
        $req = PurchaseRequest::withPermission('purchase')->findOrFail($id);

        if ($req->status != 'Pending' && !Auth::user()->isAdmin()) {
            return back()->with('error', 'Sadece "Onay Bekleyen" talepler silinebilir.');
        }

        $req->items()->delete(); 
        $req->delete();          

        return redirect()->route('admin.purchase.requests.index')->with('success', 'Talep tamamen silindi.');
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'action' => 'required|in:Approved,Rejected',
            'approval_note' => 'required|string|min:5', 
            'approval_date' => 'nullable|date', // Yeni tarihimizi doğrulamaya ekledik
        ]);

        $purchaseRequest = PurchaseRequest::where('approver_id', Auth::id())->orWhere(function ($query) use ($id) {
            if (Auth::user()->isAdmin()) {
                $query->where('id', $id);
            } else {
                $query->whereRaw('1=0');
            }
        })->findOrFail($id);

        if (Auth::id() != $purchaseRequest->approver_id && !Auth::user()->isAdmin()) {
            abort(403, 'Bu işlem için yetkiniz yok.');
        }

        DB::table('purchase_requests')->where('id', $purchaseRequest->id)->update([
            'status' => $request->action,
            'approval_note' => $request->approval_note,
            'responded_at' => $request->approval_date ? \Carbon\Carbon::parse($request->approval_date) : now(),
            'updated_at' => now(),
        ]);

        $msg = $request->action == 'Approved' ? 'Talep onaylandı, teklif sürecine aktarılacak.' : 'Talep reddedildi.';
        return back()->with('success', $msg);
    }

    public function printForm($id)
    {
        $req = PurchaseRequest::withPermission('purchase')->with(['requester', 'department', 'items.material', 'approver'])->findOrFail($id);
        $logoUrl = asset('assets/img/logo.png');
        return view('purchasing::purchase.requests.print-form', compact('req'));
    }
}