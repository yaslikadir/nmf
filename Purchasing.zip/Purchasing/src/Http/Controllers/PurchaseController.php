<?php

namespace Modules\Purchasing\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Purchasing\Models\PurchaseRequest;
use Modules\Purchasing\Models\PurchaseRequestItem;
use Modules\Inventory\Models\Material;
use App\Models\Department;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PurchaseController extends Controller
{
    public function index()
    {
        $requests = PurchaseRequest::withPermission('purchase_requests')
            ->with(['requester', 'department', 'approver'])
            ->withCount('items')
            ->orderByRaw("FIELD(priority, 'High', 'Normal', 'Low')")
            ->latest()
            ->paginate(15);

        return view('purchasing::purchase.requests.index', compact('requests'));
    }

    public function create(Request $request)
    {
        $preSelectedMaterialId = $request->query('material_id'); 

        $materials = Material::select('id', 'name', 'sku', 'unit', 'cas_no')->get();
        $managers = User::where('id', '!=', Auth::id())->get();
        $departments = Department::all(); 
        $userDepartment = Auth::user()->department; 

        return view('purchasing::purchase.requests.create', compact('materials', 'userDepartment', 'managers', 'preSelectedMaterialId', 'departments'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'request_date' => 'required|date',
            'department_id' => 'required|exists:departments,id',
            'approver_id' => 'required|exists:users,id',
            'requested_by_date' => 'required|date|after_or_equal:request_date',
            'priority' => 'required',
            'items' => 'required|array|min:1', 
            'items.*.material_id' => 'required|exists:materials,id',
            'items.*.quantity' => 'required|numeric|min:0.0001',
        ], [
            'request_date.required' => 'Lütfen talep tarihini belirtiniz.',
            'approver_id.required' => 'Lütfen onaylayacak yöneticiyi seçiniz.',
            'requested_by_date.required' => 'Lütfen termin tarihini belirtiniz.',
            'requested_by_date.after_or_equal' => 'Termin tarihi, talep tarihinden eski olamaz.',
            'items.required' => 'Lütfen listeye en az bir malzeme ekleyiniz.',
            'items.min' => 'Lütfen listeye en az bir malzeme ekleyiniz.',
            'department_id.required' => 'Departman bilgisi alınamadı, lütfen sayfayı yenileyip tekrar deneyin.',
            'items.*.material_id.required' => 'Seçilen malzemelerden biri hatalı.',
            'items.*.quantity.required' => 'Lütfen tüm malzemeler için miktar giriniz.',
            'items.*.quantity.min' => 'Miktar 0 dan büyük olmalıdır.',
        ]);

        try {
            DB::beginTransaction();

            $dateStr = date('Ymd');
            $count = PurchaseRequest::whereDate('created_at', today())->count() + 1;
            $reqNo = 'REQ-' . $dateStr . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

            $purchaseRequest = PurchaseRequest::create([
                'request_no' => $reqNo,
                'request_date' => $request->request_date,
                'requester_id' => Auth::id(),
                'department_id' => $request->department_id,
                'approver_id' => $request->approver_id,
                'requested_by_date' => $request->requested_by_date,
                'priority' => $request->priority,
                'reason' => $request->reason,
                'status' => 'Pending',
            ]);

            foreach ($request->items as $item) {
                PurchaseRequestItem::create([
                    'purchase_request_id' => $purchaseRequest->id,
                    'material_id' => $item['material_id'],
                    'quantity' => $item['quantity'],
                    'unit' => $item['unit'] ?? 'Adet',
                    'technical_specifications' => $item['specs'] ?? null,
                ]);
            }

            DB::commit();
            return redirect()->route('admin.purchase.requests.index')
                ->with('success', 'Satın alma talebi başarıyla oluşturuldu. No: ' . $reqNo);

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Kayıt sırasında hata oluştu: ' . $e->getMessage())->withInput();
        }
    }

    public function show($id)
    {
        $req = PurchaseRequest::with(['requester', 'department', 'items.material', 'approver'])->findOrFail($id);
        return view('purchasing::purchase.requests.show', compact('req'));
    }

    public function edit($id)
    {
        $req = PurchaseRequest::with('items.material')->findOrFail($id);
        
        if ($req->status != 'Pending' && !Auth::user()->isAdmin()) {
            return back()->with('error', 'Sadece "Onay Bekleyen" talepler düzenlenebilir.');
        }

        $materials = Material::select('id', 'name', 'sku', 'unit', 'cas_no')->get();
        $managers = User::where('id', '!=', Auth::id())->get();
        $departments = Department::all();
        $userDepartment = Auth::user()->department;

        return view('purchasing::purchase.requests.edit', compact('req', 'materials', 'managers', 'departments', 'userDepartment'));
    }

    public function update(Request $request, $id)
    {
        $req = PurchaseRequest::findOrFail($id);

        if ($req->status != 'Pending' && !Auth::user()->isAdmin()) {
            abort(403, 'Sadece onay bekleyen talepleri düzenleyebilirsiniz.');
        }

        $request->validate([
            'request_date' => 'required|date',
            'approver_id' => 'required|exists:users,id',
            'requested_by_date' => 'required|date|after_or_equal:request_date',
            'items' => 'required|array|min:1', 
        ]);

        try {
            DB::beginTransaction();

            $req->update([
                'request_date' => $request->request_date,
                'approver_id' => $request->approver_id,
                'requested_by_date' => $request->requested_by_date,
                'priority' => $request->priority,
                'reason' => $request->reason,
            ]);

            $req->items()->delete();

            foreach ($request->items as $item) {
                PurchaseRequestItem::create([
                    'purchase_request_id' => $req->id,
                    'material_id' => $item['material_id'],
                    'quantity' => $item['quantity'],
                    'unit' => $item['unit'] ?? 'Adet',
                    'technical_specifications' => $item['specs'] ?? null,
                ]);
            }

            DB::commit();
            return redirect()->route('admin.purchase.requests.show', $req->id)->with('success', 'Talep başarıyla güncellendi.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    public function destroy($id)
    {
        $req = PurchaseRequest::findOrFail($id);

        if ($req->status != 'Pending' && !Auth::user()->isAdmin()) {
            return back()->with('error', 'Sadece "Onay Bekleyen" talepler silinebilir.');
        }

        $req->items()->delete(); 
        $req->delete();          

        return redirect()->route('admin.purchase.requests.index')->with('success', 'Talep tamamen silindi.');
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'action' => 'required|in:Approved,Rejected',
            'approval_note' => 'required|string|min:5', 
            'approval_date' => 'nullable|date', // Yeni tarihimizi doğrulamaya ekledik
        ]);

        $purchaseRequest = PurchaseRequest::findOrFail($id);

        if (Auth::id() != $purchaseRequest->approver_id && !Auth::user()->isAdmin()) {
            abort(403, 'Bu işlem için yetkiniz yok.');
        }

        $purchaseRequest->update([
            'status' => $request->action,
            'approval_note' => $request->approval_note,
            // Eğer formdan approval_date gelirse onu, gelmezse (gizliyse) şu anki tarihi kaydediyoruz.
            'responded_at' => $request->approval_date ? \Carbon\Carbon::parse($request->approval_date) : now(),
        ]);

        $msg = $request->action == 'Approved' ? 'Talep onaylandı, teklif sürecine aktarılacak.' : 'Talep reddedildi.';
        return back()->with('success', $msg);
    }

    public function printForm($id)
    {
        $req = PurchaseRequest::with(['requester', 'department', 'items.material', 'approver'])->findOrFail($id);
        $logoUrl = asset('assets/img/logo.png');
        return view('purchasing::purchase.requests.print-form', compact('req'));
    }
}