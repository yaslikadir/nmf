<?php

namespace Modules\Purchasing\Support;

use Illuminate\Database\Eloquent\Builder;

trait BranchScoped
{
    protected static function bootBranchScoped(): void
    {
        static::addGlobalScope('purchasing_branch', function (Builder $builder): void {
            $model = $builder->getModel();
            $branchId = session('active_branch_id');
            $assigneeColumns = $model->branchScopeAssigneeColumns
                ?? array_filter([$model->branchScopeAssigneeColumn ?? null]);
            $parentApproval = $model->branchScopeParentApproval ?? null;
            $userId = auth()->id();
            $canSeeAssigned = (!empty($assigneeColumns) && $userId) || ($parentApproval && $userId);

            $builder->where(function (Builder $query) use ($model, $branchId, $assigneeColumns, $parentApproval, $userId, $canSeeAssigned): void {
                if ($branchId) {
                    $query->where($model->qualifyColumn('branch_id'), $branchId);
                } else {
                    $query->whereRaw('1 = 0');
                }

                if (!$canSeeAssigned) {
                    return;
                }

                if ($userId) {
                    foreach ($assigneeColumns as $column) {
                        $query->orWhere($model->qualifyColumn($column), $userId);
                    }
                }

                if ($parentApproval && $userId) {
                    $parentTable = $parentApproval['table'];
                    $foreignKey = $parentApproval['foreign_key'];
                    $parentKey = $parentApproval['parent_key'] ?? 'id';
                    $approvalColumns = $parentApproval['assignee_columns'] ?? ['approver_id'];
                    $query->orWhereExists(function ($subquery) use ($parentTable, $foreignKey, $parentKey, $approvalColumns, $model, $userId): void {
                        $subquery->selectRaw('1')
                            ->from($parentTable)
                            ->whereColumn($parentTable . '.' . $parentKey, $model->qualifyColumn($foreignKey))
                            ->where(function ($assignees) use ($parentTable, $approvalColumns, $userId): void {
                                foreach ($approvalColumns as $index => $column) {
                                    $index === 0
                                        ? $assignees->where($parentTable . '.' . $column, $userId)
                                        : $assignees->orWhere($parentTable . '.' . $column, $userId);
                                }
                            });
                    });
                }
            });
        });

        static::creating(function ($model): void {
            $branchId = session('active_branch_id');
            if (!$branchId) {
                throw new \RuntimeException('Satın alma kaydı oluşturulmadan önce aktif şube seçilmelidir.');
            }
            $model->branch_id = $branchId;
        });

        static::updating(function ($model): void {
            $branchId = session('active_branch_id');
            if (!$branchId || (string) $model->branch_id !== (string) $branchId) {
                throw new \RuntimeException('Satın alma kaydı farklı bir şubeye taşınamaz.');
            }
        });
    }
}
