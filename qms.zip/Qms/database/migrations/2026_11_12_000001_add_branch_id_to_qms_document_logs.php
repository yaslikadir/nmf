<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('qms_document_logs') && !Schema::hasColumn('qms_document_logs', 'branch_id')) {
            Schema::table('qms_document_logs', function (Blueprint $table): void {
                $table->unsignedBigInteger('branch_id')->nullable()->index()->after('id');
            });
        }

        // Eski audit kayıtları belgeyle aynı şubeye bağlansın; log geçmişi görünmez kalmasın.
        if (Schema::hasTable('qms_document_logs')
            && Schema::hasColumn('qms_document_logs', 'branch_id')
            && Schema::hasTable('qms_documents')
            && Schema::hasColumn('qms_documents', 'branch_id')) {
            DB::table('qms_document_logs')
                ->join('qms_documents', 'qms_documents.id', '=', 'qms_document_logs.document_id')
                ->whereNull('qms_document_logs.branch_id')
                ->update(['qms_document_logs.branch_id' => DB::raw('qms_documents.branch_id')]);
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('qms_document_logs') && Schema::hasColumn('qms_document_logs', 'branch_id')) {
            Schema::table('qms_document_logs', function (Blueprint $table): void {
                $table->dropColumn('branch_id');
            });
        }
    }
};
