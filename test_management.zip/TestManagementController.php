<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sample;
use App\Models\Offer;
use App\Models\AnalysisWorkOrder;
use App\Models\AnalysisResult;
use App\Models\AnalysisMethod;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class TestManagementController extends Controller
{
    public function index()
    {
        // GÜNCELLEME: 'Analiz Tamamlandı' statüsü eklendi ki bitenler uçup gitmesin
        $offersForAnalysis = Offer::with(['customer', 'items', 'samples.workOrders.result'])
            ->whereHas('samples', function($q) {
                $q->whereIn('global_status', ['Analize Hazır', 'Analiz Aşamasında', 'Analiz Tamamlandı']);
            })->orderBy('created_at', 'desc')->get();

        $materials = \App\Models\Material::select('id', 'name', 'unit', 'sku')
            ->where('is_active', true)
            ->get();

        return view('admin.test_management.index', compact('offersForAnalysis', 'materials'));
    }

    /**
     * AJAX: Modal açıldığında teklife ait numuneleri ve parametreleri getirir
     */
    public function getOfferDetails($offerId)
    {
        $offer = Offer::with(['items.parameter.subParameters', 'items.parameter.scopeType'])->findOrFail($offerId);
        
        // GÜNCELLEME: Modalda bitenleri de görebilmek için 'Analiz Tamamlandı' eklendi
        $samples = Sample::with(['workOrders.result', 'workOrders.analyst'])
            ->where('offer_id', $offerId)
            ->whereIn('global_status', ['Analize Hazır', 'Analiz Aşamasında', 'Analiz Tamamlandı'])
            ->get();

        // Teklif kalemlerinde olmayan ama numunelere (barkodlara) atanmış parametreleri bul
        $sampleParamNames = $samples->map(function($s) {
            return trim($s->analysis_summary ?: $s->description);
        })->filter()->unique()->toArray();

        $extraParameters = \App\Models\ScopeParameter::with(['subParameters', 'scopeType'])
            ->whereIn('name', $sampleParamNames)
            ->get();

        $methods = AnalysisMethod::select('id', 'code', 'name')->get();

        if ($samples->isEmpty()) {
            return response()->json(['status' => 'error', 'message' => 'İşlem yapılacak numune bulunamadı.']);
        }

        return response()->json([
            'status' => 'success',
            'offer' => $offer,
            'samples' => $samples,
            'extra_parameters' => $extraParameters,
            'methods' => $methods
        ]);
    }

    /**
     * AJAX: Tablodaki tüm doldurulmuş sonuçları TEK SEFERDE kaydeder ve Referans kıyaslamasını yapar
     */
    public function saveBulkResults(Request $request, $offerId)
    {
        $results = $request->input('results', []);

        try {
            DB::beginTransaction();

            $offerHasUpdates = false;

            foreach ($results as $sampleId => $parameters) {
                $sample = Sample::find($sampleId);
                if (!$sample) continue;

                $sampleUpdated = false;

                foreach ($parameters as $paramId => $data) {
                    $hasValue = isset($data['value']) && trim($data['value']) !== '';
                    $hasNote = isset($data['note']) && trim($data['note']) !== '';

                    if (!$hasValue && !$hasNote) {
                        continue;
                    }

                    $param = \App\Models\ScopeParameter::find($paramId);
                    
                    $conformance = 'Bilgi Amaçlı';
                    
                    if ($hasValue && $param && ($param->limit_min !== null || $param->limit_max !== null)) {
                        $valStr = str_replace(',', '.', $data['value']);
                        
                        if (is_numeric($valStr)) { 
                            $val = floatval($valStr);
                            $min = $param->limit_min !== null ? floatval($param->limit_min) : -999999;
                            $max = $param->limit_max !== null ? floatval($param->limit_max) : 999999;
                            $conformance = ($val >= $min && $val <= $max) ? 'Uygun' : 'Uygun Değil';
                        }
                    }

                    $order = AnalysisWorkOrder::firstOrCreate(
                        ['sample_id' => $sample->id, 'scope_parameter_id' => $paramId],
                        ['assigned_by' => Auth::id(), 'target_date' => now()]
                    );

                    $existingResult = AnalysisResult::where('analysis_work_order_id', $order->id)->first();
                    $orderUpdate = ['analyst_id' => Auth::id()];
                    if ($hasValue) {
                        $orderUpdate['status'] = 'Completed';
                        $orderUpdate['completed_at'] = now();
                    }
                    $order->update($orderUpdate);

                    AnalysisResult::updateOrCreate(
                        ['analysis_work_order_id' => $order->id],
                        [
                            // Not eklemek tek başına analiz sonucu değildir; varsa eski ölçüm değerini koru.
                            'result_value'      => $hasValue ? $data['value'] : ($existingResult->result_value ?? null),
                            'result_unit'       => $param->unit ?? '',
                            'uncertainty'       => $data['uncertainty'] ?? null,
                            'applied_limit_min' => $param->limit_min ?? null,
                            'applied_limit_max' => $param->limit_max ?? null,
                            'conformance'       => $conformance,
                            'raw_data'          => $hasNote ? $data['note'] : null,
                            'recorded_by'       => Auth::id(),
                        ]
                    );

                    $sampleUpdated = true;
                    $offerHasUpdates = true;
                }

                if ($sampleUpdated && $sample->global_status === 'Analize Hazır') {
                    $sample->update(['global_status' => 'Analiz Aşamasında', 'status' => 'Analiz Aşamasında']);
                }
            }

            DB::commit();

            if ($offerHasUpdates) {
                return response()->json(['status' => 'success', 'message' => 'Girilen tüm sonuçlar ve notlar başarıyla kaydedildi.']);
            } else {
                return response()->json(['status' => 'info', 'message' => 'Kaydedilecek yeni bir sonuç veya not bulunamadı.']);
            }

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }

    // ÇOKLU DOSYA YÜKLEME METODU
    public function uploadOfferRawData(Request $request, $offerId)
    {
        $request->validate([
            'raw_data_files' => 'required|array',
            'raw_data_files.*' => 'file|mimes:pdf,xls,xlsx,zip|max:50480', 
        ], [
            'raw_data_files.*.mimes' => 'Lütfen sadece PDF, Excel (xls, xlsx) veya ZIP formatında dosya yükleyin.',
            'raw_data_files.*.max' => 'Yüklenen dosyaların boyutu en fazla 50MB olabilir.'
        ]);

        try {
            $offer = Offer::findOrFail($offerId);

            if ($request->hasFile('raw_data_files')) {
                
                $currentData = $offer->raw_data_file;
                $existingFiles = [];

                if (!empty($currentData)) {
                    if (is_array($currentData)) {
                        $existingFiles = $currentData; 
                    } else {
                        $decoded = json_decode($currentData, true);
                        if (is_array($decoded)) {
                            $existingFiles = $decoded; 
                        } else {
                            $existingFiles = [$currentData]; 
                        }
                    }
                }

                $newPaths = [];
                foreach ($request->file('raw_data_files') as $file) {
                    // YENİ: Orijinal dosya adını alıp sunucuya uygun (Türkçe karaktersiz) hale getiriyoruz
                    $extension = $file->getClientOriginalExtension();
                    $nameWithoutExt = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
                    $safeName = \Illuminate\Support\Str::slug($nameWithoutExt) . '.' . $extension;
                    
                    // Çakışmayı önlemek için başına benzersiz ID ekliyoruz
                    $fileName = time() . '_' . uniqid() . '_' . $safeName;
                    
                    $newPaths[] = $file->storeAs('analysis_raw_data/offers', $fileName, 'public');
                }

                $allFiles = array_merge($existingFiles, $newPaths);
                
                $offer->raw_data_file = json_encode(array_values($allFiles));
                $offer->save();
                
                return response()->json([
                    'status' => 'success', 
                    'message' => 'Dosyalar başarıyla yüklendi.',
                    'raw_files' => array_values($allFiles) 
                ]);
            }
            return response()->json(['status' => 'error', 'message' => 'Dosya bulunamadı.']);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }

    // ÇOKLU VE TEKLİ DOSYA SİLME METODU
    public function deleteOfferRawData(Request $request, $offerId)
    {
        $request->validate([
            'files_to_delete' => 'required|array'
        ]);

        try {
            $offer = Offer::findOrFail($offerId);
            $filesToDelete = $request->files_to_delete;

            $currentData = $offer->raw_data_file;
            $existingFiles = [];

            if (!empty($currentData)) {
                if (is_array($currentData)) {
                    $existingFiles = $currentData;
                } else {
                    $decoded = json_decode($currentData, true);
                    if (is_array($decoded)) {
                        $existingFiles = $decoded;
                    } else {
                        $existingFiles = [$currentData];
                    }
                }
            }

            $remainingFiles = [];
            foreach ($existingFiles as $file) {
                // Tırnak işaretlerinden ve parantezlerden arındırılmış temiz dosya yolu
                $cleanFile = trim($file, "\"'[]");
                
                // Eğer bu dosya silinecekler listesinde varsa
                if (in_array($cleanFile, $filesToDelete)) {
                    // Fiziksel olarak sunucudan (diskten) de siliyoruz
                    if (Storage::disk('public')->exists($cleanFile)) {
                        Storage::disk('public')->delete($cleanFile);
                    }
                } else {
                    // Silinmeyecekse kalanlar listesine ekle
                    $remainingFiles[] = $file;
                }
            }

            // Kalan dosyaları tekrar kaydet (Eğer hiç evrak kalmadıysa null yap)
            $offer->raw_data_file = empty($remainingFiles) ? null : json_encode(array_values($remainingFiles));
            $offer->save();

            return response()->json([
                'status' => 'success',
                'message' => 'Seçilen evraklar başarıyla silindi.',
                'raw_files' => array_values($remainingFiles) // Kalan evrakları ekrana çizmek için geri gönder
            ]);

        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }

    public function completeOfferAnalysis($offerId)
    {
        try {
            DB::beginTransaction();

            $samples = Sample::where('offer_id', $offerId)
                ->whereIn('global_status', ['Analize Hazır', 'Analiz Aşamasında'])
                ->get();

            foreach ($samples as $sample) {
                $sample->update([
                    'status' => 'Raporlama Bekliyor', 
                    'global_status' => 'Analiz Tamamlandı'
                ]);
            }

            DB::commit();
            return response()->json(['status' => 'success', 'message' => 'Tüm analiz işlemleri tamamlandı ve Raporlama departmanına sevk edildi.']);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }

    /**
     * AJAX: Seçilen Ana Parametrenin Alt Parametrelerini Getir
     */
    public function getSubParameters($parameterId)
    {
        $subParams = \App\Models\SubParameter::where('scope_parameter_id', $parameterId)->get();
        return response()->json(['status' => 'success', 'data' => $subParams]);
    }

    /**
     * AJAX: Yeni Alt Parametre Kaydet
     */
    public function storeSubParameter(Request $request)
    {
        $request->validate([
            'scope_parameter_id' => 'required|exists:scope_parameters,id',
            'name' => 'required|string|max:255'
        ]);

        $sub = \App\Models\SubParameter::create($request->all());

        return response()->json(['status' => 'success', 'message' => 'Alt parametre eklendi.', 'data' => $sub]);
    }

    /**
     * AJAX: Alt Parametre Sil
     */
    public function destroySubParameter($id)
    {
        \App\Models\SubParameter::destroy($id);
        return response()->json(['status' => 'success', 'message' => 'Alt parametre silindi.']);
    }

    /**
     * YENİ: Alt Parametreyi Güncelle (Edit Modu)
     */
    public function updateSubParameter(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        try {
            // Model adını kendi yapına göre kontrol et (örn: ScopeParameterItem vb.)
            $sub = \App\Models\SubParameter::findOrFail($id);
            
            $sub->update([
                'code' => $request->code,
                'name' => $request->name,
                'unit' => $request->unit
            ]);

            return response()->json(['status' => 'success', 'message' => 'Alt parametre başarıyla güncellendi.']);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }
}
