@extends('layouts.admin')
@section('title', 'Görevlerim')

@section('content')
<div class="container-fluid px-4 mt-4">
    <h1 class="h3 mb-4 text-gray-800"><i class="fas fa-vial me-2 text-primary"></i>Analiz Görevlerim</h1>

    <div class="row">
        @forelse($myTasks as $task)
        <div class="col-md-6 col-xl-4 mb-4">
            <div class="card shadow h-100 border-left-{{ $task->status == 'In_Progress' ? 'warning' : 'primary' }}">
                <div class="card-header d-flex justify-content-between align-items-center bg-white">
                    <span class="badge bg-dark fs-6 font-monospace">{{ $task->sample->barcode }}</span>
                    <small class="text-muted fw-bold">Son Tarih: {{ $task->target_date ? $task->target_date->format('d.m.Y') : '-' }}</small>
                </div>
                <div class="card-body">
                    <h5 class="fw-bold text-dark mb-1">{{ $task->parameter->name }}</h5>
                    <p class="text-muted small mb-3">
                        {{-- ISO 17025 MÜŞTERİ KÖRLÜĞÜ (GİZLİLİK): SADECE TEKLİF NO GÖSTERİLİR --}}
                        <strong>Teklif No:</strong> {{ $task->sample->offer->offer_no ?? 'Bilinmiyor' }} <br>
                        <strong>Metot:</strong> {{ $task->parameter->analysis_methods ?? 'Standart Metot' }}
                    </p>

                    @if($task->status == 'Assigned')
                        <div class="alert alert-light border small mb-3">
                            <i class="fas fa-info-circle me-1"></i> Göreve başlamak için butona tıklayın.
                        </div>
                        <form action="{{ route('admin.test-management.start', $task->id) }}" method="POST">
                            @csrf <input type="hidden" name="action" value="start">
                            <button class="btn btn-primary w-100 fw-bold"><i class="fas fa-play me-1"></i> ANALİZE BAŞLA</button>
                        </form>

                    @elseif($task->status == 'In_Progress')
                        <div class="alert alert-warning small mb-3 py-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <span><i class="fas fa-spinner fa-spin me-1"></i> Analiz sürüyor...</span>
                                @if($task->parameter->limit_min || $task->parameter->limit_max)
                                    <span class="badge bg-warning text-dark">
                                        Ref: {{ $task->parameter->limit_min ?? '0' }} - {{ $task->parameter->limit_max ?? '∞' }} {{ $task->parameter->unit }}
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <form action="{{ route('admin.test-management.save-result', $task->id) }}" method="POST">
                            @csrf <input type="hidden" name="action" value="complete">
                            
                            {{-- Sonuç ve Belirsizlik Alanları --}}
                            <div class="row g-2 mb-2">
                                <div class="col-8">
                                    <label class="small fw-bold text-muted">Sonuç Değeri <span class="text-danger">*</span></label>
                                    <input type="text" name="result_value" class="form-control" placeholder="Örn: 7.45" required>
                                </div>
                                <div class="col-4">
                                    <label class="small fw-bold text-muted">Belirsizlik (+/-)</label>
                                    <input type="text" name="uncertainty" class="form-control" placeholder="0.2">
                                </div>
                            </div>

                            {{-- STOKTAN DÜŞME: MALZEME SEÇİM ALANI --}}
                            <div class="border rounded p-2 mb-3 bg-light">
                                <label class="small fw-bold text-primary d-block mb-2">
                                    <i class="fas fa-flask me-1"></i> Kullanılan Malzemeler
                                </label>
                                
                                <div id="material-area-{{ $task->id }}">
                                    {{-- Dinamik satırlar buraya gelecek --}}
                                </div>

                                <button type="button" class="btn btn-sm btn-outline-primary w-100 mt-2" onclick="addMaterialRow({{ $task->id }})">
                                    <i class="fas fa-plus me-1"></i> Malzeme Ekle
                                </button>
                            </div>

                            {{-- Ham Veri / Notlar --}}
                            <div class="mb-3">
                                <textarea name="note" class="form-control form-control-sm" rows="2" placeholder="Ham veri veya notlar (Opsiyonel)..."></textarea>
                            </div>
                            
                            <button class="btn btn-success w-100 fw-bold shadow-sm">
                                <i class="fas fa-save me-1"></i> KAYDET VE TAMAMLA
                            </button>
                        </form>
                    @endif
                </div>
            </div>
        </div>
        @empty
        <div class="col-12 text-center py-5">
            <div class="alert alert-success d-inline-block px-5 shadow-sm">
                <i class="fas fa-mug-hot fa-2x mb-2 text-success"></i><br>
                <h5 class="fw-bold">Harika!</h5>
                Şu an üzerinizde bekleyen bir analiz iş emri yok.
            </div>
        </div>
        @endforelse
    </div>
</div>
@endsection

@push('scripts')
<script>
    const allMaterials = @json($materials);
    function addMaterialRow(taskId) {
        const wrapper = document.getElementById(`material-area-${taskId}`);
        const rowId = Date.now(); 
        
        let options = '<option value="">Malzeme Seçin...</option>';
        allMaterials.forEach(m => {
            options += `<option value="${m.id}">${m.name} (${m.sku})</option>`;
        });

        const html = `
            <div class="row g-1 mb-2 align-items-end" id="row-${rowId}">
                <div class="col-7">
                    <select name="used_materials[${rowId}][id]" class="form-select form-select-sm" required>
                        ${options}
                    </select>
                </div>
                <div class="col-3">
                    <input type="number" name="used_materials[${rowId}][quantity]" class="form-control form-control-sm" step="0.01" placeholder="Miktar" required>
                </div>
                <div class="col-2 text-end">
                    <button type="button" class="btn btn-sm btn-link text-danger" onclick="document.getElementById('row-${rowId}').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `;
        wrapper.insertAdjacentHTML('beforeend', html);
    }
</script>
@endpush