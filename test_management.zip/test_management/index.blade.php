@extends('layouts.admin')
@section('title', 'Analiz ve Sonuç Girişi')

@push('css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    {{-- YENİ: Intro.js CSS --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intro.js/7.2.0/introjs.min.css">
    
    <style>
        .result-input { border: 1px solid #ced4da; font-weight: bold; color: #495057; transition: all 0.3s ease; }
        .result-input:focus { border-color: #0d6efd; box-shadow: 0 0 0 0.2rem rgba(13,110,253,.25); }
        .bg-success-subtle { background-color: #d1e7dd !important; }
        .bg-danger-subtle { background-color: #f8d7da !important; }
        .metot-link { text-decoration: none; font-weight: bold; color: #0dcaf0; transition: color 0.2s; }
        .metot-link:hover { color: #055160; text-decoration: underline; }
        .select2-container .select2-selection--single { min-height: 38px !important; }
        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__arrow { top: 50%; transform: translateY(-50%); }
        
        .modal-table-sm { table-layout: fixed !important; width: 100% !important; }
        .modal-table-sm th, .modal-table-sm td { padding: 0.5rem; font-size: 0.85rem; vertical-align: middle; overflow: hidden; text-overflow: ellipsis; }
        .summary-card { cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; opacity: 0.8; }
        .summary-card:hover { transform: translateY(-3px); box-shadow: 0 6px 12px rgba(0,0,0,0.1) !important; opacity: 1; }
        .summary-card.active-filter { opacity: 1; transform: scale(1.03); box-shadow: 0 4px 15px rgba(0,0,0,0.15) !important; border: 2px solid #333 !important; }
        .dt-search-large label { margin-bottom: 0; font-weight: bold; color: #495057; }
        .dt-search-large input { width: 300px !important; border-radius: 20px; border: 2px solid #0d6efd; padding: 0.3rem 1rem; outline: none; margin-left: 10px; }
        .dt-search-large input:focus { box-shadow: 0 0 5px rgba(13,110,253,0.5); }
        .progress-thin { height: 6px; border-radius: 3px; }

        .manual-search-container { background: #f8f9fa; padding: 15px; border-bottom: 1px solid #dee2e6; display: flex; justify-content: space-between; align-items: center; }
    </style>
@endpush

@php
    $statNotStarted = 0;
    $statInProgress = 0;
    $statCompleted = 0;

    foreach($offersForAnalysis as $offer) {
        $totalParams = 0;
        $enteredParams = 0;
        $validSamplesCount = 0;

        foreach($offer->samples as $sample) {
            if (!in_array($sample->global_status, [
                'Analize Hazır',
                'Analiz Aşamasında',
                'Analiz Tamamlandı'
            ])) {
                continue;
            }

            $validSamplesCount++;
            $totalParams++;

            // 1) Analiz Görevleri ekranında kaydedilmiş sonuç kontrolü.
            $hasAnalysisResult = false;

            foreach($sample->workOrders as $wo) {
                if ($wo->result && !empty($wo->result->result_value)) {
                    $hasAnalysisResult = true;
                    break;
                }
            }

            // 2) Saha Filtre Ata ekranından kaydedilmiş field_data kontrolü.
            // Saha sonuçları henüz AnalysisResult tablosuna aktarılmadan önce
            // samples.field_data.field_equipment altında tutulur.
            $hasFieldEquipmentResult = false;
            $fieldData = $sample->field_data;

            if (is_string($fieldData)) {
                $fieldData = json_decode($fieldData, true) ?: [];
            }

            if (is_array($fieldData)) {
                $fieldEquipment = $fieldData['field_equipment'] ?? [];

                if (is_array($fieldEquipment) && !empty($fieldEquipment)) {
                    foreach($fieldEquipment as $fieldEquipmentValue) {
                        if (is_array($fieldEquipmentValue)) {
                            $nonEmptyValues = collect($fieldEquipmentValue)
                                ->filter(function($value, $key) {
                                    // Sadece gerçek ölçüm/filtre alanlarını değerlendir.
                                    // ID gibi teknik alanlar tek başına sonuç sayılmaz.
                                    if (in_array($key, ['filter_stock_id'], true)) {
                                        return false;
                                    }

                                    return $value !== null
                                        && trim((string) $value) !== '';
                                });

                            if ($nonEmptyValues->isNotEmpty()) {
                                $hasFieldEquipmentResult = true;
                                break;
                            }
                        } elseif ($fieldEquipmentValue !== null
                            && trim((string) $fieldEquipmentValue) !== '') {
                            $hasFieldEquipmentResult = true;
                            break;
                        }
                    }
                }
            }

            if ($hasAnalysisResult || $hasFieldEquipmentResult) {
                $enteredParams++;
            }
        }

        $offer->valid_samples_count = $validSamplesCount;
        $offer->total_params = $totalParams;
        $offer->entered_params = $enteredParams;
        $offer->progress_percent = $totalParams > 0
            ? round(($enteredParams / $totalParams) * 100)
            : 0;

        if ($totalParams == 0 || $enteredParams == 0) {
            $offer->calc_status = 'Başlamadı';
            $statNotStarted++;
        } elseif ($enteredParams < $totalParams) {
            $offer->calc_status = 'Devam Ediyor';
            $statInProgress++;
        } else {
            $offer->calc_status = 'Tamamlandı';
            $statCompleted++;
        }
    }
@endphp

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-microscope me-2 text-primary"></i>Analiz Sonuç Girişi</h1>
        <div>
            {{-- YENİ: SAYFA REHBERİ BUTONU --}}
            <button class="btn btn-info text-white shadow-sm fw-bold me-2" id="btn-tour">
                <i class="fas fa-info-circle me-1"></i> Sayfa Rehberi
            </button>
            <button class="btn btn-warning shadow-sm fw-bold" id="btn-sub-param" data-bs-toggle="modal" data-bs-target="#subParameterModal">
                <i class="fas fa-sitemap me-1"></i> Alt Parametre Yönetimi
            </button>
        </div>
    </div>

    {{-- DASHBOARD KARTLARI --}}
    <div class="row mb-4" id="dashboard-cards">
        <div class="col-md-3">
            <div class="card shadow-sm border-0 border-start border-4 border-primary summary-card active-filter main-filter-card" data-status="all">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-xs fw-bold text-primary text-uppercase mb-1">Tüm Teklifler</div>
                        <div class="h4 mb-0 fw-bold text-gray-800">{{ $offersForAnalysis->count() }}</div>
                    </div>
                    <i class="fas fa-list fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-0 border-start border-4 border-secondary summary-card main-filter-card" data-status="Başlamadı">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-xs fw-bold text-secondary text-uppercase mb-1">Hiç Başlamayan</div>
                        <div class="h4 mb-0 fw-bold text-gray-800">{{ $statNotStarted }}</div>
                    </div>
                    <i class="fas fa-stop-circle fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-0 border-start border-4 border-warning summary-card main-filter-card" data-status="Devam Ediyor">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-xs fw-bold text-warning text-uppercase mb-1">Devam Eden</div>
                        <div class="h4 mb-0 fw-bold text-gray-800">{{ $statInProgress }}</div>
                    </div>
                    <i class="fas fa-spinner fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-0 border-start border-4 border-success summary-card main-filter-card" data-status="Tamamlandı">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-xs fw-bold text-success text-uppercase mb-1">Biten (İnceleme Bekliyor)</div>
                        <div class="h4 mb-0 fw-bold text-gray-800">{{ $statCompleted }}</div>
                    </div>
                    <i class="fas fa-check-double fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
    </div>

    {{-- AKTİF TEKLİFLER TABLOSU --}}
    <div class="card shadow mb-4 border-top-primary">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="mainOffersTable" width="100%">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3">Teklif No</th>
                            <th>Müşteri Bilgisi</th>
                            <th class="text-center">Numune Sayısı</th>
                            <th>Analiz İlerlemesi</th>
                            <th style="display:none;">Durum</th> 
                            <th class="text-center pe-3" width="160">Aksiyon</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($offersForAnalysis as $offer)
                        <tr>
                            <td class="fw-bold text-primary fs-5 ps-3">{{ $offer->offer_no }}</td>
                            <td class="fw-bold text-danger"><i class="fas fa-user-secret me-1"></i> Müşteri Gizlidir</td>
                            <td class="text-center"><span class="badge bg-dark fs-6">{{ $offer->valid_samples_count }} Numune</span></td>
                            <td>
                                @php
                                    $pColor = 'secondary';
                                    if($offer->calc_status == 'Devam Ediyor') $pColor = 'warning';
                                    if($offer->calc_status == 'Tamamlandı') $pColor = 'success';
                                @endphp
                                <div class="d-flex justify-content-between small fw-bold text-muted mb-1">
                                    <span>%{{ $offer->progress_percent }} Tamamlandı</span>
                                    <span>{{ $offer->entered_params }} / {{ $offer->total_params }} Parametre</span>
                                </div>
                                <div class="progress progress-thin">
                                    <div class="progress-bar bg-{{ $pColor }}" style="width: {{ $offer->progress_percent }}%"></div>
                                </div>
                            </td>
                            <td style="display:none;">{{ $offer->calc_status }}</td>
                            <td class="text-center pe-3">
                                @if($offer->calc_status == 'Başlamadı')
                                    <button class="btn btn-sm btn-outline-primary w-100 fw-bold shadow-sm btn-open-analysis" data-id="{{ $offer->id }}" data-no="{{ $offer->offer_no }}">
                                        <i class="fas fa-play me-1"></i> Sonuç Girmeye Başla
                                    </button>
                                @elseif($offer->calc_status == 'Devam Ediyor')
                                    <button class="btn btn-sm btn-warning text-dark w-100 fw-bold shadow-sm btn-open-analysis" data-id="{{ $offer->id }}" data-no="{{ $offer->offer_no }}">
                                        <i class="fas fa-spinner fa-spin me-1"></i> Devam Et
                                    </button>
                                @else
                                    <button class="btn btn-sm btn-success w-100 fw-bold shadow-sm btn-open-analysis" data-id="{{ $offer->id }}" data-no="{{ $offer->offer_no }}">
                                        <i class="fas fa-check-double me-1"></i> İncele & Bitir
                                    </button>
                                @endif
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@include('admin.test_management.modals._analysis')
@include('admin.test_management.modals._sub_results')
@include('admin.test_management.modals._sub_parameters')
@include('admin.test_management.modals._voc_merge')
@include('admin.test_management.modals._toz_modal')
@include('admin.test_management.modals._pm10_modal')

@endsection

@push('scripts')
    @include('admin.test_management.scripts._index_scripts')
@endpush