@extends('layouts.admin')
@section('title', 'İş Emri Dağıtımı')

@section('content')
<div class="container-fluid px-4 mt-4">
    <h1 class="h3 mb-4 text-gray-800"><i class="fas fa-tasks me-2 text-primary"></i>İş Emri Dağıtımı (Yönetici)</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-light">
            <h6 class="m-0 font-weight-bold text-primary">Analiz Bekleyen Numuneler</h6>
        </div>
        <div class="card-body">
            <div class="accordion" id="samplesAccordion">
                @forelse($pendingSamples as $sample)
                <div class="accordion-item border mb-3 shadow-sm">
                    <h2 class="accordion-header" id="heading{{ $sample->id }}">
                        <button class="accordion-button collapsed bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#collapse{{ $sample->id }}">
                            <div class="d-flex w-100 justify-content-between align-items-center pe-3">
                                <div>
                                    <span class="badge bg-primary me-2">{{ $sample->barcode }}</span>
                                    <span class="fw-bold text-dark">{{ $sample->offer->customer->name ?? 'Müşteri Yok' }}</span>
                                </div>
                                <div class="text-muted small">
                                    <i class="fas fa-flask me-1"></i> {{ $sample->offer->offerItems->count() }} Analiz
                                    <span class="mx-2">|</span>
                                    <i class="far fa-clock me-1"></i> Kabul: {{ $sample->accepted_at ? $sample->accepted_at->format('d.m.Y H:i') : '-' }}
                                </div>
                            </div>
                        </button>
                    </h2>
                    <div id="collapse{{ $sample->id }}" class="accordion-collapse collapse" data-bs-parent="#samplesAccordion">
                        <div class="accordion-body bg-white">
                            <form action="{{ route('admin.test-management.assign', $sample->id) }}" method="POST">
                                @csrf
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label class="form-label small fw-bold">Hedef Tamamlanma Tarihi (Tüm Numune)</label>
                                        <input type="date" name="target_date" class="form-control form-control-sm" value="{{ now()->addDays(3)->format('Y-m-d') }}">
                                    </div>
                                    <div class="col-md-9 text-end align-self-end">
                                        <button type="submit" class="btn btn-success btn-sm fw-bold">
                                            <i class="fas fa-check-circle me-1"></i> SEÇİLİ ANALİZLERİ ATA
                                        </button>
                                    </div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered align-middle">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Analiz Parametresi</th>
                                                <th>Metot (Varsayılan)</th>
                                                <th width="300">Sorumlu Analist</th>
                                                <th width="100" class="text-center">Durum</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($sample->offer->offerItems as $item)
                                                @php
                                                    // Daha önce atama yapılmış mı kontrol et
                                                    $existingOrder = $sample->workOrders->where('scope_parameter_id', $item->scope_parameter_id)->first();
                                                @endphp
                                                <tr>
                                                    <td>
                                                        <span class="fw-bold">{{ $item->parameter->name }}</span>
                                                        @if($item->parameter->is_accredited) <i class="fas fa-certificate text-success ms-1" title="Akredite"></i> @endif
                                                    </td>
                                                    <td class="small text-muted">{{ $item->parameter->analysis_methods ?? '-' }}</td>
                                                    <td>
                                                        @if($existingOrder)
                                                            <div class="d-flex align-items-center text-success">
                                                                <i class="fas fa-user-check me-2"></i> 
                                                                {{ $existingOrder->analyst->name ?? 'Bilinmiyor' }}
                                                            </div>
                                                        @else
                                                            <select name="assignments[{{ $item->scope_parameter_id }}]" class="form-select form-select-sm border-primary">
                                                                <option value="">-- Analist Seçiniz --</option>
                                                                @foreach($analysts as $analyst)
                                                                    <option value="{{ $analyst->id }}">{{ $analyst->name }}</option>
                                                                @endforeach
                                                            </select>
                                                        @endif
                                                    </td>
                                                    <td class="text-center">
                                                        @if($existingOrder)
                                                            <span class="badge bg-info">{{ $existingOrder->status }}</span>
                                                        @else
                                                            <span class="badge bg-secondary">Bekliyor</span>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @empty
                <div class="alert alert-info text-center py-5">
                    <i class="fas fa-glass-cheers fa-3x mb-3 text-gray-300"></i><br>
                    Şu an analiz bekleyen numune bulunmamaktadır. Harika!
                </div>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection