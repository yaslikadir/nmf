<div class="modal fade" id="tozResultModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content shadow-lg border-0">
            <div class="modal-header bg-warning text-dark py-3">
                <h5 class="modal-title fw-bold"><i class="fas fa-balance-scale me-2"></i> Toz (Partikül Madde / EPA 17) Tartım İstasyonu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 bg-light">
                <div class="alert alert-info shadow-sm border-info d-flex align-items-center mb-4">
                    <i class="fas fa-info-circle fa-2x me-3"></i>
                    <div>Tartım verilerini <strong>Gram (g)</strong> cinsinden giriniz. Sistem otomatik olarak miligrama (mg) çevirecektir. <br><small>Not: Saha ve hacim şartları "Raporlama" aşamasında girilmektedir.</small></div>
                </div>
                
                <form id="tozResultForm">
                    <input type="hidden" id="currentTozSampleId">
                    <input type="hidden" id="currentTozParamId">
                    
                    <div class="table-responsive shadow-sm rounded">
                        <table class="table table-bordered table-hover align-middle text-center mb-0 bg-white" style="font-size: 0.85rem;">
                            <thead class="table-dark">
                                <tr>
                                    <th rowspan="2" class="align-middle" width="16%">Ölçüm / Barkod</th>
                                    <th colspan="3" class="bg-primary border-primary text-white" width="36%">Filtre Tartımı (g)</th>
                                    <th colspan="3" class="bg-info border-info text-dark" width="36%">Geri Yıkama Tartımı (g)</th>
                                    <th rowspan="2" class="align-middle bg-success border-success text-white" width="12%">Toplam Toz (mg)</th>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white border-primary bg-opacity-75">İlk</th>
                                    <th class="bg-primary text-white border-primary bg-opacity-75">Son</th>
                                    <th class="bg-primary text-white border-primary bg-opacity-75">Fark(mg)</th>
                                    
                                    <th class="bg-info text-dark border-info bg-opacity-75">İlk</th>
                                    <th class="bg-info text-dark border-info bg-opacity-75">Son</th>
                                    <th class="bg-info text-dark border-info bg-opacity-75">Fark(mg)</th>
                                </tr>
                            </thead>
                            <tbody id="tozTbody">
                                <!-- JS tarafından dinamik doldurulacak -->
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="mt-3 text-end" id="tozAverageResultArea" style="display:none;">
                        <h5 class="fw-bold text-dark mb-0 bg-white d-inline-block p-3 rounded shadow-sm border border-secondary">
                            Ortalama Toz Kütlesi: <span class="text-success" id="tozAverageValue">0.0000</span> <small class="text-muted fs-6">mg</small>
                        </h5>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-white">
                <button type="button" class="btn btn-secondary fw-bold px-4" data-bs-dismiss="modal">İPTAL</button>
                <button type="button" class="btn btn-success fw-bold px-4 shadow-sm" id="btnSaveTozResultModal"><i class="fas fa-save me-1"></i> KAYDET VE BİRLEŞTİR</button>
            </div>
        </div>
    </div>
</div>