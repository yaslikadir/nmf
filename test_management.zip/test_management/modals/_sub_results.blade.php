{{-- ALT PARAMETRE SONUÇ GİRİŞ MODALI (DİNAMİK THEAD) --}}
<div class="modal fade" id="subResultModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl"> 
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-info text-white py-3">
                <h5 class="modal-title fw-bold text-dark"><i class="fas fa-list-ol me-2"></i> Alt Parametre (Element) Sonuçları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light p-0">
                
                {{-- YENİ: HIZLI ARAMA ÇUBUĞU --}}
                <div class="p-3 border-bottom bg-white d-flex justify-content-between align-items-center shadow-sm">
                    <div class="input-group input-group-sm" style="width: 350px;">
                        <span class="input-group-text bg-light text-muted border-end-0"><i class="fas fa-search"></i></span>
                        <input type="text" id="subParamSearchInput" class="form-control border-start-0 fw-bold text-primary" placeholder="Parametre ara (En az 3 harf)..." autocomplete="off">
                    </div>
                    <small class="text-muted fst-italic" id="subParamSearchInfo">Tüm parametreler listeleniyor.</small>
                </div>

                <div class="table-responsive">
                    <input type="hidden" id="currentSubResultSampleId">
                    <input type="hidden" id="currentSubResultParamId">
                    
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light" id="subResultThead">
                            <tr>
                                <th>Parametre (Element)</th>
                                <th width="160">Sonuç Değeri</th>
                                <th width="130">Belirsizlik (±)</th>
                                <th width="200">Açıklama / Not</th>
                            </tr>
                        </thead>
                        <tbody id="subResultTbody">
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer bg-white py-2 border-top shadow-sm">
                <button type="button" class="btn btn-secondary btn-sm fw-bold px-4" data-bs-dismiss="modal">İptal</button>
                <button type="button" class="btn btn-info text-dark btn-sm fw-bold px-4 shadow-sm" id="btnSaveSubResultModal"><i class="fas fa-check me-1"></i> Değerleri Uygula</button>
            </div>
        </div>
    </div>
</div>