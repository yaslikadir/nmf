{{-- VOC EŞLEŞTİRME (MAPPING) MODALI --}}
<div class="modal fade" id="vocMergeModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-dark text-white py-3">
                <h5 class="modal-title fw-bold"><i class="fas fa-link me-2 text-warning"></i> VOC Numune Birleştirme Sihirbazı</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light p-4">
                <div class="alert alert-info text-dark shadow-sm border-info">
                    <i class="fas fa-info-circle me-1"></i> <strong>Bilgi:</strong> Seçtiğiniz barkodları laboratuvardaki periyotlarına göre eşleştirin. 
                    <br><small>1. Ölçüm Ana Barkod kabul edilecek ve hesaplamalar onun içine JSON olarak yazılacaktır. Diğer barkodlar otomatik olarak "Tamamlandı" statüsüne geçecektir.</small>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="fw-bold text-success">1. Ölçüm (M1) - <small class="text-muted">Ana Barkod</small> <span class="text-danger">*</span></label>
                        <select class="form-select border-success fw-bold merge-select" id="merge_m1"></select>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold text-success">2. Ölçüm (M2) <span class="text-danger">*</span></label>
                        <select class="form-select border-success fw-bold merge-select" id="merge_m2"></select>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold text-success">3. Ölçüm (M3) <span class="text-danger">*</span></label>
                        <select class="form-select border-success fw-bold merge-select" id="merge_m3"></select>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold text-danger">Şahit (Tanık) Numune <small class="text-muted">(İsteğe Bağlı)</small></label>
                        <select class="form-select border-danger fw-bold merge-select" id="merge_blank">
                            <option value="">-- Şahit Numune Yok --</option>
                        </select>
                    </div>
                </div>
                <div id="mergeWarningBox" class="text-danger fw-bold mt-3 small text-center" style="display:none;"></div>
            </div>
            <div class="modal-footer bg-white py-3">
                <button type="button" class="btn btn-secondary fw-bold px-4" data-bs-dismiss="modal">İptal Et</button>
                <button type="button" class="btn btn-warning text-dark fw-bold px-4 shadow-sm" id="btnContinueVocMerge">
                    Devam Et ve Değerleri Gir <i class="fas fa-arrow-right ms-1"></i>
                </button>
            </div>
        </div>
    </div>
</div>