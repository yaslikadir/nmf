{{-- ALT PARAMETRE YÖNETİM MODALI --}}
<div class="modal fade" id="subParameterModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-warning text-dark py-3">
                <h5 class="modal-title fw-bold"><i class="fas fa-sitemap me-2"></i> Dinamik Alt Parametre Yönetimi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light p-4">
                <div class="mb-4 p-3 bg-white border rounded shadow-sm">
                    <label class="fw-bold mb-2">Ana Parametre Seçin <span class="text-danger">*</span></label>
                    <select class="form-select select2-subparam" id="mainParamSelect" style="width: 100%;">
                        <option value="">-- Arama Yaparak Ana Parametre Seçin --</option>
                    </select>
                </div>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 fw-bold">Alt Parametre Listesi</h6>
                        <button class="btn btn-primary btn-sm fw-bold" id="btnToggleAddForm" disabled>
                            <i class="fas fa-plus me-1"></i> Yeni Ekle
                        </button>
                    </div>
                    
                    <div class="card-body bg-light border-bottom" id="subParamAddSection" style="display: none;">
                        <form id="addSubParamForm">
                            <input type="hidden" id="edit_sub_param_id" value="">
                            <div class="row g-2 align-items-end">
                                <div class="col-md-2">
                                    <label class="small fw-bold text-muted">Kısa Ad (Örn: Cd)</label>
                                    <input type="text" id="sub_code" class="form-control form-control-sm" placeholder="Opsiyonel">
                                </div>
                                <div class="col-md-5">
                                    <label class="small fw-bold text-muted">Uzun Ad <span class="text-danger">*</span></label>
                                    <input type="text" id="sub_name" class="form-control form-control-sm" required>
                                </div>
                                <div class="col-md-2">
                                    <label class="small fw-bold text-muted">Birim</label>
                                    <input type="text" id="sub_unit" class="form-control form-control-sm" placeholder="mg/L vb.">
                                </div>
                                <div class="col-md-3 text-end d-flex gap-1">
                                    <button type="button" class="btn btn-sm btn-secondary w-100 fw-bold shadow-sm" id="btnCancelEdit" style="display:none;">İPTAL</button>
                                    <button type="submit" class="btn btn-sm btn-success w-100 fw-bold shadow-sm" id="btnSubmitSubParam">
                                        <i class="fas fa-save"></i> KAYDET
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-3">Uzun Ad / İçerik</th>
                                        <th>Kısa Ad</th>
                                        <th class="text-center">Birim</th>
                                        <th class="text-center pe-3" width="80">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody id="subParamsTbody">
                                    <tr><td colspan="4" class="text-center py-4 text-muted">Lütfen yukarıdan ana parametre seçin.</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light py-2">
                <button type="button" class="btn btn-secondary btn-sm fw-bold px-4" data-bs-dismiss="modal">KAPAT</button>
            </div>
        </div>
    </div>
</div>