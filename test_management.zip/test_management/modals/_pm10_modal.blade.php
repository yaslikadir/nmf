{{-- ÇEVRE HAVASI PM 10 (SADECE FİLTRE) VERİ GİRİŞ MODALI --}}
<div class="modal fade" id="pm10ResultModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered"> 
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-dark text-white py-3">
                <h5 class="modal-title fw-bold"><i class="fas fa-wind text-info me-2"></i> Çevre Havası PM 10 Tartım Girişi</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light p-4">
                <input type="hidden" id="currentPm10SampleId">
                <input type="hidden" id="currentPm10ParamId">
                
                <div class="alert alert-info text-dark border-info shadow-sm small fw-bold">
                    <i class="fas fa-info-circle me-1"></i> Tartım verilerini <b>Gram (g)</b> cinsinden giriniz. Sistem otomatik olarak miligrama (mg) çevirecektir.
                </div>

                <div class="card shadow-sm border-0 border-start border-4 border-info">
                    <div class="card-header bg-white py-2 fw-bold text-info"><i class="fas fa-filter me-1"></i> Filtre Tartımı</div>
                    <div class="card-body py-3">
                        <div class="input-group input-group-sm mb-3">
                            <span class="input-group-text bg-light fw-bold" style="width: 120px;">İlk Tartım (Dara)</span>
                            <input type="number" step="any" id="pm10_filtre_ilk" class="form-control pm10-calc-input" placeholder="0.0000">
                            <span class="input-group-text bg-light text-muted">g</span>
                        </div>
                        <div class="input-group input-group-sm mb-3">
                            <span class="input-group-text bg-light fw-bold" style="width: 120px;">Son Tartım (Brüt)</span>
                            <input type="number" step="any" id="pm10_filtre_son" class="form-control pm10-calc-input" placeholder="0.0000">
                            <span class="input-group-text bg-light text-muted">g</span>
                        </div>
                        
                        <hr class="text-muted">

                        <div class="input-group input-group-sm border border-success rounded shadow-sm">
                            <span class="input-group-text bg-success text-white fw-bold" style="width: 120px;">Net Toz (Fark)</span>
                            <input type="text" id="pm10_filtre_fark" class="form-control bg-white fw-bold text-success fs-6" readonly tabindex="-1">
                            <span class="input-group-text bg-success text-white fw-bold">mg</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light py-3 border-top shadow-sm">
                <button type="button" class="btn btn-secondary fw-bold px-4" data-bs-dismiss="modal">Kapat</button>
                <button type="button" class="btn btn-info text-dark fw-bold px-5 shadow-sm" id="btnSavePm10ResultModal">
                    <i class="fas fa-save me-1"></i> Tartımı Kaydet
                </button>
            </div>
        </div>
    </div>
</div>