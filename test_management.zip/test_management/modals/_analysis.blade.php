{{-- DİNAMİK SONUÇ GİRİŞ MODALI --}}
<div class="modal fade" id="analysisModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content bg-light">
            <div class="modal-header bg-primary text-white py-3">
                <h5 class="modal-title fw-bold"><i class="fas fa-vials me-2"></i> Analiz Veri Girişi - Teklif: <span id="modalOfferNo" class="text-warning"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            
            <div class="modal-body p-0" id="modalAnalysisBody">
                <div class="text-center py-5"><i class="fas fa-spinner fa-spin fa-3x text-primary"></i><h5 class="mt-3">Yükleniyor...</h5></div>
            </div>

            <div class="modal-footer bg-white border-top py-3 d-flex justify-content-between align-items-center shadow-lg">
                <div>
                    <button type="button" class="btn btn-primary fw-bold px-5 py-2 shadow-sm" id="btnSaveBulkResults">
                        <i class="fas fa-save me-2"></i> GİRİLEN TÜM SONUÇLARI KAYDET
                    </button>
                    <span class="text-muted small ms-3 fw-bold"><i class="fas fa-magic text-warning me-1"></i> Kaydettikten sonra sistem otomatik referans (Min/Max) kıyaslaması yapıp ekranı günceller.</span>
                </div>
                <div>
                    <button type="button" class="btn btn-secondary fw-bold px-4 me-2" data-bs-dismiss="modal">KAPAT / SONRA DEVAM ET</button>
                    <button type="button" class="btn btn-success fw-bold px-5 shadow" id="btnCompleteOffer">
                        <i class="fas fa-check-double me-2"></i> TÜMÜ BİTTİ (RAPORLAMAYA GÖNDER)
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>