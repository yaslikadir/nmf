@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
{{-- YENİ: Intro.js Scripti (Sanal Tur İçin) --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/intro.js/7.2.0/intro.min.js"></script>

<script>
const SINGLE_BARCODE_BUILD = '2026-09-09-auto-fill-field-data'; 
console.info('[Analiz] Aktif JavaScript sürümü:', SINGLE_BARCODE_BUILD);

$(document).ready(function() {
    toastr.options = { "closeButton": true, "progressBar": true, "timeOut": "5000" };

    $('body').tooltip({
        selector: '[data-bs-toggle="tooltip"]',
        trigger: 'hover'
    });

    let mainTable = $('#mainOffersTable').DataTable({ 
        "language": { "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json" }, 
        "order": [],
        "dom": '<"d-flex justify-content-between p-3"<"h6 text-primary fw-bold"><"dt-search-large"f>>rt<"bottom p-3"ip><"clear">'
    });
    
    $('.dt-search-large input').attr('placeholder', 'Teklif No ile Ara...');

    $('.main-filter-card').on('click', function() {
        $('.main-filter-card').removeClass('active-filter border-dark');
        $(this).addClass('active-filter border-dark');
        
        let status = $(this).data('status');
        if (status === 'all') {
            mainTable.column(4).search('').draw();
        } else {
            mainTable.column(4).search(status).draw();
        }
    });

    let currentOfferId = null;
    let globalResData = null;
    let processedAnalysisData = [];
    let rowsPerPage_opt = 50; 
    let currentPage_opt = 1; 
    let uniqueParams = new Set();

    $(document).on('click', '.btn-open-analysis', function(e) {
        e.preventDefault();
        currentOfferId = $(this).data('id');
        $('#modalOfferNo').text($(this).data('no'));
        
        let modal = new bootstrap.Modal(document.getElementById('analysisModal'));
        modal.show();

        fetchAndRenderData();
    });

    function fetchAndRenderData() {
        $('#modalAnalysisBody').html('<div class="text-center py-5"><i class="fas fa-spinner fa-spin fa-3x text-primary"></i><h5 class="mt-3">Numuneler ve Parametreler Yükleniyor...</h5></div>');
        $.ajax({
            url: "/admin/test-management/get-offer-details/" + currentOfferId,
            type: "GET",
            success: function(res) {
                if (res.status === 'success') {
                    globalResData = res;
                    setTimeout(() => {
                        processRawData(res);
                        renderAnalysisForm(res);
                    }, 50);
                } else {
                    $('#modalAnalysisBody').html(`<div class="alert alert-danger">${res.message}</div>`);
                }
            },
            error: function() { 
                $('#modalAnalysisBody').html('<div class="alert alert-danger">Veriler yüklenirken hata oluştu!</div>'); 
            }
        });
    }

    function formatChem(text) {
        if (!text) return '';
        return text.replace(/_([0-9₀-₉]+|[a-zA-Z]+)/g, function(match, p1) {
            let normalNum = p1.replace(/[₀-₉]/g, c => "₀₁₂₃₄₅₆₇₈₉".indexOf(c));
            return '<sub>' + normalNum + '</sub>';
        });
    }

    function formatSubResultSummary(val) {
        if(!val) return '';
        try {
            let arr = JSON.parse(val);
            if(Array.isArray(arr)) {
                return arr.filter(x => x.value).map(x => {
                    let uncertHtml = x.uncertainty ? ` <small class="text-muted">(±${x.uncertainty})</small>` : '';
                    return `${formatChem(x.code || x.name)}: <span class="text-primary">${x.value}</span>${uncertHtml}`;
                }).join(' | ');
            }
        } catch(e) { return val; }
        return '';
    }

    function dedupeById(list) {
        if (!Array.isArray(list)) return [];
        let seen = new Set();
        return list.filter(function(s) {
            let key = s.id != null ? s.id : s.barcode;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    function dedupeOfferItems(list) {
        if (!Array.isArray(list)) return [];
        let seen = new Set();
        return list.filter(function(item) {
            if (!item.parameter) return true;
            let key = item.parameter.id;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    function normalizeAnalysisText(value) {
        return String(value || '')
            .toLocaleLowerCase('tr-TR')
            .replace(/İ/g, 'i')
            .replace(/ı/g, 'i')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function analysisMethodMatches(fullText, selectedText) {
        const full = normalizeAnalysisText(fullText);
        const selected = normalizeAnalysisText(selectedText);

        if (!full || !selected) return false;

        const methodRegex = /(epa\s*(?:metot\s*)?\d+[a-z]*|ts\s*iso\s*[\d-]+|ts\s*en\s*[\d-]+|metot\s*\d+|sm\s*\d+[a-z]*|cen\/ts\s*[\d-]+)/gi;
        const fullMethods = full.match(methodRegex) || [];
        const selectedMethods = selected.match(methodRegex) || [];

        if (selectedMethods.length > 0) {
            return selectedMethods.some(selectedMethod =>
                fullMethods.some(fullMethod =>
                    normalizeAnalysisText(fullMethod) === normalizeAnalysisText(selectedMethod)
                )
            );
        }

        return full.includes(selected);
    }

    function parseSampleFieldData(sample) {
        let fieldData = sample && sample.field_data ? sample.field_data : {};

        if (typeof fieldData === 'string') {
            try {
                fieldData = JSON.parse(fieldData);
            } catch (e) {
                fieldData = {};
            }
        }

        if (!fieldData || typeof fieldData !== 'object') fieldData = {};

        const fieldEquipment = fieldData.field_equipment;

        return {
            raw: fieldData,
            fieldEquipment: fieldEquipment && typeof fieldEquipment === 'object'
                ? fieldEquipment
                : {}
        };
    }

    function findOfferItemForSample(sample, offerItems) {
        const contentStr = sample.analysis_summary || sample.description || '';
        const normalizedContent = normalizeAnalysisText(contentStr);
        const fieldData = parseSampleFieldData(sample);
        const fieldEquipment = fieldData.fieldEquipment;
        const fieldParameterIds = Object.keys(fieldEquipment).map(id => String(id));

        // En güvenilir eşleştirme: saha kaydındaki ScopeParameter ID'si.
        let item = offerItems.find(function (offerItem) {
            return offerItem && offerItem.parameter &&
                fieldParameterIds.includes(String(offerItem.parameter.id));
        });
        if (item) return item;

        // Eski kayıtlar için parametre adına göre eşleştirme.
        item = offerItems.find(function (offerItem) {
            return offerItem && offerItem.parameter &&
                normalizeAnalysisText(offerItem.parameter.name) === normalizedContent;
        });
        if (item) return item;

        // EPA 5 gibi analysis_methods içindeki metotlara göre eşleştirme.
        return offerItems.find(function (offerItem) {
            if (!offerItem || !offerItem.parameter) return false;

            const parameter = offerItem.parameter;
            const fullText = [
                parameter.name || '',
                parameter.analysis_methods || ''
            ].join(' ');

            return analysisMethodMatches(fullText, contentStr);
        }) || null;
    }

    function processRawData(res) {
        let tempData = [];
        uniqueParams = new Set();
        let samples = dedupeById(res.samples);
        let offerItems = dedupeOfferItems(res.offer.items);
        
        if (res.extra_parameters) {
            res.extra_parameters.forEach(function(param) {
                let exists = offerItems.find(i => i.parameter && i.parameter.id === param.id);
                if (!exists) { 
                    offerItems.push({ id: 'ext_' + param.id, parameter: param }); 
                }
            });
        }

        samples.forEach(sample => {
            const contentStr = sample.analysis_summary || sample.description || '';
            const item = findOfferItemForSample(sample, offerItems);
            
            if (item && item.parameter) {
                uniqueParams.add(item.parameter.name);
                
                let existingOrder = sample.work_orders ? sample.work_orders.find(wo => wo.scope_parameter_id == item.parameter.id) : null;
                let existingResult = existingOrder && existingOrder.result ? existingOrder.result : null;
                
                let rValue = (existingResult && existingResult.result_value !== null) ? String(existingResult.result_value) : '';
                let rUncert = (existingResult && existingResult.uncertainty !== null) ? String(existingResult.uncertainty) : '';
                let rNote = (existingResult && existingResult.raw_data !== null) ? String(existingResult.raw_data) : '';
                
                let scopeName = item.parameter.scope_type ? item.parameter.scope_type.name : 'Kapsam Tanımsız';
                let paramName = item.parameter.name;
                let paramNameLower = paramName.toLowerCase().replace(/"/g, ''); 
                let scopeNameLower = scopeName.toLowerCase();
                
                let cleanParam = paramNameLower.replace(/[\s\-]/g, '');
                
                let isVolumeCalculated = cleanParam.includes('ağırmetal') || cleanParam.includes('klorürörneklemesi');

                let isToz = scopeNameLower.includes('emisyon') && (
                    cleanParam.includes('toz') || cleanParam.includes('partikül') || 
                    cleanParam.includes('epa17') || cleanParam.includes('epa5') || cleanParam.includes('epa29') || 
                    cleanParam.includes('9096') || cleanParam.includes('13284')
                );
                
                let isPm10 = cleanParam.includes('pm10') || 
                             cleanParam.includes('çökentoz') || 
                             cleanParam.includes('çevrehavasındapartikül');

                let hasSubParams = item.parameter.sub_parameters && item.parameter.sub_parameters.length > 0;

                // =========================================================================
                // YENİ HARİKA ÖZELLİK: SAHA EKİPMAN (İLK/SON TARTIM) VERİSİNİ OTOMATİK ÇEK
                // =========================================================================
                // Eğer analist henüz bir sonuç kaydetmemişse (rValue boşsa)
                if (rValue === '') {
                    let fieldDataStr = sample.field_data;
                    let fieldDataObj = {};
                    
                    try { 
                        fieldDataObj = typeof fieldDataStr === 'string' ? JSON.parse(fieldDataStr) : (fieldDataStr || {}); 
                    } catch(e) {}
                    
                    let fieldEq = fieldDataObj.field_equipment || {};
                    let sahaJsonStr = fieldEq[String(item.parameter.id)] || fieldEq[item.parameter.id];
                    
                    // Sahadan gelen bir JSON (Filtre ölçümü) verisi varsa
                    if (sahaJsonStr) {
                        if (isToz || isPm10) {
                            // Toz ve PM10 modal yapısı, saha JSON verisi ile %100 uyumludur. Direkt basıyoruz.
                            rValue = String(sahaJsonStr);
                        } else if (!hasSubParams) {
                            // Eğer tekil bir sonuç kutusuysa (Ağır Metal vs. hesaplanan), JSON içinden sadece net sonucu çekip yaz.
                            try {
                                let parsedField = JSON.parse(sahaJsonStr);
                                if (Array.isArray(parsedField)) parsedField = parsedField[0].data || parsedField[0];
                                let val = parsedField.konsantrasyon || parsedField.filtre_fark || parsedField.net_fark || '';
                                if (val !== '') rValue = String(val);
                            } catch(e) {}
                        }
                    }
                }
                // =========================================================================

                let pMin = item.parameter.limit_min !== null ? item.parameter.limit_min : '';
                let pMax = item.parameter.limit_max !== null ? item.parameter.limit_max : '';
                let refText = (pMin !== '' || pMax !== '') ? `${pMin} - ${pMax}` : '-';

                let isFilled = false;
                let colorClass = '';
                let bgClass = '';
                
                let isMergedGeneral = rValue === '[BİRLEŞTİRİLDİ]';

                if (isMergedGeneral) {
                    isFilled = true;
                } else if (hasSubParams) {
                    try {
                        let parsed = JSON.parse(rValue);
                        if(Array.isArray(parsed) && parsed.some(x => x.value !== null && x.value !== '')) isFilled = true;
                    } catch(e) {}
                } else if (isToz) {
                    try {
                        let parsed = JSON.parse(rValue);
                        if (Array.isArray(parsed)) {
                            if (parsed.some(x => x.data && x.data.konsantrasyon !== '' && x.type !== 'blank')) isFilled = true;
                        } else {
                            if (parsed.konsantrasyon !== undefined && parsed.konsantrasyon !== '') isFilled = true;
                        }
                    } catch(e) { if(rValue !== '') isFilled = true; }
                } else if (isPm10) {
                    let pm10Val = '';
                    try {
                        if(rValue.startsWith('{') || rValue.startsWith('[')) { 
                            let parsed = JSON.parse(rValue);
                            if(Array.isArray(parsed)) parsed = parsed[0].data || parsed[0];
                            pm10Val = parsed.net_fark || parsed.filtre_fark || parsed.konsantrasyon || ''; 
                        } 
                        else { pm10Val = rValue; }
                    } catch(e) {}
                    if (pm10Val !== '') isFilled = true;
                } else {
                    if (rValue !== '') {
                        isFilled = true;
                        if (existingResult && existingResult.conformance === 'Uygun') colorClass = 'text-success border-success bg-success-subtle';
                        else if (existingResult && existingResult.conformance === 'Uygun Değil') { colorClass = 'text-danger border-danger bg-danger-subtle'; bgClass = 'bg-danger-subtle'; }
                        else colorClass = 'text-primary border-primary bg-light'; // Auto-Fill gelenler için mavi yanar
                    }
                }

                tempData.push({
                    sample: sample,
                    item: item,
                    parameter: item.parameter,
                    existingResult: existingResult,
                    rValue: rValue,
                    rUncert: rUncert,
                    rNote: rNote,
                    refText: refText,
                    scopeName: scopeName,
                    paramName: paramName,
                    paramNameLower: paramNameLower,
                    isToz: isToz,
                    isPm10: isPm10,
                    isVolumeCalculated: isVolumeCalculated,
                    hasSubParams: hasSubParams,
                    isFilled: isFilled,
                    colorClass: colorClass,
                    bgClass: bgClass,
                    barcode: sample.barcode,
                    searchStr: (sample.barcode + ' ' + paramName + ' ' + contentStr).toLowerCase(),
                    children: [] 
                });
            }
        });

        processedAnalysisData = [];
        let childrenData = [];
        let parentMap = {}; 

        // 1. Ana barkodların JSON verisini okuyup çocukların TAM BARKODUNU haritala (M1, M2, M3 Destekli)
        tempData.forEach(item => {
            if (item.rValue && (item.rValue.startsWith('[') || item.rValue.startsWith('{')) && item.rValue !== '[BİRLEŞTİRİLDİ]') {
                try {
                    let parsed = JSON.parse(item.rValue);
                    if (Array.isArray(parsed)) {
                        parsed.forEach(row => {
                            // Toz için standart barkod
                            if (row.barcode && row.barcode !== item.sample.barcode) {
                                parentMap[row.barcode + '_' + item.parameter.id] = item.sample.barcode;
                            }
                            // VOC için M1, M2, M3 barkod zekası
                            if (row.m2_barcode) parentMap[row.m2_barcode + '_' + item.parameter.id] = item.sample.barcode;
                            if (row.m3_barcode) parentMap[row.m3_barcode + '_' + item.parameter.id] = item.sample.barcode;
                            if (row.blank_barcode) parentMap[row.blank_barcode + '_' + item.parameter.id] = item.sample.barcode;
                        });
                    }
                } catch(e) {}
            }
        });

        // 2. YENİ ZEKİ AYIRICI: Çocukları ve Ana Numuneleri Ayır
        tempData.forEach(item => {
            let expectedParent = parentMap[item.sample.barcode + '_' + item.parameter.id];
            
            // Eğer rValue [BİRLEŞTİRİLDİ] ise VEYA parentMap içinde ebeveyni belli ise bu banko bir çocuktur.
            if (item.rValue === '[BİRLEŞTİRİLDİ]' || expectedParent) {
                if (item.rValue !== '[BİRLEŞTİRİLDİ]') {
                    item.rValue = '[BİRLEŞTİRİLDİ]';
                    item.rNote = 'Ana barkoda bağlandı.';
                    item.isFilled = true;
                }
                childrenData.push(item);
            } else {
                processedAnalysisData.push(item);
            }
        });

        // 3. Çocukları GERÇEK Ana Barkodlarına Ekle (Accordion Listesi İçin)
        childrenData.forEach(child => {
            let expectedParentBarcode = parentMap[child.sample.barcode + '_' + child.parameter.id];
            let parent = null;
            
            if (expectedParentBarcode) {
                parent = processedAnalysisData.find(p => p.sample.barcode === expectedParentBarcode && p.parameter.id === child.parameter.id);
            } else {
                // Yedek Güvenlik
                let noteMatch = child.rNote ? String(child.rNote).match(/Bu analiz, (.*?) numaralı/) : null;
                if (noteMatch && noteMatch[1]) {
                    parent = processedAnalysisData.find(p => p.sample.barcode === noteMatch[1].trim() && p.parameter.id === child.parameter.id);
                }
            }

            // AUTO-REPAIR (Zeka 1): Eğer hala parent bulunamadıysa, bir önceki ANA NUMUNEYİ bul ve ona bağla!
            if (!parent) {
                let childIndex = tempData.findIndex(t => t.sample.id === child.sample.id && t.parameter.id === child.parameter.id);
                for(let i = childIndex - 1; i >= 0; i--) {
                    if (tempData[i].parameter.id === child.parameter.id && tempData[i].rValue !== '[BİRLEŞTİRİLDİ]') {
                        parent = processedAnalysisData.find(p => p.sample.id === tempData[i].sample.id && p.parameter.id === child.parameter.id);
                        break;
                    }
                }
            }

            if (parent) {
                parent.children.push(child);
                parent.searchStr += ' ' + child.sample.barcode.toLowerCase();
            } else {
                processedAnalysisData.push(child);
            }
        });
    }

    function renderAnalysisForm(res) {
        let csrfToken = $('meta[name="csrf-token"]').attr('content') || "{{ csrf_token() }}";

        let html = `
        <div class="manual-search-container">
            <div class="d-flex align-items-center">
                <div class="me-3">
                    <span class="badge bg-primary p-2">Toplam: <span id="countTotal">0</span></span>
                    <span class="badge bg-success p-2">Girilen: <span id="countEntered">0</span></span>
                    <span class="badge bg-warning text-dark p-2">Bekleyen: <span id="countPending">0</span></span>
                </div>
                <div class="btn-group btn-group-sm me-2">
                    <button type="button" class="btn btn-outline-primary active manual-filter-btn" data-filter="all">Tümü</button>
                    <button type="button" class="btn btn-outline-success manual-filter-btn" data-filter="entered">Girilenler</button>
                    <button type="button" class="btn btn-outline-warning manual-filter-btn" data-filter="pending">Bekleyenler</button>
                </div>
                
                <select id="paramFilterDropdown" class="form-select form-select-sm border-primary fw-bold text-primary shadow-sm ms-2" style="width: 250px; border-radius: 20px; font-size: 0.8rem; cursor: pointer;">
                    <option value="all">Tüm Parametreler</option>
                </select>

                
            </div>
            <div class="dt-search-large">
                <input type="text" id="manualTableSearch" placeholder="Barkod veya Parametre Ara...">
            </div>
        </div>
        
        <form id="bulkResultsForm">
            <input type="hidden" name="_token" value="${csrfToken}">
            <input type="hidden" id="currentFilterMode" value="all">
            
            <div class="p-3">
                <div class="d-flex justify-content-between align-items-center bg-warning-subtle p-2 border border-warning mb-2 rounded shadow-sm" id="bulkActionsBar" style="display:none !important;">
                    <span class="fw-bold text-dark"><i class="fas fa-check-square me-1 text-success"></i> <span id="selectedParamCount">0</span> barkod seçildi</span>
                    <button type="button" class="btn btn-dark fw-bold btn-sm shadow-sm px-4" id="btnOpenVocMerge">
                        <i class="fas fa-object-group me-1 text-warning"></i> Seçili Ölçümleri Birleştir (M1-M2-M3-Şahit)
                    </button>
                </div>

                <div class="table-responsive bg-white shadow-sm rounded">
                    <table class="table table-hover table-bordered align-middle mb-0 modal-table-sm" id="bulkResultsTableManual" style="table-layout: fixed; width: 100%;">
                        <thead class="table-dark">
                            <tr>
                                <th width="40" class="text-center"><input type="checkbox" id="selectAllParams" style="transform: scale(1.3); cursor:pointer;"></th>
                                <th width="120" class="text-center">Barkod</th>
                                <th width="150" class="text-warning">İstenen Ölçümler</th> 
                                <th width="200">Analiz Parametresi</th>
                                <th width="100" class="text-center">Min-Max</th>
                                <th width="280">Sonuç Değeri</th>
                                <th width="90">Belirsizlik</th>
                                <th width="180">Açıklama / Not</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <span class="text-muted small fw-bold" id="pageInfoText"></span>
                    <div id="paginationControls"></div>
                </div>

            </div>
        </form>

        <div class="px-3 mb-5">
            <div class="card shadow-sm border-info">
                <div class="card-header bg-info text-white py-2 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 fw-bold"><i class="fas fa-file-upload me-2"></i> Ham Data & Evrak Yükleme (Tüm Teklif İçin Ortak)</h6>
                </div>
                <div class="card-body bg-light">
                    <form id="globalUploadForm" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="${csrfToken}">
                        <div class="row align-items-center">
                            <div class="col-md-8"><input type="file" name="raw_data_files[]" class="form-control border-info" accept=".pdf,.xls,.xlsx,.zip" multiple required></div>
                            <div class="col-md-4 text-end"><button type="submit" class="btn btn-info text-white fw-bold w-100 shadow-sm" id="btnUploadGlobal"><i class="fas fa-upload me-1"></i> DOSYALARI YÜKLE</button></div>
                        </div>
                        <div id="globalFileLink" class="mt-3 w-100"></div>
                    </form>
                </div>
            </div>
        </div>`;

        $('#modalAnalysisBody').html(html);

        let filterOptionsHtml = '<option value="all">Tüm Parametreler</option>';
        Array.from(uniqueParams).sort().forEach(p => {
            let safeVal = p.toLowerCase().replace(/"/g, '');
            filterOptionsHtml += `<option value="${safeVal}">${p}</option>`;
        });
        $('#paramFilterDropdown').html(filterOptionsHtml);

        if(res.offer && res.offer.raw_data_file) {
            let rawData = res.offer.raw_data_file;
            let files = [];
            if (Array.isArray(rawData)) { files = rawData; } 
            else if (typeof rawData === 'string' && rawData.trim() !== '') {
                try {
                    let parsed = JSON.parse(rawData);
                    if (typeof parsed === 'string') parsed = JSON.parse(parsed); 
                    files = Array.isArray(parsed) ? parsed : [rawData];
                } catch(e) { files = [rawData]; }
            }
            drawFiles(files); 
        } else {
            $('#globalFileLink').html('<span class="text-muted fst-italic">Henüz evrak yüklenmemiş.</span>');
        }

        runManualFilter_opt(1);
    }

    function renderTableRows_opt(data) {
        let html = '';
        data.forEach(item => {
            let sample = item.sample;
            let param = item.parameter;
            
            let methodText = param.analysis_methods || '';
            let methodLink = `<span class="text-muted fw-normal d-block text-truncate" style="max-width: 180px;">${methodText || 'Metot Yok'}</span>`;

            let displayContent = '';
            let fullDesc = sample.description ? sample.description.replace(/"/g, '&quot;') : '';

            if (fullDesc) {
                let shortDesc = fullDesc.length > 25 ? fullDesc.substring(0, 25) + '...' : fullDesc;
                displayContent = `<span data-bs-toggle="tooltip" data-bs-placement="right" title="${fullDesc}" style="cursor: help; border-bottom: 1px dotted #888;">${shortDesc}</span>`;
            } else {
                displayContent = '<span class="text-muted fst-italic">İçerik Yok</span>';
            }

            let cbCell = `<td class="text-center align-middle bg-light"><input type="checkbox" class="form-check-input param-cb border-dark" value="${sample.id}" data-param="${param.id}" data-barcode="${sample.barcode}" data-paramname="${item.paramNameLower}" style="transform: scale(1.3); cursor:pointer;"></td>`;

            // AÇILIR/KAPANIR ACCORDION BUTONU
            let toggleBtn = '';
            if (item.children && item.children.length > 0) {
                toggleBtn = `<br><button class="btn btn-sm btn-outline-danger shadow-sm rounded-pill py-0 px-2 mt-1" type="button" data-bs-toggle="collapse" data-bs-target=".child_rows_${sample.id}_${param.id}"><i class="fas fa-sitemap"></i> Bağlı Barkodlar (${item.children.length}) <i class="fas fa-caret-down ms-1"></i></button>`;
            }

            let barcodeCell = `
                <td class="fw-bold font-monospace text-primary align-middle text-center bg-light">
                    ${sample.barcode} <br>
                    <span class="badge ${sample.global_status == 'Analiz Aşamasında' ? 'bg-warning text-dark' : 'bg-secondary'} mt-1 fw-normal" style="font-size:0.65rem;">${sample.global_status}</span>
                    ${toggleBtn}
                </td>`;

            let contentCell = `<td class="align-middle bg-light text-dark fw-bold" style="font-size:0.75rem;"><i class="fas fa-clipboard-list text-warning me-1"></i> ${displayContent}</td>`;

            let valueCell = ''; 
            let uncertaintyCell = ''; 
            let noteCell = `<td><input type="text" name="results[${sample.id}][${param.id}][note]" class="form-control form-control-sm" value="${item.rNote}" placeholder="Açıklama..." autocomplete="off"></td>`;

            if (item.hasSubParams) {
                let isMerged = item.rValue === '[BİRLEŞTİRİLDİ]';
                let isJsonFilled = false;
                try {
                    let parsed = JSON.parse(item.rValue);
                    if(Array.isArray(parsed) && parsed.some(x => x.value !== null && x.value !== '')) isJsonFilled = true;
                } catch(e) {}
                
                let btnClass = isMerged ? 'btn-secondary text-white opacity-75' : (isJsonFilled ? 'btn-success text-white' : 'btn-info text-dark');
                let btnIcon = isMerged ? 'fa-link' : (isJsonFilled ? 'fa-edit' : 'fa-list-ol');
                let btnText = isMerged ? 'Kilitli' : (isJsonFilled ? 'Düzenle' : 'Alt Değerler');
                let disabledAttr = isMerged ? 'disabled' : '';
                
                let badgeCount = param.sub_parameters.length;
                let selectedSubs = sample.selected_sub_parameters ? sample.selected_sub_parameters : [];
                if (selectedSubs && selectedSubs.length > 0) {
                    let filteredCount = param.sub_parameters.filter(sub => selectedSubs.map(String).includes(String(sub.id))).length;
                    if(filteredCount > 0) badgeCount = filteredCount;
                }
                let badgeHtml = isMerged ? '' : `(${badgeCount})`;

                valueCell = `
                    <td>
                        <input type="hidden" name="results[${sample.id}][${param.id}][value]" class="json-val-input" id="val_${sample.id}_${param.id}" value='${item.rValue.replace(/'/g, "&#39;").replace(/"/g, '&quot;')}'>
                        <button type="button" class="btn btn-sm ${btnClass} w-100 fw-bold shadow-sm btn-open-subs" data-sample="${sample.id}" data-param="${param.id}" ${disabledAttr}>
                            <i class="fas ${btnIcon} me-1"></i> <span class="btn-text">${btnText}</span> ${badgeHtml}
                        </button>
                        <div class="small mt-1 text-muted fw-bold text-center" id="summary_${sample.id}_${param.id}" style="max-height: 40px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            ${isMerged ? '<span class="text-danger"><i class="fas fa-code-branch"></i> Ana Barkoda Birleştirildi</span>' : formatSubResultSummary(item.rValue)}
                        </div>
                    </td>`;
                uncertaintyCell = `<td><input type="text" name="results[${sample.id}][${param.id}][uncertainty]" class="form-control form-control-sm bg-light text-muted text-center" value="${item.rUncert}" placeholder="-" readonly tabindex="-1"></td>`;
            } else if (item.isToz) {
                let isMerged = item.rValue === '[BİRLEŞTİRİLDİ]';
                let isJsonFilled = false;
                let hasAnyData = false; 
                let isMatrix = false;
                let finalKons = '';

                if (isMerged) {
                    isJsonFilled = true;
                    hasAnyData = true;
                } else {
                    try {
                        let parsed = JSON.parse(item.rValue);
                        if (Array.isArray(parsed)) {
                            isMatrix = true;
                            if (parsed.some(x => x.data && (x.data.filtre_ilk !== '' || x.data.filtre_son !== ''))) hasAnyData = true;
                            if (parsed.some(x => x.data && x.data.konsantrasyon !== '' && x.type !== 'blank')) {
                                isJsonFilled = true;
                                let firstFilled = parsed.find(x => x.data && x.data.konsantrasyon !== '' && x.type !== 'blank');
                                if(firstFilled) finalKons = firstFilled.data.konsantrasyon;
                            }
                        } else {
                            if (parsed.filtre_ilk !== undefined && parsed.filtre_ilk !== '') hasAnyData = true;
                            if (parsed.konsantrasyon !== undefined && parsed.konsantrasyon !== '') {
                                isJsonFilled = true;
                                finalKons = parsed.konsantrasyon;
                            }
                        }
                    } catch(e) {}
                }
                
                let btnClass = isMerged ? 'btn-secondary text-white opacity-75' : (isJsonFilled ? 'btn-success text-white' : 'btn-info text-dark');
                let btnIcon = isMerged ? 'fa-link' : (hasAnyData ? 'fa-edit' : 'fa-balance-scale');
                
                let btnText = 'Tartım Gir';
                if (isMerged) {
                    btnText = 'Kilitli';
                } else if (isMatrix) {
                    btnText = hasAnyData ? 'Çoklu Düzenle' : 'Çoklu Tartım Gir';
                } else {
                    btnText = hasAnyData ? 'Tartım Düzenle' : 'Tartım Gir';
                }
                
                valueCell = `
                    <td>
                        <input type="hidden" name="results[${sample.id}][${param.id}][value]" class="json-val-input toz-hidden-val" id="val_${sample.id}_${param.id}" value='${item.rValue.replace(/'/g, "&#39;").replace(/"/g, '&quot;')}'>
                        <button type="button" class="btn btn-sm ${btnClass} w-100 fw-bold shadow-sm btn-open-toz" data-sample="${sample.id}" data-param="${param.id}" ${isMerged ? 'disabled' : ''}>
                            <i class="fas ${btnIcon} me-1"></i> <span class="btn-text">${btnText}</span>
                        </button>
                        <div class="small mt-1 text-muted fw-bold text-center" id="summary_${sample.id}_${param.id}">
                        ${isMerged ? '<span class="text-danger"><i class="fas fa-code-branch"></i> Ana Barkoda Bağlandı</span>' : (isJsonFilled ? '<span class="text-success fw-bold"><i class="fas fa-check-double"></i> Veriler Kayıtlı</span>' : '')}
                        </div>
                    </td>`;
                uncertaintyCell = `<td><input type="text" name="results[${sample.id}][${param.id}][uncertainty]" class="form-control form-control-sm bg-light text-muted text-center" value="${item.rUncert}" placeholder="-" readonly tabindex="-1"></td>`;
            } else if (item.isPm10) {
                let pm10Val = '';
                try {
                    if(item.rValue.startsWith('{') || item.rValue.startsWith('[')) { 
                        let parsed = JSON.parse(item.rValue);
                        if(Array.isArray(parsed)) parsed = parsed[0].data || parsed[0];
                        pm10Val = parsed.net_fark || parsed.filtre_fark || parsed.konsantrasyon || ''; 
                    } 
                    else { pm10Val = item.rValue; }
                } catch(e) {}
                let isJsonFilled = pm10Val !== '';
                
                let btnClass = isJsonFilled ? 'btn-success text-white' : 'btn-info text-dark';
                let btnIcon = isJsonFilled ? 'fa-edit' : 'fa-balance-scale';
                let btnText = isJsonFilled ? 'Tartım Düzenle' : 'Tartım Gir (PM 10)';
                
                valueCell = `
                    <td>
                        <input type="hidden" name="results[${sample.id}][${param.id}][value]" class="json-val-input pm10-hidden-val" id="val_${sample.id}_${param.id}" value='${item.rValue.replace(/'/g, "&#39;").replace(/"/g, '&quot;')}'>
                        <button type="button" class="btn btn-sm ${btnClass} w-100 fw-bold shadow-sm btn-open-pm10" data-sample="${sample.id}" data-param="${param.id}">
                            <i class="fas ${btnIcon} me-1"></i> <span class="btn-text">${btnText}</span>
                        </button>
                        <div class="small mt-1 text-muted fw-bold text-center" id="summary_${sample.id}_${param.id}">
                            ${isJsonFilled ? '<span class="text-danger fw-bold"><i class="fas fa-check"></i> ' + pm10Val + ' mg</span>' : ''}
                        </div>
                    </td>`;
                uncertaintyCell = `<td><input type="text" name="results[${sample.id}][${param.id}][uncertainty]" class="form-control form-control-sm bg-light text-muted text-center" value="${item.rUncert}" placeholder="-" readonly tabindex="-1"></td>`;
            } else {
                if (item.isVolumeCalculated) {
                    valueCell = `
                        <td>
                            <div class="d-flex gap-1 mb-1">
                                <div class="input-group input-group-sm w-50">
                                    <input type="number" step="any" class="form-control form-control-sm single-dev-val border-warning px-1" placeholder="Cihaz">
                                </div>
                                <div class="input-group input-group-sm w-50">
                                    <input type="number" step="any" class="form-control form-control-sm single-vol-val border-warning px-1" value="0.05" placeholder="Hacim">
                                </div>
                            </div>
                            <div class="input-group input-group-sm">
                                <input type="text" name="results[${sample.id}][${param.id}][value]" class="form-control result-input single-calc-res bg-light fw-bold text-primary ${item.colorClass}" value="${item.rValue}" placeholder="Sonuç" readonly tabindex="-1">
                                <span class="input-group-text bg-light fw-bold text-muted px-1">mg</span>
                            </div>
                        </td>`;
                } else {
                    valueCell = `
                        <td>
                            <div class="input-group input-group-sm">
                                <input type="text" name="results[${sample.id}][${param.id}][value]" class="form-control result-input ${item.colorClass}" value="${item.rValue}" placeholder="Değer" autocomplete="off">
                                <span class="input-group-text bg-light fw-bold text-muted px-1">${param.unit || ''}</span>
                            </div>
                        </td>`;
                }
                uncertaintyCell = `<td><input type="text" name="results[${sample.id}][${param.id}][uncertainty]" class="form-control form-control-sm" value="${item.rUncert}" placeholder="±" autocomplete="off"></td>`;
            }

            html += `
                <tr class="analysis-row ${item.isFilled ? 'bg-success-subtle' : item.bgClass}" data-sampleid="${sample.id}" data-paramid="${param.id}" data-filled="${item.isFilled ? '1' : '0'}" data-paramname="${item.paramNameLower}">
                    ${cbCell} ${barcodeCell} ${contentCell} 
                    <td class="fw-bold text-dark">
                        <span class="d-block text-truncate" style="max-width: 180px;" title="${param.name}">${param.name}</span>
                        <small class="text-danger fw-bold"><i class="fas fa-layer-group me-1"></i>${item.scopeName}</small>
                        ${methodLink}
                    </td>
                    <td class="text-center text-muted fw-bold small bg-light">${item.refText}</td>
                    ${valueCell} ${uncertaintyCell} ${noteCell}
                </tr>`;
                
            // --- GİZLİ (ACCORDION) BARKOD SATIRLARI ---
            if (item.children && item.children.length > 0) {
                item.children.forEach(child => {
                    html += `
                    <tr class="collapse child_rows_${sample.id}_${param.id} bg-danger bg-opacity-10 border-bottom border-danger">
                        <td class="text-center align-middle"><i class="fas fa-link text-danger opacity-50"></i></td>
                        <td class="fw-bold font-monospace text-danger align-middle text-center" style="font-size:0.8rem;">
                            <i class="fas fa-level-up-alt me-1 fa-rotate-90"></i> ${child.sample.barcode}
                        </td>
                        <td class="align-middle text-muted" style="font-size:0.75rem;">${child.sample.description || 'İçerik Yok'}</td>
                        <td class="fw-bold text-muted" style="font-size:0.85rem;">${child.parameter.name}</td>
                        <td class="text-center text-muted small">${child.refText}</td>
                        <td class="p-2">
                            <button type="button" class="btn btn-sm btn-secondary text-white opacity-75 w-100 fw-bold" disabled style="height: 31px;">
                                <i class="fas fa-link me-1"></i> Kilitli
                            </button>
                            <div class="small mt-1 text-danger fw-bold text-center"><i class="fas fa-code-branch"></i> Ana Barkoda Bağlandı</div>
                        </td>
                        <td><input type="text" class="form-control form-control-sm bg-light text-center" value="-" disabled></td>
                        <td><input type="text" class="form-control form-control-sm bg-light text-muted" value="${child.rNote || ''}" disabled></td>
                    </tr>`;
                });
            }
        });

        $('#bulkResultsTableManual tbody').html(html);
        $('[data-bs-toggle="tooltip"]').tooltip();
        updateDashboardCounts();
    }

    function runManualFilter_opt(page = 1) {
        currentPage_opt = page;
        let searchText = $('#manualTableSearch').val().toLowerCase();
        let filterMode = $('#currentFilterMode').val();
        let paramDropdownVal = $('#paramFilterDropdown').val();

        let filteredData = processedAnalysisData.filter(item => {
            let matchesSearch = searchText === '' || item.searchStr.indexOf(searchText) > -1;
            let matchesDropdown = (paramDropdownVal === 'all') || (item.paramNameLower === paramDropdownVal);
            let matchesFilter = true;

            if (filterMode === 'entered') matchesFilter = item.isFilled;
            else if (filterMode === 'pending') matchesFilter = !item.isFilled;

            return matchesSearch && matchesDropdown && matchesFilter;
        });

        let totalItems = filteredData.length;
        let totalPages = Math.ceil(totalItems / rowsPerPage_opt) || 1;
        if (currentPage_opt > totalPages) currentPage_opt = totalPages;

        let startIdx = (currentPage_opt - 1) * rowsPerPage_opt;
        let endIdx = startIdx + rowsPerPage_opt;
        let pagedData = filteredData.slice(startIdx, endIdx);

        renderTableRows_opt(pagedData);
        renderPaginationControls_opt(totalPages, currentPage_opt, totalItems, startIdx, endIdx);
    }

    function renderPaginationControls_opt(totalPages, current, totalItems, startIdx, endIdx) {
        let container = $('#paginationControls');
        let infoText = $('#pageInfoText');
        
        if (totalItems === 0) {
            infoText.html('<span class="text-danger">Arama kriterlerine uygun kayıt bulunamadı.</span>');
            container.html('');
            return;
        }

        let showingStart = startIdx + 1;
        let showingEnd = Math.min(endIdx, totalItems);
        infoText.html(`Toplam <b>${totalItems}</b> kayıttan <b>${showingStart}-${showingEnd}</b> arası gösteriliyor.`);

        if(totalPages <= 1) {
            container.html('');
            return;
        }

        let html = '<ul class="pagination pagination-sm mb-0 shadow-sm">';
        html += `<li class="page-item ${current === 1 ? 'disabled' : ''}"><a class="page-link-opt" href="#" data-page="${current - 1}">&laquo; Önceki</a></li>`;
        
        let startP = Math.max(1, current - 2);
        let endP = Math.min(totalPages, current + 2);

        for(let i = startP; i <= endP; i++) {
            html += `<li class="page-item ${i === current ? 'active' : ''}"><a class="page-link-opt" href="#" data-page="${i}">${i}</a></li>`;
        }

        html += `<li class="page-item ${current === totalPages ? 'disabled' : ''}"><a class="page-link-opt" href="#" data-page="${current + 1}">Sonraki &raquo;</a></li>`;
        html += '</ul>';
        
        container.html(html);
    }

    let searchFilterTimeout;
    $(document).on('input', '#manualTableSearch', function() {
        clearTimeout(searchFilterTimeout);
        searchFilterTimeout = setTimeout(function() { runManualFilter_opt(1); }, 200); 
    });
    
    $(document).on('change', '#paramFilterDropdown', function() { runManualFilter_opt(1); }); 

    $(document).on('click', '.manual-filter-btn', function() {
        $('.manual-filter-btn').removeClass('active');
        $(this).addClass('active');
        $('#currentFilterMode').val($(this).data('filter'));
        runManualFilter_opt(1);
    });

    $(document).on('click', '.page-link-opt', function(e) {
        e.preventDefault();
        let page = $(this).data('page');
        if (page) runManualFilter_opt(page);
    });

    function updateRowStatus($row) {
        let sampleId = $row.data('sampleid');
        let paramId = $row.data('paramid');
        let isFilled = false;
        
        let stdInput = $row.find('.result-input');
        if (stdInput.length > 0 && stdInput.val().trim() !== '') {
            isFilled = true;
            let devInput = $row.find('.single-dev-val');
            if (devInput.length > 0 && devInput.val().trim() === '') isFilled = false; 
        }

        let jsonInput = $row.find('.json-val-input');
        if (jsonInput.length > 0) {
            let val = jsonInput.val();
            if (val === '[BİRLEŞTİRİLDİ]') {
                isFilled = true;
            } else {
                try {
                    let parsed = JSON.parse(val);
                    if(Array.isArray(parsed)) {
                        if (parsed.some(x => x.value !== undefined && x.value !== null && x.value !== '')) {
                            isFilled = true;
                        } 
                        else if (parsed.some(x => x.data && x.data.konsantrasyon !== undefined && x.data.konsantrasyon !== '')) {
                            isFilled = true;
                        }
                    } else if (!Array.isArray(parsed) && ((parsed.konsantrasyon !== undefined && parsed.konsantrasyon !== '') || (parsed.net_fark !== undefined && parsed.net_fark !== ''))) {
                        isFilled = true; 
                    }
                } catch(e) {}
            }
        }
        
        $row.attr('data-filled', isFilled ? '1' : '0');
        if (isFilled) {
            $row.removeClass('bg-danger-subtle bg-light').addClass('bg-success-subtle');
        } else {
            $row.removeClass('bg-success-subtle');
        }

        let itemIndex = processedAnalysisData.findIndex(item => item.sample.id == sampleId && item.parameter.id == paramId);
        if (itemIndex !== -1) {
            processedAnalysisData[itemIndex].isFilled = isFilled;
            if(stdInput.length > 0) processedAnalysisData[itemIndex].rValue = stdInput.val();
            else if(jsonInput.length > 0) processedAnalysisData[itemIndex].rValue = jsonInput.val();
        }
    }

    function updateDashboardCounts() {
        let total = processedAnalysisData.length;
        let entered = processedAnalysisData.filter(item => item.isFilled).length;

        $('#countTotal').text(total); 
        $('#countEntered').text(entered); 
        $('#countPending').text(total - entered);

        let allFilled = (total > 0 && entered === total);
        let $completeBtn = $('#btnCompleteOffer');
        if (allFilled) {
            $completeBtn.prop('disabled', false).removeClass('btn-secondary').addClass('btn-success').attr('title', 'Tüm sonuçlar girildi, raporlamaya gönderebilirsiniz.');
        } else {
            $completeBtn.prop('disabled', true).removeClass('btn-success').addClass('btn-secondary').attr('title', total === 0 ? 'Analiz bulunamadı.' : ((total - entered) + ' adet parametreye henüz değer girilmedi.'));
        }
    }

    $(document).on('input change', '.result-input', function() {
        updateRowStatus($(this).closest('tr'));
        updateDashboardCounts();
    });

    $(document).on('input', '.single-dev-val, .single-vol-val', function() {
        let td = $(this).closest('td');
        let dev = parseFloat(td.find('.single-dev-val').val());
        let vol = parseFloat(td.find('.single-vol-val').val());
        let resInput = td.find('.single-calc-res');

        if (!isNaN(dev) && !isNaN(vol)) {
            let result = dev * vol;
            resInput.val(result.toFixed(4).replace(/\.?0+$/, ''));
        } else { resInput.val(''); }

        updateRowStatus($(this).closest('tr'));
        updateDashboardCounts();
    });

    $(document).on('click', '.btn-open-toz', function() {
        let sampleId = $(this).data('sample');
        let paramId = $(this).data('param');

        $('#currentTozSampleId').val(sampleId);
        $('#currentTozParamId').val(paramId);

        let currentValStr = $(`#val_${sampleId}_${paramId}`).val();
        let parsed = null;
        try {
            if(currentValStr.startsWith('{') || currentValStr.startsWith('[')) parsed = JSON.parse(currentValStr);
        } catch(e) {}

        let rowsData = [];
        let isMergeActive = window.isVocMergeMode && window.currentVocMergeData && (window.currentVocMergeData.m1[0] == sampleId);

        if (isMergeActive) {
            rowsData.push({ type: 'm1', label: '1. Ölçüm', barcode: window.currentVocMergeData.m1[2], data: {} });
            rowsData.push({ type: 'm2', label: '2. Ölçüm', barcode: window.currentVocMergeData.m2[2], data: {} });
            rowsData.push({ type: 'm3', label: '3. Ölçüm', barcode: window.currentVocMergeData.m3[2], data: {} });
            if (window.currentVocMergeData.blank) {
                rowsData.push({ type: 'blank', label: 'Şahit', barcode: window.currentVocMergeData.blank[2], data: {} });
            }
        } else if (Array.isArray(parsed)) {
            rowsData = parsed;
        } else {
            let barcode = $(this).closest('tr').find('.param-cb').data('barcode') || 'Tekil Numune';
            // YENİ: Tek objeyse, JSON objesini data arrayine atarak otomatik doldurmayı sağla
            rowsData.push({ type: 'single', label: 'Tekil Ölçüm', barcode: barcode, data: parsed || {} });
        }

        let tbodyHtml = '';
        rowsData.forEach(row => {
            let d = row.data || {};
            let isBlank = row.type === 'blank';
            let bgClass = isBlank ? 'bg-danger-subtle bg-opacity-10' : '';
            let labelHtml = `<strong class="${isBlank ? 'text-danger' : 'text-primary'}">${row.label}</strong><br><small class="text-muted font-monospace">${row.barcode}</small>`;

            tbodyHtml += `
            <tr class="toz-row ${bgClass}" data-type="${row.type}" data-label="${row.label}" data-barcode="${row.barcode}">
                <td class="align-middle bg-light text-start ps-2 lh-sm border-end border-dark">${labelHtml}</td>
                <td><input type="number" step="any" class="form-control form-control-sm text-center toz-calc-input toz-fi border-primary" value="${d.filtre_ilk || ''}"></td>
                <td><input type="number" step="any" class="form-control form-control-sm text-center toz-calc-input toz-fs border-primary" value="${d.filtre_son || ''}"></td>
                <td class="bg-primary bg-opacity-10 border-end border-dark"><input type="text" class="form-control form-control-sm text-center toz-ff fw-bold text-primary bg-white" value="${d.filtre_fark || ''}" readonly tabindex="-1"></td>
                
                <td><input type="number" step="any" class="form-control form-control-sm text-center toz-calc-input toz-yi border-info" value="${d.yikama_ilk || ''}"></td>
                <td><input type="number" step="any" class="form-control form-control-sm text-center toz-calc-input toz-ys border-info" value="${d.yikama_son || ''}"></td>
                <td class="bg-info bg-opacity-10 border-end border-dark"><input type="text" class="form-control form-control-sm text-center toz-yf fw-bold text-dark bg-white" value="${d.yikama_fark || ''}" readonly tabindex="-1"></td>
                
                <td class="bg-success bg-opacity-10"><input type="text" class="form-control form-control-sm text-center toz-kons fw-bold text-success bg-white shadow-sm" value="${d.konsantrasyon || ''}" readonly tabindex="-1"></td>
            </tr>
            `;
        });

        $('#tozTbody').html(tbodyHtml);
        
        if(rowsData.length > 1) { 
            $('#tozAverageResultArea').show(); 
            $('#btnSaveTozResultModal').html('<i class="fas fa-save me-1"></i> KAYDET VE BİRLEŞTİR');
        } else { 
            $('#tozAverageResultArea').hide(); 
            $('#btnSaveTozResultModal').html('<i class="fas fa-save me-1"></i> KAYDET');
        }

        calculateTozGrid(); 
        new bootstrap.Modal(document.getElementById('tozResultModal')).show();
    });

    $(document).on('input', '.toz-calc-input', function() { calculateTozGrid(); });

    function parseSafeFloat(val) {
        if (!val) return 0;
        let str = String(val).replace(',', '.'); 
        let parsed = parseFloat(str);
        return isNaN(parsed) ? 0 : parsed;
    }

    function calculateTozGrid() {
        let totalKons = 0;
        let validMeasCount = 0;

        $('#tozTbody .toz-row').each(function() {
            let rowType = $(this).data('type');
            
            let fI = parseSafeFloat($(this).find('.toz-fi').val());
            let fS = parseSafeFloat($(this).find('.toz-fs').val());
            let yI = parseSafeFloat($(this).find('.toz-yi').val());
            let yS = parseSafeFloat($(this).find('.toz-ys').val());
            
            let ff = (fS - fI) * 1000; if(ff < 0) ff = 0;
            let yf = (yS - yI) * 1000; if(yf < 0) yf = 0;

            $(this).find('.toz-ff').val(ff > 0 ? ff.toFixed(4) : '');
            $(this).find('.toz-yf').val(yf > 0 ? yf.toFixed(4) : '');

            let tozToplamNet = ff + yf;

            if(tozToplamNet > 0) {
                $(this).find('.toz-kons').val(tozToplamNet.toFixed(4));
                if (rowType !== 'blank') {
                    totalKons += tozToplamNet;
                    validMeasCount++;
                }
            } else {
                $(this).find('.toz-kons').val('');
            }
        });

        if (validMeasCount > 0) {
            $('#tozAverageValue').text((totalKons / validMeasCount).toFixed(4));
        } else {
            $('#tozAverageValue').text('0.0000');
        }
    }

    $(document).on('click', '#btnSaveTozResultModal', function() {
        let sampleId = $('#currentTozSampleId').val();
        let paramId = $('#currentTozParamId').val();

        let rowsData = [];
        let isMerged = false;
        let avgKons = $('#tozAverageValue').text();

        $('#tozTbody .toz-row').each(function() {
            let type = $(this).data('type');
            if (type !== 'single') isMerged = true;
            
            rowsData.push({
                type: type,
                label: $(this).data('label'),
                barcode: $(this).data('barcode'),
                data: {
                    filtre_ilk: $(this).find('.toz-fi').val(),
                    filtre_son: $(this).find('.toz-fs').val(),
                    filtre_fark: $(this).find('.toz-ff').val(),
                    yikama_ilk: $(this).find('.toz-yi').val(),
                    yikama_son: $(this).find('.toz-ys').val(),
                    yikama_fark: $(this).find('.toz-yf').val(),
                    vm: '', tm: '', pm: '',
                    konsantrasyon: $(this).find('.toz-kons').val() 
                }
            });
        });

        let jsonToSave = isMerged ? JSON.stringify(rowsData) : JSON.stringify(rowsData[0].data);
        $(`#val_${sampleId}_${paramId}`).val(jsonToSave);

        let finalKonsStr = '';
        let isFilled = false;
        
        if (isMerged) {
            isFilled = rowsData.some(r => r.data.konsantrasyon !== '' && r.type !== 'blank');
            finalKonsStr = avgKons;
        } else {
            finalKonsStr = rowsData[0].data.konsantrasyon || '';
            isFilled = finalKonsStr !== '' && finalKonsStr !== '0.0000';
        }

        let btn = $(`.btn-open-toz[data-sample="${sampleId}"][data-param="${paramId}"]`);
        if (isFilled) {
            btn.removeClass('btn-info text-dark').addClass('btn-success text-white').find('i').removeClass('fa-balance-scale').addClass('fa-edit');
            btn.find('.btn-text').text(isMerged ? 'Çoklu Düzenle' : 'Tartım Düzenle');
            $(`#summary_${sampleId}_${paramId}`).html('<span class="text-success fw-bold"><i class="fas fa-check-double"></i> Veriler Kayıtlı</span>');
        } else {
            btn.removeClass('btn-success text-white').addClass('btn-info text-dark').find('i').removeClass('fa-edit').addClass('fa-balance-scale');
            btn.find('.btn-text').text(isMerged ? 'Çoklu Tartım Gir' : 'Tartım Gir');
            $(`#summary_${sampleId}_${paramId}`).html('');
        }

        updateRowStatus(btn.closest('tr'));

        if (window.isVocMergeMode && window.currentVocMergeData && window.currentVocMergeData.m1[0] == sampleId) {
            let message = "Ana barkoda bağlandı.";
            let mainSampleId = window.currentVocMergeData.m1[0];

            let updateMergedRow = function(id) {
                if(!id) return;
                let itemIndex = processedAnalysisData.findIndex(item => item.sample.id == id && item.parameter.id == paramId);
                if (itemIndex !== -1) {
                    let mergedItem = processedAnalysisData.splice(itemIndex, 1)[0]; 
                    mergedItem.rValue = "[BİRLEŞTİRİLDİ]";
                    mergedItem.rNote = message;
                    mergedItem.rUncert = "-";
                    mergedItem.isFilled = true;
                    
                    let parentIndex = processedAnalysisData.findIndex(item => item.sample.id == mainSampleId && item.parameter.id == paramId);
                    if(parentIndex !== -1) {
                        processedAnalysisData[parentIndex].children.push(mergedItem);
                        processedAnalysisData[parentIndex].searchStr += ' ' + mergedItem.sample.barcode.toLowerCase();
                    }
                }
            };

            updateMergedRow(window.currentVocMergeData.m2[0]);
            updateMergedRow(window.currentVocMergeData.m3[0]);
            if(window.currentVocMergeData.blank) updateMergedRow(window.currentVocMergeData.blank[0]);

            window.isVocMergeMode = false;
            window.currentVocMergeData = null;
            $('#bulkActionsBar').hide(); 
            $('.param-cb').prop('checked', false); 
            
            runManualFilter_opt(currentPage_opt);
        }

        updateDashboardCounts();
        bootstrap.Modal.getInstance(document.getElementById('tozResultModal')).hide();
    });

    $(document).on('click', '.btn-open-pm10', function() {
        let sampleId = $(this).data('sample');
        let paramId = $(this).data('param');

        $('#currentPm10SampleId').val(sampleId);
        $('#currentPm10ParamId').val(paramId);

        let currentValStr = $(`#val_${sampleId}_${paramId}`).val();
        let parsed = {};
        try {
            if(currentValStr.startsWith('{') || currentValStr.startsWith('[')) {
                let temp = JSON.parse(currentValStr);
                parsed = Array.isArray(temp) ? (temp[0].data || temp[0]) : temp;
            }
        } catch(e) {}

        // YENİ: PM10 İçin Saha Verisini Modal'a Doldur
        $('#pm10_filtre_ilk').val(parsed.filtre_ilk || '');
        $('#pm10_filtre_son').val(parsed.filtre_son || '');
        
        calculatePm10();
        new bootstrap.Modal(document.getElementById('pm10ResultModal')).show();
    });

    function calculatePm10() {
        let fIlk = parseFloat($('#pm10_filtre_ilk').val()) || 0;
        let fSon = parseFloat($('#pm10_filtre_son').val()) || 0;
        let fFark = (fSon - fIlk) * 1000; 
        if(fFark < 0) fFark = 0;
        $('#pm10_filtre_fark').val(fFark > 0 ? fFark.toFixed(4) : '');
    }

    $(document).on('input', '.pm10-calc-input', function() { calculatePm10(); });

    $(document).on('click', '#btnSavePm10ResultModal', function() {
        let sampleId = $('#currentPm10SampleId').val();
        let paramId = $('#currentPm10ParamId').val();

        let data = {
            filtre_ilk: $('#pm10_filtre_ilk').val(),
            filtre_son: $('#pm10_filtre_son').val(),
            net_fark: $('#pm10_filtre_fark').val()
        };

        let jsonStr = JSON.stringify(data);
        $(`#val_${sampleId}_${paramId}`).val(jsonStr);

        let konsVal = data.net_fark;
        let isFilled = konsVal !== '' && konsVal !== null && parseFloat(konsVal) > 0;

        let btn = $(`.btn-open-pm10[data-sample="${sampleId}"][data-param="${paramId}"]`);
        if (isFilled) {
            btn.removeClass('btn-info text-dark').addClass('btn-success text-white').find('i').removeClass('fa-balance-scale').addClass('fa-edit');
            btn.find('.btn-text').text('Tartım Düzenle');
            $(`#summary_${sampleId}_${paramId}`).html('<span class="text-danger fw-bold"><i class="fas fa-check"></i> ' + parseFloat(konsVal).toFixed(4) + ' mg</span>');
        } else {
            btn.removeClass('btn-success text-white').addClass('btn-info text-dark').find('i').removeClass('fa-edit').addClass('fa-balance-scale');
            btn.find('.btn-text').text('Tartım Gir (PM 10)');
            $(`#summary_${sampleId}_${paramId}`).html('');
        }

        updateRowStatus(btn.closest('tr'));
        updateDashboardCounts();

        bootstrap.Modal.getInstance(document.getElementById('pm10ResultModal')).hide();
    });

    // =========================================================================
    // VOC M1 M2 M3 BARKOD ZEKASI VE AUTO-REPAIR
    // =========================================================================
    $(document).on('click', '.btn-open-subs', function() {
        let sampleId = $(this).data('sample');
        let paramId = $(this).data('param');

        let paramObj = null;
        if(globalResData && globalResData.offer && globalResData.offer.items) {
            globalResData.offer.items.forEach(i => { if(i.parameter && i.parameter.id == paramId) paramObj = i.parameter; });
        }
        if(!paramObj || !paramObj.sub_parameters) return;

        let currentSample = globalResData.samples.find(s => s.id == sampleId);
        let selectedSubs = currentSample && currentSample.selected_sub_parameters ? currentSample.selected_sub_parameters : [];

        $('#currentSubResultSampleId').val(sampleId);
        $('#currentSubResultParamId').val(paramId);
        
        $('#subParamSearchInput').val('');
        $('#subParamSearchInfo').html('Tüm parametreler listeleniyor.');

        let paramNameLower = paramObj.name.toLowerCase();
        let scopeObj = paramObj.scope_type || paramObj.scopeType || null;
        let scopeNameLower = scopeObj && scopeObj.name ? scopeObj.name.toLowerCase() : '';
        
        let isHeavyMetal = paramNameLower.includes('ağır metal') || paramNameLower.includes('klorür örneklemesi');
        let isEmisyonVoc = scopeNameLower.includes('emisyon') && paramNameLower.includes('voc');

        let currentValStr = $(`#val_${sampleId}_${paramId}`).val();
        let currentVals = [];
        try { 
            let parsed = JSON.parse(currentValStr); 
            if (Array.isArray(parsed)) currentVals = parsed;
        } catch(e) {}

        let savedVf1 = currentVals.length && currentVals[0].vf1 !== undefined ? currentVals[0].vf1 : '1.0';
        let savedVf2 = currentVals.length && currentVals[0].vf2 !== undefined ? currentVals[0].vf2 : '1.0';
        let savedVf3 = currentVals.length && currentVals[0].vf3 !== undefined ? currentVals[0].vf3 : '1.0';
        let savedVt  = currentVals.length && currentVals[0].vt !== undefined ? currentVals[0].vt : '1.0';
        
        let savedM1Barcode = currentVals.length && currentVals[0].m1_barcode ? currentVals[0].m1_barcode : '';
        let savedM2Barcode = currentVals.length && currentVals[0].m2_barcode ? currentVals[0].m2_barcode : '';
        let savedM3Barcode = currentVals.length && currentVals[0].m3_barcode ? currentVals[0].m3_barcode : '';
        let savedBlankBarcode = currentVals.length && currentVals[0].blank_barcode ? currentVals[0].blank_barcode : '';

        let currentItem = processedAnalysisData.find(item => item.sample.id == sampleId && item.parameter.id == paramId);
        let childBarcodes = currentItem && currentItem.children ? currentItem.children.map(c => c.sample.barcode) : [];
        if (!savedM2Barcode && childBarcodes.length > 0) savedM2Barcode = childBarcodes[0];
        if (!savedM3Barcode && childBarcodes.length > 1) savedM3Barcode = childBarcodes[1];
        if (!savedBlankBarcode && childBarcodes.length > 2) savedBlankBarcode = childBarcodes[2];

        let isMergeActive = window.isVocMergeMode && window.currentVocMergeData && (window.currentVocMergeData.m1[0] == sampleId);
        let hasBlankData = currentVals.length > 0 && currentVals[0].vt !== undefined;
        let showBlankColumn = (isMergeActive || hasBlankData) && isEmisyonVoc;

        let labelM1 = (isMergeActive && window.currentVocMergeData.m1) ? window.currentVocMergeData.m1[2] : (savedM1Barcode || currentSample.barcode);
        let labelM2 = (isMergeActive && window.currentVocMergeData.m2) ? window.currentVocMergeData.m2[2] : (savedM2Barcode || 'Belirtilmedi');
        let labelM3 = (isMergeActive && window.currentVocMergeData.m3) ? window.currentVocMergeData.m3[2] : (savedM3Barcode || 'Belirtilmedi');
        
        let blankLabel = "Şahit Seçilmedi";
        let blankEnabled = false;
        
        if (isMergeActive && window.currentVocMergeData.blank) {
            blankLabel = window.currentVocMergeData.blank[2];
            blankEnabled = true;
        } else if (hasBlankData && savedBlankBarcode) {
            blankLabel = savedBlankBarcode;
            blankEnabled = true;
        }

        let theadHtml = `
        <tr>
            <th class="align-middle">Parametre (Element)</th>
            ${isHeavyMetal ? '<th width="160" class="text-center bg-warning-subtle text-dark align-middle">Cihaz Değeri</th><th width="100" class="text-center bg-warning-subtle text-dark align-middle">Hacim</th>' : ''}
            ${isEmisyonVoc ? `
                <th width="160" class="text-center bg-success-subtle text-dark border-start">
                    1. Ölçüm <br><small class="text-primary fw-bold" id="lbl_m1">${labelM1}</small>
                    <div class="input-group input-group-sm mt-1 shadow-sm" title="1. Ölçüm Çözücü Hacmi (vF)">
                        <span class="input-group-text bg-white" style="font-size:0.65rem;">vF (mL)</span>
                        <input type="number" step="any" class="form-control text-center global-vf fw-bold text-primary" data-target="1" id="vf_1" value="${savedVf1}">
                    </div>
                </th>
                <th width="160" class="text-center bg-success-subtle text-dark border-start">
                    2. Ölçüm <br><small class="text-primary fw-bold" id="lbl_m2">${labelM2}</small>
                    <div class="input-group input-group-sm mt-1 shadow-sm" title="2. Ölçüm Çözücü Hacmi (vF)">
                        <span class="input-group-text bg-white" style="font-size:0.65rem;">vF (mL)</span>
                        <input type="number" step="any" class="form-control text-center global-vf fw-bold text-primary" data-target="2" id="vf_2" value="${savedVf2}">
                    </div>
                </th>
                <th width="160" class="text-center bg-success-subtle text-dark border-start">
                    3. Ölçüm <br><small class="text-primary fw-bold" id="lbl_m3">${labelM3}</small>
                    <div class="input-group input-group-sm mt-1 shadow-sm" title="3. Ölçüm Çözücü Hacmi (vF)">
                        <span class="input-group-text bg-white" style="font-size:0.65rem;">vF (mL)</span>
                        <input type="number" step="any" class="form-control text-center global-vf fw-bold text-primary" data-target="3" id="vf_3" value="${savedVf3}">
                    </div>
                </th>
                ${showBlankColumn ? `
                <th width="160" class="text-center bg-danger-subtle text-dark border-start">
                    Şahit (Tanık)<br><small class="text-danger fw-bold" id="lbl_blank">${blankLabel}</small>
                    <div class="input-group input-group-sm mt-1 shadow-sm" title="Şahit Çözücü Hacmi (vT)">
                        <span class="input-group-text bg-white" style="font-size:0.65rem;">vT (mL)</span>
                        <input type="number" step="any" class="form-control text-center global-vt fw-bold text-danger" id="vt_blank" value="${savedVt}" ${!blankEnabled ? 'disabled' : ''}>
                    </div>
                </th>
                ` : ''}
            ` : `
                <th width="160" class="align-middle">Sonuç Değeri</th>
            `}
            <th width="120" class="align-middle border-start">Belirsizlik (±)</th>
            <th width="180" class="align-middle">Açıklama / Not</th>
        </tr>`;
        $('#subResultThead').html(theadHtml);

        let tbody = $('#subResultTbody');
        tbody.empty();

        let addedCount = 0;

        paramObj.sub_parameters.forEach(sub => {
            if (selectedSubs && selectedSubs.length > 0) {
                if (!selectedSubs.map(String).includes(String(sub.id))) return; 
            }
            addedCount++;

            let ex = currentVals.find(x => x.id == sub.id);
            let val = ex ? (ex.value || '') : '';
            let uncert = ex ? (ex.uncertainty || '') : '';
            let note = ex ? (ex.note || '') : '';

            let devVal = ex && ex.device_value !== undefined ? ex.device_value : '';
            let volVal = ex && ex.volume_value !== undefined ? ex.volume_value : (isHeavyMetal ? '0.05' : '');

            let cf1Val = ex && ex.cf1 !== undefined ? ex.cf1 : '';
            let cf2Val = ex && ex.cf2 !== undefined ? ex.cf2 : '';
            let cf3Val = ex && ex.cf3 !== undefined ? ex.cf3 : '';
            let ctVal  = ex && ex.ct  !== undefined ? ex.ct  : '';

            let m1Val = ex && ex.m1 !== undefined ? ex.m1 : '';
            let m2Val = ex && ex.m2 !== undefined ? ex.m2 : '';
            let m3Val = ex && ex.m3 !== undefined ? ex.m3 : '';

            let tr = `
            <tr class="sub-result-row" data-id="${sub.id}" data-name="${sub.name}" data-code="${sub.code || ''}">
                <td class="fw-bold align-middle">${sub.name} <small class="text-danger">(${formatChem(sub.code) || '-'})</small></td>
                
                ${isHeavyMetal ? `
                    <td>
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control form-control-sm sub-device-val text-center border-warning" value="${devVal}" placeholder="Cihaz">
                            <button class="btn btn-outline-secondary btn-loq px-2 border-warning" type="button" tabindex="-1" title="LOQ Ekle"><span class="fw-bold" style="font-size:0.7rem;">&lt;loq</span></button>
                        </div>
                    </td>
                    <td><input type="number" step="any" class="form-control form-control-sm sub-volume-val text-center border-warning" value="${volVal}" placeholder="Hacim"></td>
                ` : ''}
                
                ${isEmisyonVoc ? `
                    <td class="border-start">
                        <input type="number" step="any" class="form-control form-control-sm text-center border-primary emisyon-cf-val mb-1" data-meas="1" value="${cf1Val}" placeholder="Cihaz (ppm)">
                        <input type="text" class="form-control form-control-sm text-center border-success emisyon-m-val emisyon-m1-val bg-light fw-bold text-success" data-meas="1" value="${m1Val}" placeholder="Net (mg)" readonly tabindex="-1" style="font-size: 0.75rem;">
                    </td>
                    <td class="border-start">
                        <input type="number" step="any" class="form-control form-control-sm text-center border-primary emisyon-cf-val mb-1" data-meas="2" value="${cf2Val}" placeholder="Cihaz (ppm)">
                        <input type="text" class="form-control form-control-sm text-center border-success emisyon-m-val emisyon-m2-val bg-light fw-bold text-success" data-meas="2" value="${m2Val}" placeholder="Net (mg)" readonly tabindex="-1" style="font-size: 0.75rem;">
                    </td>
                    <td class="border-start">
                        <input type="number" step="any" class="form-control form-control-sm text-center border-primary emisyon-cf-val mb-1" data-meas="3" value="${cf3Val}" placeholder="Cihaz (ppm)">
                        <input type="text" class="form-control form-control-sm text-center border-success emisyon-m-val emisyon-m3-val bg-light fw-bold text-success" data-meas="3" value="${m3Val}" placeholder="Net (mg)" readonly tabindex="-1" style="font-size: 0.75rem;">
                    </td>
                    ${showBlankColumn ? `
                    <td class="border-start bg-danger-subtle bg-opacity-10">
                        <input type="number" step="any" class="form-control form-control-sm text-center border-danger emisyon-ct-val mb-1" value="${ctVal}" placeholder="Cihaz (cT)" ${!blankEnabled ? 'disabled' : ''}>
                        <input type="text" class="form-control form-control-sm text-center border-danger emisyon-mt-val bg-white fw-bold text-danger" placeholder="Şahit Yükü (mg)" readonly tabindex="-1" style="font-size: 0.75rem;">
                    </td>
                    ` : ''}
                ` : `
                    <td class="align-middle">
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control sub-val ${isHeavyMetal ? 'bg-light fw-bold text-primary' : ''}" value="${val}" placeholder="Sonuç" ${isHeavyMetal ? 'readonly tabindex="-1"' : ''}>
                            <span class="input-group-text bg-light fw-bold text-muted">${isHeavyMetal ? 'mg' : (sub.unit || '')}</span>
                        </div>
                    </td>
                `}
                
                <td class="align-middle border-start"><input type="text" class="form-control form-control-sm sub-uncert text-center" value="${uncert}" placeholder="Örn: 0.2"></td>
                <td class="align-middle"><input type="text" class="form-control form-control-sm sub-note" value="${note}" placeholder="Not..."></td>
            </tr>`;
            tbody.append(tr);
        });

        if(addedCount === 0) {
            tbody.append('<tr><td colspan="5" class="text-center py-4 text-warning fw-bold"><i class="fas fa-exclamation-triangle me-1"></i> Bu numune için Numune Kabul aşamasında hiçbir alt parametre seçilmemiş!</td></tr>');
        }

        new bootstrap.Modal(document.getElementById('subResultModal')).show();
        setTimeout(() => $('.global-vf').first().trigger('input'), 200); 
    });

    function calculateVocRow($tr) {
        let ct = parseFloat($tr.find('.emisyon-ct-val').val()) || 0;
        let vt = parseFloat($('#vt_blank').val()) || 1.0;
        let mt = (ct * vt) / 1000;
        
        $tr.find('.emisyon-mt-val').val(mt > 0 ? mt.toFixed(10).replace(/\.?0+$/, '') : '');

        [1, 2, 3].forEach(meas => {
            let cf = parseFloat($tr.find('.emisyon-cf-val[data-meas="'+meas+'"]').val());
            let vf = parseFloat($('#vf_' + meas).val()) || 1.0;
            let $mInput = $tr.find('.emisyon-m-val[data-meas="'+meas+'"]');

            if (!isNaN(cf)) {
                let mf = (cf * vf) / 1000;
                let mn = mf - mt;
                if (mn < 0) mn = 0;
                $mInput.val(mn.toFixed(10).replace(/\.?0+$/, ''));
            } else {
                $mInput.val('');
            }
        });
    }

    $(document).on('input', '.emisyon-cf-val, .emisyon-ct-val', function() { calculateVocRow($(this).closest('tr')); });
    $(document).on('input', '.global-vf, .global-vt', function() { $('.sub-result-row').each(function() { calculateVocRow($(this)); }); });

    $(document).on('click', '#btnSaveSubResultModal', function() {
        let sampleId = $('#currentSubResultSampleId').val();
        let paramId = $('#currentSubResultParamId').val();

        let results = [];
        $('.sub-result-row').each(function() {
            let devVal = $(this).find('.sub-device-val').length ? $(this).find('.sub-device-val').val() : null;
            let volVal = $(this).find('.sub-volume-val').length ? $(this).find('.sub-volume-val').val() : null;
            
            let cf1Val = $(this).find('.emisyon-cf-val[data-meas="1"]').length ? $(this).find('.emisyon-cf-val[data-meas="1"]').val() : null;
            let cf2Val = $(this).find('.emisyon-cf-val[data-meas="2"]').length ? $(this).find('.emisyon-cf-val[data-meas="2"]').val() : null;
            let cf3Val = $(this).find('.emisyon-cf-val[data-meas="3"]').length ? $(this).find('.emisyon-cf-val[data-meas="3"]').val() : null;
            let ctVal  = $(this).find('.emisyon-ct-val').length ? $(this).find('.emisyon-ct-val').val() : null;

            let m1Val = $(this).find('.emisyon-m1-val').length ? $(this).find('.emisyon-m1-val').val() : null;
            let m2Val = $(this).find('.emisyon-m2-val').length ? $(this).find('.emisyon-m2-val').val() : null;
            let m3Val = $(this).find('.emisyon-m3-val').length ? $(this).find('.emisyon-m3-val').val() : null;

            let finalValue = $(this).find('.sub-val').length ? $(this).find('.sub-val').val() : null;

            if (m1Val !== null && m2Val !== null && m3Val !== null) {
                let v1 = parseFloat(m1Val) || 0;
                let v2 = parseFloat(m2Val) || 0;
                let v3 = parseFloat(m3Val) || 0;
                if(m1Val !== '' || m2Val !== '' || m3Val !== '') {
                    finalValue = ((v1 + v2 + v3) / 3).toFixed(10).replace(/\.?0+$/, ''); 
                } else {
                    finalValue = '';
                }
            }

            results.push({
                id: $(this).data('id'), name: $(this).data('name'), code: $(this).data('code'),
                value: finalValue, device_value: devVal, volume_value: volVal,
                cf1: cf1Val, cf2: cf2Val, cf3: cf3Val, ct: ctVal,
                m1: m1Val, m2: m2Val, m3: m3Val,
                vf1: $('#vf_1').length ? $('#vf_1').val() : '1.0',
                vf2: $('#vf_2').length ? $('#vf_2').val() : '1.0',
                vf3: $('#vf_3').length ? $('#vf_3').val() : '1.0',
                vt: $('#vt_blank').length ? $('#vt_blank').val() : null,
                
                m1_barcode: $('#lbl_m1').length && $('#lbl_m1').text() !== 'Belirtilmedi' ? $('#lbl_m1').text() : null,
                m2_barcode: $('#lbl_m2').length && $('#lbl_m2').text() !== 'Belirtilmedi' ? $('#lbl_m2').text() : null,
                m3_barcode: $('#lbl_m3').length && $('#lbl_m3').text() !== 'Belirtilmedi' ? $('#lbl_m3').text() : null,
                blank_barcode: $('#lbl_blank').length && $('#lbl_blank').text() !== 'Şahit Seçilmedi' ? $('#lbl_blank').text() : null,
                
                uncertainty: $(this).find('.sub-uncert').val(),
                note: $(this).find('.sub-note').val()
            });
        });

        let jsonStr = JSON.stringify(results);
        $(`#val_${sampleId}_${paramId}`).val(jsonStr);
        $(`#summary_${sampleId}_${paramId}`).html(formatSubResultSummary(jsonStr));

        let btn = $(`.btn-open-subs[data-sample="${sampleId}"][data-param="${paramId}"]`);
        btn.removeClass('btn-info text-dark btn-secondary disabled').addClass('btn-success text-white').prop('disabled', false).find('i').removeClass('fa-list-ol fa-link').addClass('fa-edit');
        btn.find('.btn-text').text('Değerleri Düzenle');
        updateRowStatus(btn.closest('tr'));

        if (window.isVocMergeMode && window.currentVocMergeData && window.currentVocMergeData.m1[0] == sampleId) {
            let message = "Ana barkoda bağlandı.";
            let mainSampleId = window.currentVocMergeData.m1[0];

            let updateMergedRow = function(id) {
                if(!id) return;
                let itemIndex = processedAnalysisData.findIndex(item => item.sample.id == id && item.parameter.id == paramId);
                if (itemIndex !== -1) {
                    let mergedItem = processedAnalysisData.splice(itemIndex, 1)[0]; 
                    mergedItem.rValue = "[BİRLEŞTİRİLDİ]";
                    mergedItem.rNote = message;
                    mergedItem.rUncert = "-";
                    mergedItem.isFilled = true;
                    
                    let parentIndex = processedAnalysisData.findIndex(item => item.sample.id == mainSampleId && item.parameter.id == paramId);
                    if(parentIndex !== -1) {
                        processedAnalysisData[parentIndex].children.push(mergedItem);
                        processedAnalysisData[parentIndex].searchStr += ' ' + mergedItem.sample.barcode.toLowerCase();
                    }
                }
            };

            updateMergedRow(window.currentVocMergeData.m2[0]);
            updateMergedRow(window.currentVocMergeData.m3[0]);
            if(window.currentVocMergeData.blank) updateMergedRow(window.currentVocMergeData.blank[0]);

            window.isVocMergeMode = false;
            window.currentVocMergeData = null;
            $('#bulkActionsBar').hide(); 
            $('.param-cb').prop('checked', false); 
            
            runManualFilter_opt(currentPage_opt);
        }

        bootstrap.Modal.getInstance(document.getElementById('subResultModal')).hide();
        updateDashboardCounts();
    });

    $(document).on('change', '.param-cb, #selectAllParams', function() {
        if ($(this).attr('id') === 'selectAllParams') {
            let isChecked = $(this).is(':checked');
            $('.param-cb').prop('checked', isChecked);
        }

        let checkedBoxes = $('.param-cb:checked');
        let count = checkedBoxes.length;
        $('#selectedParamCount').text(count);

        if (count > 1) {
            $('#bulkActionsBar').attr('style', 'display: flex !important');
        } else {
            $('#bulkActionsBar').attr('style', 'display: none !important');
        }
    });

    $(document).on('click', '#btnOpenVocMerge', function() {
        let checkedBoxes = $('.param-cb:checked');
        let isValid = true;
        let firstParamId = null;
        let barcodes = [];

        checkedBoxes.each(function() {
            let currentParamId = $(this).data('param');
            if (firstParamId === null) firstParamId = currentParamId;
            if (firstParamId !== currentParamId) isValid = false; 

            barcodes.push({ sampleId: $(this).val(), paramId: currentParamId, barcode: $(this).data('barcode') });
        });

        if (!isValid) { toastr.error('Birleştirme işlemi için seçtiğiniz tüm barkodların AYNI ANALİZ PARAMETRESİNE (Örn: Sadece Toz) ait olması gerekir!'); return; }
        if (barcodes.length < 2 || barcodes.length > 4) { toastr.warning('Birleştirme işlemi için en az 2, en fazla 4 adet (3 Ölçüm + 1 Şahit) barkod seçmelisiniz.'); return; }

        $('.merge-select').empty();
        $('#merge_blank').append('<option value="">-- Şahit Numune Yok --</option>');
        
        let optionsHtml = '<option value="">-- Barkod Seçin --</option>';
        barcodes.forEach(b => {
            let valStr = b.sampleId + '|' + b.paramId + '|' + b.barcode;
            optionsHtml += `<option value="${valStr}">${b.barcode}</option>`;
        });

        $('#merge_m1').html(optionsHtml);
        $('#merge_m2').html(optionsHtml);
        $('#merge_m3').html(optionsHtml);
        barcodes.forEach(b => {
            let valStr = b.sampleId + '|' + b.paramId + '|' + b.barcode;
            $('#merge_blank').append(`<option value="${valStr}">${b.barcode}</option>`);
        });

        if(barcodes[0]) $('#merge_m1').val(barcodes[0].sampleId + '|' + barcodes[0].paramId + '|' + barcodes[0].barcode);
        if(barcodes[1]) $('#merge_m2').val(barcodes[1].sampleId + '|' + barcodes[1].paramId + '|' + barcodes[1].barcode);
        if(barcodes[2]) $('#merge_m3').val(barcodes[2].sampleId + '|' + barcodes[2].paramId + '|' + barcodes[2].barcode);
        if(barcodes[3]) $('#merge_blank').val(barcodes[3].sampleId + '|' + barcodes[3].paramId + '|' + barcodes[3].barcode);

        $('#mergeWarningBox').hide();
        new bootstrap.Modal(document.getElementById('vocMergeModal')).show(); 
    });

    $(document).on('click', '#btnContinueVocMerge', function() {
        let m1 = $('#merge_m1').val();
        let m2 = $('#merge_m2').val();
        let m3 = $('#merge_m3').val();
        let blank = $('#merge_blank').val();

        if (!m1 || !m2 || !m3) { $('#mergeWarningBox').text("Lütfen 1., 2. ve 3. ölçüm için birer barkod seçin.").show(); return; }

        let selectedVals = [m1, m2, m3];
        if (blank) selectedVals.push(blank);
        
        let uniqueVals = new Set(selectedVals);
        if (uniqueVals.size !== selectedVals.length) { $('#mergeWarningBox').text("Hata: Aynı barkodu birden fazla ölçüme atayamazsınız!").show(); return; }

        window.currentVocMergeData = { m1: m1.split('|'), m2: m2.split('|'), m3: m3.split('|'), blank: blank ? blank.split('|') : null };
        window.isVocMergeMode = true;

        let vocMergeModalEl = document.getElementById('vocMergeModal');
        let vocMergeModal = bootstrap.Modal.getInstance(vocMergeModalEl);
        
        $(vocMergeModalEl).one('hidden.bs.modal', function () {
            let mainSampleId = window.currentVocMergeData.m1[0];
            let mainParamId = window.currentVocMergeData.m1[1];
            
            let btnSubs = $(`.btn-open-subs[data-sample="${mainSampleId}"][data-param="${mainParamId}"]`);
            let btnToz  = $(`.btn-open-toz[data-sample="${mainSampleId}"][data-param="${mainParamId}"]`);
            let btnPm10 = $(`.btn-open-pm10[data-sample="${mainSampleId}"][data-param="${mainParamId}"]`);

            if(btnSubs.length) { 
                btnSubs.trigger('click'); 
            } else if(btnToz.length) { 
                btnToz.trigger('click'); 
            } else if(btnPm10.length) { 
                btnPm10.trigger('click'); 
            } else { 
                toastr.error("Ana barkod tabloda bulunamadı! Lütfen manuel olarak ilk barkodun giriş butonuna tıklayın."); 
            }
        });

        vocMergeModal.hide();
        toastr.success('Eşleştirme başarılı! Şimdi formül/tartım değerlerini girin.');
    });

    $(document).on('click', '#btnMagicFill_opt', function() {
        if(!confirm('Henüz değer girilmemiş (bekleyen) tüm analizlere otomatik olarak "0.0001" değeri atanacaktır. Onaylıyor musunuz?')) return;
        let $btn = $(this);
        let origHtml = $btn.html();
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i> Oto Dolum Yapılıyor...');
        
        setTimeout(function() {
            let fillCount = 0;
            processedAnalysisData.forEach(item => {
                if (!item.isFilled) {
                    if (item.hasSubParams) {
                        let results = [];
                        let currentSample = item.sample;
                        let selectedSubs = currentSample && currentSample.selected_sub_parameters ? currentSample.selected_sub_parameters : [];
                        
                        let existingParsed = [];
                        try { existingParsed = JSON.parse(item.rValue); if(!Array.isArray(existingParsed)) existingParsed = []; } catch(e) {}

                        item.parameter.sub_parameters.forEach(sub => {
                            if (selectedSubs && selectedSubs.length > 0) {
                                if (!selectedSubs.map(String).includes(String(sub.id))) return; 
                            }
                            
                            let ex = existingParsed.find(x => x.id == sub.id) || {};
                            results.push({
                                id: sub.id, name: sub.name, code: sub.code || '',
                                value: '0.0001', device_value: '0.002', volume_value: '0.05',
                                cf1: ex.cf1, cf2: ex.cf2, cf3: ex.cf3, ct: ex.ct,
                                m1: '0.0001', m2: '0.0001', m3: '0.0001',
                                vf1: ex.vf1 || '1.0', vf2: ex.vf2 || '1.0', vf3: ex.vf3 || '1.0', vt: ex.vt,
                                m1_barcode: ex.m1_barcode, m2_barcode: ex.m2_barcode, m3_barcode: ex.m3_barcode, blank_barcode: ex.blank_barcode,
                                uncertainty: '', note: 'Ham data (Dosya) baz alındı.'
                            });
                        });
                        item.rValue = JSON.stringify(results);
                    } else {
                        item.rValue = '0.0001';
                    }
                    item.rNote = 'Ham data (Dosya) baz alındı.';
                    item.isFilled = true;
                    fillCount++;
                }
            });
            runManualFilter_opt(currentPage_opt);
            updateDashboardCounts();
            if(fillCount > 0) toastr.success(fillCount + ' adet bekleyen parametreye anında "0.0001" değeri atandı.', 'Sihir Tamamlandı 🪄');
            else toastr.info('Doldurulacak boş parametre bulunamadı.', 'Bilgi');
            $btn.prop('disabled', false).html(origHtml);
        }, 50); 
    });

    $('#btnSaveBulkResults').on('click', function() {
        let btn = $(this); let origHtml = btn.html();
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> LÜTFEN BEKLEYİN, KAYDEDİLİYOR...');

        let postData = { _token: $('meta[name="csrf-token"]').attr('content') || "{{ csrf_token() }}" };
        processedAnalysisData.forEach(item => {
            let finalValue = item.rValue;
            
            if(finalValue && typeof finalValue === 'string' && finalValue.includes('type":"m1"')) {
                try {
                    let check = JSON.parse(finalValue);
                    finalValue = JSON.stringify(check);
                } catch(e) {}
            }

            postData[`results[${item.sample.id}][${item.parameter.id}][value]`] = finalValue;
            postData[`results[${item.sample.id}][${item.parameter.id}][uncertainty]`] = item.rUncert || '';
            postData[`results[${item.sample.id}][${item.parameter.id}][note]`] = item.rNote || '';

            if (item.children && item.children.length > 0) {
                item.children.forEach(child => {
                    let childVal = child.rValue === '' || child.rValue == null ? '[BİRLEŞTİRİLDİ]' : child.rValue;
                    postData[`results[${child.sample.id}][${child.parameter.id}][value]`] = childVal;
                    postData[`results[${child.sample.id}][${child.parameter.id}][uncertainty]`] = child.rUncert || '';
                    postData[`results[${child.sample.id}][${child.parameter.id}][note]`] = child.rNote || '';
                });
            }
        });

        $.ajax({
            url: "/admin/test-management/save-bulk-results/" + currentOfferId,
            type: "POST", data: postData,
            success: function(res) {
                if(res.status === 'success') { toastr.success(res.message); fetchAndRenderData(); } 
                else if(res.status === 'info') toastr.info(res.message); 
                else toastr.error(res.message);
            },
            error: function(xhr) { 
                let errMsg = 'Kayıt işlemi başarısız oldu.';
                if(xhr.responseJSON && xhr.responseJSON.message) errMsg += '<br><small><b>Detay:</b> ' + xhr.responseJSON.message + '</small>';
                toastr.error(errMsg, 'Hata', {timeOut: 10000}); 
            },
            complete: function() { btn.prop('disabled', false).html(origHtml); }
        });
    });

    $('#btnCompleteOffer').click(function() {
        if(!currentOfferId) return;
        updateDashboardCounts();
        let total = parseInt($('#countTotal').text()) || 0;
        let entered = parseInt($('#countEntered').text()) || 0;
        if (total === 0 || entered < total) {
            toastr.warning('Raporlamaya göndermeden önce TÜM analizlere (' + entered + '/' + total + ') sonuç değeri girmelisiniz. Eksik: ' + (total - entered) + ' adet.', 'Eksik Sonuç');
            return;
        }

        if(confirm('TÜM numunelerin TÜM parametre sonuçlarını girdiğinizden emin misiniz? Onaylarsanız numuneler Raporlama departmanına aktarılacaktır.')) {
            let btn = $(this); let origHtml = btn.html();
            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> BEKLEYİN...');

            $.ajax({
                url: "/admin/test-management/complete-offer-analysis/" + currentOfferId,
                type: "POST", data: { _token: $('meta[name="csrf-token"]').attr('content') || "{{ csrf_token() }}" },
                success: function(res) {
                    if(res.status === 'success') {
                        toastr.success(res.message); $('#analysisModal').modal('hide');
                        setTimeout(() => location.reload(), 1500);
                    } else { toastr.error(res.message); btn.prop('disabled', false).html(origHtml); }
                },
                error: function() { toastr.error('Hata oluştu.'); btn.prop('disabled', false).html(origHtml); }
            });
        }
    });

    $(document).on('submit', '#globalUploadForm', function(e) {
        e.preventDefault();
        let formData = new FormData(this);
        let btn = $('#btnUploadGlobal');
        let origHtml = btn.html();
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i> YÜKLENİYOR...');

        $.ajax({
            url: "/admin/test-management/upload-offer-raw-data/" + currentOfferId,
            type: "POST", data: formData, processData: false, contentType: false,
            success: function(res) {
                if(res.status === 'success') {
                    toastr.success(res.message);
                    drawFiles(res.raw_files); 
                    $('input[name="raw_data_files[]"]').val(''); 
                } else { toastr.error(res.message); }
            },
            error: function() { toastr.error('Yükleme başarısız.'); },
            complete: function() { btn.prop('disabled', false).html('<i class="fas fa-upload me-1"></i> DOSYALARI YÜKLE'); }
        });
    });

    function drawFiles(filesArray) {
        let fileHtml = '';
        if (filesArray && filesArray.length > 0) {
            fileHtml += `
            <div class="w-100 mb-2 border-bottom pb-2 d-flex justify-content-between align-items-center">
                <span class="text-muted small fw-bold"><i class="fas fa-info-circle text-info"></i> Silmek istediğiniz evrakları yandaki kutulardan seçebilirsiniz.</span>
                <button type="button" class="btn btn-sm btn-danger shadow-sm" id="btnDeleteSelectedFiles" style="display:none;">
                    <i class="fas fa-trash-alt me-1"></i> Seçilenleri Sil (<span id="selectedFileCount">0</span>)
                </button>
            </div>
            <div class="d-flex flex-wrap gap-2 w-100">`;

            filesArray.forEach((file, index) => {
                if(file && typeof file === 'string') {
                    let cleanFile = file.replace(/^[\\"'\[\]]+|[\\"'\[\]]+$/g, '');
                    if (cleanFile.trim() !== '') {
                        let fileName = cleanFile.split('/').pop();
                        let displayName = fileName;
                        let match = fileName.match(/^\d+_[a-zA-Z0-9]+_(.*)$/);
                        if(match) displayName = match[1];
                        else if (fileName.length > 30) displayName = 'Evrak ' + (index + 1) + ' (' + fileName.substring(0, 8) + '...)';

                        fileHtml += `
                        <div class="btn-group shadow-sm file-item-group">
                            <div class="input-group-text bg-white border-info">
                                <input class="form-check-input mt-0 file-delete-checkbox" type="checkbox" value="${cleanFile}" style="cursor:pointer;">
                            </div>
                            <a href="/storage/${cleanFile}" target="_blank" class="btn btn-outline-info border-start-0 text-dark fw-bold" title="${displayName}">
                                <i class="fas fa-file-download text-primary me-1"></i> 
                                <span style="max-width: 180px; display: inline-block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: bottom;">${displayName}</span>
                            </a>
                            <button type="button" class="btn btn-outline-danger btn-delete-single-file" data-file="${cleanFile}" title="Bu Evrağı Sil"><i class="fas fa-times"></i></button>
                        </div>`;
                    }
                }
            });
            fileHtml += `</div>`;
        } else {
            fileHtml = '<span class="text-muted fst-italic">Henüz evrak yüklenmemiş.</span>';
        }
        $('#globalFileLink').html(fileHtml);
    }

    $(document).on('change', '.file-delete-checkbox', function() {
        let checkedCount = $('.file-delete-checkbox:checked').length;
        if (checkedCount > 0) {
            $('#selectedFileCount').text(checkedCount);
            $('#btnDeleteSelectedFiles').fadeIn('fast');
        } else {
            $('#btnDeleteSelectedFiles').fadeOut('fast');
        }
    });

    $(document).on('click', '.btn-delete-single-file', function() {
        let file = $(this).data('file');
        if (confirm('Bu evrak dosyasını kalıcı olarak silmek istediğinize emin misiniz?')) executeFileDelete([file]);
    });

    $(document).on('click', '#btnDeleteSelectedFiles', function() {
        let filesToDelete = [];
        $('.file-delete-checkbox:checked').each(function() { filesToDelete.push($(this).val()); });
        if (filesToDelete.length > 0 && confirm(filesToDelete.length + ' adet evrak dosyasını kalıcı olarak silmek istediğinize emin misiniz?')) {
            executeFileDelete(filesToDelete);
        }
    });

    function executeFileDelete(filesArray) {
        let $bulkBtn = $('#btnDeleteSelectedFiles');
        let btnStr = filesArray.length > 1 ? $bulkBtn.html() : '<i class="fas fa-times"></i>';
        
        if(filesArray.length > 1) $bulkBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> SİLİNİYOR...');

        $.ajax({
            url: "/admin/test-management/delete-offer-raw-data/" + currentOfferId,
            type: "POST", 
            data: { _token: $('meta[name="csrf-token"]').attr('content') || "{{ csrf_token() }}", _method: "DELETE", files_to_delete: filesArray },
            success: function(res) {
                if(res.status === 'success') {
                    toastr.success(res.message);
                    drawFiles(res.raw_files); 
                    $('#btnDeleteSelectedFiles').fadeOut('fast');
                    $('#selectedFileCount').text('0');
                } else {
                    toastr.error(res.message);
                    if(filesArray.length > 1) $bulkBtn.prop('disabled', false).html(btnStr);
                }
            },
            error: function(xhr) {
                let errMsg = 'Silme işlemi başarısız oldu.';
                if(xhr.responseJSON && xhr.responseJSON.message) errMsg += '<br><small><b>Hata Detayı:</b> ' + xhr.responseJSON.message + '</small>';
                toastr.error(errMsg, 'Sunucu Hatası', {timeOut: 10000, escapeHtml: false});
                if(filesArray.length > 1) $bulkBtn.prop('disabled', false).html(btnStr);
            }
        });
    }

    $(document).on('input', '#subParamSearchInput', function() {
        let searchText = $(this).val().toLocaleLowerCase('tr-TR');
        let rows = $('#subResultTbody tr.sub-result-row');

        if (searchText.length >= 3) {
            let matchCount = 0;
            rows.each(function() {
                let paramName = String($(this).data('name')).toLocaleLowerCase('tr-TR');
                let paramCode = $(this).data('code') ? String($(this).data('code')).toLocaleLowerCase('tr-TR') : '';

                if (paramName.includes(searchText) || paramCode.includes(searchText)) {
                    $(this).show(); matchCount++;
                } else { $(this).hide(); }
            });
            
            if(matchCount > 0) $('#subParamSearchInfo').html(`<span class="text-success fw-bold"><i class="fas fa-check"></i> ${matchCount} eşleşme bulundu.</span>`);
            else $('#subParamSearchInfo').html(`<span class="text-danger fw-bold"><i class="fas fa-times"></i> Eşleşen parametre yok.</span>`);
        } else {
            rows.show();
            $('#subParamSearchInfo').html('Tüm parametreler listeleniyor.');
        }
    });
    
    $('.select2-subparam').select2({
        dropdownParent: $('#subParameterModal'), 
        theme: 'bootstrap-5', 
        placeholder: "Parametre Arayın (Örn: Ağır Metal)", 
        allowClear: true, 
        minimumInputLength: 0,
        ajax: {
            url: "{{ route('admin.samples.search-parameters') }}",
            dataType: 'json',
            delay: 250,
            data: function (params) { return { q: params.term }; },
            processResults: function (data) { return { results: data.results }; },
            cache: true
        }
    });

    $('#mainParamSelect').on('change', function() {
        let id = $(this).val();
        if(!id) { 
            $('#btnToggleAddForm').prop('disabled', true);
            $('#subParamAddSection').slideUp(); 
            $('#subParamsTbody').html('<tr><td colspan="4" class="text-center py-4 text-muted">Lütfen bir parametre seçin.</td></tr>'); 
            return; 
        }
        $('#btnToggleAddForm').prop('disabled', false);
        loadSubParameters(id);
    });

    $('#btnToggleAddForm').on('click', function() { $('#subParamAddSection').slideToggle(); });

    function loadSubParameters(id) {
        $('#subParamsTbody').html('<tr><td colspan="4" class="text-center py-4"><i class="fas fa-spinner fa-spin"></i> Yükleniyor...</td></tr>');
        let url = "{{ route('admin.test-management.sub-parameters.get', ':id') }}".replace(':id', id);
        
        $.get(url, function(res) {
            if(res.status === 'success') {
                let html = '';
                if(res.data.length === 0) { 
                    html = '<tr><td colspan="4" class="text-center py-4 text-muted fst-italic">Bu ana parametreye ait alt parametre bulunamadı.</td></tr>'; 
                } else {
                    res.data.forEach(sub => {
                        html += `
                        <tr>
                            <td class="fw-bold ps-3">${sub.name}</td>
                            <td class="text-danger fw-bold">${formatChem(sub.code) || '-'}</td>
                            <td class="text-center text-muted">${sub.unit || '-'}</td>
                            <td class="text-center pe-3">
                                <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2 btn-edit-sub me-1" data-id="${sub.id}" data-code="${sub.code || ''}" data-name="${sub.name}" data-unit="${sub.unit || ''}" title="Düzenle"><i class="fas fa-edit"></i></button>
                                <button type="button" class="btn btn-sm btn-outline-danger py-0 px-2 btn-delete-sub" data-id="${sub.id}" title="Sil"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>`;
                    });
                }
                $('#subParamsTbody').html(html);
            }
        });
    }

    $(document).on('click', '.btn-edit-sub', function() {
        $('#edit_sub_param_id').val($(this).data('id'));
        $('#sub_code').val($(this).data('code'));
        $('#sub_name').val($(this).data('name'));
        $('#sub_unit').val($(this).data('unit'));
        
        $('#btnSubmitSubParam').removeClass('btn-success').addClass('btn-warning text-dark').html('<i class="fas fa-edit"></i> GÜNCELLE');
        $('#btnCancelEdit').show();
        $('#subParamAddSection').slideDown(); 
    });

    $('#btnCancelEdit').on('click', function() {
        $('#edit_sub_param_id').val('');
        $('#sub_code, #sub_name, #sub_unit').val('');
        $('#btnSubmitSubParam').removeClass('btn-warning text-dark').addClass('btn-success').html('<i class="fas fa-save"></i> KAYDET');
        $(this).hide();
    });

    $('#addSubParamForm').on('submit', function(e) {
        e.preventDefault(); 
        let mainId = $('#mainParamSelect').val();
        let editId = $('#edit_sub_param_id').val(); 
        if(!mainId) return;

        let btn = $('#btnSubmitSubParam'); 
        let origHtml = btn.html();
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i>');

        let isEdit = (editId !== "");
        let url = isEdit ? "/admin/test-management/sub-parameters/" + editId : "{{ route('admin.test-management.sub-parameters.store') }}";

        $.ajax({
            url: url, 
            type: "POST", 
            data: { 
                _token: $('meta[name="csrf-token"]').attr('content') || "{{ csrf_token() }}", 
                _method: isEdit ? "PUT" : "POST", 
                scope_parameter_id: mainId, 
                code: $('#sub_code').val(), 
                name: $('#sub_name').val(), 
                unit: $('#sub_unit').val() 
            },
            success: function(res) {
                if(res.status === 'success') { 
                    toastr.success(res.message); 
                    $('#btnCancelEdit').click(); 
                    if(!isEdit) $('#subParamAddSection').slideUp(); 
                    loadSubParameters(mainId); 
                } else { toastr.error(res.message); }
            },
            error: function(xhr) { 
                let errMsg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Kayıt başarısız! Form verilerini kontrol edin.';
                toastr.error(errMsg); 
            },
            complete: function() { btn.prop('disabled', false).html(origHtml); }
        });
    });

    $(document).on('click', '.btn-delete-sub', function() {
        if(confirm('Bu alt parametreyi silmek istediğinize emin misiniz?')) {
            let id = $(this).data('id');
            let mainId = $('#mainParamSelect').val();
            let url = "{{ route('admin.test-management.sub-parameters.destroy', ':id') }}".replace(':id', id);
            
            $.ajax({ 
                url: url, type: 'DELETE', data: { _token: $('meta[name="csrf-token"]').attr('content') || "{{ csrf_token() }}" }, 
                success: function(res) { 
                    if(res.status === 'success') { toastr.success(res.message); loadSubParameters(mainId); }
                } 
            });
        }
    });

    $('#sub_code').on('input', function() {
        let val = $(this).val();
        const subMap = { '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉' };
        let newVal = val.replace(/[0-9]/g, function(match) { return subMap[match]; });
        if (val !== newVal) $(this).val(newVal);
    });

}); 

$(document).on('click', '.btn-loq', function() {
    let input = $(this).siblings('.sub-device-val');
    input.val('<loq').trigger('input'); 
});

$(document).on('input', '.sub-device-val, .sub-volume-val', function() {
    let row = $(this).closest('tr'); 
    
    let cihazStr = String(row.find('.sub-device-val').val() || '').trim();
    let hacimStr = String(row.find('.sub-volume-val').val() || '').trim();
    
    if (cihazStr.toLowerCase() === '<loq' || cihazStr.toLowerCase() === 'loq') {
        row.find('.sub-val').val('<loq');
        return;
    }
    
    let cihaz = parseFloat(cihazStr.replace(',', '.')) || 0;
    let hacim = parseFloat(hacimStr.replace(',', '.')) || 0;
    
    if (cihazStr !== '' && hacimStr !== '' && !isNaN(cihaz) && !isNaN(hacim)) {
        let sonuc = parseFloat((cihaz * hacim).toFixed(10));
        row.find('.sub-val').val(sonuc);
    } else {
        row.find('.sub-val').val('');
    }
});
</script>
@endpush