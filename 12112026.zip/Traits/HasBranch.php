<?php

namespace App\Traits;

use App\Scopes\BranchScope;
use Modules\Branches\Models\Branch;

trait HasBranch
{
    /**
     * Trait boot edildiğinde çalışacak metot
     */
    protected static function bootHasBranch()
    {
        // 1. LİSTELEME: Okuma işlemlerinde (Select) Global Scope'u devreye sok
        static::addGlobalScope(new BranchScope);

        // 2. KAYDETME: Yeni bir kayıt (Insert) oluşturulurken araya gir
        static::creating(function ($model) {
            // Eğer modelde branch_id manuel girilmemişse ve session'da şube varsa otomatik ata
            if (session()->has('active_branch_id') && empty($model->branch_id)) {
                $model->branch_id = session('active_branch_id');
            }
        });
    }

    /**
     * Her şubeye bağlı modelin ana şube ile olan ilişkisi
     */
    public function branch()
    {
        return $this->belongsTo(Branch::class, 'branch_id');
    }
}