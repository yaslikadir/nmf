<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

trait HasPermissionScope
{
    /**
     * Modül bazlı otomatik yetki filtresi (Level 1, 2, 3)
     */
    public function scopeWithPermission(Builder $builder, string $moduleKey)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();

        // 1. Giriş yapılmamışsa veya Admin ise filtreleme yapma
        if (!$user || $user->isAdmin()) {
            return $builder;
        }

        // 2. Kullanıcının aktif rolündeki yetki paketini çekiyoruz
        $permission = \App\Models\RolePermission::where('role_id', $user->active_role_id)
            ->whereHas('module', fn($q) => $q->where('module_key', $moduleKey))
            ->first();

        // 3. Yetki tanımlanmışsa Seviye Kontrolüne Başla
        if ($permission) {
            $level = (int)$permission->view_level;
            
            // Modelde özel bir sahip sütunu belirtilmişse onu al, yoksa varsayılan 'created_by' kullan
            // (Örneğin PurchaseRequest modelinde ownerColumn = 'requester_id' ayarladık)
            $ownerCol = $builder->getModel()->ownerColumn ?? 'created_by';

            return match ($level) {
                // SEVİYE 1: Kendi Oluşturdukları VEYA Kendisine Atananlar
                1 => $builder->where(function ($query) use ($user, $ownerCol, $builder) {
                    // 1A. Kaydı oluşturan kişi kendi mi?
                    $query->where($ownerCol, $user->id);
                    
                    // 1B. Eğer bu modelde 'users' (atanan personeller) ilişkisi varsa (Örn: Ölçüm Planı) onu da kontrol et
                    if (method_exists($builder->getModel(), 'users')) {
                        $query->orWhereHas('users', function ($q) use ($user) {
                            $q->where('users.id', $user->id); 
                        });
                    }
                }),

                // SEVİYE 2: Grup/Departman Yetkisi
                2 => $user->department_id 
                    ? $builder->whereHas('creator', function ($q) use ($user) {
                        $q->where('department_id', $user->department_id);
                      })
                    : $builder->where($ownerCol, $user->id), // Departmanı yoksa Level 1'e düşür (Güvenlik)

                // SEVİYE 3: Tüm Kayıtlar
                3 => $builder,

                // TANIMSIZ: Güvenlik Kalkanı
                default => $builder->whereRaw('1=0'),
            };
        }

        // Hiç yetki satırı yoksa veriyi tamamen gizle
        return $builder->whereRaw('1=0');
    }
}