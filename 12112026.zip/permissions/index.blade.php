@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    <form action="{{ route('admin.permissions.store') }}" method="POST" id="rbacForm">
        @csrf
        
        {{-- ÜST BAR: ROL SEÇİMİ VE KAYDET BUTONU --}}
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body bg-white d-flex flex-wrap justify-content-between align-items-center gap-3 py-3 rounded">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-primary bg-opacity-10 text-primary rounded p-2">
                        <i class="fas fa-user-shield fa-lg"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold text-dark">Rol Bazlı Sidebar Menü & Yetki Yönetimi</h5>
                        <small class="text-muted">Rolü seçin, sol menüde (Sidebar) hangi ekranları göreceğini ve yetki seviyesini belirleyin.</small>
                    </div>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <select name="role_id" class="form-select form-select-sm border-primary fw-bold text-primary shadow-sm" style="min-width: 240px; height: 38px;" onchange="window.location.href='?role_id=' + this.value">
                        <option value="">-- Yönetilecek Rolü Seçin --</option>
                        <?php foreach($roles as $role): ?>
                            <option value="{{ $role->id }}" {{ $selectedRoleId == $role->id ? 'selected' : '' }}>
                                ROL: {{ mb_strtoupper($role->name) }}
                            </option>
                        <?php endforeach; ?>
                    </select>

                    @if($selectedRoleId)
                        <button type="submit" class="btn btn-success btn-sm px-4 fw-bold shadow-sm" style="height: 38px;">
                            <i class="fas fa-save me-1"></i> ROL YETKİLERİNİ KAYDET
                        </button>
                        <a href="{{ route('admin.permissions.index') }}" class="btn btn-danger text-white btn-sm px-3 d-flex align-items-center shadow-sm" style="height: 38px;">
                            VAZGEÇ
                        </a>
                    @endif
                </div>
            </div>
        </div>

        @if($selectedRoleId)
            @php
                $targetRole = \App\Models\Role::find($selectedRoleId);
                $rawMenuPerms = $targetRole ? ($targetRole->menu_permissions ?? []) : [];
                if (is_string($rawMenuPerms)) {
                    $rawMenuPerms = json_decode($rawMenuPerms, true) ?? [];
                }

                // Birebir sidebar_user.blade.php sırasıyla tüm menü ağacı
                $sidebarSections = [
                    [
                        'heading' => '1. MÜŞTERİ İLİŞKİLERİ & SATIŞ YÖNETİMİ',
                        'icon'    => 'fas fa-users text-success',
                        'items'   => [
                            ['type' => 'module', 'group' => 'Müşteri Yönetimi', 'key' => 'customers',       'title' => 'Müşteriler'],
                            ['type' => 'module', 'group' => 'Müşteri Yönetimi', 'key' => 'contacts',        'title' => 'Kontaklar'],
                            ['type' => 'module', 'group' => 'Müşteri Yönetimi', 'key' => 'activities',      'title' => 'Görüşme Kayıtları'],
                            ['type' => 'module', 'group' => 'Toplantı & Ajanda','key' => 'meetings',        'title' => 'Toplantı & Ajanda (Dashboard / Liste)'],
                            ['type' => 'module', 'group' => 'Satış Yönetimi',   'key' => 'requests',        'title' => 'Müşteri Talepleri'],
                            ['type' => 'module', 'group' => 'Satış Yönetimi',   'key' => 'offers',          'title' => 'Teklifler'],
                            ['type' => 'module', 'group' => 'Satış Yönetimi',   'key' => 'offer_templates', 'title' => 'Teklif Şablonları'],
                        ]
                    ],
                    [
                        'heading' => '2. LABORATUVAR (LIMS) - NUMUNE & ANALİZ',
                        'icon'    => 'fas fa-flask text-danger',
                        'items'   => [
                            ['type' => 'module', 'group' => 'Numune Yönetimi', 'key' => 'sample_management',   'title' => 'Barkod Oluştur / Kabul & Takip / BKM'],
                            ['type' => 'module', 'group' => 'Numune Yönetimi', 'key' => 'sample_transfers',    'title' => 'Transfer & Lojistik'],
                            ['type' => 'module', 'group' => 'Numune Yönetimi', 'key' => 'sample_disposals',    'title' => 'Numune İmha'],
                            ['type' => 'module', 'group' => 'Numune Yönetimi', 'key' => 'storage_locations',   'title' => 'Depo Tanımları'],
                            ['type' => 'module', 'group' => 'Analiz & Rapor',  'key' => 'sample_preparations', 'title' => 'Ön İşlem & Hazırlık'],
                            ['type' => 'module', 'group' => 'Analiz & Rapor',  'key' => 'test_management',     'title' => 'Analiz İş Emirleri / Analiz Görevlerim'],
                            ['type' => 'module', 'group' => 'Analiz & Rapor',  'key' => 'reporting',           'title' => 'Raporlama & Onay'],
                            ['type' => 'module', 'group' => 'Analiz & Rapor',  'key' => 'methods',             'title' => 'Metot Yönetimi'],
                            ['type' => 'module', 'group' => 'Analiz & Rapor',  'key' => 'parameters',          'title' => 'Parametreler'],
                        ]
                    ],
                    [
                        'heading' => '3. PLANLAMA & SAHA OPERASYON (İŞ PLANLAMA)',
                        'icon'    => 'fas fa-calendar-check text-primary',
                        'items'   => [
                            ['type' => 'module', 'group' => 'İş Planlama', 'key' => 'planning',          'title' => 'Ölçüm Planlama Listesi'],
                            ['type' => 'module', 'group' => 'İş Planlama', 'key' => 'planning_calendar', 'title' => 'Ölçüm Takvimi'],
                            ['type' => 'module', 'group' => 'İş Planlama', 'key' => 'tasks',             'title' => 'Görev Yönetimi'],
                        ]
                    ],
                    [
                        'heading' => '4. KAYNAK YÖNETİMİ (STOK & CİHAZ)',
                        'icon'    => 'fas fa-boxes text-warning',
                        'items'   => [
                            ['type' => 'module', 'group' => 'Stok & Cihaz', 'key' => 'materials', 'title' => 'RM / CRM / Kimyasal & Stok Hareketleri'],
                            ['type' => 'module', 'group' => 'Stok & Cihaz', 'key' => 'devices',   'title' => 'Cihazlar & Kalibrasyon'],
                        ]
                    ],
                    [
                        'heading' => '5. SATIN ALMA & LOJİSTİK',
                        'icon'    => 'fas fa-shopping-cart text-danger',
                        'items'   => [
                            ['type' => 'module', 'group' => 'Satın Alma', 'key' => 'suppliers', 'title' => 'Tedarikçiler'],
                            ['type' => 'module', 'group' => 'Satın Alma', 'key' => 'purchase',  'title' => 'Satın Alma (Seviye 1: Sadece Talepler | Seviye 2-3: Teklif & Siparişler Dahil)'],
                        ]
                    ],
                    [
                        'heading' => '6. KALİTE YÖNETİMİ (QMS)',
                        'icon'    => 'fas fa-certificate text-info',
                        'items'   => [
                            ['type' => 'module', 'group' => 'Kalite (QMS)', 'key' => 'qms_documents', 'title' => 'Doküman Yönetimi'],
                            ['type' => 'module', 'group' => 'Kalite (QMS)', 'key' => 'qms_changes',   'title' => 'Değişiklik Yönetimi'],
                            ['type' => 'module', 'group' => 'Kalite (QMS)', 'key' => 'qms_trainings', 'title' => 'Eğitim Yönetimi (Seviye 1: Eğitimlerim | Seviye 2-3: Tüm Eğitim/Plan/Talepler)'],
                            ['type' => 'module', 'group' => 'Kalite (QMS)', 'key' => 'qms_audits',    'title' => 'Denetimler (Audit)'],
                            ['type' => 'module', 'group' => 'Kalite (QMS)', 'key' => 'qms_capas',     'title' => 'DÖF / CAPA'],
                            ['type' => 'module', 'group' => 'Kalite (QMS)', 'key' => 'qms_feedbacks', 'title' => 'Geri Bildirimler & Linkler'],
                            ['type' => 'module', 'group' => 'Kalite (QMS)', 'key' => 'qms_risks',     'title' => 'Risk & Acil Durum Planları'],
                        ]
                    ],
                    [
                        'heading' => '7. OPERASYON & PROJE YÖNETİMİ',
                        'icon'    => 'fas fa-project-diagram text-primary',
                        'items'   => [
                            ['type' => 'module', 'group' => 'Proje Yönetimi', 'key' => 'project_management', 'title' => 'Proje Yönetimi (PM Paneli, Projeler & Görevler)'],
                        ]
                    ],
                    [
                        'heading' => '8. HABERLEŞME (DUYURU & ENTEGRASYON)',
                        'icon'    => 'fas fa-rss text-warning',
                        'items'   => [
                            ['type' => 'menu', 'group' => 'Duyuru & Entegrasyon', 'key' => 'announcements_csb',    'title' => 'ÇŞB Duyuruları'],
                            ['type' => 'menu', 'group' => 'Duyuru & Entegrasyon', 'key' => 'announcements_turkak', 'title' => 'TÜRKAK Duyuruları'],
                            ['type' => 'menu', 'group' => 'Duyuru & Entegrasyon', 'key' => 'turkak_documents',     'title' => 'Asist Dokümanlarım'],
                            ['type' => 'menu', 'group' => 'Duyuru & Entegrasyon', 'key' => 'bots',                 'title' => 'Robot Yönetimi'],
                        ]
                    ],
                    [
                        'heading' => '9. SİSTEM (YÖNETİM PANELİ)',
                        'icon'    => 'fas fa-cogs text-secondary',
                        'items'   => [
                            ['type' => 'module', 'group' => 'Yönetim Paneli', 'key' => 'users',       'title' => 'Kullanıcılar'],
                            ['type' => 'menu',   'group' => 'Yönetim Paneli', 'key' => 'personnel',   'title' => 'Personel Listesi'],
                            ['type' => 'menu',   'group' => 'Yönetim Paneli', 'key' => 'departments', 'title' => 'Departmanlar'],
                            ['type' => 'menu',   'group' => 'Yönetim Paneli', 'key' => 'permissions', 'title' => 'Yetki & Roller'],
                            ['type' => 'module', 'group' => 'Yönetim Paneli', 'key' => 'settings',    'title' => 'Genel Ayarlar'],
                            ['type' => 'menu',   'group' => 'Yönetim Paneli', 'key' => 'logs',        'title' => 'İşlem Kayıtları (Log)'],
                            ['type' => 'menu',   'group' => 'Yönetim Paneli', 'key' => 'definitions', 'title' => 'Sistem Tanımları'],
                        ]
                    ],
                ];
            @endphp

            {{-- HIZLI TOPLU İŞLEM ÇUBUĞU --}}
            <div class="d-flex justify-content-between align-items-center mb-3 bg-light p-2 px-3 rounded border">
                <div class="small text-muted">
                    <i class="fas fa-lightbulb text-warning me-1"></i>
                    <strong>Kullanım:</strong> "Menüde Görünsün" anahtarını açtığınızda ilgili menü sol barda aktif olur, kapattığınızda gizlenir.
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-xs btn-outline-primary fw-bold" onclick="toggleAllMenus(true)">
                        <i class="fas fa-check-double me-1"></i> Tüm Menüleri Aç
                    </button>
                    <button type="button" class="btn btn-xs btn-outline-secondary fw-bold" onclick="toggleAllMenus(false)">
                        <i class="fas fa-eye-slash me-1"></i> Tümünü Gizle
                    </button>
                </div>
            </div>

            {{-- SIDEBAR BÖLÜMLERİ LİSTESİ --}}
            <?php foreach($sidebarSections as $sIndex => $section): ?>
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-header bg-dark text-white py-2 px-3 d-flex justify-content-between align-items-center">
                        <span class="fw-bold small">
                            <i class="{{ $section['icon'] }} me-2"></i>{{ $section['heading'] }}
                        </span>
                        <span class="badge bg-secondary">{{ count($section['items']) }} Menü</span>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover mb-0 align-middle">
                                <thead class="bg-light text-secondary" style="font-size: 0.72rem;">
                                    <tr>
                                        <th class="ps-3" width="16%">ÜST MENÜ</th>
                                        <th width="26%">SIDEBAR ALT MENÜ ADI</th>
                                        <th class="text-center" width="12%">MENÜDE GÖRÜNSÜN</th>
                                        <th class="text-center" width="14%">VERİ GÖRÜNÜRLÜĞÜ</th>
                                        <th class="text-center" width="8%">EKLE</th>
                                        <th class="text-center" width="10%">DÜZENLE</th>
                                        <th class="text-center" width="10%">SİL</th>
                                        <th class="text-center" width="6%">İNDİR</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($section['items'] as $item): ?>
                                        <?php if($item['type'] === 'module'): ?>
                                            <?php
                                                $mod = $modules[$item['key']] ?? null;
                                                $perm = ($mod && isset($permissions[$mod->id])) ? $permissions[$mod->id] : null;
                                                $vLevel = $perm ? (int) $perm->view_level : 0;
                                                $uLevel = $perm ? (int) $perm->update_level : 0;
                                                $dLevel = $perm ? (int) $perm->delete_level : 0;
                                                $isVisible = $vLevel > 0;
                                            ?>
                                            <?php if($mod): ?>
                                            <tr class="perm-row {{ $isVisible ? 'table-active-row' : 'opacity-75' }}" data-mod-id="{{ $mod->id }}">
                                                <td class="ps-3 small text-muted fw-bold">{{ $item['group'] }}</td>
                                                <td>
                                                    <div class="fw-bold text-dark" style="font-size: 0.85rem;">{{ $item['title'] }}</div>
                                                    <code class="text-muted" style="font-size: 0.68rem;">{{ $item['key'] }}</code>
                                                </td>
                                                <td class="text-center">
                                                    <div class="form-check form-switch d-inline-block m-0">
                                                        <input type="checkbox" class="form-check-input menu-visibility-switch" data-target-mod="{{ $mod->id }}" {{ $isVisible ? 'checked' : '' }}>
                                                    </div>
                                                </td>
                                                <td class="p-1">
                                                    <select name="perms[{{ $mod->id }}][view_level]" id="view_level_{{ $mod->id }}" class="form-select form-select-sm view-level-select {{ $isVisible ? 'border-primary text-primary fw-bold' : '' }}" data-mod-id="{{ $mod->id }}">
                                                        <option value="0" {{ $vLevel === 0 ? 'selected' : '' }}>⛔ Gizli (Yok)</option>
                                                        <option value="1" {{ $vLevel === 1 ? 'selected' : '' }}>👤 Sadece Kendi</option>
                                                        <option value="2" {{ $vLevel === 2 ? 'selected' : '' }}>🏢 Departmanı</option>
                                                        <option value="3" {{ $vLevel === 3 ? 'selected' : '' }}>🌍 Tümü (Şube)</option>
                                                    </select>
                                                </td>
                                                <td class="text-center">
                                                    <input type="checkbox" name="perms[{{ $mod->id }}][can_create]" class="form-check-input action-field-{{ $mod->id }}" value="1" {{ ($perm && $perm->can_create) ? 'checked' : '' }}>
                                                </td>
                                                <td class="p-1">
                                                    <select name="perms[{{ $mod->id }}][update_level]" class="form-select form-select-sm action-select-{{ $mod->id }}">
                                                        <option value="0" {{ $uLevel === 0 ? 'selected' : '' }}>⛔ Yok</option>
                                                        <option value="1" {{ $uLevel === 1 ? 'selected' : '' }}>👤 Kendi</option>
                                                        <option value="2" {{ $uLevel === 2 ? 'selected' : '' }}>🏢 Dept.</option>
                                                        <option value="3" {{ $uLevel === 3 ? 'selected' : '' }}>🌍 Tümü</option>
                                                    </select>
                                                </td>
                                                <td class="p-1">
                                                    <select name="perms[{{ $mod->id }}][delete_level]" class="form-select form-select-sm action-select-{{ $mod->id }}">
                                                        <option value="0" {{ $dLevel === 0 ? 'selected' : '' }}>⛔ Yok</option>
                                                        <option value="1" {{ $dLevel === 1 ? 'selected' : '' }}>👤 Kendi</option>
                                                        <option value="2" {{ $dLevel === 2 ? 'selected' : '' }}>🏢 Dept.</option>
                                                        <option value="3" {{ $dLevel === 3 ? 'selected' : '' }}>🌍 Tümü</option>
                                                    </select>
                                                </td>
                                                <td class="text-center">
                                                    <input type="checkbox" name="perms[{{ $mod->id }}][can_export]" class="form-check-input action-field-{{ $mod->id }}" value="1" {{ ($perm && $perm->can_export) ? 'checked' : '' }}>
                                                </td>
                                            </tr>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            {{-- SABİT MENÜ SATIRI --}}
                                            <?php
                                                $mKey = $item['key'];
                                                $mChecked = !empty($rawMenuPerms[$mKey]) && $rawMenuPerms[$mKey] == 1;
                                            ?>
                                            <tr class="perm-row {{ $mChecked ? 'table-active-row' : 'opacity-75' }}">
                                                <td class="ps-3 small text-muted fw-bold">{{ $item['group'] }}</td>
                                                <td>
                                                    <div class="fw-bold text-dark" style="font-size: 0.85rem;">{{ $item['title'] }}</div>
                                                    <span class="badge bg-light text-secondary border" style="font-size: 0.65rem;">Sabit Menü ({{ $mKey }})</span>
                                                </td>
                                                <td class="text-center">
                                                    <div class="form-check form-switch d-inline-block m-0">
                                                        <input class="form-check-input static-menu-switch" type="checkbox" name="menu_perms[{{ $mKey }}]" value="1" {{ $mChecked ? 'checked' : '' }}>
                                                    </div>
                                                </td>
                                                <td colspan="5" class="text-muted small ps-3">
                                                    <i class="fas fa-info-circle me-1 text-primary"></i>Sabit menü — Açıldığında sol menüde görünür ve sayfaya erişebilir.
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="sticky-bottom bg-white border-top p-3 text-end shadow-lg rounded-top mb-4">
                <button type="submit" class="btn btn-success px-5 fw-bold shadow">
                    <i class="fas fa-save me-2"></i> ROL YETKİLERİNİ KAYDET
                </button>
            </div>
        @else
            <div class="alert alert-info shadow-sm d-flex align-items-center p-4">
                <i class="fas fa-hand-point-up fa-2x me-3 text-primary"></i>
                <div>
                    <h6 class="mb-1 fw-bold">Lütfen Yukarıdan Bir Rol Seçin</h6>
                    <p class="mb-0 small">Rol seçtiğiniz anda sol menüdeki (Sidebar) tüm başlıklar ekrana gelecek ve tek tıkla hangi menüleri görüp göremeyeceğini seçebileceksiniz.</p>
                </div>
            </div>
        @endif
    </form>
</div>

@push('css')
<style>
    .table-active-row { background-color: #f0fdf4 !important; }
    .form-switch .form-check-input { width: 2.6em; height: 1.3em; cursor: pointer; }
    .form-select-sm { font-size: 0.75rem; }
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    // 1. Modül "Menüde Görünsün" Switch'i değiştiğinde:
    document.querySelectorAll('.menu-visibility-switch').forEach(function (sw) {
        sw.addEventListener('change', function () {
            const modId = this.getAttribute('data-target-mod');
            const selectEl = document.getElementById('view_level_' + modId);
            const row = this.closest('tr');

            if (this.checked) {
                // Açıldıysa ve 0 ise varsayılan olarak 3 (Tümü) yap
                if (selectEl.value === '0') {
                    selectEl.value = '3';
                }
                selectEl.classList.add('border-primary', 'text-primary', 'fw-bold');
                row.classList.add('table-active-row');
                row.classList.remove('opacity-75');
            } else {
                // Kapatıldıysa görünürlüğü ve alt yetkileri sıfırla
                selectEl.value = '0';
                selectEl.classList.remove('border-primary', 'text-primary', 'fw-bold');
                row.classList.remove('table-active-row');
                row.classList.add('opacity-75');

                document.querySelectorAll('.action-field-' + modId).forEach(cb => cb.checked = false);
                document.querySelectorAll('.action-select-' + modId).forEach(sel => sel.value = '0');
            }
        });
    });

    // 2. Veri Görünürlüğü (Select) manuel değiştirildiğinde Switch'i senkronize et:
    document.querySelectorAll('.view-level-select').forEach(function (sel) {
        sel.addEventListener('change', function () {
            const modId = this.getAttribute('data-mod-id');
            const sw = document.querySelector('.menu-visibility-switch[data-target-mod="' + modId + '"]');
            const row = this.closest('tr');

            if (parseInt(this.value) > 0) {
                if (sw) sw.checked = true;
                this.classList.add('border-primary', 'text-primary', 'fw-bold');
                row.classList.add('table-active-row');
                row.classList.remove('opacity-75');
            } else {
                if (sw) sw.checked = false;
                this.classList.remove('border-primary', 'text-primary', 'fw-bold');
                row.classList.remove('table-active-row');
                row.classList.add('opacity-75');
            }
        });
    });

    // 3. Sabit menü switch'i değiştiğinde satır rengini güncelle
    document.querySelectorAll('.static-menu-switch').forEach(function (sw) {
        sw.addEventListener('change', function () {
            const row = this.closest('tr');
            if (this.checked) {
                row.classList.add('table-active-row');
                row.classList.remove('opacity-75');
            } else {
                row.classList.remove('table-active-row');
                row.classList.add('opacity-75');
            }
        });
    });
});

// Tüm menüleri tek tıkla aç/kapat
function toggleAllMenus(state) {
    document.querySelectorAll('.menu-visibility-switch, .static-menu-switch').forEach(function (sw) {
        if (sw.checked !== state) {
            sw.checked = state;
            sw.dispatchEvent(new Event('change'));
        }
    });
}
</script>
@endpush
@endsection