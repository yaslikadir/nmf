<?php

namespace Modules\Purchasing\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;

class PurchasingServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        foreach ([
            'PurchaseDelivery', 'PurchaseDeliveryItem', 'PurchaseOffer', 'PurchaseOfferItem',
            'PurchaseOrder', 'PurchaseRequest', 'PurchaseRequestItem', 'Supplier',
            'SupplierClass', 'SupplierCriterion', 'SupplierEvaluation', 'SupplierQuestion',
        ] as $model) {
            $legacy = 'App\\Models\\' . $model;
            $module = 'Modules\\Purchasing\\Models\\' . $model;
            if (!class_exists($legacy) && class_exists($module)) {
                class_alias($module, $legacy);
            }
        }
    }

    public function boot(): void
    {
        // Migrations
        $this->loadMigrationsFrom(__DIR__ . '/../../database/migrations');

        // Views (Ana projede 'purchasing::' olarak çağırılacak)
        $this->loadViewsFrom(__DIR__ . '/../../resources/views', 'purchasing');

        // Routes
        $this->registerRoutes();
    }

    protected function registerRoutes(): void
    {
        Route::middleware(['web', 'auth', 'verified', 'active_user'])
            ->prefix('admin')
            ->name('admin.')
            ->group(__DIR__ . '/../../routes/web.php');
    }
}