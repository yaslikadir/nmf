<?php
namespace Modules\Purchasing\Models;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class PurchaseOrder extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];
    protected $casts = ['ordered_at' => 'datetime', 'delivery_date' => 'date', 'invoice_date' => 'date'];

    public function request() { return $this->belongsTo(PurchaseRequest::class, 'purchase_request_id'); }
    public function offer() { return $this->belongsTo(PurchaseOffer::class, 'purchase_offer_id'); }
    public function supplier() { return $this->belongsTo(Supplier::class); }

    // Siparişe ait teslimatlar
    public function deliveries()
    {
        return $this->hasMany(PurchaseDelivery::class);
    }

    // Siparişe ait ek dökümanlar ilişkisi
    public function documents()
    {
        return $this->hasMany(\Modules\Purchasing\Models\PurchaseOrderDocument::class, 'purchase_order_id', 'id');
    }
}

