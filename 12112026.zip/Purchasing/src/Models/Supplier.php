<?php

namespace Modules\Purchasing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class Supplier extends Model
{
    use BranchScoped;
    use HasFactory;
    
    protected $guarded = ['branch_id'];

    // JSON alanını diziye çevir
    protected $casts = [
        'product_categories' => 'array',
        'has_iso_9001' => 'boolean',
        'has_iso_17025' => 'boolean',
        'last_evaluation_date' => 'date',
    ];

    // İlişkiler
    public function evaluations()
    {
        return $this->hasMany(SupplierEvaluation::class)->latest();
    }

    public function orders()
    {
        return $this->hasMany(PurchaseOrder::class);
    }

    // YENİ EKLENEN: Tedarikçinin Teklifleri (500 Hatasını Çözen Kısım)
    public function offers()
    {
        return $this->hasMany(PurchaseOffer::class, 'supplier_id');
    }

    // Helper: Durum Rengi
    public function getStatusColorAttribute()
    {
        return match($this->status) {
            'Approved' => 'success',
            'Conditional' => 'warning',
            'Rejected' => 'danger',
            default => 'secondary',
        };
    }

    public function supplierClass()
    {
        return $this->belongsTo(SupplierClass::class, 'supplier_class_id');
    }
}