<?php
namespace Modules\Purchasing\Models;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class PurchaseDeliveryItem extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];
    // Teklif kalemiyle (Sipariş satırı) ilişki
    public function orderItem() { return $this->belongsTo(PurchaseOfferItem::class, 'purchase_offer_item_id'); }
}