<?php
namespace Modules\Purchasing\Models;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class PurchaseOffer extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];
    protected $casts = ['offer_date' => 'date', 'valid_until' => 'date'];

    public function request() { return $this->belongsTo(PurchaseRequest::class, 'purchase_request_id'); }
    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function items() { return $this->hasMany(PurchaseOfferItem::class); }
}