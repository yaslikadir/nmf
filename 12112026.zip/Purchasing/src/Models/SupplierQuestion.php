<?php

namespace Modules\Purchasing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class SupplierQuestion extends Model
{
    use BranchScoped;
    use HasFactory;

    protected $guarded = ['branch_id'];

    public function supplierClass()
    {
        return $this->belongsTo(SupplierClass::class);
    }
}