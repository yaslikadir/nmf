<?php
namespace Modules\Purchasing\Models;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class PurchaseOfferItem extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];
    
    // Hangi talep kalemine fiyat verdik?
    public function offer() { return $this->belongsTo(PurchaseOffer::class, 'purchase_offer_id'); }

    public function requestItem() { return $this->belongsTo(PurchaseRequestItem::class, 'purchase_request_item_id'); }
}