<?php
namespace Modules\Purchasing\Models;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class SupplierEvaluation extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];
    protected $casts = ['evaluation_date' => 'date'];

    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function evaluator() { return $this->belongsTo(\App\Models\User::class, 'evaluator_id'); }
}