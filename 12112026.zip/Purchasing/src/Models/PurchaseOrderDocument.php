<?php

namespace Modules\Purchasing\Models;

use Illuminate\Database\Eloquent\Model;

class PurchaseOrderDocument extends Model
{
    protected $table = 'purchase_order_documents';
    
    protected $fillable = [
        'purchase_order_id', 
        'name', 
        'file_path', 
        'uploaded_by'
    ];
}