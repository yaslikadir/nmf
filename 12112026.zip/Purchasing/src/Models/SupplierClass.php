<?php

namespace Modules\Purchasing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class SupplierClass extends Model
{
    use BranchScoped;
    use HasFactory;

    protected $guarded = ['branch_id'];

    public function questions()
    {
        return $this->hasMany(SupplierQuestion::class);
    }

    public function criteria()
    {
        return $this->hasMany(SupplierCriterion::class);
    }

    public function suppliers()
    {
        return $this->hasMany(Supplier::class);
    }
}