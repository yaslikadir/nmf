<?php

namespace Modules\Purchasing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class PurchaseRequestItem extends Model
{
    use BranchScoped;
    use HasFactory;

    protected $guarded = ['branch_id'];

    // İLİŞKİLER

    // 1. Hangi Talebe Ait?
    public function purchaseRequest()
    {
        return $this->belongsTo(PurchaseRequest::class);
    }

    // 2. Hangi Malzeme?
    public function material()
    {
        return $this->belongsTo(\Modules\Inventory\Models\Material::class);
    }
}