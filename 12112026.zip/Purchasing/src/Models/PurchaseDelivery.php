<?php
namespace Modules\Purchasing\Models;
use Illuminate\Database\Eloquent\Model;
use Modules\Purchasing\Support\BranchScoped;

class PurchaseDelivery extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];
    protected $casts = ['delivery_date' => 'date'];

    public function order() { return $this->belongsTo(PurchaseOrder::class, 'purchase_order_id'); }
    public function items() { return $this->hasMany(PurchaseDeliveryItem::class); }
    public function receiver() { return $this->belongsTo(\App\Models\User::class, 'received_by'); }
}