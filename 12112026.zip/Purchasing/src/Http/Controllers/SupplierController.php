<?php

namespace Modules\Purchasing\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Purchasing\Models\Supplier;
use Modules\Purchasing\Models\SupplierEvaluation;
use Modules\Purchasing\Models\SupplierClass;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class SupplierController extends Controller
{
    public function index()
    {
        $suppliers = Supplier::with('supplierClass')->latest()->get();
        $supplierClasses = SupplierClass::all();

        return view('purchasing::suppliers.index', compact('suppliers', 'supplierClasses'));
    }

    public function create()
    {
        $supplierClasses = SupplierClass::all();
        return view('purchasing::suppliers.create', compact('supplierClasses'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'company_name' => 'required',
            'category' => 'required|array', 
            'tax_plate_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096', 
            'iso_9001_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096',
            'iso_17025_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096',
        ], [
            'company_name.required' => 'Firma ünvanı zorunludur.',
            'category.required' => 'Lütfen en az bir kategori seçiniz.',
            'tax_plate_file.file' => 'Vergi levhası geçerli bir dosya olmalıdır.',
            'tax_plate_file.mimes' => 'Vergi levhası sadece PDF, JPG veya PNG formatında olabilir.',
            'tax_plate_file.max' => 'Dosya boyutu 4MB\'dan küçük olmalıdır.',
            'iso_9001_file.file' => 'ISO 9001 geçerli bir dosya olmalıdır.',
            'iso_9001_file.mimes' => 'ISO 9001 sadece PDF, JPG veya PNG formatında olabilir.',
            'iso_17025_file.file' => 'Akreditasyon belgesi geçerli bir dosya olmalıdır.',
            'iso_17025_file.mimes' => 'Akreditasyon belgesi sadece PDF, JPG veya PNG formatında olabilir.',
        ]);

        $data = $request->only([
            'company_name', 'contact_person', 'supplier_class_id', 'email', 'phone', 'website',
            'address', 'notes', 'supplier_category', 'tax_no', 'accreditation_scope',
            'iso_certified', 'iso_certificate_date', 'iso_certificate_expiry', 'last_audit_date',
            'has_tax_plate', 'has_signature_circular', 'has_trade_registry',
            'has_activity_certificate', 'has_iso_files', 'has_iso_9001', 'has_iso_17025',
            'affects_analysis'
        ]);

        if ($request->has('category') && is_array($request->category)) {
            $data['category'] = implode(', ', $request->category); 
        }

        if ($request->hasFile('tax_plate_file')) {
            $data['tax_plate_file'] = $request->file('tax_plate_file')->store('suppliers/docs', 'public');
            $data['has_tax_plate'] = true;
        }

        if ($request->hasFile('iso_9001_file')) {
            $data['iso_9001_file'] = $request->file('iso_9001_file')->store('suppliers/docs', 'public');
        }

        if ($request->hasFile('iso_17025_file')) {
            $data['iso_17025_file'] = $request->file('iso_17025_file')->store('suppliers/docs', 'public');
        }

        Supplier::create($data);

        return redirect()->route('admin.suppliers.index')->with('success', 'Tedarikçi kartı başarıyla açıldı.');
    }

    public function show($id)
    {
        $supplier = Supplier::with([
            'supplierClass.questions', 
            'supplierClass.criteria',
            'evaluations.evaluator',
            'offers.request'
        ])->findOrFail($id);

        $supplier->setRelation('evaluations', $supplier->evaluations->sortByDesc('evaluation_date'));

        return view('purchasing::suppliers.show', compact('supplier'));
    }

    public function storeEvaluation(Request $request, $id)
    {
        $supplier = Supplier::with('supplierClass.criteria')->findOrFail($id);
        
        $total = 0;
        $scoresData = []; // Bireysel puanları tutacağımız dizi
        
        // Puanları topla ve diziye aktar
        if ($request->has('scores') && is_array($request->scores)) {
            $scoresData = $request->scores;
            foreach ($request->scores as $score) {
                $total += intval($score);
            }
        }

        $status = 'Rejected'; 
        
        if ($supplier->supplierClass && $supplier->supplierClass->criteria->count() > 0) {
            $matchedCriterion = $supplier->supplierClass->criteria()
                ->where('min_score', '<=', $total)
                ->where('max_score', '>=', $total)
                ->first();

            if ($matchedCriterion) {
                if (in_array($matchedCriterion->color_code, ['success', 'primary'])) {
                    $status = 'Approved';
                } elseif ($matchedCriterion->color_code == 'warning') {
                    $status = 'Conditional';
                } else {
                    $status = 'Rejected';
                }
            }
        } else {
            if ($total >= 85) $status = 'Approved';
            elseif ($total >= 70) $status = 'Conditional';
        }

        $evalDate = $request->filled('evaluation_date') 
            ? \Carbon\Carbon::parse($request->evaluation_date)->format('Y-m-d H:i:s') 
            : now();

        // Değerlendirme objesini oluştur
        $evaluation = new SupplierEvaluation([
            'supplier_id' => $supplier->id,
            'evaluator_id' => Auth::id(),
            'evaluation_date' => $evalDate,
            'score_technical' => 0,
            'score_cert' => 0,
            'score_quality' => 0,
            'score_delivery' => 0,
            'score_docs' => 0,
            'score_complaint' => 0,
            'total_score' => $total,
            'result' => $status,
            'comments' => $request->comments,
        ]);
        
        // Bireysel puanları modele doğrudan atayarak kaydediyoruz
        $evaluation->scores = json_encode($scoresData);
        $evaluation->save();

        $supplier->update([
            'score' => $total, 
            'performance_note' => $request->comments,
            'status' => $status,
            'last_evaluation_date' => $evalDate,
            'approved_by' => ($status == 'Approved' ? Auth::id() : null)
        ]);

        return back()->with('success', 'Değerlendirme kaydedildi ve tedarikçi durumu güncellendi.');
    }

    public function edit($id)
    {
        $supplier = Supplier::findOrFail($id);
        $supplierClasses = SupplierClass::all();
        return view('purchasing::suppliers.edit', compact('supplier', 'supplierClasses'));
    }

    public function update(Request $request, $id)
    {
        $supplier = Supplier::findOrFail($id);

        $request->validate([
            'company_name' => 'required',
            'category' => 'required|array', 
            'tax_plate_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096', 
            'iso_9001_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096',
            'iso_17025_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096',
        ]);

        $data = $request->only([
            'company_name', 'contact_person', 'supplier_class_id', 'email', 'phone', 'website',
            'address', 'notes', 'supplier_category', 'tax_no', 'accreditation_scope',
            'iso_certified', 'iso_certificate_date', 'iso_certificate_expiry', 'last_audit_date',
            'has_tax_plate', 'has_signature_circular', 'has_trade_registry',
            'has_activity_certificate', 'has_iso_files', 'has_iso_9001', 'has_iso_17025',
            'affects_analysis'
        ]);

        if ($request->has('category') && is_array($request->category)) {
            $data['category'] = implode(', ', $request->category);
        }

        $data['has_tax_plate'] = $request->has('has_tax_plate');
        $data['has_iso_9001'] = $request->has('has_iso_9001');
        $data['has_iso_17025'] = $request->has('has_iso_17025');
        $data['affects_analysis'] = $request->has('affects_analysis');

        if ($request->hasFile('tax_plate_file')) {
            $data['tax_plate_file'] = $request->file('tax_plate_file')->store('suppliers/docs', 'public');
            $data['has_tax_plate'] = true; 
        }

        if ($request->hasFile('iso_9001_file')) {
            $data['iso_9001_file'] = $request->file('iso_9001_file')->store('suppliers/docs', 'public');
        }

        if ($request->hasFile('iso_17025_file')) {
            $data['iso_17025_file'] = $request->file('iso_17025_file')->store('suppliers/docs', 'public');
        }

        $supplier->update($data);

        return redirect()->route('admin.suppliers.show', $supplier->id)
                         ->with('success', 'Tedarikçi bilgileri güncellendi.');
    }

    /**
     * Geçmiş Değerlendirmeyi Güncelle
     */
    public function updateEvaluation(Request $request, $id)
    {
        $eval = SupplierEvaluation::findOrFail($id);
        $supplier = $eval->supplier;

        $request->validate([
            'evaluation_date' => 'required|date',
            'total_score' => 'required|integer|min:0|max:100',
            'comments' => 'nullable|string'
        ]);

        $total = $request->total_score;
        $status = 'Rejected';
        
        // Tarihi güvenli bir formata çeviriyoruz
        $evalDate = Carbon::parse($request->evaluation_date)->format('Y-m-d H:i:s');

        // Kriterlere göre yeni durumu (Onaylı/Red) hesapla
        if ($supplier->supplierClass && $supplier->supplierClass->criteria->count() > 0) {
            $matched = $supplier->supplierClass->criteria()
                ->where('min_score', '<=', $total)
                ->where('max_score', '>=', $total)->first();
            
            if ($matched) {
                if (in_array($matched->color_code, ['success', 'primary'])) $status = 'Approved';
                elseif ($matched->color_code == 'warning') $status = 'Conditional';
            }
        } else {
            if ($total >= 85) $status = 'Approved';
            elseif ($total >= 70) $status = 'Conditional';
        }

        // Karne Güncelleniyor
        $eval->update([
            'evaluation_date' => $evalDate,
            'total_score' => $total,
            'result' => $status,
            'comments' => $request->comments
        ]);

        // Eğer güncellenen karne EN SON karne ise tedarikçinin ana puanını da güncelle
        $latestEval = $supplier->evaluations()->orderBy('evaluation_date', 'desc')->first();
        if ($latestEval && $latestEval->id == $eval->id) {
            $supplier->update([
                'score' => $total,
                'performance_note' => $request->comments,
                'status' => $status,
                'last_evaluation_date' => $evalDate
            ]);
        }

        return back()->with('success', 'Değerlendirme karnesi başarıyla güncellendi.');
    }

    /**
     * Geçmiş Değerlendirmeyi Sil
     */
    public function destroyEvaluation($id)
    {
        $eval = SupplierEvaluation::findOrFail($id);
        $supplier = $eval->supplier;
        $eval->delete();

        // Silindikten sonra geriye kalan EN YENİ karneyi bulup ana tedarikçi puanını ona göre geri alıyoruz
        $latestEval = $supplier->evaluations()->orderBy('evaluation_date', 'desc')->first();
        
        if ($latestEval) {
            $supplier->update([
                'score' => $latestEval->total_score,
                'performance_note' => $latestEval->comments,
                'status' => $latestEval->result,
                'last_evaluation_date' => $latestEval->evaluation_date
            ]);
        } else {
            // Eğer hiç karne kalmadıysa sıfırla
            $supplier->update([
                'score' => null,
                'performance_note' => null,
                'status' => 'Pending',
                'last_evaluation_date' => null
            ]);
        }

        return back()->with('success', 'Karne silindi. Tedarikçi puanı bir önceki karneye göre güncellendi.');
    }

    /**
     * Tedarikçiyi Tamamen Sil (Soft Delete değil, Kalıcı Silme)
     */
    public function destroy($id)
    {
        $supplier = Supplier::findOrFail($id);

        if ($supplier->orders()->count() > 0) {
            return back()->with('error', 'Bu tedarikçiye ait geçmiş veya aktif siparişler bulunduğu için silinemez! Lütfen tedarikçiyi "Red" veya "Pasif" duruma çekiniz.');
        }

        if ($supplier->tax_plate_file) {
            \Illuminate\Support\Facades\Storage::disk('public')->delete($supplier->tax_plate_file);
        }
        if ($supplier->iso_9001_file) {
            \Illuminate\Support\Facades\Storage::disk('public')->delete($supplier->iso_9001_file);
        }
        if ($supplier->iso_17025_file) {
            \Illuminate\Support\Facades\Storage::disk('public')->delete($supplier->iso_17025_file);
        }

        $supplier->delete();

        return redirect()->route('admin.suppliers.index')->with('success', 'Tedarikçi sistemden başarıyla silindi.');
    }

    /**
     * Tüm tedarikçilerin listesini FR-06-01 formatında yazdırmak için
     */
    public function printList()
    {
        // Sadece Onaylı ve Şartlı Onaylı olan tedarikçileri göstermek isterseniz buradaki where'i açabilirsiniz.
        // Şimdilik tümünü listeleyecek şekilde ayarladık.
        $suppliers = Supplier::with('supplierClass')->orderBy('company_name', 'asc')->get();
        
        return view('purchasing::suppliers.print_list', compact('suppliers'));
    }

    /**
     * FR-06-02 Tedarikçi Değerlendirme Formunu Yazdırmak İçin
     */
    public function printEvaluation($id, $evalId)
    {
        $supplier = Supplier::with('supplierClass.questions')->findOrFail($id);
        $eval = SupplierEvaluation::with('evaluator')->findOrFail($evalId);

        return view('purchasing::suppliers.print_evaluation', compact('supplier', 'eval'));
    }
}