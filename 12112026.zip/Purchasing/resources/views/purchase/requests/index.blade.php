@extends('layouts.admin')

@push('css')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
<style>
    .bg-success-soft { background-color: #e3f9ed; }
    .bg-warning-soft { background-color: #fff9e6; }
    .bg-danger-soft { background-color: #ffe6e6; }
    .bg-info-soft { background-color: #e3f2fd; }
    .table-hover tbody tr:hover { background-color: #f8f9fa; cursor: pointer; }
    #requestsTable_wrapper .dataTables_filter { float: right; }
    #requestsTable_wrapper .dataTables_length { float: left; }
    .btn-export { font-size: 0.75rem; padding: 4px 12px; font-weight: bold; }
    .action-icon { cursor: pointer; margin: 0 5px; color: #6c757d; transition: color 0.2s; }
    .action-icon:hover { color: #007bff; }
    .badge-high { background-color: #dc3545; color: white; }
    .badge-normal { background-color: #0d6efd; color: white; }
    .badge-low { background-color: #6c757d; color: white; }
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="text-primary fw-bold mb-0 text-uppercase">
            <i class="fas fa-shopping-basket me-2"></i>TALEP HAVUZU
        </h5>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.purchase.requests.create') }}" class="btn btn-sm btn-success px-4 fw-bold shadow-sm">
                <i class="fas fa-plus me-1"></i> YENİ TALEP
            </a>
            <button type="button" class="btn btn-sm btn-primary px-4 fw-bold shadow-sm" onclick="location.reload();">
                <i class="fas fa-sync me-1"></i> YENİLE
            </button>
        </div>
    </div>

    <div class="card shadow-none border mb-3">
        <div class="card-header bg-light py-2 border-bottom">
            <div class="row align-items-center g-2">
                <div class="col-md-6">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="d-flex gap-1">
                            <select class="form-select form-select-sm" id="listeTuru" style="width: auto;">
                                <option value="tum">Tüm Durumlar</option>
                                <option value="bekleyen">Onay Bekleyenler</option>
                                <option value="onaylanan">Onaylananlar</option>
                                <option value="reddedilen">Reddedilenler</option>
                                <option value="siparis">Sipariş Verilen</option>
                            </select>
                            <select class="form-select form-select-sm" id="tumListe" style="width: auto;">
                                <option value="tum">Tüm Tarihler</option>
                                <option value="buay">Bu Ay</option>
                                <option value="bugun">Bugün</option>
                                <option value="gecenay">Geçen Ay</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary btn-export"><i class="fas fa-filter me-1"></i> ACİLİYET</button>
                        <button type="button" class="btn btn-sm btn-success btn-export" id="btnExportXLS"><i class="fas fa-file-excel me-1"></i> XLS</button>
                        <button type="button" class="btn btn-sm btn-danger btn-export" id="btnExportPDF"><i class="fas fa-file-pdf me-1"></i> PDF</button>
                        <button type="button" class="btn btn-sm btn-warning btn-export" id="btnColumnToggle"><i class="fas fa-columns me-1"></i> SÜTUNLAR</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-2">
            <div class="table-responsive">
                <table class="table table-sm table-hover table-bordered mb-0 align-middle" id="requestsTable" style="font-size: 0.85rem;">
                    <thead class="bg-primary text-white">
                        <tr>
                            <th width="30" class="text-center">#</th>
                            <th>Talep No</th>
                            <th>Talep Eden</th>
                            <th>Departman</th>
                            <th>Talep Tarihi</th>
                            <th>Termin Tarihi</th>
                            <th class="text-center">Kalem</th>
                            <th class="text-center">Öncelik</th>
                            <th class="text-center">Durum</th>
                            <th>Onaycı</th>
                            <th width="100" class="text-center">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($requests as $index => $req)
                        <tr data-id="{{ $req->id }}">
                            <td class="text-center">{{ $index + 1 }}</td>
                            <td class="fw-bold text-primary">{{ $req->request_no }}</td>
                            <td>{{ $req->requester?->name ?? 'Bilinmiyor' }}</td>
                            <td>{{ $req->department?->name ?? '-' }}</td>
                            
                            {{-- DÜZELTİLEN YER: Talep Tarihi Artık request_date Sütunundan --}}
                            <td>{{ $req->request_date ? \Carbon\Carbon::parse($req->request_date)->format('d.m.Y') : $req->created_at->format('d.m.Y') }}</td>
                            
                            <td>
                                @if($req->requested_by_date)
                                    <span class="{{ $req->requested_by_date < now() && $req->status == 'Pending' ? 'text-danger fw-bold' : '' }}">
                                        {{ \Carbon\Carbon::parse($req->requested_by_date)->format('d.m.Y') }}
                                    </span>
                                @else
                                    -
                                @endif
                            </td>
                            <td class="text-center fw-bold">{{ $req->items_count }}</td>
                            <td class="text-center">
                                @if($req->priority == 'High') <span class="badge badge-high">ACİL</span>
                                @elseif($req->priority == 'Normal') <span class="badge badge-normal">Normal</span>
                                @else <span class="badge badge-low">Düşük</span>
                                @endif
                            </td>
                            <td class="text-center">
                                @if($req->status == 'Approved' && $req->offers_count > 0 && !$req->converted_offer_id)
                                    <span class="badge bg-primary">Teklifler İnceleniyor</span>
                                @else
                                    @switch($req->status)
                                        @case('Pending') <span class="badge bg-warning text-dark">Onay Bekliyor</span> @break
                                        @case('Approved') <span class="badge bg-success">Onaylandı</span> @break
                                        @case('Rejected') <span class="badge bg-danger">Reddedildi</span> @break
                                        @case('Ordered') <span class="badge bg-info text-white">Sipariş Verildi</span> @break
                                        @case('Completed') <span class="badge bg-dark">Tamamlandı</span> @break
                                    @endswitch
                                @endif
                            </td>
                            <td>
                                @if($req->approver_id == Auth::id() && $req->status == 'Pending')
                                    <span class="text-danger fw-bold small"><i class="fas fa-arrow-right me-1"></i> SİZDE</span>
                                @else
                                    <span class="small text-muted">{{ $req->approver?->name ?? '-' }}</span>
                                @endif
                            </td>

                            {{-- DÜZELTİLEN YER: İŞLEMLER (SİLME EKLENDİ) --}}
                            {{-- İŞLEMLER SÜTUNU --}}
                            <td class="text-center">
                                {{-- 1. İNCELE (GÖZ) BUTONU: Herkese ve her duruma açık --}}
                                <a href="{{ route('admin.purchase.requests.show', $req->id) }}" class="btn btn-sm btn-info shadow-sm py-0 px-2 text-white" title="İncele">
                                    <i class="fas fa-eye small"></i>
                                </a>

                                {{-- 2. DÜZENLE VE SİL BUTONLARI: Sadece "Bekliyor (Pending)" durumunda ve yetkiliyse açık --}}
                                @if($req->status == 'Pending' && (Auth::user()->isAdmin() || Auth::id() == $req->requester_id))
                                    
                                    {{-- DÜZENLE BUTONU --}}
                                    <a href="{{ route('admin.purchase.requests.edit', $req->id) }}" class="btn btn-sm btn-warning shadow-sm py-0 px-2 text-dark" title="Düzenle">
                                        <i class="fas fa-edit small"></i>
                                    </a>

                                    {{-- SİL BUTONU --}}
                                    <form action="{{ route('admin.purchase.requests.destroy', $req->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Bu talebi tamamen silmek istediğinize emin misiniz?');">
                                        @csrf @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger shadow-sm py-0 px-2" title="Sil">
                                            <i class="fas fa-trash small"></i>
                                        </button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="11" class="text-center py-4 text-muted">
                                <i class="fas fa-inbox fa-3x mb-3 d-block opacity-25"></i>
                                Henüz talep kaydı bulunmuyor.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-2 small">
            <div class="text-muted">Toplam {{ count($requests) }} kayıt listelendi.</div>
        </div>
    </div>

    {{-- İSTATİSTİKLER (Aynı kaldı) --}}
    <div class="row g-3 mt-3">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-primary text-white h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-white-50 mb-1 small">Toplam Talep</h6><h3 class="fw-bold mb-0">{{ $requests->count() }}</h3></div>
                        <div class="fs-1 text-white-50"><i class="fas fa-clipboard-list"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-warning-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-muted mb-1 small">Onay Bekleyen</h6><h3 class="fw-bold mb-0 text-warning">{{ $requests->where('status', 'Pending')->count() }}</h3></div>
                        <div class="fs-1 text-warning opacity-50"><i class="fas fa-hourglass-half"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-success-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-muted mb-1 small">Onaylanan (İşlemde)</h6><h3 class="fw-bold mb-0 text-success">{{ $requests->whereIn('status', ['Approved', 'Ordered'])->count() }}</h3></div>
                        <div class="fs-1 text-success opacity-50"><i class="fas fa-check-circle"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-danger-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-muted mb-1 small">Acil Talepler</h6><h3 class="fw-bold mb-0 text-danger">{{ $requests->where('priority', 'High')->count() }}</h3></div>
                        <div class="fs-1 text-danger opacity-50"><i class="fas fa-exclamation-triangle"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="columnModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary text-white">
                <h6 class="modal-title fw-bold mb-0"><i class="fas fa-columns me-2"></i>Sütun Ayarları</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-2">
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="3" checked id="col3"><label class="form-check-label" for="col3">Departman</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="4" checked id="col4"><label class="form-check-label" for="col4">Talep Tarihi</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="5" checked id="col5"><label class="form-check-label" for="col5">Termin Tarihi</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="7" checked id="col7"><label class="form-check-label" for="col7">Öncelik</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="9" checked id="col9"><label class="form-check-label" for="col9">Onaycı</label></div></div>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
$(document).ready(function() {
    $.fn.dataTable.ext.errMode = 'none';

    const table = $('#requestsTable').DataTable({
        language: {
            "emptyTable": "Tabloda veri yok",
            "info": "_TOTAL_ kayıttan _START_ - _END_ arası gösteriliyor",
            "infoEmpty": "Kayıt yok",
            "infoFiltered": "(_MAX_ kayıt içerisinden)",
            "lengthMenu": "_MENU_ kayıt göster",
            "loadingRecords": "Yükleniyor...",
            "search": "Ara:",
            "zeroRecords": "Eşleşen kayıt bulunamadı",
            "paginate": { "first": "İlk", "last": "Son", "next": "Sonraki", "previous": "Önceki" }
        },
        pageLength: 25,
        order: [[7, 'desc'], [4, 'desc']], 
        dom: 'Bfrtip',
        buttons: [],
        columnDefs: [
            { orderable: false, targets: [0, 10] } 
        ]
    });

    $('#listeTuru').on('change', function() {
        const val = $(this).val();
        if (val === 'tum') table.column(8).search('').draw();
        else if (val === 'bekleyen') table.column(8).search('Onay Bekliyor').draw();
        else if (val === 'onaylanan') table.column(8).search('Onaylandı').draw();
        else if (val === 'reddedilen') table.column(8).search('Reddedildi').draw();
        else if (val === 'siparis') table.column(8).search('Sipariş').draw();
    });

    $('#tumListe').on('change', function() {
        const value = $(this).val();
        const today = new Date();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const yyyy = today.getFullYear();

        if (value === 'bugun') {
            const todayStr = String(today.getDate()).padStart(2, '0') + '.' + mm + '.' + yyyy;
            table.column(4).search(todayStr).draw();
        } else if (value === 'buay') {
            table.column(4).search('.' + mm + '.' + yyyy).draw();
        } else {
            table.column(4).search('').draw();
        }
    });

    $('#btnExportXLS').on('click', function() { table.button('.buttons-excel').trigger(); });
    $('#btnExportPDF').on('click', function() { table.button('.buttons-pdf').trigger(); });

    $('#btnColumnToggle').on('click', function() { $('#columnModal').modal('show'); });
    $('.column-toggle').on('change', function() {
        const column = table.column($(this).data('column'));
        column.visible(!column.visible());
    });

    $('#requestsTable tbody').on('click', 'tr', function(e) {
        if (!$(e.target).closest('a, button, form').length) {
            const id = $(this).data('id');
            if(id) window.location.href = `/admin/purchase/requests/${id}`;
        }
    });
});
</script>
@endpush