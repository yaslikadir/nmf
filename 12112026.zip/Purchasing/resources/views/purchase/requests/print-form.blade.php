<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>FR-06-01 Satın Alma Talep ve Kontrol Formu</title>
    <style>
        @page {
            size: A4 landscape; /* Yatay A4 formatı */
            margin: 5mm; 
        }
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 11px;
            color: #000;
            background: #fff;
        }
        .container {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 5px;
        }
        td, th {
            border: 1px solid #000;
            padding: 3px 5px; 
            vertical-align: middle;
            line-height: 1.3;
        }
        .text-center { text-align: center; }
        .text-left { text-align: left; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        
        /* GÜNCELLENEN BAŞLIK RENGİ (#E2EFDA) */
        .bg-custom { 
            background-color: #E2EFDA !important; 
            -webkit-print-color-adjust: exact; 
            print-color-adjust: exact;
        }
        
        /* Başlıklar ve Fontlar */
        .header-title {
            font-size: 16px; 
            font-weight: bold;
        }
        .small-text {
            font-size: 10px;
        }
        
        /* Satır Yükseklikleri */
        .h-dynamic { height: 35px; } 
        .h-empty { height: 35px; }   
        
        /* Yazdırma Butonu */
        .no-print {
            position: fixed; top: 10px; right: 10px;
            background: #333; color: #fff; padding: 8px 15px;
            text-decoration: none; border-radius: 4px; font-family: sans-serif;
            font-size: 12px; z-index: 9999; border: none; cursor: pointer;
        }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>

    <button onclick="window.print()" class="no-print">YAZDIR / PDF</button>

    <div class="container">
        
        {{-- ÜST BİLGİ VE LOGO TABLOSU --}}
        <table>
            <tbody>
                <tr>
                    <td rowspan="4" style="width: 20%; padding: 5px; text-align: center;">
                        {{-- DİNAMİK LOGO ÇEKİMİ --}}
                        @php
                            $logo = \App\Models\Setting::where('key', 'site_logo')->value('value');
                        @endphp
                        @if($logo)
                            <img src="{{ asset($logo) }}" alt="Logo" style="max-height: 60px; max-width: 100%;">
                        @else
                            <h2 style="margin: 0; font-size: 16px;">AKADEMİ ÇEVRE</h2>
                        @endif
                    </td>
                    
                    <td rowspan="4" class="text-center header-title" style="width: 50%;">
                        SATINALMA TALEP VE KONTROL<br>FORMU
                    </td>
                    
                    <td style="width: 15%; font-weight: bold; font-size: 10px;">Doküman No</td>
                    <td style="width: 15%; font-size: 10px;">FR-06-01</td>
                </tr>
                <tr>
                    <td style="font-weight: bold; font-size: 10px;">Yayın Tarihi</td>
                    <td style="font-size: 10px;">03.06.2024</td>
                </tr>
                <tr>
                    <td style="font-weight: bold; font-size: 10px;">Rev. No/Tarih</td>
                    <td style="font-size: 10px;">00/-</td>
                </tr>
                <tr>
                    <td style="font-weight: bold; font-size: 10px;">Sayfa No</td>
                    <td style="font-size: 10px;">1/1</td>
                </tr>
            </tbody>
        </table>

        {{-- ANA VERİ TABLOSU --}}
        <table>
            <thead>
                <tr>
                    <th colspan="8" class="bg-custom text-center font-bold" style="padding: 4px;">
                        Talep Edilen Malzemenin / Cihazın / Hizmetin
                    </th>
                </tr>
                <tr class="bg-custom">
                    <th style="width: 5%;">Sıra No</th>
                    <th style="width: 15%;">Adı</th>
                    <th style="width: 25%;">Özellikleri*</th>
                    <th style="width: 10%;">Miktarı</th>
                    <th style="width: 10%;">İstenen Zaman</th>
                    <th style="width: 10%;">Teslim Tarihi</th>
                    <th style="width: 10%;">Karar<br>Kabul/Ret</th>
                    <th style="width: 15%;">Açıklama</th>
                </tr>
            </thead>
            <tbody>
                {{-- DİNAMİK SİPARİŞ KALEMLERİ --}}
                @foreach($req->items as $index => $item)
                
                @php
                    $deliveryDate = '';
                    $decision = '';
                    $note = '';

                    // Bu talep kaleminin dönüştüğü teklif kalemini bul
                    $offerItem = \Modules\Purchasing\Models\PurchaseOfferItem::where('purchase_request_item_id', $item->id)->first();

                    if($offerItem) {
                        // Teklif kalemine ait mal kabul (teslimat) işlemlerini bul (İlişki hatası vermemesi için direkt çağırıyoruz)
                        $delItems = \Modules\Purchasing\Models\PurchaseDeliveryItem::where('purchase_offer_item_id', $offerItem->id)->get();
                            
                        if($delItems->count() > 0) {
                            
                            $lastDelItem = $delItems->sortByDesc('created_at')->first();
                            
                            // Ana teslimat formunu buluyoruz
                            $lastDelivery = \Modules\Purchasing\Models\PurchaseDelivery::find($lastDelItem->purchase_delivery_id);
                            
                            if ($lastDelivery) {
                                // Tarih formatı hatasına karşı güvenli parse
                                $deliveryDate = \Carbon\Carbon::parse($lastDelivery->delivery_date)->format('d.m.Y');
                                $note = $lastDelivery->notes ?? '';
                            }
                            
                            $totalAcc = $delItems->sum('quantity_accepted');
                            $totalRej = $delItems->sum('quantity_rejected');
                            
                            if($totalRej > 0 && $totalAcc == 0) {
                                $decision = 'RET';
                                $note = $delItems->filter(function($d) { return !empty($d->rejection_reason); })->pluck('rejection_reason')->implode(', ');
                            } elseif($totalRej > 0 && $totalAcc > 0) {
                                $decision = 'KISMİ KABUL';
                                $note = $delItems->filter(function($d) { return !empty($d->rejection_reason); })->pluck('rejection_reason')->implode(', ');
                            } else {
                                $decision = 'KABUL';
                            }
                        }
                    }
                @endphp

                <tr>
                    <td class="text-center h-dynamic">{{ $index + 1 }}</td>
                    <td>{{ $item->material->name ?? 'Silinmiş / Bilinmeyen Malzeme' }}</td>
                    <td style="font-size: 10px;">
                        <strong>Kod:</strong> {{ $item->material->sku ?? '-' }}<br>
                        {{ $item->technical_specifications ?? '' }}
                    </td>
                    <td class="text-center font-bold">{{ number_format($item->quantity, 2) }} {{ $item->unit }}</td>
                    <td class="text-center">{{ $req->requested_by_date ? \Carbon\Carbon::parse($req->requested_by_date)->format('d.m.Y') : '-' }}</td>
                    
                    {{-- DİNAMİK OLARAK DOLDURULAN MAL KABUL ALANLARI --}}
                    <td class="text-center font-bold">{{ $deliveryDate }}</td> 
                    <td class="text-center font-bold {{ $decision == 'RET' ? 'text-danger' : '' }}">{{ $decision }}</td>
                    <td style="font-size: 10px;">{{ $note }}</td>
                </tr>
                @endforeach

                {{-- BOŞ SATIR DOLDURMA (A4'te çok boş kalmaması için asgari 6 satıra tamamla) --}}
                @for($i = $req->items->count(); $i < 6; $i++)
                <tr>
                    <td class="text-center h-empty">{{ $i + 1 }}</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                @endfor
            </tbody>
        </table>

        {{-- TARİH ALANI --}}
        <div style="margin-top: 5px; margin-bottom: 5px; font-weight: bold; font-size: 11px;">
            Talep Tarihi : {{ $req->request_date ? \Carbon\Carbon::parse($req->request_date)->format('d.m.Y') : $req->created_at->format('d.m.Y') }}
        </div>

        {{-- İMZA ALANI (Yeni Word formatına uygun) --}}
        <table>
            <tbody>
                <tr>
                    <td class="text-center" style="vertical-align: top; height: 60px; width: 50%;">
                        <div class="font-bold mb-2">Talebi Yapan</div>
                        <div class="small-text mt-1 text-left" style="padding-left: 10px;">
                            <strong>Adı / Soyadı:</strong> {{ $req->requester->name ?? 'Bilinmeyen Personel' }}
                        </div>
                        <div class="small-text mt-3 text-left" style="padding-left: 10px;">
                            <strong>İmza:</strong>
                        </div>
                    </td>
                    
                    <td class="text-center" style="vertical-align: top; width: 50%;">
                        <div class="font-bold mb-2">Onay Veren</div>
                        <div class="small-text mt-1 text-left" style="padding-left: 10px;">
                            <strong>Adı / Soyadı:</strong> {{ $req->approver->name ?? '...........................' }}
                        </div>
                        <div class="small-text mt-3 text-left" style="padding-left: 10px;">
                            <strong>İmza:</strong>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>

        {{-- ALT NOT --}}
        <p class="small-text" style="font-style: italic; margin-top: 5px;">
            *Alımı yapılan ürün/hizmetler bu madde altında belirtilen özellikler üzerinden kontrol edilir.
        </p>

    </div>
</body>
</html>