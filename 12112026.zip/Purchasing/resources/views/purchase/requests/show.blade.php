@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    
    {{-- BAŞLIK ALANI --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h3 mb-0 text-gray-800">
                Talep Detayı: <span class="text-primary">{{ $req->request_no }}</span>
            </h2>
            <p class="text-muted small mb-0">Talep Tarihi: {{ $req->request_date ? \Carbon\Carbon::parse($req->request_date)->format('d.m.Y') : $req->created_at->format('d.m.Y H:i') }}</p>
        </div>
        <div>
            @if($req->status == 'Pending' && (Auth::user()->isAdmin() || Auth::id() == $req->requester_id))
            <a href="{{ route('admin.purchase.requests.edit', $req->id) }}" class="btn btn-warning btn-sm ms-2 shadow-sm">
                <i class="fas fa-edit me-1"></i> Düzenle
            </a>
            @endif

            @if($req->status == 'Approved')
            <a href="{{ route('admin.purchase.offers.create', ['request_id' => $req->id]) }}" class="btn btn-success btn-sm ms-2 shadow-sm">
                <i class="fas fa-plus-circle me-1"></i> Fiyat Teklifi Gir
            </a>
            @endif
            <a href="{{ route('admin.purchase.requests.print', $req->id) }}" target="_blank" class="btn btn-dark btn-sm ms-2 shadow-sm">
                <i class="fas fa-print me-1"></i> Formu Yazdır
            </a>
            <a href="{{ route('admin.purchase.requests.index') }}" class="btn btn-secondary btn-sm ms-2 shadow-sm">
                <i class="fas fa-arrow-left me-1"></i> Listeye Dön
            </a>
        </div>
    </div>

    <div class="row">
        {{-- SOL KOLON: TALEP BİLGİLERİ --}}
        <div class="col-lg-8">
            {{-- DURUM KARTI --}}
            <div class="card mb-4 shadow-sm border-top-lg border-{{ $req->status == 'Approved' ? 'success' : ($req->status == 'Rejected' ? 'danger' : 'warning') }}">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="text-uppercase text-muted small fw-bold">Talep Durumu</h6>
                            <h4 class="mb-0 fw-bold">
                                @if($req->status == 'Pending') <span class="text-warning"><i class="fas fa-clock me-2"></i>ONAY BEKLİYOR</span>
                                @elseif($req->status == 'Approved') <span class="text-success"><i class="fas fa-check-circle me-2"></i>ONAYLANDI</span>
                                @elseif($req->status == 'Rejected') <span class="text-danger"><i class="fas fa-times-circle me-2"></i>REDDEDİLDİ</span>
                                @endif
                            </h4>
                        </div>
                        <div class="text-end">
                            <h6 class="text-uppercase text-muted small fw-bold">Öncelik</h6>
                            @if($req->priority == 'High')
                                <span class="badge bg-danger fs-6">ACİL</span>
                            @elseif($req->priority == 'Normal')
                                <span class="badge bg-primary fs-6">NORMAL</span>
                            @else
                                <span class="badge bg-secondary fs-6">DÜŞÜK</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            {{-- ÜRÜN LİSTESİ --}}
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light fw-bold">
                    <i class="fas fa-list me-1"></i> Talep Edilen Malzemeler
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light text-muted small text-uppercase">
                            <tr>
                                <th class="ps-3">Malzeme</th>
                                <th>Stok Kodu</th>
                                <th>Miktar</th>
                                <th>Teknik Şart / Not</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($req->items as $item)
                            <tr>
                                <td class="ps-3 fw-bold">{{ $item->material->name ?? 'Silinmiş/Bilinmeyen Malzeme' }}</td>
                                <td><span class="badge bg-light text-dark border">{{ $item->material->sku ?? '-' }}</span></td>
                                <td class="fw-bold text-dark">{{ number_format($item->quantity, 2) }} {{ $item->unit }}</td>
                                <td class="small text-muted">{{ $item->technical_specifications ?? '-' }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            {{-- MUKAYESE CETVELİ (TEKLİFLER VARSA GÖSTER) --}}
            @if($req->offers && $req->offers->count() > 0)
            <div class="card shadow-sm mb-4 border-top-lg border-primary">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold text-primary mb-0">
                        <i class="fas fa-balance-scale me-2"></i>Teklif Mukayese Cetveli
                    </h6>
                    <span class="badge bg-primary">{{ $req->offers->count() }} Teklif Alındı</span>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle mb-0 text-center">
                        <thead class="bg-light text-muted small text-uppercase">
                            <tr>
                                <th class="text-start" style="width: 200px;">Malzeme / Hizmet</th>
                                <th style="width: 80px;">Miktar</th>
                                
                                @foreach($req->offers as $offer)
                                <th class="{{ $offer->status == 'Won' ? 'bg-success-soft' : '' }}">
                                    <div class="fw-bold text-dark">{{ $offer->supplier->company_name ?? 'Silinmiş Tedarikçi' }}</div>
                                    <div class="small text-muted">{{ $offer->offer_no }}</div>
                                    <div class="x-small text-muted">{{ $offer->currency }}</div>
                                    
                                    @if($offer->status == 'Won')
                                        <span class="badge bg-success mt-1">KAZANDI</span>
                                    @endif
                                </th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($req->items as $reqItem)
                            <tr>
                                <td class="text-start fw-bold text-dark bg-light">
                                    {{ $reqItem->material->name ?? 'Silinmiş/Bilinmeyen Malzeme' }}
                                </td>
                                <td class="bg-light fw-bold">{{ $reqItem->quantity }} {{ $reqItem->unit }}</td>

                                @foreach($req->offers as $offer)
                                    @php
                                        $offerItem = $offer->items->where('purchase_request_item_id', $reqItem->id)->first();
                                    @endphp
                                    
                                    <td class="{{ $offer->status == 'Won' ? 'bg-success-soft' : '' }}">
                                        @if($offerItem)
                                            <div class="fw-bold text-dark">
                                                {{ number_format($offerItem->unit_price, 2, ',', '.') }}
                                            </div>
                                            <div class="x-small text-muted">
                                                Toplam: {{ number_format($offerItem->net_total, 2, ',', '.') }}
                                            </div>
                                        @else
                                            <span class="text-muted small">-</span>
                                        @endif
                                    </td>
                                @endforeach
                            </tr>
                            @endforeach

                            <tr class="bg-light fw-bold">
                                <td colspan="2" class="text-end text-uppercase">Genel Toplam :</td>
                                @foreach($req->offers as $offer)
                                <td class="{{ $offer->status == 'Won' ? 'bg-success-soft' : '' }}">
                                    <div class="text-primary fs-6">
                                        {{ number_format($offer->sub_total, 2, ',', '.') }} {{ $offer->currency }}
                                    </div>
                                    @if($offer->status == 'Pending')
                                        <form action="{{ route('admin.purchase.offers.select-winner', $offer->id) }}" method="POST" class="mt-2">
                                            @csrf
                                            <button type="submit" class="btn btn-xs btn-outline-success fw-bold w-100" onclick="return confirm('Bu tedarikçiyi onaylıyor musunuz?')">
                                                <i class="fas fa-check me-1"></i> SEÇ / ONAYLA
                                            </button>
                                        </form>
                                    @endif
                                </td>
                                @endforeach
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            @endif

            {{-- İŞLEM GEÇMİŞİ / YORUM ALANI --}}
            @if($req->status != 'Pending')
            <div class="card shadow-sm border-start-lg border-info bg-light">
                <div class="card-body">
                    <h6 class="fw-bold text-info"><i class="fas fa-info-circle me-1"></i> İşlem Sonucu</h6>
                    <p class="mb-1"><strong>İşlemi Yapan:</strong> {{ $req->approver->name ?? 'Sistem Yöneticisi' }}</p>
                    <p class="mb-1"><strong>İşlem Tarihi:</strong> {{ $req->responded_at ? $req->responded_at->format('d.m.Y H:i') : '-' }}</p>
                    <hr>
                    <p class="mb-0 small text-dark"><strong>Yönetici Notu:</strong> <br> 
                        <em class="fs-6">"{{ $req->approval_note }}"</em>
                    </p>
                </div>
            </div>
            @endif
        </div>

        {{-- SAĞ KOLON: KİŞİ BİLGİLERİ VE AKSİYON --}}
        <div class="col-lg-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Talep Sahibi</div>
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="avatar-md bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width:40px; height:40px">
                            {{ substr($req->requester->name ?? 'U', 0, 1) }}
                        </div>
                        <div>
                            <div class="fw-bold">{{ $req->requester->name ?? 'Bilinmeyen Kullanıcı' }}</div>
                            <div class="small text-muted">{{ $req->requester->email ?? '-' }}</div>
                        </div>
                    </div>
                    <div class="mb-2">
                        <small class="text-muted d-block fw-bold">Departman</small>
                        <span>{{ $req->department->name ?? '-' }}</span>
                    </div>
                    <div class="mb-2">
                        <small class="text-muted d-block fw-bold">İstenen Tarih (Termin)</small>
                        <span class="text-danger fw-bold"><i class="far fa-calendar-alt me-1"></i> {{ $req->requested_by_date ? \Carbon\Carbon::parse($req->requested_by_date)->format('d.m.Y') : '-' }}</span>
                    </div>
                    <div class="mb-0">
                        <small class="text-muted d-block fw-bold">Talep Nedeni</small>
                        <div class="p-2 bg-light rounded small mt-1 border">
                            {{ $req->reason ?? 'Açıklama girilmemiş.' }}
                        </div>
                    </div>
                </div>
            </div>

            @if($req->status == 'Pending' && (Auth::id() == $req->approver_id || Auth::user()->role == 'admin'))
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white fw-bold">
                    <i class="fas fa-gavel me-1"></i> Yönetici Kararı
                </div>
                <div class="card-body">
                    <div class="alert alert-info small">
                        <i class="fas fa-info-circle me-1"></i> Bu talep onayınızı bekliyor. Lütfen kararınızı ve gerekçenizi belirtiniz.
                    </div>

                    <form action="{{ route('admin.purchase.requests.update-status', $req->id) }}" method="POST">
                        @csrf
                        
                        {{-- GİZLİ ONAY TARİHİ ALANI --}}
                        <div class="mb-3" id="hiddenDateContainer" style="display: none;">
                            <label class="fw-bold small text-danger"><i class="fas fa-calendar-alt me-1"></i> Geçmişe Dönük Onay Tarihi</label>
                            <input type="datetime-local" name="approval_date" class="form-control form-control-sm border-danger" value="{{ date('Y-m-d\TH:i') }}">
                            <div class="form-text small text-muted">Gizli mod açıldı. Geriye dönük işlem için tarihi değiştirebilirsiniz.</div>
                        </div>

                        <div class="mb-3">
                            <label class="fw-bold small">Onay/Red Açıklaması <span class="text-danger">*</span></label>
                            <textarea name="approval_note" class="form-control" rows="3" placeholder="Gerekçenizi veya notunuzu buraya yazınız..." required minlength="5"></textarea>
                            <div class="form-text small text-muted">Bu alan zorunludur.</div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="action" value="Approved" class="btn btn-success fw-bold">
                                <i class="fas fa-check me-1"></i> TALEBİ ONAYLA
                            </button>
                            <button type="submit" name="action" value="Rejected" class="btn btn-outline-danger fw-bold">
                                <i class="fas fa-times me-1"></i> REDDET
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            @endif

        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Ctrl + Shift + T Kombinasyonunu Yakalama Kodu
    document.addEventListener('keydown', function(event) {
        if (event.ctrlKey && event.shiftKey && (event.key === 't' || event.key === 'T')) {
            event.preventDefault(); // Tarayıcının kendi Ctrl+Shift+T sekme açma işlemini engelle
            
            const dateContainer = document.getElementById('hiddenDateContainer');
            if (dateContainer) {
                if (dateContainer.style.display === 'none') {
                    dateContainer.style.display = 'block';
                } else {
                    dateContainer.style.display = 'none';
                }
            }
        }
    });
</script>
@endpush