@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="text-primary fw-bold"><i class="fas fa-plus-circle me-2"></i>YENİ SATIN ALMA TALEBİ OLUŞTUR</h5>
        <a href="{{ route('admin.purchase.requests.index') }}" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i> Listeye Dön</a>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger mb-3">
            <ul class="mb-0 small">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.purchase.requests.store') }}" method="POST">
        @csrf
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <div class="row">
                    {{-- SOL KOLON: TALEP BİLGİLERİ --}}
                    <div class="col-md-6 border-end">
                        <h6 class="text-primary fw-bold mb-3 border-bottom pb-2">TALEP ÜST BİLGİLERİ</h6>
                        
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label fw-bold small">Talep Eden / Dep.:</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control bg-light" value="{{ Auth::user()->name }} ({{ $userDepartment->name ?? 'Departman Yok' }})" readonly>
                                <input type="hidden" name="department_id" value="{{ Auth::user()->department_id ?? '' }}">
                            </div>
                        </div>

                        {{-- YENİ EKLENEN TALEP TARİHİ --}}
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label fw-bold small text-danger">Talep Tarihi:*</label>
                            <div class="col-sm-8">
                                <input type="date" name="request_date" class="form-control" value="{{ old('request_date', date('Y-m-d')) }}" required>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label fw-bold small text-danger">Onaylayacak Yönetici:*</label>
                            <div class="col-sm-8">
                                <select name="approver_id" class="form-select" required>
                                    <option value="">Seçiniz...</option>
                                    @foreach($managers as $manager)
                                        <option value="{{ $manager->id }}">{{ $manager->name }} ({{ $manager->role }})</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label fw-bold small text-danger">İstenen Termin Tarihi:*</label>
                            <div class="col-sm-8">
                                <input type="date" name="requested_by_date" class="form-control" value="{{ old('requested_by_date') }}" required>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label fw-bold small text-danger">Öncelik Durumu:*</label>
                            <div class="col-sm-8">
                                <select name="priority" class="form-select" required>
                                    <option value="Normal" selected>Normal</option>
                                    <option value="High" class="text-danger fw-bold">ACİL</option>
                                    <option value="Low" class="text-muted">Düşük Öncelik</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    {{-- SAĞ KOLON: TALEP NEDENİ --}}
                    <div class="col-md-6">
                        <h6 class="text-primary fw-bold mb-3 border-bottom pb-2">TALEP NEDENİ / GEREKÇESİ</h6>
                        <div class="form-group h-100">
                            <textarea name="reason" class="form-control" style="height: 180px; resize: none;" placeholder="Lütfen bu malzemenin/hizmetin neden talep edildiğini, nerede kullanılacağını veya projesini detaylıca yazınız...">{{ old('reason') }}</textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- ALT BÖLÜM: KALEMLER (ITEMS) --}}
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> İhtiyaç Listesi (Kalemler)</span>
                <button type="button" class="btn btn-sm btn-light text-danger fw-bold" onclick="addItemRow()">
                    <i class="fas fa-plus me-1"></i> Satır Ekle
                </button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover mb-0 align-middle" id="itemsTable">
                        <thead class="bg-light small">
                            <tr>
                                <th style="width: 35%">Malzeme / Hizmet Seçimi</th>
                                <th style="width: 15%">Miktar</th>
                                <th style="width: 15%">Birim</th>
                                <th style="width: 25%">Teknik Özellik / Not</th>
                                <th style="width: 10%" class="text-center">İşlem</th>
                            </tr>
                        </thead>
                        <tbody id="itemsBody">
                        </tbody>
                    </table>
                </div>
                <div id="emptyMessage" class="text-center py-5 text-muted">
                    <i class="fas fa-box-open fa-2x mb-2 opacity-50"></i><br>
                    Henüz ürün eklenmedi. "Satır Ekle" butonunu kullanın.
                </div>
            </div>
            <div class="card-footer bg-white text-end py-3">
                <button type="submit" class="btn btn-success px-5 fw-bold btn-lg shadow-sm"><i class="fas fa-paper-plane me-2"></i> TALEBİ ONAYA GÖNDER</button>
            </div>
        </div>
    </form>
</div>

{{-- TEKNİK ÖZELLİK OKUMA MODALI --}}
<div class="modal fade" id="specsModal" tabindex="-1" aria-labelledby="specsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold" id="specsModalLabel"><i class="fas fa-info-circle me-2"></i>Teknik Özellikler / Şartname</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body bg-light">
                <div class="p-3 bg-white rounded border" id="modalSpecsContent" style="white-space: pre-wrap; font-size: 0.95rem; min-height: 150px;"></div>
            </div>
            <div class="modal-footer border-top-0 bg-light">
                <button type="button" class="btn btn-secondary fw-bold px-4" data-bs-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    const materials = @json($materials);
    const preSelectedId = "{{ $preSelectedMaterialId ?? '' }}"; 

    function addItemRow(selectedMaterialId = null) {
        const index = new Date().getTime() + Math.floor(Math.random() * 1000);
        const tbody = document.getElementById('itemsBody');
        document.getElementById('emptyMessage').style.display = 'none';

        let options = '<option value="">Malzeme Seçiniz...</option>';
        materials.forEach(m => {
            const isSelected = (selectedMaterialId && m.id == selectedMaterialId) ? 'selected' : '';
            const casNo = m.cas_no ? m.cas_no : '';
            const unit = m.unit ? m.unit : '';
            const escapedCas = casNo.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
            
            options += `<option value="${m.id}" data-unit="${unit}" data-cas="${escapedCas}" ${isSelected}>${m.sku} - ${m.name}</option>`;
        });

        const html = `
            <tr id="row-${index}" class="item-row">
                <td>
                    <select name="items[${index}][material_id]" class="form-select form-select-sm material-select" required onchange="updateRowDetails(this, ${index})">
                        ${options}
                    </select>
                </td>
                <td><input type="number" name="items[${index}][quantity]" class="form-control form-control-sm" step="0.01" min="0.01" placeholder="0.00" required></td>
                <td><input type="text" name="items[${index}][unit]" id="unit-${index}" class="form-control form-control-sm bg-light" readonly placeholder="Birim"></td>
                <td>
                    <textarea name="items[${index}][specs]" id="specs-${index}" class="form-control form-control-sm" rows="1" style="resize: vertical;" placeholder="Varsa özellik yazın..."></textarea>
                </td>
                <td class="text-center">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-sm btn-outline-primary" title="Özellikleri Tam Ekran Oku" onclick="viewSpecs(${index})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-danger" title="Satırı Sil" onclick="removeRow(${index})">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
        tbody.insertAdjacentHTML('beforeend', html);

        if(selectedMaterialId) {
            const selectElem = document.querySelector(`#row-${index} select`);
            if(selectElem) updateRowDetails(selectElem, index);
        }
    }

    function removeRow(index) {
        if(document.querySelectorAll('.item-row').length > 1) {
            const row = document.getElementById(`row-${index}`);
            if(row) row.remove();
        } else {
            alert("Talebinizde en az 1 kalem bulunmalıdır! Satırı silmek yerine içeriğini değiştirebilirsiniz.");
        }
        
        if(document.getElementById('itemsBody').children.length === 0) {
            document.getElementById('emptyMessage').style.display = 'block';
        }
    }

    function updateRowDetails(select, index) {
        const option = select.options[select.selectedIndex];
        const unit = option.getAttribute('data-unit');
        const casNo = option.getAttribute('data-cas'); 
        
        document.getElementById(`unit-${index}`).value = unit || 'Adet';
        
        const specsInput = document.getElementById(`specs-${index}`);
        if(casNo && casNo !== '-') {
            specsInput.value = casNo;
        } else {
            specsInput.value = ''; 
        }
    }

    function viewSpecs(index) {
        const currentSpecs = document.getElementById(`specs-${index}`).value;
        const modalContentBox = document.getElementById('modalSpecsContent');
        
        if(currentSpecs && currentSpecs.trim() !== '') {
            modalContentBox.textContent = currentSpecs;
            modalContentBox.classList.remove('text-muted', 'fst-italic');
        } else {
            modalContentBox.textContent = "Bu ürün/hizmet için henüz bir teknik özellik veya not girilmemiş.";
            modalContentBox.classList.add('text-muted', 'fst-italic');
        }

        const myModal = new bootstrap.Modal(document.getElementById('specsModal'));
        myModal.show();
    }

    document.addEventListener('DOMContentLoaded', function() {
        if (preSelectedId) {
            addItemRow(preSelectedId);
        } else {
            addItemRow();
        }
    });
</script>
@endpush