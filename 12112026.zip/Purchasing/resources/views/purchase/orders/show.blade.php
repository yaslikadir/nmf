@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    
    {{-- BAŞLIK ALANI --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h3 mb-0 text-gray-800">
                Sipariş Detayı: <span class="text-primary">{{ $order->order_no }}</span>
            </h2>
            <p class="text-muted small mb-0">
                Sipariş Tarihi: {{ $order->ordered_at->format('d.m.Y H:i') }}
            </p>
        </div>
        <div>
            <a href="{{ route('admin.purchase.orders.index') }}" class="btn btn-secondary btn-sm shadow-sm">
                <i class="fas fa-arrow-left me-1"></i> Listeye Dön
            </a>
        </div>
    </div>

    @php
        // SİPARİŞ TÜRÜNÜ BELİRLE (Hizmet mi, Fiziksel Malzeme mi?)
        $isServiceOrder = false;
        foreach($order->offer->items as $item) {
            if(isset($item->requestItem->material->category->name) && str_contains(strtolower($item->requestItem->material->category->name), 'hizmet')) {
                $isServiceOrder = true;
                break;
            }
        }
    @endphp

    <div class="row">
        {{-- SOL KOLON: SİPARİŞ BİLGİLERİ VE ÜRÜNLER --}}
        <div class="col-lg-8">
            
            {{-- DURUM VE TEDARİKÇİ KARTLARI --}}
            <div class="row g-3 mb-4">
                {{-- Tedarikçi Kartı --}}
                <div class="col-md-6">
                    <div class="card h-100 shadow-sm border-start-lg border-primary">
                        <div class="card-body">
                            <div class="small text-muted fw-bold text-uppercase mb-1">Tedarikçi Firma</div>
                            <div class="h5 font-weight-bold text-gray-800">{{ $order->supplier->company_name }}</div>
                            <div class="small text-muted">
                                <i class="fas fa-user me-1"></i> Yetkili: {{ $order->supplier->contact_name ?? '-' }}<br>
                                <i class="fas fa-phone me-1"></i> Tel: {{ $order->supplier->phone ?? '-' }}
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Durum Kartı --}}
                <div class="col-md-6">
                    <div class="card h-100 shadow-sm border-start-lg border-{{ $order->status == 'Completed' ? 'success' : ($order->status == 'Cancelled' ? 'danger' : 'warning') }}">
                        <div class="card-body">
                            <div class="small text-muted fw-bold text-uppercase mb-1">Sipariş Durumu</div>
                            <div class="h5 font-weight-bold">
                                @switch($order->status)
                                    @case('Ordered')
                                        @if($isServiceOrder)
                                            <span class="text-primary"><i class="fas fa-user-cog me-2"></i>HİZMET BEKLENİYOR</span>
                                            <div class="small text-muted fw-normal mt-1">Hizmetin verilmesi/tamamlanması bekleniyor.</div>
                                        @else
                                            <span class="text-primary"><i class="fas fa-truck-loading me-2"></i>MAL BEKLENİYOR</span>
                                            <div class="small text-muted fw-normal mt-1">Sipariş geçildi, ürün teslimatı bekleniyor.</div>
                                        @endif
                                        @break
                                    @case('GoodsReceived')
                                        @if($isServiceOrder)
                                            <span class="text-warning"><i class="fas fa-check-double me-2"></i>HİZMET ALINDI</span>
                                            <div class="small text-muted fw-normal mt-1">Hizmet onaylandı. Fatura bekleniyor.</div>
                                        @else
                                            <span class="text-warning"><i class="fas fa-boxes me-2"></i>KISMİ/TAM TESLİMAT</span>
                                            <div class="small text-muted fw-normal mt-1">Mal kabul işlemi yapıldı. Fatura bekleniyor.</div>
                                        @endif
                                        @break
                                    @case('Completed')
                                        <span class="text-success"><i class="fas fa-check-circle me-2"></i>TAMAMLANDI</span>
                                        <div class="small text-muted fw-normal mt-1">Süreç başarıyla sonlandırıldı.</div>
                                        @break
                                    @case('Cancelled')
                                        <span class="text-danger"><i class="fas fa-times-circle me-2"></i>İPTAL EDİLDİ</span>
                                        @break
                                @endswitch
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- SİPARİŞ KALEMLERİ --}}
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light fw-bold">
                    <i class="fas {{ $isServiceOrder ? 'fa-clipboard-list' : 'fa-boxes' }} me-1"></i> Sipariş Kalemleri (Tekliften Gelen)
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light small text-uppercase">
                            <tr>
                                <th class="ps-3">Malzeme / Hizmet</th>
                                <th class="text-center">Miktar</th>
                                <th class="text-end">Birim Fiyat</th>
                                <th class="text-end">Toplam</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->offer->items as $item)
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold">{{ $item->requestItem->material->name ?? 'Silinmiş Malzeme' }}</div>
                                    <div class="small text-muted">{{ $item->description }}</div>
                                </td>
                                <td class="text-center fw-bold">
                                    {{ number_format($item->quantity, 2) }} {{ $item->requestItem->unit ?? '' }}
                                </td>
                                <td class="text-end">
                                    {{ number_format($item->unit_price, 2, ',', '.') }} {{ $order->offer->currency }}
                                </td>
                                <td class="text-end fw-bold text-dark">
                                    {{ number_format($item->net_total, 2, ',', '.') }} {{ $order->offer->currency }}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                        <tfoot class="bg-light">
                            <tr>
                                <td colspan="3" class="text-end fw-bold">Genel Toplam (KDV Hariç):</td>
                                <td class="text-end fw-bold text-primary fs-6">
                                    {{ number_format($order->offer->grand_total, 2, ',', '.') }} {{ $order->offer->currency }}
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            {{-- TALEP BİLGİSİ (Referans) --}}
            <div class="card shadow-sm mb-4">
                <div class="card-body py-2">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="small text-muted"><i class="fas fa-link me-1"></i> Bağlı Talep Kaydı:</span>
                        <a href="{{ route('admin.purchase.requests.show', $order->purchase_request_id) }}" class="btn btn-link btn-sm fw-bold text-decoration-none">
                            {{ $order->request->request_no }} <i class="fas fa-external-link-alt ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>

            {{-- SÜREÇ VE İŞLEM GEÇMİŞİ (ZAMAN ÇİZELGESİ) --}}
            <style>
                .timeline-container { position: relative; padding-left: 1.5rem; }
                .timeline-container::before { content: ''; position: absolute; left: 15px; top: 0; bottom: 0; width: 2px; background-color: #e3e6ec; }
                .timeline-item { position: relative; margin-bottom: 1.5rem; }
                .timeline-item:last-child { margin-bottom: 0; }
                .timeline-icon { position: absolute; left: -31px; top: 0; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; border: 3px solid #fff; box-shadow: 0 0 0 1px #e3e6ec; }
                .timeline-content { padding-left: 1rem; }
            </style>

            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white fw-bold text-dark">
                    <i class="fas fa-history me-1 text-primary"></i> Süreç ve Onay Geçmişi
                </div>
                <div class="card-body pt-4">
                    <div class="timeline-container">
                        
                        {{-- 1. ADIM: Talep Oluşturuldu --}}
                        <div class="timeline-item">
                            <div class="timeline-icon bg-primary"><i class="fas fa-file-alt"></i></div>
                            <div class="timeline-content">
                                <h6 class="mb-1 fw-bold">Talep Oluşturuldu</h6>
                                <div class="small text-muted mb-1">
                                    <i class="far fa-calendar-alt me-1"></i> {{ $order->request->request_date ? \Carbon\Carbon::parse($order->request->request_date)->format('d.m.Y') : $order->request->created_at->format('d.m.Y') }} &nbsp;|&nbsp; 
                                    <i class="far fa-user me-1"></i> {{ $order->request->requester->name ?? 'Bilinmiyor' }}
                                </div>
                                <p class="small mb-0 text-dark">Satın alma talebi sisteme girildi ve onaya sunuldu.</p>
                            </div>
                        </div>

                        {{-- 2. ADIM: Yönetici Onayı --}}
                        <div class="timeline-item">
                            <div class="timeline-icon bg-success"><i class="fas fa-check"></i></div>
                            <div class="timeline-content">
                                <h6 class="mb-1 fw-bold">Yönetici Onayı</h6>
                                <div class="small text-muted mb-1">
                                    <i class="far fa-calendar-check me-1"></i> {{ $order->request->responded_at ? $order->request->responded_at->format('d.m.Y H:i') : '-' }} &nbsp;|&nbsp; 
                                    <i class="far fa-user me-1"></i> {{ $order->request->approver->name ?? 'Bilinmiyor' }}
                                </div>
                                @if($order->request->approval_note)
                                <div class="p-2 bg-light rounded small mt-1 border-start border-success border-3">
                                    <em>"{{ $order->request->approval_note }}"</em>
                                </div>
                                @endif
                            </div>
                        </div>

                        {{-- 3. ADIM: Sipariş Emri --}}
                        <div class="timeline-item">
                            <div class="timeline-icon bg-info"><i class="fas fa-file-invoice-dollar"></i></div>
                            <div class="timeline-content">
                                <h6 class="mb-1 fw-bold">Sipariş Emri Oluşturuldu</h6>
                                <div class="small text-muted mb-1">
                                     &nbsp;|&nbsp; 
                                    <i class="far fa-building me-1"></i> {{ $order->supplier->company_name ?? '-' }}
                                </div>
                                <p class="small mb-0 text-dark">Teklif onaylanıp sipariş aşamasına geçildi.</p>
                            </div>
                        </div>

                        {{-- 4. ADIM: Teslimatlar / Mal Kabul --}}
                        @if(isset($order->deliveries) && $order->deliveries->count() > 0)
                            @foreach($order->deliveries as $del)
                            <div class="timeline-item">
                                <div class="timeline-icon bg-warning text-dark"><i class="fas fa-dolly"></i></div>
                                <div class="timeline-content">
                                    <h6 class="mb-1 fw-bold">{{ $isServiceOrder ? 'Hizmet Kabulü Yapıldı' : 'Mal Kabul Yapıldı' }} ({{ $del->delivery_note_no }})</h6>
                                    <div class="small text-muted mb-1">
                                        
                                        <i class="far fa-calendar-check me-1"></i> Teslim: {{ $del->delivery_date->format('d.m.Y') }}
                                    </div>
                                    @if($del->notes)
                                    <p class="small mb-0 text-dark"><strong>Not:</strong> {{ $del->notes }}</p>
                                    @endif
                                </div>
                            </div>
                            @endforeach
                        @elseif($order->status == 'GoodsReceived')
                            <div class="timeline-item">
                                <div class="timeline-icon bg-warning text-dark"><i class="fas fa-dolly"></i></div>
                                <div class="timeline-content">
                                    <h6 class="mb-1 fw-bold">{{ $isServiceOrder ? 'Hizmet Kabulü Yapıldı' : 'Mal Kabul Yapıldı' }}</h6>
                                    <div class="small text-muted mb-1">
                                        <i class="far fa-clock me-1"></i> {{ $order->updated_at->format('d.m.Y H:i') }}
                                    </div>
                                </div>
                            </div>
                        @endif

                        {{-- 5. ADIM: Tamamlanma (Fatura) --}}
                        @if($order->status == 'Completed')
                        <div class="timeline-item">
                            <div class="timeline-icon bg-dark"><i class="fas fa-flag-checkered"></i></div>
                            <div class="timeline-content">
                                <h6 class="mb-1 fw-bold">Süreç Tamamlandı (Fatura İşlendi)</h6>
                                <div class="small text-muted mb-1">
                                    <i class="far fa-clock me-1"></i> {{ $order->updated_at->format('d.m.Y H:i') }} &nbsp;|&nbsp;
                                    <i class="fas fa-file-invoice me-1"></i> Fat. No: {{ $order->invoice_no }}
                                </div>
                            </div>
                        </div>
                        @endif

                        {{-- İPTAL ADIMI (Eğer iptal edildiyse) --}}
                        @if($order->status == 'Cancelled')
                        <div class="timeline-item">
                            <div class="timeline-icon bg-danger"><i class="fas fa-times"></i></div>
                            <div class="timeline-content">
                                <h6 class="mb-1 fw-bold text-danger">Sipariş İptal Edildi</h6>
                                <div class="small text-muted mb-1">
                                    <i class="far fa-clock me-1"></i> {{ $order->updated_at->format('d.m.Y H:i') }}
                                </div>
                            </div>
                        </div>
                        @endif

                    </div>
                </div>
            </div>

        </div>

        {{-- SAĞ KOLON: OPERASYONEL İŞLEMLER (AKILLI PANEL) --}}
        <div class="col-lg-4">
            
            {{-- ADIM 1: YENİ TASARIM HİZMET VEYA MAL KABULÜ --}}
            <div class="card shadow-sm mb-3 border-primary">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <span class="fw-bold">
                        <i class="fas {{ $isServiceOrder ? 'fa-handshake' : 'fa-dolly' }} me-2"></i> 
                        1. {{ $isServiceOrder ? 'Hizmet Kabul Onayı' : 'Mal Kabul İşlemleri' }}
                    </span>
                </div>
                
                <div class="card-body p-0">
                    
                    @if($order->status != 'Completed' && $order->status != 'Cancelled')
                    <div class="p-3 border-bottom bg-light">
                        <div class="d-grid">
                            <a href="{{ route('admin.purchase.orders.delivery-form', $order->id) }}" class="btn btn-outline-primary fw-bold bg-white">
                                <i class="fas fa-plus-circle me-1"></i> 
                                {{ $isServiceOrder ? 'HİZMET KABUL VE KONTROL GİRİŞİ YAP' : 'YENİ MAL KABUL GİRİŞİ YAP' }}
                            </a>
                        </div>
                        <div class="text-center x-small text-muted mt-2">
                            {{ $isServiceOrder ? 'Hizmet onay kriterlerini girmek için tıklayınız.' : 'Parçalı veya tam teslimat girişi için tıklayınız.' }}
                        </div>
                    </div>
                    @endif

                    {{-- TESLİMAT / HİZMET GEÇMİŞİ LİSTESİ --}}
                    <div class="table-responsive">
                        <table class="table table-sm table-hover mb-0 align-middle" style="font-size: 0.85rem;">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3">Tarih</th>
                                    <th>{{ $isServiceOrder ? 'Form/Kayıt No' : 'İrsaliye' }}</th>
                                    <th class="text-center">Kalem</th>
                                    <th class="text-end pe-3">Detay</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($order->deliveries ?? [] as $delivery)
                                <tr>
                                    <td class="ps-3 fw-bold text-dark">{{ $delivery->delivery_date->format('d.m.Y') }}</td>
                                    <td>{{ $delivery->delivery_note_no }}</td>
                                    <td class="text-center"><span class="badge bg-secondary">{{ $delivery->items->count() }}</span></td>
                                    <td class="text-end pe-3">
                                        {{-- MODALI TETİKLEYEN BUTON --}}
                                        <button type="button" class="btn btn-xs btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#deliveryModal{{ $delivery->id }}">
                                            <i class="fas fa-search me-1"></i> İncele
                                        </button>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-4">
                                        <i class="fas fa-clipboard-check fa-2x mb-2 opacity-25"></i><br>
                                        Henüz {{ $isServiceOrder ? 'hizmet onay' : 'mal kabul' }} işlemi yapılmadı.
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{-- 2. ADIM: FATURA / KAPAMA --}}
            <div class="card shadow-sm mb-3 {{ $order->status == 'GoodsReceived' ? 'border-warning' : '' }}">
                <div class="card-header {{ $order->status == 'GoodsReceived' ? 'bg-warning text-dark' : 'bg-light text-muted' }} fw-bold">
                    <i class="fas fa-file-invoice-dollar me-2"></i> 2. Fatura Girişi
                    @if($order->status == 'Completed')
                        <i class="fas fa-check-circle float-end mt-1 text-success"></i>
                    @endif
                </div>
                <div class="card-body">
                    {{-- Fatura girişi ancak en az bir mal/hizmet kabul yapıldıysa görünür --}}
                    @if($order->status == 'GoodsReceived')
                        <div class="alert alert-warning small text-dark">
                            <i class="fas fa-exclamation-triangle me-1"></i> 
                            {{ $isServiceOrder ? 'Hizmet onayı verildi.' : 'Mal kabul işlemleri başladı.' }} 
                            Fatura bilgilerini girerek süreci tamamlayın.
                        </div>
                        <form action="{{ route('admin.purchase.orders.complete', $order->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="mb-3">
                                <label class="small fw-bold">Fatura No <span class="text-danger">*</span></label>
                                <input type="text" name="invoice_no" class="form-control" required placeholder="Örn: FAT-2026/99">
                            </div>
                            <div class="mb-3">
                                <label class="small fw-bold">Fatura Tarihi <span class="text-danger">*</span></label>
                                <input type="date" name="invoice_date" class="form-control" value="{{ date('Y-m-d') }}" required>
                            </div>
                            <div class="mb-3">
                                <label class="small fw-bold">Fatura / Rapor Dosyası (İsteğe Bağlı)</label>
                                <input type="file" name="invoice_file" class="form-control form-control-sm">
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-success fw-bold text-white">
                                    <i class="fas fa-check-double me-1"></i> SİPARİŞİ TAMAMLA
                                </button>
                            </div>
                        </form>
                    @elseif($order->status == 'Completed')
                        <table class="table table-sm table-borderless mb-0 small">
                            <tr>
                                <td class="text-muted">Fatura No:</td>
                                <td class="fw-bold">{{ $order->invoice_no }}</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Fatura Tarihi:</td>
                                <td class="fw-bold">{{ $order->invoice_date ? \Carbon\Carbon::parse($order->invoice_date)->format('d.m.Y') : '-' }}</td>
                            </tr>
                            @if($order->invoice_file)
                            <tr>
                                <td colspan="2" class="pt-2">
                                    <a href="{{ asset('storage/'.$order->invoice_file) }}" target="_blank" class="btn btn-xs btn-outline-dark w-100">
                                        <i class="fas fa-paperclip me-1"></i> Dosyayı Görüntüle
                                    </a>
                                </td>
                            </tr>
                            @endif
                        </table>
                        <div class="alert alert-success small mt-3 mb-0 text-center fw-bold">
                            <i class="fas fa-check-circle me-1"></i> SİPARİŞ TAMAMLANDI
                        </div>
                    @elseif($order->status == 'Ordered')
                        <div class="text-center text-muted small py-3">
                            <i class="fas fa-lock me-1"></i> Fatura girişi için önce 
                            <strong>{{ $isServiceOrder ? 'Hizmet Kabulü' : 'Mal Kabul' }}</strong> yapmalısınız.
                        </div>
                    @endif
                </div>
            </div>

            {{-- 3. ADIM: EKLENEN EK DÖKÜMANLAR ALANI --}}
            <div class="card shadow-sm mb-3 border-secondary">
                <div class="card-header bg-secondary text-white fw-bold">
                    <i class="fas fa-folder-open me-2"></i> 3. Sipariş Dökümanları
                </div>
                <div class="card-body">
                    
                    {{-- YÜKLÜ DÖKÜMANLAR LİSTESİ --}}
                    @if($order->documents && $order->documents->count() > 0)
                    <div class="table-responsive mb-3">
                        <table class="table table-sm table-bordered align-middle mb-0">
                            <thead class="bg-light text-muted small">
                                <tr>
                                    <th>Belge Adı</th>
                                    <th>Yüklenme Tarihi</th>
                                    <th width="100" class="text-center">İşlem</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($order->documents as $doc)
                                <tr>
                                    <td class="fw-bold"><i class="fas fa-file-alt text-primary me-2"></i> {{ $doc->name }}</td>
                                    <td class="small text-muted">{{ $doc->created_at->format('d.m.Y H:i') }}</td>
                                    <td class="text-center">
                                        <a href="{{ asset('storage/'.$doc->file_path) }}" target="_blank" class="btn btn-xs btn-primary shadow-sm">
                                            <i class="fas fa-eye"></i> İncele
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <hr>
                    @endif

                    {{-- YENİ DOSYA YÜKLEME FORMU --}}
                    <div class="alert alert-secondary small">
                        Fatura dışında siparişe ait (sözleşme, garanti belgesi vb.) yeni evrakları buradan yükleyebilirsiniz.
                    </div>
                    <form action="{{ route('admin.purchase.orders.upload-document', $order->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="row align-items-end g-2">
                            <div class="col-md-5">
                                <label class="small fw-bold">Belge Adı/Açıklaması <span class="text-danger">*</span></label>
                                <input type="text" name="document_name" class="form-control form-control-sm" required placeholder="Örn: Bakım Sözleşmesi">
                            </div>
                            <div class="col-md-5">
                                <label class="small fw-bold">Dosya <span class="text-danger">*</span></label>
                                <input type="file" name="document_file" class="form-control form-control-sm" required>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-sm btn-secondary fw-bold w-100 h-100 py-2">
                                    <i class="fas fa-upload me-1"></i> YÜKLE
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

{{-- TESLİMAT/HİZMET GEÇMİŞİ DETAY MODALLARI --}}
@if(isset($order->deliveries))
    @foreach($order->deliveries as $delivery)
    <div class="modal fade" id="deliveryModal{{ $delivery->id }}" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title fw-bold">
                        <i class="fas {{ $isServiceOrder ? 'fa-clipboard-check' : 'fa-boxes' }} me-2"></i>
                        {{ $isServiceOrder ? 'Hizmet Kabul Formu Detayı' : 'Mal Kabul İrsaliye Detayı' }}
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body bg-light">
                    
                    {{-- ÜST BİLGİLER --}}
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="small text-muted fw-bold text-uppercase">{{ $isServiceOrder ? 'Sistem Kayıt / Form No' : 'İrsaliye No' }}</div>
                            <div class="fw-bold text-dark fs-6">{{ $delivery->delivery_note_no }}</div>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <div class="small text-muted fw-bold text-uppercase">İşlem Tarihi</div>
                            <div class="fw-bold text-dark fs-6">{{ $delivery->delivery_date->format('d.m.Y') }}</div>
                        </div>
                    </div>
                    
                    @if($delivery->notes)
                        <div class="alert alert-secondary small py-2 mb-3 border-secondary">
                            <strong><i class="fas fa-sticky-note me-1"></i> Not / Açıklama:</strong> {{ $delivery->notes }}
                        </div>
                    @endif

                    {{-- DETAY TABLOSU --}}
                    <div class="table-responsive border rounded bg-white shadow-sm">
                        <table class="table table-bordered table-hover align-middle mb-0 text-sm">
                            <thead class="bg-light text-center small text-muted">
                                <tr>
                                    <th class="text-start" style="width: 25%">{{ $isServiceOrder ? 'Hizmet Kalemi' : 'Malzeme' }}</th>
                                    <th class="text-start" style="width: 35%">Talep Edilen Özellik / Şartlar (Ne İstemiştik?)</th>
                                    <th style="width: 10%">Miktar</th>
                                    <th style="width: 10%" class="text-success">Kabul</th>
                                    <th style="width: 10%" class="text-danger">Red</th>
                                    <th style="width: 10%">Sonuç / Not</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($delivery->items as $dItem)
                                <tr>
                                    <td class="fw-bold text-dark">
                                        {{ $dItem->orderItem->requestItem->material->name ?? '-' }}
                                    </td>
                                    
                                    {{-- NE İSTEMİŞTİK? ALANI --}}
                                    <td class="small text-muted bg-light">
                                        {{ $dItem->orderItem->requestItem->technical_specifications ?? 'Belirli bir şartname girilmemiş.' }}
                                    </td>
                                    
                                    <td class="text-center fw-bold">{{ $dItem->quantity_received + 0 }}</td>
                                    <td class="text-center fw-bold text-success">{{ $dItem->quantity_accepted + 0 }}</td>
                                    <td class="text-center fw-bold text-danger">{{ $dItem->quantity_rejected > 0 ? ($dItem->quantity_rejected + 0) : '-' }}</td>
                                    
                                    <td class="text-center small">
                                        @if($dItem->quantity_rejected > 0)
                                            <span class="badge bg-danger" title="{{ $dItem->rejection_reason }}">REDDEDİLDİ</span>
                                            <div class="x-small text-muted mt-1">{{ $dItem->rejection_reason }}</div>
                                        @else
                                            <span class="badge bg-success"><i class="fas fa-check"></i> ONAYLANDI</span>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                </div>
                <div class="modal-footer bg-white">
                    <button type="button" class="btn btn-secondary fw-bold px-4" data-bs-dismiss="modal">Kapat</button>
                </div>
            </div>
        </div>
    </div>
    @endforeach
@endif
@endsection