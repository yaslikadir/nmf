@extends('layouts.admin')

@push('css')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
<style>
    /* Tablo ve Kart Stilleri */
    .bg-success-soft { background-color: #e3f9ed; }
    .bg-warning-soft { background-color: #fff9e6; }
    .bg-danger-soft { background-color: #ffe6e6; }
    .bg-info-soft { background-color: #e3f2fd; }
    .bg-primary-soft { background-color: #dbeafe; }
    
    .table-hover tbody tr:hover { background-color: #f8f9fa; cursor: pointer; }
    #ordersTable_wrapper .dataTables_filter { float: right; }
    #ordersTable_wrapper .dataTables_length { float: left; }
    .btn-export { font-size: 0.75rem; padding: 4px 12px; font-weight: bold; }
    .action-icon { cursor: pointer; margin: 0 5px; color: #6c757d; transition: color 0.2s; }
    .action-icon:hover { color: #007bff; }
    .dt-buttons { float: left; margin-right: 10px; }
    
    /* Durum Badge'leri (Sipariş Süreci) */
    .badge-ordered { background-color: #0d6efd; color: white; }       /* Sipariş Verildi (Mal Bekleniyor) */
    .badge-received { background-color: #fd7e14; color: white; }      /* Mal Kabul (Fatura Bekleniyor) */
    .badge-completed { background-color: #198754; color: white; }     /* Tamamlandı */
    .badge-cancelled { background-color: #dc3545; color: white; }     /* İptal */
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">
    {{-- ÜST AKSİYON ÇUBUĞU --}}
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="text-primary fw-bold mb-0 text-uppercase">
            <i class="fas fa-truck-loading me-2"></i>SİPARİŞ YÖNETİMİ
        </h5>
        <div class="d-flex gap-2">
            {{-- Siparişler otomatik oluştuğu için manuel ekleme butonu yerine Talep Listesine yönlendirme koyduk --}}
            <a href="{{ route('admin.purchase.requests.index') }}" class="btn btn-sm btn-secondary px-4 fw-bold shadow-sm">
                <i class="fas fa-arrow-left me-1"></i> TALEP LİSTESİNE GİT
            </a>
            <button type="button" class="btn btn-sm btn-primary px-4 fw-bold shadow-sm" onclick="location.reload();">
                <i class="fas fa-sync me-1"></i> YENİLE
            </button>
        </div>
    </div>

    {{-- FİLTRE VE EXPORT BÖLÜMÜ --}}
    <div class="card shadow-none border mb-3">
        <div class="card-header bg-light py-2 border-bottom">
            <div class="row align-items-center g-2">
                <div class="col-md-6">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="d-flex gap-1">
                            {{-- DURUM FİLTRESİ --}}
                            <select class="form-select form-select-sm" id="listeTuru" style="width: auto;">
                                <option value="tum">Tüm Durumlar</option>
                                <option value="bekleyen">Mal Bekleyenler (Sipariş)</option>
                                <option value="kabul">Fatura Bekleyenler (Mal Kabul)</option>
                                <option value="tamamlanan">Tamamlananlar</option>
                                <option value="iptal">İptal Edilenler</option>
                            </select>
                            {{-- TARİH FİLTRESİ --}}
                            <select class="form-select form-select-sm" id="tumListe" style="width: auto;">
                                <option value="tum">Tüm Tarihler</option>
                                <option value="buay">Bu Ay</option>
                                <option value="bugun">Bugün</option>
                                <option value="gecenay">Geçen Ay</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-sm btn-success btn-export" id="btnExportXLS">
                            <i class="fas fa-file-excel me-1"></i> XLS
                        </button>
                        <button type="button" class="btn btn-sm btn-danger btn-export" id="btnExportPDF">
                            <i class="fas fa-file-pdf me-1"></i> PDF
                        </button>
                        <button type="button" class="btn btn-sm btn-warning btn-export" id="btnColumnToggle">
                            <i class="fas fa-columns me-1"></i> SÜTUNLAR
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-2">
            {{-- TABLO --}}
            <div class="table-responsive">
                <table class="table table-sm table-hover table-bordered mb-0 align-middle" id="ordersTable" style="font-size: 0.85rem;">
                    <thead class="bg-primary text-white">
                        <tr>
                            <th width="30" class="text-center">#</th>
                            <th>Sipariş No</th>
                            <th>Tedarikçi</th>
                            <th>Talep No</th>
                            <th>Sipariş Tarihi</th>
                            <th class="text-end">Tutar</th>
                            <th class="text-center">Döviz</th>
                            <th class="text-center">Durum</th>
                            <th width="80" class="text-center">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($orders as $index => $order)
                        <tr data-id="{{ $order->id }}"> {{-- Tıklayınca Sipariş Detayına Gitsin --}}
                            <td class="text-center">{{ $index + 1 }}</td>
                            
                            {{-- Sipariş No --}}
                            <td class="fw-bold text-primary">{{ $order->order_no }}</td>
                            
                            {{-- Tedarikçi --}}
                            <td class="fw-bold">{{ $order->supplier->company_name ?? '-' }}</td>
                            
                            {{-- Talep No --}}
                            <td>
                                <span class="badge bg-light text-dark border">
                                    {{ $order->request->request_no ?? '-' }}
                                </span>
                            </td>
                            
                            {{-- Tarih --}}
                            <td>{{ $order->ordered_at->format('d.m.Y H:i') }}</td>

                            {{-- Tutar (İlişkili Tekliften Gelir) --}}
                            <td class="text-end fw-bold">
                                {{ $order->offer ? number_format($order->offer->grand_total, 2, ',', '.') : '-' }}
                            </td>
                            <td class="text-center small">
                                {{ $order->offer->currency ?? '-' }}
                            </td>

                            {{-- Durum --}}
                            <td class="text-center">
                                @switch($order->status)
                                    @case('Ordered')
                                        <span class="badge badge-ordered">Mal Bekleniyor</span>
                                        @break
                                    @case('GoodsReceived')
                                        <span class="badge badge-received">Fatura Bekleniyor</span>
                                        @break
                                    @case('Completed')
                                        <span class="badge badge-completed"><i class="fas fa-check-double me-1"></i> Tamamlandı</span>
                                        @break
                                    @case('Cancelled')
                                        <span class="badge badge-cancelled">İptal</span>
                                        @break
                                @endswitch
                            </td>

                            {{-- İşlemler --}}
                            <td class="text-center">
                                <a href="{{ route('admin.purchase.orders.show', $order->id) }}" class="action-icon text-primary" title="Sipariş Detayı / Mal Kabul">
                                    <i class="fas fa-boxes"></i>
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="9" class="text-center py-4 text-muted">
                                <i class="fas fa-truck-loading fa-3x mb-3 d-block opacity-25"></i>
                                Henüz sipariş kaydı bulunmuyor.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-2 small">
            <div class="text-muted">Toplam {{ $orders->total() }} sipariş listelendi.</div>
        </div>
    </div>

    {{-- İSTATİSTİK KARTLARI --}}
    <div class="row g-3 mt-3">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-info-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Toplam Sipariş</h6>
                            <h3 class="fw-bold mb-0 text-primary">{{ $orders->total() }}</h3>
                        </div>
                        <div class="fs-1 text-primary opacity-50"><i class="fas fa-clipboard-list"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-primary-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Mal Bekleyen</h6>
                            <h3 class="fw-bold mb-0 text-primary">{{ $orders->where('status', 'Ordered')->count() }}</h3>
                        </div>
                        <div class="fs-1 text-primary opacity-50"><i class="fas fa-shipping-fast"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-warning-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Fatura Bekleyen</h6>
                            <h3 class="fw-bold mb-0 text-warning">{{ $orders->where('status', 'GoodsReceived')->count() }}</h3>
                        </div>
                        <div class="fs-1 text-warning opacity-50"><i class="fas fa-file-invoice-dollar"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-success-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Tamamlanan</h6>
                            <h3 class="fw-bold mb-0 text-success">{{ $orders->where('status', 'Completed')->count() }}</h3>
                        </div>
                        <div class="fs-1 text-success opacity-50"><i class="fas fa-check-circle"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- SÜTUN AYARLARI MODAL --}}
<div class="modal fade" id="columnModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary text-white">
                <h6 class="modal-title fw-bold mb-0"><i class="fas fa-columns me-2"></i>Sütun Ayarları</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-2">
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="1" checked id="c1"><label for="c1">Sipariş No</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="2" checked id="c2"><label for="c2">Tedarikçi</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="3" checked id="c3"><label for="c3">Talep No</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="4" checked id="c4"><label for="c4">Sipariş Tarihi</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="5" checked id="c5"><label for="c5">Tutar</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="7" checked id="c7"><label for="c7">Durum</label></div></div>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
$(document).ready(function() {
    $.fn.dataTable.ext.errMode = 'none';

    // DATATABLE INIT
    const table = $('#ordersTable').DataTable({
        language: {
            "emptyTable": "Tabloda veri yok",
            "info": "_TOTAL_ kayıttan _START_ - _END_ arası gösteriliyor",
            "infoEmpty": "Kayıt yok",
            "infoFiltered": "(_MAX_ kayıt içerisinden)",
            "lengthMenu": "_MENU_ kayıt göster",
            "loadingRecords": "Yükleniyor...",
            "search": "Ara:",
            "zeroRecords": "Eşleşen kayıt bulunamadı",
            "paginate": { "first": "İlk", "last": "Son", "next": "Sonraki", "previous": "Önceki" }
        },
        pageLength: 25,
        order: [[4, 'desc']], // Sipariş Tarihine Göre Yeni->Eski
        dom: 'Bfrtip',
        buttons: [
            { extend: 'excelHtml5', text: '<i class="fas fa-file-excel me-1"></i> Excel', className: 'btn btn-success btn-sm' },
            { extend: 'pdfHtml5', text: '<i class="fas fa-file-pdf me-1"></i> PDF', className: 'btn btn-danger btn-sm' }
        ],
        columnDefs: [ { orderable: false, targets: [0, 8] } ] // # ve İşlemler sıralanamaz
    });

    // --- FİLTRELEME ---
    
    // Durum Filtresi (Kolon 7: Durum)
    $('#listeTuru').on('change', function() {
        const val = $(this).val();
        if(val === 'tum') table.column(7).search('').draw();
        else if(val === 'bekleyen') table.column(7).search('Mal Bekleniyor').draw();
        else if(val === 'kabul') table.column(7).search('Fatura Bekleniyor').draw();
        else if(val === 'tamamlanan') table.column(7).search('Tamamlandı').draw();
        else if(val === 'iptal') table.column(7).search('İptal').draw();
    });

    // Tarih Filtresi (Kolon 4: Sipariş Tarihi)
    $('#tumListe').on('change', function() {
        const value = $(this).val();
        const today = new Date();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const yyyy = today.getFullYear();

        if (value === 'bugun') {
            const todayStr = String(today.getDate()).padStart(2, '0') + '.' + mm + '.' + yyyy;
            table.column(4).search(todayStr).draw();
        } else if (value === 'buay') {
            table.column(4).search('.' + mm + '.' + yyyy).draw();
        } else {
            table.column(4).search('').draw();
        }
    });

    // --- SATIR TIKLAMA (Detaya Git) ---
    $('#ordersTable tbody').on('click', 'tr', function(e) {
        if (!$(e.target).closest('a, button').length) {
            const id = $(this).data('id');
            if(id) window.location.href = `/admin/purchase/orders/${id}`;
        }
    });

    // Sütun Gizle/Göster
    $('#btnColumnToggle').on('click', function() { $('#columnModal').modal('show'); });
    $('.column-toggle').on('change', function() {
        const column = table.column($(this).data('column'));
        column.visible(!column.visible());
    });

    // Export Tuşları
    $('#btnExportXLS').on('click', function() { table.button('.buttons-excel').trigger(); });
    $('#btnExportPDF').on('click', function() { table.button('.buttons-pdf').trigger(); });
});
</script>
@endpush