@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    
    @php
        // SİPARİŞİN TÜRÜNÜ BELİRLEYELİM (Malzeme mi, Hizmet/Kalibrasyon mu?)
        $isServiceOrder = false;
        foreach($order->offer->items as $item) {
            if(isset($item->requestItem->material->category->name) && str_contains(strtolower($item->requestItem->material->category->name), 'hizmet')) {
                $isServiceOrder = true;
                break;
            }
        }
    @endphp

    <h4 class="mb-3 text-primary fw-bold">
        <i class="fas {{ $isServiceOrder ? 'fa-handshake' : 'fa-dolly' }} me-2"></i>
        {{ $isServiceOrder ? 'Hizmet Onayı & Kalite Kontrol Girişi' : 'Mal Kabul & Kalite Kontrol Girişi' }}
    </h4>
    
    <div class="card shadow-sm border-0 mb-4 border-start-lg border-primary">
        <div class="card-body bg-light">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <span class="text-muted small d-block">Sipariş No</span>
                    <strong class="text-primary">{{ $order->order_no }}</strong>
                </div>
                <div class="col-md-4">
                    <span class="text-muted small d-block">Tedarikçi Firma</span>
                    <strong>{{ $order->supplier->company_name }}</strong>
                </div>
                <div class="col-md-3">
                    <span class="text-muted small d-block">Talep Eden</span>
                    <strong>{{ $order->request->requester->name }}</strong>
                </div>
                <div class="col-md-2 text-end">
                    @if($isServiceOrder)
                        <span class="badge bg-warning text-dark px-3 py-2"><i class="fas fa-tools me-1"></i> Hizmet Alımı</span>
                    @else
                        <span class="badge bg-success px-3 py-2"><i class="fas fa-box me-1"></i> Fiziksel Ürün</span>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <form action="{{ route('admin.purchase.orders.store-delivery', $order->id) }}" method="POST">
        @csrf
        
        {{-- İRSALİYE BİLGİLERİ (Ortak Alan) --}}
        <div class="card mb-4 shadow-sm">
            <div class="card-header fw-bold bg-white">1. {{ $isServiceOrder ? 'Hizmet Raporu / Servis Formu' : 'İrsaliye Bilgileri' }}</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold">{{ $isServiceOrder ? 'Servis/Rapor No (Varsa)' : 'İrsaliye No' }} <span class="text-danger">*</span></label>
                        <input type="text" name="delivery_note_no" class="form-control" placeholder="{{ $isServiceOrder ? 'HİZMET-ONAY' : 'İrsaliye üzerindeki numara' }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold">{{ $isServiceOrder ? 'Hizmet Tarihi' : 'Teslim Tarihi' }} <span class="text-danger">*</span></label>
                        <input type="date" name="delivery_date" class="form-control" value="{{ date('Y-m-d') }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold">Genel Notlar</label>
                        <input type="text" name="notes" class="form-control" placeholder="{{ $isServiceOrder ? 'Örn: Kalibrasyon yerinde yapıldı...' : 'Örn: Kolilerde ezik var...' }}">
                    </div>
                </div>
            </div>
        </div>

        {{-- HİZMET İSE FARKLI TABLO, ÜRÜN İSE FARKLI TABLO GÖSTERİYORUZ --}}
        <div class="card mb-4 shadow-sm border-{{ $isServiceOrder ? 'warning' : 'primary' }}">
            <div class="card-header fw-bold bg-{{ $isServiceOrder ? 'warning text-dark' : 'primary text-white' }}">
                2. {{ $isServiceOrder ? 'Hizmet/Kalibrasyon Kabul Kriterleri' : 'Ürün Kontrolü ve Sayımı' }}
            </div>
            
            <div class="table-responsive">
                <table class="table table-bordered align-middle mb-0">
                    
                    @if($isServiceOrder)
                        {{-- HİZMET KONTROL TABLOSU --}}
                        <thead class="bg-light text-center small">
                            <tr>
                                <th style="width: 30%">Hizmet / Servis Kalemi</th>
                                <th style="width: 35%">Talep Edilen Özellik / Şartlar (Ne İstemiştik?)</th>
                                <th style="width: 15%" class="bg-primary-soft">Kriterleri Karşılıyor mu?</th>
                                <th style="width: 20%">Red / Hata Açıklaması</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->offer->items as $item)
                            @if($item->remaining_qty > 0)
                            <tr>
                                <td>
                                    <strong>{{ $item->requestItem->material->name }}</strong>
                                </td>
                                <td class="small text-muted bg-light">
                                    {{-- Talep edilirken yazılan Teknik Şartname (Ne istenmişti?) --}}
                                    {{ $item->requestItem->technical_specifications ?? 'Belirli bir şartname girilmemiş.' }}
                                </td>
                                
                                {{-- HİZMET ONAY INPUTLARI --}}
                                <td class="bg-primary-soft p-3 text-center">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input border-success" type="radio" name="items[{{ $item->id }}][is_accepted]" id="accept_{{ $item->id }}" value="1" checked onchange="toggleReason({{ $item->id }}, true)">
                                        <label class="form-check-label text-success fw-bold" for="accept_{{ $item->id }}">Evet</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input border-danger" type="radio" name="items[{{ $item->id }}][is_accepted]" id="reject_{{ $item->id }}" value="0" onchange="toggleReason({{ $item->id }}, false)">
                                        <label class="form-check-label text-danger fw-bold" for="reject_{{ $item->id }}">Hayır</label>
                                    </div>
                                    
                                    {{-- Controller için gizli miktar (Hizmetlerde miktar 1 olarak sayılır veya sipariş edilen miktar kadar kabul edilir) --}}
                                    <input type="hidden" name="items[{{ $item->id }}][received_qty]" id="qty_received_{{ $item->id }}" value="{{ $item->remaining_qty }}">
                                    <input type="hidden" name="items[{{ $item->id }}][rejected_qty]" id="qty_rejected_{{ $item->id }}" value="0">
                                </td>
                                <td class="p-1">
                                    <input type="text" 
                                           name="items[{{ $item->id }}][reason]" 
                                           id="reason_{{ $item->id }}"
                                           class="form-control form-control-sm" 
                                           placeholder="Eğer hayır ise nedenini yazınız..." disabled>
                                </td>
                            </tr>
                            @endif
                            @endforeach
                        </tbody>

                    @else
                        {{-- NORMAL ÜRÜN / MAL KABUL TABLOSU --}}
                        <thead class="bg-light text-center small">
                            <tr>
                                <th style="width: 30%">Malzeme</th>
                                <th style="width: 10%">Sipariş Edilen</th>
                                <th style="width: 10%">Daha Önce Gelen</th>
                                <th style="width: 10%">KALAN</th>
                                <th style="width: 12%" class="bg-primary-soft">GELEN MİKTAR</th>
                                <th style="width: 12%" class="bg-danger-soft">RED / İADE</th>
                                <th>Red Nedeni</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->offer->items as $item)
                            @if($item->remaining_qty > 0) 
                            <tr>
                                <td>
                                    <strong>{{ $item->requestItem->material->name }}</strong>
                                    <div class="small text-muted">{{ $item->description }}</div>
                                </td>
                                <td class="text-center">{{ $item->quantity + 0 }}</td>
                                <td class="text-center text-muted">{{ $item->received_so_far + 0 }}</td>
                                <td class="text-center fw-bold">{{ $item->remaining_qty + 0 }}</td>
                                
                                <td class="bg-primary-soft p-1">
                                    <input type="number" step="0.01" 
                                           name="items[{{ $item->id }}][received_qty]" 
                                           class="form-control text-center fw-bold border-primary" 
                                           placeholder="0" max="{{ $item->remaining_qty }}">
                                </td>
                                <td class="bg-danger-soft p-1">
                                    <input type="number" step="0.01" 
                                           name="items[{{ $item->id }}][rejected_qty]" 
                                           class="form-control text-center text-danger" 
                                           placeholder="0">
                                </td>
                                <td class="p-1">
                                    <input type="text" 
                                           name="items[{{ $item->id }}][reason]" 
                                           class="form-control form-control-sm" 
                                           placeholder="Açıklama...">
                                </td>
                            </tr>
                            @endif
                            @endforeach
                        </tbody>
                    @endif

                </table>
            </div>
            
            @if($isServiceOrder)
            <div class="card-footer bg-light small text-muted">
                <i class="fas fa-info-circle me-1"></i> Kalibrasyon veya hizmet alımında, ilgili firmanın ilettiği raporun veya yaptığı işlemin talebinizi (teknik şartname) karşılayıp karşılamadığını kontrol ederek onay veriniz.
            </div>
            @endif
        </div>

        <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-5">
            <a href="{{ route('admin.purchase.orders.show', $order->id) }}" class="btn btn-secondary px-4">İptal Et</a>
            <button type="submit" class="btn btn-success fw-bold px-5">
                <i class="fas fa-save me-2"></i> İŞLEMİ KAYDET
            </button>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
    // Sadece Hizmet Alımı tablolarında çalışacak olan JavaScript (Evet/Hayır) mantığı
    function toggleReason(itemId, isAccepted) {
        let reasonInput = document.getElementById('reason_' + itemId);
        let qtyReceivedInput = document.getElementById('qty_received_' + itemId);
        let qtyRejectedInput = document.getElementById('qty_rejected_' + itemId);
        let maxQty = parseFloat(qtyReceivedInput.defaultValue); // Toplam kalan miktar

        if (isAccepted) {
            // Hizmet KABUL EDİLDİ
            reasonInput.disabled = true;
            reasonInput.value = '';
            reasonInput.required = false;
            
            // Gizli miktar inputlarını backend'in kabul edeceği şekle sok (Tümü kabul)
            qtyReceivedInput.value = maxQty;
            qtyRejectedInput.value = 0;
        } else {
            // Hizmet REDDEDİLDİ (Kriterleri sağlamadı)
            reasonInput.disabled = false;
            reasonInput.required = true;
            reasonInput.focus();
            
            // Gizli miktar inputlarını (Tümü reddedildi) olarak ayarla
            qtyReceivedInput.value = maxQty;
            qtyRejectedInput.value = maxQty;
        }
    }
</script>
@endpush