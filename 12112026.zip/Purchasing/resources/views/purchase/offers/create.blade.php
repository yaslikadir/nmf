@extends('layouts.admin')

@push('css')
<style>
    /* Select2 üzerine gelindiğinde (mavi arka plan) içindeki yazıların zorla BEYAZ olmasını sağlar */
    .select2-container--default .select2-results__option--highlighted[aria-selected] span.text-success,
    .select2-container--default .select2-results__option--highlighted[aria-selected] span.text-danger {
        color: #ffffff !important;
    }
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h3 mb-0 text-gray-800">
            <i class="fas fa-hand-holding-usd me-2 text-success"></i>Yeni Fiyat Teklifi Girişi
        </h2>
        <a href="{{ route('admin.purchase.requests.show', $req->id) }}" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left me-1"></i> Talebe Dön
        </a>
    </div>

    <form action="{{ route('admin.purchase.offers.store') }}" method="POST">
        @csrf
        <input type="hidden" name="purchase_request_id" value="{{ $req->id }}">

        <div class="row">
            {{-- SOL: TEDARİKÇİ VE GENEL BİLGİLER --}}
            <div class="col-lg-4 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-light fw-bold">Teklif Genel Bilgileri</div>
                    <div class="card-body">
                        <div class="alert alert-primary py-2 small">
                            <strong>Talep No:</strong> {{ $req->request_no }}<br>
                            Talep Eden: {{ $req->requester->name }}
                        </div>

                        {{-- TEDARİKÇİ FİLTRE SWITCH'İ --}}
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="small fw-bold">Tedarikçi Seçimi <span class="text-danger">*</span></label>
                            <div class="form-check form-switch m-0">
                                <input class="form-check-input" type="checkbox" id="showAllSuppliers">
                                <label class="form-check-label x-small text-muted" for="showAllSuppliers" style="cursor: pointer;">Tümünü Göster</label>
                            </div>
                        </div>

                        <div class="mb-3">
                            <select name="supplier_id" id="supplierSelect" class="form-select select2" required>
                                <option value="">Seçiniz...</option>
                                {{-- HTML Fallback class'ları eklendi --}}
                                @foreach($suppliers as $sup)
                                    <option value="{{ $sup->id }}" data-status="{{ $sup->status }}" class="{{ $sup->status == 'Approved' ? 'text-success' : 'text-danger' }}">
                                        {{ $sup->company_name }} {{ $sup->status != 'Approved' ? '('.($sup->status == 'Pending' ? 'Bekliyor' : ($sup->status == 'Conditional' ? 'Şartlı' : 'Red')).')' : '' }}
                                    </option>
                                @endforeach
                            </select>
                            <small id="supplierHelp" class="text-muted x-small d-block mt-1">Sadece <b>"Onaylı" (YEŞİL)</b> tedarikçiler listeleniyor.</small>
                        </div>

                        {{-- TEKLİF NUMARALARI --}}
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label class="small fw-bold text-primary">Sistem Teklif No</label>
                                <input type="text" name="offer_no" class="form-control fw-bold bg-light" value="{{ $newOfferCode }}" readonly>
                                <div class="form-text x-small">Otomatik üretilir.</div>
                            </div>
                            <div class="col-6 mb-3">
                                <label class="small fw-bold">Tedarikçi Ref No</label>
                                <input type="text" name="supplier_offer_ref" class="form-control" placeholder="Örn: 2024/Q-55">
                                <div class="form-text x-small">Faturadaki no.</div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6 mb-3">
                                <label class="small fw-bold">Teklif Tarihi <span class="text-danger">*</span></label>
                                <input type="date" name="offer_date" class="form-control" value="{{ date('Y-m-d') }}" required>
                            </div>
                            <div class="col-6 mb-3">
                                <label class="small fw-bold">Geçerlilik</label>
                                <input type="date" name="valid_until" class="form-control">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6 mb-3">
                                <label class="small fw-bold">Para Birimi</label>
                                <select name="currency" class="form-select">
                                    <option value="TL">TL (₺)</option>
                                    <option value="USD">USD ($)</option>
                                    <option value="EUR">EUR (€)</option>
                                </select>
                            </div>
                            <div class="col-6 mb-3">
                                <label class="small fw-bold">Notlar</label>
                                <textarea name="notes" class="form-control" rows="1"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- SAĞ: FİYATLANDIRMA LİSTESİ --}}
            <div class="col-lg-8 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-success text-white fw-bold">
                        <i class="fas fa-list-ol me-1"></i> Fiyatlandırma
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light small">
                                <tr>
                                    <th style="width: 35%">Malzeme / Talep</th>
                                    <th style="width: 15%">Miktar</th>
                                    <th style="width: 20%">Birim Fiyat</th>
                                    <th style="width: 15%">KDV (%)</th>
                                    <th style="width: 15%">Açıklama</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($req->items as $item)
                                <tr class="bg-light-soft">
                                    <td>
                                        <div class="fw-bold text-dark">{{ $item->material->name }}</div>
                                        <div class="small text-muted">{{ $item->technical_specifications }}</div>
                                    </td>
                                    <td>
                                        <input type="number" name="items[{{ $item->id }}][quantity]" class="form-control form-control-sm bg-white" value="{{ $item->quantity }}" step="0.01" readonly>
                                        <span class="small text-muted">{{ $item->unit }}</span>
                                    </td>
                                    <td>
                                        <input type="number" name="items[{{ $item->id }}][unit_price]" class="form-control form-control-sm border-success fw-bold" placeholder="0.00" step="0.01" required>
                                    </td>
                                    <td>
                                        <select name="items[{{ $item->id }}][tax_rate]" class="form-select form-select-sm">
                                            <option value="20">20%</option>
                                            <option value="10">10%</option>
                                            <option value="1">1%</option>
                                            <option value="0">0%</option>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="text" name="items[{{ $item->id }}][description]" class="form-control form-control-sm" placeholder="Marka vb.">
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer bg-white text-end py-3">
                        <button type="submit" class="btn btn-success px-5 fw-bold shadow">
                            <i class="fas fa-save me-1"></i> TEKLİFİ KAYDET
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function() {
        
        // SELECT2 RENKLENDİRME SİHRİ (İkonlu ve Renkli)
        function formatSupplier(state) {
            if (!state.id) { return state.text; } // Seçiniz yazısı için
            
            var status = $(state.element).data('status');
            var text = state.text;
            
            if (status === 'Approved') {
                return $('<span class="text-success fw-bold"><i class="fas fa-check-circle me-1"></i>' + text + '</span>');
            } else {
                return $('<span class="text-danger fw-bold"><i class="fas fa-exclamation-triangle me-1"></i>' + text + '</span>');
            }
        }

        // Select2'yi başlatan fonksiyon
        function initSelect2() {
            if($.fn.select2) {
                $('#supplierSelect').select2({
                    placeholder: "Seçiniz...",
                    allowClear: true,
                    templateResult: formatSupplier,      // Açılır listedeki görünüm
                    templateSelection: formatSupplier    // Seçildikten sonraki görünüm
                });
            }
        }

        // Sayfa yüklendiğinde varsayılan olarak "Sadece Onaylı" tedarikçileri göster
        filterSuppliers(false);

        // Switch değiştiğinde tetiklenecek olay
        $('#showAllSuppliers').change(function() {
            let isChecked = $(this).is(':checked');
            filterSuppliers(isChecked);
            
            // Altındaki yardım metnini güncelle
            if(isChecked) {
                $('#supplierHelp').html('<span class="text-danger fw-bold"><i class="fas fa-exclamation-triangle"></i> DİKKAT: Henüz onaylanmamış (KIRMIZI) tedarikçiler de listeleniyor!</span>');
            } else {
                $('#supplierHelp').html('Sadece <b>"Onaylı" (YEŞİL)</b> tedarikçiler listeleniyor.');
            }
        });

        // Tedarikçileri Filtreleyen Fonksiyon
        function filterSuppliers(showAll) {
            // Select2 kullanılıyorsa önce onu destroy et (Yeniden çizeceğiz)
            let useSelect2 = $.fn.select2 !== undefined && $('#supplierSelect').hasClass('select2-hidden-accessible');
            if(useSelect2) { $('#supplierSelect').select2('destroy'); }

            // Seçimi sıfırla
            $('#supplierSelect').val('');

            // Option'ları döngüye al
            $('#supplierSelect option').each(function() {
                let status = $(this).data('status');
                
                // Seçiniz (value="") olan ilk satırı es geç
                if($(this).val() === "") return true;

                if(showAll) {
                    // Switch AÇIK: Hepsini göster
                    $(this).show();
                    $(this).prop('disabled', false);
                } else {
                    // Switch KAPALI: Sadece 'Approved' olanları göster, diğerlerini gizle
                    if(status === 'Approved') {
                        $(this).show();
                        $(this).prop('disabled', false);
                    } else {
                        $(this).hide();
                        $(this).prop('disabled', true); // HTML tarafında da seçilemez yap
                    }
                }
            });

            // Select2'yi tekrar başlat (Renkli ayarlarıyla beraber)
            initSelect2();
        }
    });
</script>
@endpush