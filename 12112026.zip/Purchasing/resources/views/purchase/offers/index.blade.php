@extends('layouts.admin')

@push('css')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
<style>
    .bg-success-soft { background-color: #e3f9ed; }
    .bg-warning-soft { background-color: #fff9e6; }
    .bg-danger-soft { background-color: #ffe6e6; }
    .bg-info-soft { background-color: #e3f2fd; }
    .table-hover tbody tr:hover { background-color: #f8f9fa; cursor: pointer; }
    #offersTable_wrapper .dataTables_filter { float: right; }
    #offersTable_wrapper .dataTables_length { float: left; }
    .btn-export { font-size: 0.75rem; padding: 4px 12px; font-weight: bold; }
    .action-icon { cursor: pointer; margin: 0 5px; color: #6c757d; transition: color 0.2s; }
    .action-icon:hover { color: #007bff; }
    .dt-buttons { float: left; margin-right: 10px; }
    
    .badge-won { background-color: #198754; color: white; } 
    .badge-lost { background-color: #adb5bd; color: white; text-decoration: line-through; } 
    .badge-pending { background-color: #ffc107; color: black; } 
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">
    {{-- ÜST AKSİYON ÇUBUĞU --}}
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="text-primary fw-bold mb-0 text-uppercase">
            <i class="fas fa-hand-holding-usd me-2"></i>TEKLİF HAVUZU
        </h5>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.purchase.requests.index') }}" class="btn btn-sm btn-success px-4 fw-bold shadow-sm">
                <i class="fas fa-plus me-1"></i> YENİ TEKLİF GİR
            </a>
            <button type="button" class="btn btn-sm btn-primary px-4 fw-bold shadow-sm" onclick="location.reload();">
                <i class="fas fa-sync me-1"></i> YENİLE
            </button>
        </div>
    </div>

    {{-- FİLTRE BÖLÜMÜ --}}
    <div class="card shadow-none border mb-3">
        <div class="card-header bg-light py-2 border-bottom">
            <div class="row align-items-center g-2">
                <div class="col-md-6">
                    <div class="d-flex gap-2 align-items-center">
                        {{-- SAF HTML FORM İLE KESİN ÇÖZÜM --}}
                        <form action="{{ route('admin.purchase.offers.index') }}" method="GET" id="filterForm" class="m-0">
                            <select name="status" class="form-select form-select-sm fw-bold border-primary" onchange="document.getElementById('filterForm').submit();" style="width: auto;">
                                <option value="tum" {{ $status == 'tum' ? 'selected' : '' }}>Tüm Durumlar (Geçmiş)</option>
                                <option value="Pending" {{ $status == 'Pending' ? 'selected' : '' }}>Sadece Değerlendirilenler</option>
                                <option value="Won" {{ $status == 'Won' ? 'selected' : '' }}>Onaylananlar (Kazanan)</option>
                                <option value="Lost" {{ $status == 'Lost' ? 'selected' : '' }}>Reddedilenler (Kaybeden)</option>
                            </select>
                        </form>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-sm btn-success btn-export" id="btnExportXLS">
                            <i class="fas fa-file-excel me-1"></i> XLS
                        </button>
                        <button type="button" class="btn btn-sm btn-danger btn-export" id="btnExportPDF">
                            <i class="fas fa-file-pdf me-1"></i> PDF
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card-body p-2">
            <div class="table-responsive">
                <table class="table table-sm table-hover table-bordered mb-0 align-middle" id="offersTable" style="font-size: 0.85rem;">
                    <thead class="bg-primary text-white">
                        <tr>
                            <th width="30" class="text-center">#</th>
                            <th>Teklif No</th>
                            <th>Talep No</th>
                            <th>Tedarikçi</th>
                            <th>Teklif Tarihi</th>
                            <th>Geçerlilik</th>
                            <th class="text-end">Tutar</th>
                            <th class="text-center">Döviz</th>
                            <th class="text-center">Durum</th>
                            <th width="100" class="text-center">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($offers as $index => $offer)
                        <tr data-id="{{ $offer->purchase_request_id }}"> 
                            <td class="text-center">{{ $index + 1 }}</td>
                            <td class="fw-bold text-primary">{{ $offer->offer_no }}</td>
                            <td>
                                <a href="{{ route('admin.purchase.requests.show', $offer->purchase_request_id) }}" class="text-decoration-none text-dark fw-bold">
                                    {{ $offer->request->request_no ?? '-' }}
                                </a>
                            </td>
                            <td>{{ $offer->supplier->company_name ?? '-' }}</td>
                            <td>{{ $offer->offer_date->format('d.m.Y') }}</td>
                            <td>
                                @if($offer->valid_until)
                                    <span class="{{ $offer->valid_until < now() ? 'text-danger small' : '' }}">
                                        {{ $offer->valid_until->format('d.m.Y') }}
                                    </span>
                                @else
                                    -
                                @endif
                            </td>
                            <td class="text-end fw-bold">{{ number_format($offer->grand_total, 2, ',', '.') }}</td>
                            <td class="text-center small">{{ $offer->currency }}</td>
                            <td class="text-center">
                                @if($offer->status == 'Pending')
                                    <span class="badge badge-pending">Değerlendiriliyor</span>
                                @elseif($offer->status == 'Won')
                                    <span class="badge badge-won"><i class="fas fa-check me-1"></i> Kazandı</span>
                                @elseif($offer->status == 'Lost')
                                    <span class="badge badge-lost">Kaybetti</span>
                                @endif
                            </td>
                            <td class="text-center">
                                <a href="{{ route('admin.purchase.requests.show', $offer->purchase_request_id) }}" class="btn btn-sm btn-info shadow-sm py-0 px-2 text-white" title="Talebe Git & İncele">
                                    <i class="fas fa-eye small"></i>
                                </a>
                                {{-- YENİ EKLENEN SİL BUTONU --}}
                                @if($offer->status == 'Pending')
                                    <form action="{{ route('admin.purchase.offers.destroy', $offer->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Bu teklifi tamamen silmek istediğinize emin misiniz?');">
                                        @csrf @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger shadow-sm py-0 px-2" title="Teklifi Sil">
                                            <i class="fas fa-trash small"></i>
                                        </button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="10" class="text-center py-5 text-muted">
                                <i class="fas fa-search fa-3x mb-3 d-block opacity-25"></i>
                                <strong>Bu filtreye uygun teklif kaydı bulunamadı.</strong><br>
                                <small>Diğer kayıtları görmek için yukarıdaki menüden "Tüm Durumlar" filtresini seçebilirsiniz.</small>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            {{-- SAYFALAMA LİNKLERİ --}}
            <div class="mt-3 d-flex justify-content-center">
                {{ $offers->appends(['status' => $status])->links('pagination::bootstrap-5') }}
            </div>
        </div>
    </div>

    {{-- İSTATİSTİK KARTLARI (Artık Controller'dan gelen Gerçek veriler) --}}
    <div class="row g-3 mt-3">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-info-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Toplam Teklif</h6>
                            <h3 class="fw-bold mb-0 text-primary">{{ $counts['total'] }}</h3>
                        </div>
                        <div class="fs-1 text-primary opacity-50"><i class="fas fa-file-invoice"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-warning-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Değerlendirme Aşamasında</h6>
                            <h3 class="fw-bold mb-0 text-warning">{{ $counts['pending'] }}</h3>
                        </div>
                        <div class="fs-1 text-warning opacity-50"><i class="fas fa-balance-scale"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-success-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Onaylanan (Kazanan)</h6>
                            <h3 class="fw-bold mb-0 text-success">{{ $counts['won'] }}</h3>
                        </div>
                        <div class="fs-1 text-success opacity-50"><i class="fas fa-trophy"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-danger-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Reddedilen</h6>
                            <h3 class="fw-bold mb-0 text-danger">{{ $counts['lost'] }}</h3>
                        </div>
                        <div class="fs-1 text-danger opacity-50"><i class="fas fa-thumbs-down"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
$(document).ready(function() {
    $.fn.dataTable.ext.errMode = 'none';

    // Datatable sadece görselleştirme için kullanılıyor (Filtreleme PHP'de)
    const table = $('#offersTable').DataTable({
        language: {
            "emptyTable": " ",
            "info": "Ekranda _TOTAL_ kayıttan _START_ - _END_ arası gösteriliyor",
            "infoEmpty": "",
            "search": "Hızlı Ara:",
            "zeroRecords": "Eşleşen kayıt bulunamadı",
        },
        paging: false, 
        info: false,
        dom: 'Bfrtip',
        buttons: [
            { extend: 'excelHtml5', text: '<i class="fas fa-file-excel me-1"></i> Excel', className: 'btn btn-success btn-sm' },
            { extend: 'pdfHtml5', text: '<i class="fas fa-file-pdf me-1"></i> PDF', className: 'btn btn-danger btn-sm' }
        ],
        columnDefs: [ { orderable: false, targets: [0, 9] } ]
    });

    // Tıklanan satırda Talebe git
    $('#offersTable tbody').on('click', 'tr', function(e) {
        if (!$(e.target).closest('a, button, form').length) {
            const id = $(this).data('id'); 
            if(id) window.location.href = `/admin/purchase/requests/${id}`;
        }
    });

    // Butonlar
    $('#btnExportXLS').on('click', function() { table.button('.buttons-excel').trigger(); });
    $('#btnExportPDF').on('click', function() { table.button('.buttons-pdf').trigger(); });
});
</script>
@endpush