@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    {{-- BAŞLIK VE DURUM --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center">
            <div class="me-3">
                <div class="icon-stack icon-stack-lg bg-primary-soft text-primary">
                    <i data-feather="truck"></i>
                </div>
            </div>
            <div>
                <div class="small text-uppercase fw-bold text-muted">Tedarikçi Kartı</div>
                <h2 class="h3 mb-0 text-gray-800 fw-bold">{{ $supplier->company_name }}</h2>
            </div>
        </div>
        <div>
            <span class="badge bg-{{ $supplier->status == 'Approved' ? 'success' : ($supplier->status == 'Conditional' ? 'warning' : ($supplier->status == 'Rejected' ? 'danger' : 'secondary')) }} fs-6 shadow-sm">
                {{ match($supplier->status) { 'Approved'=>'ONAYLI', 'Conditional'=>'ŞARTLI ONAY', 'Rejected'=>'RED', default=>'PUAN BEKLİYOR' } }}
            </span>
            
            <a href="{{ route('admin.suppliers.edit', $supplier->id) }}" class="btn btn-warning btn-sm ms-2 text-dark fw-bold">
                <i class="fas fa-edit me-1"></i> Düzenle
            </a>
            
            <a href="{{ route('admin.suppliers.index') }}" class="btn btn-secondary btn-sm ms-2">
                <i class="fas fa-arrow-left me-1"></i> Listeye Dön
            </a>
        </div>
    </div>

    <div class="row">
        {{-- SOL KOLON: HIZLI BİLGİLER --}}
        <div class="col-xl-4">
            {{-- PUAN KARTI --}}
            <div class="card mb-4 border-top-lg border-primary shadow-sm">
                <div class="card-body text-center">
                    <div class="text-muted small text-uppercase fw-bold">Tedarikçi Performans Puanı</div>
                    <div class="display-4 fw-bold text-dark my-2">{{ $supplier->score ?? 0 }}</div>
                    <div class="progress mb-3" style="height: 0.5rem;">
                        <div class="progress-bar bg-{{ ($supplier->score ?? 0) >= 85 ? 'success' : (($supplier->score ?? 0) >= 70 ? 'warning' : 'danger') }}" role="progressbar" style="width: {{ $supplier->score ?? 0 }}%"></div>
                    </div>
                    <div class="small text-muted">
                        Son Değerlendirme: {{ $supplier->last_evaluation_date ? \Carbon\Carbon::parse($supplier->last_evaluation_date)->format('d.m.Y') : 'Yapılmadı' }}
                    </div>
                </div>
            </div>

            {{-- FİRMA BİLGİLERİ --}}
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-white fw-bold">Firma Künyesi</div>
                <div class="card-body">
                    {{-- TEDARİKÇİ SINIFI --}}
                    <div class="mb-3 border-bottom pb-2">
                        <label class="small fw-bold text-muted d-block mb-1">Değerlendirme Sınıfı</label>
                        @if($supplier->supplierClass)
                            <span class="badge bg-primary fs-6"><i class="fas fa-layer-group me-1"></i> {{ $supplier->supplierClass->name }}</span>
                        @else
                            <span class="badge bg-danger fs-6"><i class="fas fa-exclamation-triangle me-1"></i> Sınıf Atanmamış!</span>
                        @endif
                    </div>

                    <div class="mb-3 border-bottom pb-2">
                        <label class="small fw-bold text-muted d-block mb-1">Kategori</label>
                        <div class="d-flex flex-wrap gap-1">
                            @if($supplier->category)
                                @php
                                    $categories = explode(', ', $supplier->category);
                                @endphp
                                @foreach($categories as $cat)
                                    @if($cat == 'Critical' || str_contains(strtolower($cat), 'kritik'))
                                        <span class="badge bg-danger shadow-sm"><i class="fas fa-exclamation-triangle me-1"></i> {{ $cat }}</span>
                                    @else
                                        <span class="badge bg-primary-soft text-primary border border-primary shadow-sm">{{ $cat }}</span>
                                    @endif
                                @endforeach
                            @else
                                <span class="text-muted small">- Belirtilmemiş -</span>
                            @endif
                        </div>
                    </div>
                    <div class="mb-3 border-bottom pb-2">
                        <label class="small fw-bold text-muted d-block">Analize Etkisi</label>
                        <div>
                            @if($supplier->affects_analysis)
                                <span class="badge bg-danger-soft text-danger">Doğrudan Etkiler</span>
                            @else
                                <span class="badge bg-light text-dark border">Etkilemez</span>
                            @endif
                        </div>
                    </div>
                    <div class="mb-3 border-bottom pb-2">
                        <label class="small fw-bold text-muted d-block">Yetkili Kişi</label>
                        <div class="fw-bold">{{ $supplier->contact_person ?? '-' }}</div>
                    </div>
                    <div class="mb-3 border-bottom pb-2">
                        <label class="small fw-bold text-muted d-block">İletişim</label>
                        <div><i class="fas fa-envelope text-muted me-1"></i> {{ $supplier->email ?? '-' }}</div>
                        <div><i class="fas fa-phone text-muted me-1"></i> {{ $supplier->phone ?? '-' }}</div>
                        <div><i class="fas fa-globe text-muted me-1"></i> {{ $supplier->website ?? '-' }}</div>
                    </div>
                    <div class="mb-3 border-bottom pb-2">
                        <label class="small fw-bold text-muted d-block">Vergi No / Dairesi</label>
                        <div class="fw-bold">{{ $supplier->tax_no ?? '-' }}</div>
                    </div>
                    <div class="mb-0">
                        <label class="small fw-bold text-muted d-block">Açık Adres</label>
                        <div class="small text-secondary">{{ $supplier->address ?? '-' }}</div>
                    </div>
                </div>
            </div>
            
            {{-- RESMİ BELGELER --}}
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-white fw-bold">Resmi Belgeler & Sertifikalar</div>
                <div class="list-group list-group-flush">
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold small">Vergi Levhası</span>
                            @if($supplier->has_tax_plate) <i class="fas fa-check-circle text-success fs-5"></i> 
                            @else <i class="fas fa-times-circle text-muted fs-5"></i> @endif
                        </div>
                        @if($supplier->tax_plate_file)
                            <a href="{{ asset('storage/' . $supplier->tax_plate_file) }}" target="_blank" class="btn btn-xs btn-outline-primary w-100 mt-2">
                                <i class="fas fa-file-pdf me-1"></i> Dosyayı Görüntüle
                            </a>
                        @endif
                    </div>
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold small">ISO 9001</span>
                            @if($supplier->has_iso_9001) <i class="fas fa-check-circle text-success fs-5"></i> 
                            @else <i class="fas fa-times-circle text-muted fs-5"></i> @endif
                        </div>
                        @if($supplier->iso_9001_file)
                            <a href="{{ asset('storage/' . $supplier->iso_9001_file) }}" target="_blank" class="btn btn-xs btn-outline-primary w-100 mt-2">
                                <i class="fas fa-file-pdf me-1"></i> Dosyayı Görüntüle
                            </a>
                        @endif
                    </div>
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold small text-primary">ISO 17025 (TÜRKAK)</span>
                            @if($supplier->has_iso_17025) <i class="fas fa-check-circle text-success fs-5"></i> 
                            @else <i class="fas fa-times-circle text-muted fs-5"></i> @endif
                        </div>
                        @if($supplier->iso_17025_file)
                            <a href="{{ asset('storage/' . $supplier->iso_17025_file) }}" target="_blank" class="btn btn-xs btn-outline-primary w-100 mt-2 mb-2">
                                <i class="fas fa-file-pdf me-1"></i> Dosyayı Görüntüle
                            </a>
                        @endif
                        @if($supplier->has_iso_17025 && $supplier->accreditation_scope)
                            <div class="bg-light p-2 rounded border small text-muted mt-2">
                                <strong>Kapsam:</strong> {{ $supplier->accreditation_scope }}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            
        </div>

        {{-- SAĞ KOLON: SEKME YAPISI --}}
        <div class="col-xl-8">
            <div class="card shadow-sm mb-4">
                <div class="card-header border-bottom bg-white p-0">
                    <ul class="nav nav-tabs card-header-tabs m-0 ms-2 mt-2" id="cardTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active fw-bold text-primary" id="eval-tab" data-bs-toggle="tab" href="#eval" role="tab" aria-controls="eval" aria-selected="true">Yeni Değerlendirme</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link fw-bold text-secondary" id="history-tab" data-bs-toggle="tab" href="#history" role="tab" aria-controls="history" aria-selected="false">Geçmiş Karneler</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link fw-bold text-secondary" id="orders-tab" data-bs-toggle="tab" href="#orders" role="tab" aria-controls="orders" aria-selected="false">Satınalma / Sipariş Geçmişi</a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="cardTabContent">
                        
                        {{-- SEKME 1: YENİ DEĞERLENDİRME FORMU --}}
                        <div class="tab-pane fade show active" id="eval" role="tabpanel" aria-labelledby="eval-tab">
                            
                            @if(!$supplier->supplierClass)
                                <div class="text-center py-5">
                                    <i class="fas fa-exclamation-circle fa-4x text-warning mb-3"></i>
                                    <h4 class="fw-bold">Sınıf Seçimi Eksik!</h4>
                                    <p class="text-muted">Bu tedarikçiyi değerlendirebilmek için önce "Düzenle" butonuna tıklayarak bir <b>Tedarikçi Sınıfı</b> atamanız gerekmektedir.</p>
                                </div>
                            @elseif($supplier->supplierClass->questions->count() == 0)
                                <div class="text-center py-5">
                                    <i class="fas fa-clipboard-question fa-4x text-info mb-3"></i>
                                    <h4 class="fw-bold">Sorular Bulunamadı!</h4>
                                    <p class="text-muted">Tedarikçiye atanan <b>{{ $supplier->supplierClass->name }}</b> sınıfına ait değerlendirme sorusu yok. Lütfen ayarlardan soru ekleyin.</p>
                                </div>
                            @else
                                <h5 class="fw-bold text-dark mb-3">{{ $supplier->supplierClass->name }} Performans Değerlendirmesi</h5>
                                <div class="alert alert-info small shadow-sm border-0">
                                    <i class="fas fa-info-circle me-1"></i> ISO 17025 gereği tedarikçiler düzenli değerlendirilmelidir. Lütfen aşağıdaki <b>{{ $supplier->supplierClass->questions->count() }} kritere</b> puan veriniz.
                                </div>

                                <form action="{{ route('admin.suppliers.evaluate', $supplier->id) }}" method="POST" id="evalForm">
                                    @csrf
                                    <div class="row g-4 mt-2">
                                        
                                        {{-- TARİH SEÇİMİ --}}
                                        <div class="col-12 border-bottom pb-3 mb-2">
                                            <label class="form-label fw-bold text-dark"><i class="fas fa-calendar-alt me-1 text-primary"></i> Değerlendirme Tarihi</label>
                                            <input type="date" name="evaluation_date" class="form-control form-control-lg border-primary shadow-sm text-primary fw-bold" value="{{ date('Y-m-d') }}" max="{{ date('Y-m-d') }}" required style="max-width: 250px;">
                                        </div>

                                        @foreach($supplier->supplierClass->questions as $question)
                                        <div class="col-md-6">
                                            <label class="form-label fw-bold text-dark">
                                                {{ $question->question }}
                                                <span class="badge bg-secondary ms-1">Max: {{ $question->max_score }}</span>
                                            </label>
                                            <input type="number" name="scores[{{ $question->id }}]" class="form-control form-control-lg score-input border-primary bg-primary-soft text-primary fw-bold" 
                                                max="{{ $question->max_score }}" min="0" value="0" required>
                                        </div>
                                        @endforeach
                                        
                                        <div class="col-12 border-top pt-3 mt-4">
                                            <label class="form-label fw-bold">Değerlendirici Yorumu / Ek Notlar</label>
                                            <textarea name="comments" class="form-control" rows="3" placeholder="Bu değerlendirme ile ilgili genel kanaatinizi yazınız..."></textarea>
                                        </div>

                                        <div class="col-12 mt-4">
                                            <div class="card bg-light border-0 shadow-sm">
                                                <div class="card-body p-4 d-flex justify-content-between align-items-center rounded" style="background: linear-gradient(145deg, #f8f9fa, #e9ecef);">
                                                    <div>
                                                        <div class="small fw-bold text-muted text-uppercase mb-1">Hesaplanan Toplam Puan</div>
                                                        <h3 class="mb-0 fw-bold text-primary"><span id="totalScoreDisplay" class="display-5">0</span><span class="text-muted fs-4">/100</span></h3>
                                                    </div>
                                                    <div class="text-end">
                                                        <div class="small fw-bold text-muted text-uppercase mb-2">Değerlendirme Sonucu</div>
                                                        <span id="resultBadge" class="badge bg-secondary fs-5 px-4 py-2 shadow-sm">Puan Giriniz</span>
                                                        <input type="hidden" name="calculated_status" id="hiddenStatus">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12 text-end mt-4">
                                            <button type="submit" class="btn btn-success btn-lg fw-bold px-5 shadow-sm">
                                                <i class="fas fa-check-double me-2"></i> DEĞERLENDİRMEYİ KAYDET
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            @endif
                        </div>

                        {{-- SEKME 2: GEÇMİŞ KARNELER --}}
                        <div class="tab-pane fade" id="history" role="tabpanel" aria-labelledby="history-tab">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle border">
                                    <thead class="bg-light small text-uppercase text-muted fw-bold">
                                        <tr>
                                            <th>Tarih</th>
                                            <th>Personel</th>
                                            <th class="text-center">Toplam Puan</th>
                                            <th class="text-center">Sonuç</th>
                                            <th>Not</th>
                                            <th class="text-center">İşlem</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($supplier->evaluations ?? [] as $eval)
                                        <tr>
                                            <td class="fw-bold text-dark">{{ $eval->evaluation_date->format('d.m.Y') }}</td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="bg-primary text-white rounded-circle d-flex justify-content-center align-items-center me-2" style="width: 28px; height: 28px; font-size: 11px;">
                                                        {{ strtoupper(substr($eval->evaluator->name ?? 'S', 0, 1)) }}
                                                    </div>
                                                    <span class="fw-bold small">{{ $eval->evaluator->name ?? 'Sistem' }}</span>
                                                </div>
                                            </td>
                                            <td class="text-center fw-bold fs-6 text-primary">{{ $eval->total_score }}</td>
                                            <td class="text-center">
                                                @if($eval->result == 'Approved') <span class="badge bg-success px-2 py-1">ONAYLI</span>
                                                @elseif($eval->result == 'Conditional') <span class="badge bg-warning text-dark px-2 py-1">ŞARTLI</span>
                                                @else <span class="badge bg-danger px-2 py-1">RED</span> @endif
                                            </td>
                                            <td class="small text-muted fst-italic">"{{ Str::limit($eval->comments, 40) }}"</td>
                                            
                                            <td class="text-center">
                                                <a href="{{ route('admin.suppliers.print-eval', ['id' => $supplier->id, 'evalId' => $eval->id]) }}" target="_blank" class="btn btn-sm btn-outline-dark border-0" title="Formu Yazdır (FR-06-02)">
                                                    <i class="fas fa-print"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-outline-warning text-dark border-0" data-bs-toggle="modal" data-bs-target="#editEvalModal-{{ $eval->id }}" title="Düzenle">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <form action="{{ route('admin.suppliers.evaluations.destroy', $eval->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Bu değerlendirmeyi silmek istediğinize emin misiniz? Puan güncellenecektir.');">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-sm btn-outline-danger border-0" title="Sil">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="6" class="text-center py-5">
                                                <i class="fas fa-clipboard-list fa-3x text-muted mb-3 opacity-25"></i>
                                                <p class="text-muted fw-bold mb-0">Henüz geçmiş bir değerlendirme kaydı bulunmuyor.</p>
                                            </td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        {{-- SEKME 3: SİPARİŞ / SATINALMA GEÇMİŞİ --}}
                        <div class="tab-pane fade" id="orders" role="tabpanel" aria-labelledby="orders-tab">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle border">
                                    <thead class="bg-light small text-uppercase text-muted fw-bold">
                                        <tr>
                                            <th>Tarih</th>
                                            <th>Talep No / Teklif</th>
                                            <th>Tutar</th>
                                            <th>Durum</th>
                                            <th class="text-end">İncele</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {{-- DÜZELTİLEN KISIM: offer->purchaseRequest yerine offer->request kullanıldı --}}
                                        @forelse($supplier->offers ?? [] as $offer)
                                        <tr>
                                            <td class="fw-bold text-dark">{{ $offer->created_at->format('d.m.Y') }}</td>
                                            <td>
                                                <div class="fw-bold text-primary">{{ $offer->request->request_no ?? 'Bilinmeyen Talep' }}</div>
                                                <div class="small text-muted">Teklif No: {{ $offer->offer_no ?? '-' }}</div>
                                            </td>
                                            <td class="fw-bold text-dark">
                                                {{ number_format($offer->net_total ?? $offer->sub_total, 2, ',', '.') }} {{ $offer->currency ?? 'TL' }}
                                            </td>
                                            <td>
                                                @if($offer->status == 'Won') 
                                                    <span class="badge bg-success">KAZANILDI (SİPARİŞ)</span>
                                                @elseif($offer->status == 'Pending') 
                                                    <span class="badge bg-warning text-dark">BEKLEMEDE</span>
                                                @else 
                                                    <span class="badge bg-danger">KAYBEDİLDİ</span> 
                                                @endif
                                            </td>
                                            <td class="text-end">
                                                @if($offer->purchase_request_id)
                                                    <a href="{{ route('admin.purchase.requests.show', $offer->purchase_request_id) }}" target="_blank" class="btn btn-sm btn-outline-primary shadow-sm fw-bold">
                                                        <i class="fas fa-external-link-alt me-1"></i> Görüntüle
                                                    </a>
                                                @else
                                                    <span class="text-muted small">Talep Silinmiş</span>
                                                @endif
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="5" class="text-center py-5">
                                                <i class="fas fa-shopping-cart fa-3x text-muted mb-3 opacity-25"></i>
                                                <p class="text-muted fw-bold mb-0">Bu tedarikçiye ait herhangi bir satınalma/teklif kaydı bulunmuyor.</p>
                                            </td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- GEÇMİŞ DEĞERLENDİRME DÜZENLEME MODALLARI --}}
@foreach($supplier->evaluations ?? [] as $eval)
<div class="modal fade" id="editEvalModal-{{ $eval->id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i>Karne Düzenle ({{ $eval->evaluation_date->format('d.m.Y') }})</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('admin.suppliers.evaluations.update', $eval->id) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="modal-body bg-light">
                    <div class="alert alert-info small">
                        Puanı değiştirdiğinizde, sistem kriterlere göre "Onaylı/Red" durumunu tekrar hesaplayacaktır. Eğer bu güncellediğiniz karne <b>en son karne</b> ise, tedarikçinin ana puanı da değişir.
                    </div>
                    
                    {{-- TARİH DÜZENLEME --}}
                    <div class="mb-3">
                        <label class="form-label fw-bold"><i class="fas fa-calendar-alt me-1"></i> Değerlendirme Tarihi</label>
                        <input type="date" name="evaluation_date" class="form-control fw-bold text-primary" value="{{ $eval->evaluation_date->format('Y-m-d') }}" max="{{ date('Y-m-d') }}" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Toplam Puan (100 Üzerinden)</label>
                        <input type="number" name="total_score" class="form-control fw-bold fs-5 text-primary" min="0" max="100" value="{{ $eval->total_score }}" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Değerlendirici Yorumu</label>
                        <textarea name="comments" class="form-control" rows="4" required>{{ $eval->comments }}</textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-warning fw-bold text-dark"><i class="fas fa-save me-1"></i> Karneyi Güncelle</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endforeach

@endsection

@push('scripts')
{{-- EĞER SINIF VE KRİTERLER VARSA JAVASCRIPT ÇALIŞSIN --}}
@if($supplier->supplierClass && $supplier->supplierClass->criteria->count() > 0)
<script>
    const criteria = @json($supplier->supplierClass->criteria);

    document.querySelectorAll('.score-input').forEach(input => {
        input.addEventListener('input', calculateTotal);
    });

    calculateTotal(); 

    function calculateTotal() {
        let total = 0;
        
        document.querySelectorAll('.score-input').forEach(input => {
            let val = parseInt(input.value) || 0;
            let max = parseInt(input.getAttribute('max'));
            if(val > max) { val = max; input.value = max; } 
            total += val;
        });

        document.getElementById('totalScoreDisplay').innerText = total;

        const badge = document.getElementById('resultBadge');
        const hiddenStatus = document.getElementById('hiddenStatus');
        
        badge.className = 'badge fs-5 px-4 py-2 shadow-sm'; 
        let matched = false;

        criteria.forEach(c => {
            if(total >= c.min_score && total <= c.max_score) {
                badge.innerText = c.status_label;
                badge.classList.add('bg-' + c.color_code);
                hiddenStatus.value = c.status_label;
                matched = true;
            }
        });

        if(!matched) {
            badge.innerText = 'Kriter Bulunamadı';
            badge.classList.add('bg-secondary');
            hiddenStatus.value = 'Unknown';
        }
    }
</script>
@endif
@endpush