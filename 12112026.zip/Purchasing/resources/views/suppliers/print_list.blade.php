<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>LT-06-01 Onaylı Dış Tedarikçi Listesi</title>
    <style>
        /* A4 Yatay yazdırma ayarları */
        @page {
            size: A4 landscape;
            margin: 10mm;
        }
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 11px;
            color: #000;
            background: #fff;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            margin: 0 auto;
        }
        
        /* Başlık tablosu (Logo, Form Adı, Form No) */
        table.header-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        .header-table td {
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
            vertical-align: middle;
            font-weight: bold;
        }

        /* Ana Veri Tablosu */
        table.data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .data-table th, .data-table td {
            border: 1px solid #000;
            padding: 6px;
            text-align: center;
            vertical-align: middle;
            font-size: 10px;
        }
        
        /* SÜTUN BAŞLIK RENGİ (MS Word: Yeşil, Vurgu 6, Daha Açık 80%) */
        .data-table th {
            background-color: #E2EFDA !important; 
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        .text-left { text-align: left !important; }

        /* İmza alanı */
        table.signature-table {
            width: 100%;
            border: none;
            margin-top: 30px;
        }
        .signature-table td {
            width: 50%;
            border: none;
            padding: 10px;
            vertical-align: top;
        }

        /* Yazdırma Butonu */
        .no-print {
            position: fixed; top: 10px; right: 10px;
            background: #333; color: #fff; padding: 8px 15px;
            text-decoration: none; border-radius: 4px; font-family: sans-serif;
            font-size: 12px; z-index: 9999; cursor: pointer; border: none;
        }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>

    <button onclick="window.print()" class="no-print">YAZDIR / PDF</button>

    <div class="container">
        
        {{-- Başlık Tablosu --}}
        <table class="header-table">
            <tr>
                <td style="width: 20%;" rowspan="3">
                    {{-- SİSTEMDEN DİNAMİK LOGO ÇEKİMİ --}}
                    @php
                        $logo = \App\Models\Setting::where('key', 'site_logo')->value('value');
                    @endphp
                    @if($logo)
                        <img src="{{ asset($logo) }}" alt="Logo" style="max-height: 60px; max-width: 100%;">
                    @else
                        <h2 style="margin: 0; font-size: 16px;">AKADEMİ ÇEVRE</h2>
                    @endif
                </td>
                <td style="width: 60%; font-size: 16px;" rowspan="3">
                    ONAYLI DIŞ TEDARİKÇİ LİSTESİ
                </td>
                <td style="width: 10%; text-align: left; font-size: 10px;">Doküman No</td>
                <td style="width: 10%; text-align: left; font-size: 10px;">LT-06-01</td>
            </tr>
            <tr>
                <td style="text-align: left; font-size: 10px;">Yayın Tarihi</td>
                <td style="text-align: left; font-size: 10px;">03.06.2024</td>
            </tr>
            <tr>
                <td style="text-align: left; font-size: 10px;">Revizyon No / Tarih</td>
                <td style="text-align: left; font-size: 10px;">00</td>
            </tr>
        </table>

        {{-- Ana Liste Tablosu --}}
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 3%;">NO</th>
                    <th style="width: 18%;">Firma Adı</th>
                    <th style="width: 12%;">Yetkili Kişi</th>
                    <th style="width: 20%;">Adresi</th>
                    <th style="width: 10%;">Tel. / Faks No</th>
                    <th style="width: 10%;">Tedarikçi Sınıfı</th>
                    <th style="width: 12%;">Temin Edilecek Ürün/Hizmet</th>
                    <th style="width: 5%;">Toplam Puanı</th>
                    <th style="width: 10%;">Tedarikçi Grubu</th>
                </tr>
            </thead>
            <tbody>
                @forelse($suppliers as $index => $sup)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td class="text-left"><strong>{{ $sup->company_name }}</strong></td>
                    <td>{{ $sup->contact_person ?? '-' }}</td>
                    <td class="text-left">{{ $sup->address ?? '-' }}</td>
                    <td>{{ $sup->phone ?? '-' }}</td>
                    
                    {{-- Sınıf --}}
                    <td>{{ $sup->supplierClass->name ?? '-' }}</td>
                    
                    {{-- Ürün/Hizmet Kategori (Eğer virgüllü geldiyse temiz birleştir) --}}
                    <td>{{ str_replace(',', ', ', $sup->category ?? '-') }}</td>
                    
                    {{-- Puan --}}
                    <td>{{ $sup->score ?? '-' }}</td>
                    
                    {{-- Tedarikçi Grubu (Örn: Onaylı, Şartlı vs) --}}
                    <td>
                        @switch($sup->status)
                            @case('Approved') Onaylı @break
                            @case('Conditional') Şartlı @break
                            @case('Rejected') Reddedildi @break
                            @default Bekliyor
                        @endswitch
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="9" style="padding: 20px;">Sistemde kayıtlı tedarikçi bulunmuyor.</td>
                </tr>
                @endforelse
            </tbody>
        </table>

        {{-- İmza Tablosu --}}
        <table class="signature-table">
            <tr>
                <td>
                    <div style="font-weight: bold; margin-bottom: 5px;">Hazırlayan :</div>
                    <div>Adı - Soyadı</div>
                    <div style="margin-top: 40px;">Tarih/İmza</div>
                </td>
                <td style="text-align: right;">
                    <div style="font-weight: bold; margin-bottom: 5px; text-align: left; display: inline-block; width: 150px;">Onaylayan:</div><br>
                    <div style="text-align: left; display: inline-block; width: 150px;">Adı - Soyadı</div><br>
                    <div style="margin-top: 40px; text-align: left; display: inline-block; width: 150px;">Tarih/İmza</div>
                </td>
            </tr>
        </table>

    </div>
</body>
</html>