@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h2 class="h3 mb-0 text-gray-800">
                <i class="fas fa-cog me-2 text-info"></i>{{ $class->name }} - Değerlendirme Ayarları
            </h2>
            <p class="text-muted small mb-0">{{ $class->description }}</p>
        </div>
        <a href="{{ route('admin.supplier-classes.index') }}" class="btn btn-secondary btn-sm shadow-sm">
            <i class="fas fa-arrow-left me-1"></i> Sınıflara Dön
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"><i class="fas fa-check-circle me-1"></i> {{ session('success') }} <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show"><i class="fas fa-exclamation-triangle me-1"></i> {{ session('error') }} <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    @endif
    @if($errors->any())
        <div class="alert alert-danger"><ul class="mb-0 small">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>
    @endif

    {{-- 100 PUAN İLERLEME ÇUBUĞU (MATEMATİK KONTROLÜ) --}}
    <div class="card shadow-sm border-0 mb-4 bg-light">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-end mb-1">
                <span class="fw-bold text-dark">Toplam Değerlendirme Puanı Durumu</span>
                <span class="fw-bold fs-5 {{ $totalScore == 100 ? 'text-success' : ($totalScore > 100 ? 'text-danger' : 'text-warning') }}">
                    {{ $totalScore }} / 100 Puan
                </span>
            </div>
            <div class="progress" style="height: 25px;">
                <div class="progress-bar fw-bold fs-6 {{ $totalScore == 100 ? 'bg-success' : ($totalScore > 100 ? 'bg-danger' : 'bg-warning text-dark') }} progress-bar-striped {{ $totalScore < 100 ? 'progress-bar-animated' : '' }}" 
                     role="progressbar" 
                     style="width: {{ $totalScore > 100 ? 100 : $totalScore }}%;" 
                     aria-valuenow="{{ $totalScore }}" aria-valuemin="0" aria-valuemax="100">
                    {{ $totalScore }}%
                </div>
            </div>
            @if($totalScore < 100)
                <small class="text-muted mt-1 d-block"><i class="fas fa-info-circle"></i> Sistemi kullanabilmek için soru ekleyerek puanı tam 100'e tamamlamalısınız.</small>
            @elseif($totalScore == 100)
                <small class="text-success fw-bold mt-1 d-block"><i class="fas fa-check"></i> Harika! Puan dağılımı kusursuz (100 Puan).</small>
            @endif
        </div>
    </div>

    <div class="row">
        {{-- SOL KOLON: SORULAR --}}
        <div class="col-xl-7 mb-4">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold m-0 text-primary"><i class="fas fa-question-circle me-1"></i> Değerlendirme Soruları</h6>
                </div>
                <div class="card-body p-0">
                    {{-- Soru Ekleme Formu --}}
                    <div class="p-3 bg-light border-bottom">
                        <form action="{{ route('admin.supplier-classes.questions.store', $class->id) }}" method="POST" class="row g-2 align-items-center">
                            @csrf
                            <div class="col-md-8">
                                <input type="text" name="question" class="form-control form-control-sm" placeholder="Soru metnini yazın (Örn: Ürün kalitesi nasıldı?)" required>
                            </div>
                            <div class="col-md-2">
                                <input type="number" name="max_score" class="form-control form-control-sm" placeholder="Puan (Örn: 20)" min="1" max="100" required>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-sm btn-primary w-100 fw-bold" {{ $totalScore >= 100 ? 'disabled' : '' }}>
                                    <i class="fas fa-plus"></i> Ekle
                                </button>
                            </div>
                        </form>
                    </div>

                    {{-- Sorular Tablosu --}}
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-white small text-muted">
                                <tr>
                                    <th class="ps-3">Soru</th>
                                    <th width="100" class="text-center">Puan</th>
                                    <th width="60" class="text-center">Sil</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($class->questions as $q)
                                <tr>
                                    <td class="ps-3 fw-bold text-dark">{{ $q->question }}</td>
                                    <td class="text-center"><span class="badge bg-info text-white fs-6">{{ $q->max_score }} Puan</span></td>
                                    <td class="text-center">
                                        <form action="{{ route('admin.supplier-classes.questions.destroy', $q->id) }}" method="POST">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('Silmek istediğinize emin misiniz?')"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                @empty
                                <tr><td colspan="3" class="text-center py-4 text-muted">Henüz soru eklenmedi.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        {{-- SAĞ KOLON: KRİTERLER (0-60 RED vb.) --}}
        <div class="col-xl-5 mb-4">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-header bg-white">
                    <h6 class="fw-bold m-0 text-success"><i class="fas fa-tags me-1"></i> Puanlama Kriterleri (Sonuçlar)</h6>
                </div>
                <div class="card-body p-0">
                    {{-- Kriter Ekleme Formu --}}
                    <div class="p-3 bg-light border-bottom">
                        <form action="{{ route('admin.supplier-classes.criteria.store', $class->id) }}" method="POST" class="row g-2">
                            @csrf
                            <div class="col-md-3">
                                <input type="number" name="min_score" class="form-control form-control-sm" placeholder="Min Puan" min="0" max="100" required>
                            </div>
                            <div class="col-md-3">
                                <input type="number" name="max_score" class="form-control form-control-sm" placeholder="Max Puan" min="0" max="100" required>
                            </div>
                            <div class="col-md-6 mb-2">
                                <input type="text" name="status_label" class="form-control form-control-sm" placeholder="Sonuç (Örn: Şartlı Kabul)" required>
                            </div>
                            <div class="col-md-8">
                                <select name="color_code" class="form-select form-select-sm" required>
                                    <option value="danger">Kırmızı (Kötü/Red)</option>
                                    <option value="warning">Sarı (Orta/Şartlı)</option>
                                    <option value="success">Yeşil (İyi/Uygun)</option>
                                    <option value="primary">Mavi (Mükemmel)</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-sm btn-success w-100 fw-bold"><i class="fas fa-plus"></i> Ekle</button>
                            </div>
                        </form>
                    </div>

                    {{-- Kriterler Tablosu --}}
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-white small text-muted">
                                <tr>
                                    <th class="ps-3">Puan Aralığı</th>
                                    <th>Sonuç Etiketi</th>
                                    <th width="50" class="text-center">Sil</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($class->criteria->sortBy('min_score') as $c)
                                <tr>
                                    <td class="ps-3 fw-bold">{{ $c->min_score }} - {{ $c->max_score }}</td>
                                    <td><span class="badge bg-{{ $c->color_code }} w-100 py-2">{{ $c->status_label }}</span></td>
                                    <td class="text-center">
                                        <form action="{{ route('admin.supplier-classes.criteria.destroy', $c->id) }}" method="POST">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-sm text-danger border-0"><i class="fas fa-times"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                @empty
                                <tr><td colspan="3" class="text-center py-4 text-muted">Kriter eklenmedi. (Örn: 0-60 Red)</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection