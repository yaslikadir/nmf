@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h3 mb-0 text-gray-800"><i class="fas fa-layer-group me-2 text-primary"></i>Tedarikçi Sınıfları (Değerlendirme Yapısı)</h2>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-1"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="row">
        {{-- YENİ SINIF EKLEME FORMU --}}
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-0 border-top-lg border-primary">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-plus-circle me-1"></i> Yeni Sınıf Ekle
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.supplier-classes.store') }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Sınıf Adı <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="Örn: A Sınıfı (Ürün)" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Açıklama (Opsiyonel)</label>
                            <textarea name="description" class="form-control" rows="3" placeholder="Bu sınıfa hangi tedarikçiler girer?"></textarea>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary fw-bold w-100"><i class="fas fa-save me-1"></i> Sınıfı Kaydet</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        {{-- SINIFLAR LİSTESİ --}}
        <div class="col-md-8 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light small text-uppercase text-muted">
                                <tr>
                                    <th class="ps-3">Sınıf Adı</th>
                                    <th class="text-center">Soru Sayısı</th>
                                    <th class="text-center">Toplam Puan</th>
                                    <th class="text-center">Kayıtlı Tedarikçi</th>
                                    <th class="text-end pe-3">İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($classes as $class)
                                <tr>
                                    <td class="ps-3">
                                        <div class="fw-bold text-dark">{{ $class->name }}</div>
                                        <div class="small text-muted">{{ Str::limit($class->description, 50) }}</div>
                                    </td>
                                    <td class="text-center fw-bold">{{ $class->questions_count }}</td>
                                    <td class="text-center">
                                        @php $total = $class->questions->sum('max_score'); @endphp
                                        <span class="badge {{ $total == 100 ? 'bg-success' : 'bg-warning text-dark' }}">
                                            {{ $total }} / 100
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-secondary">{{ $class->suppliers_count }} Tedarikçi</span>
                                    </td>
                                    <td class="text-end pe-3">
                                        <a href="{{ route('admin.supplier-classes.show', $class->id) }}" class="btn btn-sm btn-info text-white fw-bold shadow-sm">
                                            <i class="fas fa-cog me-1"></i> Soruları Ayarla
                                        </a>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="5" class="text-center py-5 text-muted">
                                        <i class="fas fa-info-circle fa-2x mb-2 opacity-50"></i><br>
                                        Henüz bir tedarikçi sınıfı tanımlanmamış.
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection