@extends('layouts.admin')

@push('css')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
<style>
    /* Tablo ve Kart Stilleri */
    .bg-success-soft { background-color: #e3f9ed; }
    .bg-warning-soft { background-color: #fff9e6; }
    .bg-danger-soft { background-color: #ffe6e6; }
    .bg-info-soft { background-color: #e3f2fd; }
    
    .table-hover tbody tr:hover { background-color: #f8f9fa; cursor: pointer; }
    #suppliersTable_wrapper .dataTables_filter { float: right; }
    #suppliersTable_wrapper .dataTables_length { float: left; }
    .btn-export { font-size: 0.75rem; padding: 4px 12px; font-weight: bold; }
    .action-icon { cursor: pointer; margin: 0 5px; color: #6c757d; transition: color 0.2s; }
    .action-icon:hover { color: #007bff; }
    .dt-buttons { float: left; margin-right: 10px; }
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">
    {{-- ÜST AKSİYON ÇUBUĞU --}}
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="text-primary fw-bold mb-0 text-uppercase">
            <i class="fas fa-truck me-2"></i>TEDARİKÇİ YÖNETİMİ
        </h5>
        <div class="d-flex gap-2">
            {{-- YENİ EKLENEN FORMU YAZDIR BUTONU --}}
            <a href="{{ route('admin.suppliers.print-list') }}" target="_blank" class="btn btn-sm btn-dark px-3 fw-bold shadow-sm">
                <i class="fas fa-print me-1"></i> Formu Yazdır
            </a>
            <a href="{{ route('admin.suppliers.create') }}" class="btn btn-sm btn-success px-4 fw-bold shadow-sm">
                <i class="fas fa-plus me-1"></i> YENİ TEDARİKÇİ
            </a>
            <button type="button" class="btn btn-sm btn-primary px-4 fw-bold shadow-sm" onclick="location.reload();">
                <i class="fas fa-sync me-1"></i> YENİLE
            </button>
        </div>
    </div>

    {{-- FİLTRE VE EXPORT BÖLÜMÜ --}}
    <div class="card shadow-none border mb-3">
        <div class="card-header bg-light py-2 border-bottom">
            <div class="row align-items-center g-2">
                <div class="col-md-6">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="d-flex gap-1">
                            {{-- SINIF FİLTRESİ --}}
                            <select class="form-select form-select-sm" id="classFilter" style="width: auto;">
                                <option value="tum">Tüm Sınıflar</option>
                                @foreach($supplierClasses as $cls)
                                    <option value="{{ $cls->name }}">{{ $cls->name }}</option>
                                @endforeach
                            </select>
                            {{-- DURUM FİLTRESİ --}}
                            <select class="form-select form-select-sm" id="statusFilter" style="width: auto;">
                                <option value="tum">Tüm Durumlar</option>
                                <option value="Onaylı">Onaylı</option>
                                <option value="Şartlı">Şartlı</option>
                                <option value="Red">Red</option>
                                <option value="Bekliyor">Bekliyor</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-sm btn-success btn-export" id="btnExportXLS">
                            <i class="fas fa-file-excel me-1"></i> XLS
                        </button>
                        <button type="button" class="btn btn-sm btn-danger btn-export" id="btnExportPDF">
                            <i class="fas fa-file-pdf me-1"></i> PDF
                        </button>
                        <button type="button" class="btn btn-sm btn-warning btn-export" id="btnColumnToggle">
                            <i class="fas fa-columns me-1"></i> SÜTUNLAR
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-2">
            {{-- TABLO --}}
            <div class="table-responsive">
                <table class="table table-sm table-hover table-bordered mb-0 align-middle" id="suppliersTable" style="font-size: 0.85rem;">
                    <thead class="bg-primary text-white">
                        <tr>
                            <th width="30" class="text-center">#</th>
                            <th>Firma Adı</th>
                            <th>Sınıfı</th>
                            <th>Kategori (Ürün)</th>
                            <th>Yetkili Kişi</th>
                            <th class="text-center">ISO 17025</th>
                            <th class="text-center">Son Değerlendirme</th>
                            <th class="text-center">Puan</th>
                            <th class="text-center">Durum</th>
                            <th width="100" class="text-center">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($suppliers as $index => $sup)
                        <tr data-id="{{ $sup->id }}">
                            <td class="text-center">{{ $index + 1 }}</td>
                            
                            {{-- Firma Adı --}}
                            <td class="fw-bold text-primary">{{ $sup->company_name }}</td>
                            
                            {{-- Yeni: Değerlendirme Sınıfı --}}
                            <td>
                                @if($sup->supplierClass)
                                    <span class="badge bg-dark">{{ $sup->supplierClass->name }}</span>
                                @else
                                    <span class="badge bg-secondary border">Sınıf Yok</span>
                                @endif
                            </td>

                            {{-- Eski Kategori (Virgüllü formatı şık bir şekilde basıyoruz) --}}
                            <td>
                                @if($sup->category)
                                    <div class="d-flex flex-wrap gap-1">
                                        @foreach(explode(', ', $sup->category) as $cat)
                                            <span class="badge bg-light text-dark border">{{ $cat }}</span>
                                        @endforeach
                                    </div>
                                @else
                                    <span class="text-muted">-</span>
                                @endif
                            </td>
                            
                            {{-- Yetkili --}}
                            <td>
                                {{ $sup->contact_person ?? '-' }}<br>
                                <small class="text-muted">{{ $sup->phone }}</small>
                            </td>

                            {{-- Kalite Belgeleri --}}
                            <td class="text-center">
                                @if($sup->has_iso_17025) <i class="fas fa-check-circle text-success fs-5" title="ISO 17025 Var"></i> @else <i class="fas fa-minus text-muted opacity-25"></i> @endif
                            </td>

                            {{-- Son Değerlendirme Tarihi --}}
                            <td class="text-center">
                                @if($sup->last_evaluation_date)
                                    {{ \Carbon\Carbon::parse($sup->last_evaluation_date)->format('d.m.Y') }}
                                @else
                                    <span class="text-muted">-</span>
                                @endif
                            </td>

                            {{-- Puan (Veritabanındaki score sütununa güncellendi) --}}
                            <td class="text-center">
                                @if(isset($sup->score))
                                    <span class="badge fs-6 bg-{{ $sup->score >= 85 ? 'success' : ($sup->score >= 70 ? 'warning text-dark' : 'danger') }}">
                                        {{ $sup->score }}
                                    </span>
                                @else
                                    <span class="text-muted">-</span>
                                @endif
                            </td>

                            {{-- Durum --}}
                            <td class="text-center">
                                @switch($sup->status)
                                    @case('Approved') <span class="badge bg-success">Onaylı</span> @break
                                    @case('Conditional') <span class="badge bg-warning text-dark">Şartlı</span> @break
                                    @case('Rejected') <span class="badge bg-danger">Red</span> @break
                                    @default <span class="badge bg-secondary">Bekliyor</span>
                                @endswitch
                            </td>

                            {{-- İşlemler --}}
                            <td class="text-center">
                                <a href="{{ route('admin.suppliers.show', $sup->id) }}" class="btn btn-sm btn-info shadow-sm py-0 px-2 text-white" title="Detay & Puanlama">
                                    <i class="fas fa-eye small"></i>
                                </a>
                                <a href="{{ route('admin.suppliers.edit', $sup->id) }}" class="btn btn-sm btn-warning shadow-sm py-0 px-2 text-dark" title="Düzenle">
                                    <i class="fas fa-edit small"></i>
                                </a>
                                {{-- YENİ EKLENEN SİL BUTONU (Sadece Admin yetkilileri silebilir güvenlik kuralı eklenebilir) --}}
                                @if(Auth::user()->isAdmin())
                                <form action="{{ route('admin.suppliers.destroy', $sup->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Bu tedarikçiyi sistemden tamamen silmek istediğinize emin misiniz? DİKKAT: Bu işlem geri alınamaz!');">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger shadow-sm py-0 px-2" title="Sil">
                                        <i class="fas fa-trash small"></i>
                                    </button>
                                </form>
                                @endif
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="10" class="text-center py-4 text-muted">
                                <i class="fas fa-truck-loading fa-3x mb-3 d-block opacity-25"></i>
                                Henüz kayıtlı tedarikçi bulunmuyor.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-2 small text-muted">
            Toplam {{ count($suppliers) }} tedarikçi listelendi.
        </div>
    </div>

    {{-- İSTATİSTİK KARTLARI (DİNAMİK DURUMLAR) --}}
    <div class="row g-3 mt-3">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-primary text-white h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 mb-1 small">Toplam Tedarikçi</h6>
                            <h3 class="fw-bold mb-0">{{ $suppliers->count() }}</h3>
                        </div>
                        <div class="fs-1 text-white-50"><i class="fas fa-warehouse"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-success-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Onaylı Tedarikçiler</h6>
                            <h3 class="fw-bold mb-0 text-success">{{ $suppliers->where('status', 'Approved')->count() }}</h3>
                        </div>
                        <div class="fs-1 text-success opacity-50"><i class="fas fa-check-circle"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-warning-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Şartlı Onaylı</h6>
                            <h3 class="fw-bold mb-0 text-warning">{{ $suppliers->where('status', 'Conditional')->count() }}</h3>
                        </div>
                        <div class="fs-1 text-warning opacity-50"><i class="fas fa-exclamation-triangle"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-danger-soft h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Reddedilen (RED)</h6>
                            <h3 class="fw-bold mb-0 text-danger">{{ $suppliers->where('status', 'Rejected')->count() }}</h3>
                        </div>
                        <div class="fs-1 text-danger opacity-50"><i class="fas fa-times-circle"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- SÜTUN AYARLARI MODAL --}}
<div class="modal fade" id="columnModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary text-white">
                <h6 class="modal-title fw-bold mb-0"><i class="fas fa-columns me-2"></i>Sütun Ayarları</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-2">
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="2" checked id="c2"><label for="c2">Sınıfı</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="3" checked id="c3"><label for="c3">Kategori</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="4" checked id="c4"><label for="c4">Yetkili Kişi</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="5" checked id="c5"><label for="c5">ISO 17025</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="6" checked id="c6"><label for="c6">Son Değerlendirme</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="7" checked id="c7"><label for="c7">Puan</label></div></div>
                    <div class="col-6"><div class="form-check"><input class="form-check-input column-toggle" type="checkbox" data-column="8" checked id="c8"><label for="c8">Durum</label></div></div>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
$(document).ready(function() {
    $.fn.dataTable.ext.errMode = 'none';

    const table = $('#suppliersTable').DataTable({
        language: {
            "emptyTable": "Tabloda veri yok",
            "info": "_TOTAL_ kayıttan _START_ - _END_ arası gösteriliyor",
            "infoEmpty": "Kayıt yok",
            "infoFiltered": "(_MAX_ kayıt içerisinden)",
            "lengthMenu": "_MENU_ kayıt göster",
            "loadingRecords": "Yükleniyor...",
            "search": "Ara:",
            "zeroRecords": "Eşleşen kayıt bulunamadı",
            "paginate": { "first": "İlk", "last": "Son", "next": "Sonraki", "previous": "Önceki" }
        },
        pageLength: 25,
        dom: 'Bfrtip',
        buttons: [
            { extend: 'excelHtml5', text: '<i class="fas fa-file-excel me-1"></i> Excel', className: 'btn btn-success btn-sm' },
            { extend: 'pdfHtml5', text: '<i class="fas fa-file-pdf me-1"></i> PDF', className: 'btn btn-danger btn-sm' }
        ],
        columnDefs: [ { orderable: false, targets: [0, 9] } ] // # ve İşlemler (Yeni eklenen sütun nedeniyle 8'den 9'a güncellendi)
    });

    // --- FİLTRELEME ---
    
    // Sınıf Filtresi (Kolon 2: Sınıf)
    $('#classFilter').on('change', function() {
        const val = $(this).val();
        if(val === 'tum') table.column(2).search('').draw();
        else table.column(2).search(val).draw();
    });

    // Durum Filtresi (Kolon 8: Durum - Yeni eklenen sütun nedeniyle 7'den 8'e güncellendi)
    $('#statusFilter').on('change', function() {
        const val = $(this).val();
        if(val === 'tum') table.column(8).search('').draw();
        else table.column(8).search(val).draw();
    });

    // --- BUTON AKSİYONLARI ---
    $('#suppliersTable tbody').on('click', 'tr', function(e) {
        if (!$(e.target).closest('a, button').length) {
            const id = $(this).data('id');
            if(id) window.location.href = `/admin/suppliers/${id}`;
        }
    });

    $('#btnColumnToggle').on('click', function() { $('#columnModal').modal('show'); });
    $('.column-toggle').on('change', function() {
        const column = table.column($(this).data('column'));
        column.visible(!column.visible());
    });

    $('#btnExportXLS').on('click', function() { table.button('.buttons-excel').trigger(); });
    $('#btnExportPDF').on('click', function() { table.button('.buttons-pdf').trigger(); });
});
</script>
@endpush