<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>FR-06-02 Dış Tedarikçi Değerlendirme Formu</title>
    <style>
        /* A4 Dikey Yazdırma Ayarları */
        @page {
            size: A4 portrait;
            margin: 10mm;
        }
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 11px;
            color: #000;
            background: #fff;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            margin: 0 auto;
        }

        /* Tüm Tablolar İçin Genel Stil */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        td, th {
            border: 1px solid #000;
            padding: 5px;
            vertical-align: middle;
            line-height: 1.3;
        }

        .text-center { text-align: center; }
        .text-left { text-align: left; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }

        /* Arka Plan Rengi: MS Word (Yeşil, Vurgu 6, Daha Açık %80) -> #E2EFDA */
        .bg-custom {
            background-color: #E2EFDA !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        /* Yazdırma Butonu */
        .no-print {
            position: fixed; top: 10px; right: 10px;
            background: #333; color: #fff; padding: 8px 15px;
            text-decoration: none; border-radius: 4px; font-family: sans-serif;
            font-size: 12px; z-index: 9999; cursor: pointer; border: none;
        }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>

    <button onclick="window.print()" class="no-print">YAZDIR / PDF</button>

    <div class="container">

        {{-- BAŞLIK TABLOSU --}}
        <table>
            <tr>
                <td rowspan="4" style="width: 20%; text-align: center;">
                    @php
                        $logo = \App\Models\Setting::where('key', 'site_logo')->value('value');
                    @endphp
                    @if($logo)
                        <img src="{{ asset($logo) }}" alt="Logo" style="max-height: 60px; max-width: 100%;">
                    @else
                        <h2 style="margin: 0; font-size: 16px;">AKADEMİ ÇEVRE</h2>
                    @endif
                </td>
                <td rowspan="4" class="text-center font-bold" style="width: 50%; font-size: 16px;">
                    DIŞ TEDARİKÇİ DEĞERLENDİRME FORMU
                </td>
                <td style="width: 15%; font-weight: bold; font-size: 10px;">Doküman No</td>
                <td style="width: 15%; font-size: 10px;">FR-06-02</td>
            </tr>
            <tr>
                <td style="font-weight: bold; font-size: 10px;">Yayın Tarihi</td>
                <td style="font-size: 10px;">03.06.2024</td>
            </tr>
            <tr>
                <td style="font-weight: bold; font-size: 10px;">Rev. No/Tarih</td>
                <td style="font-size: 10px;">00/-</td>
            </tr>
            <tr>
                <td style="font-weight: bold; font-size: 10px;">Sayfa No</td>
                <td style="font-size: 10px;">1/1</td>
            </tr>
        </table>

        {{-- TEDARİKÇİ BİLGİLERİ TABLOSU --}}
        <table>
            <tr>
                <td colspan="6" class="bg-custom font-bold text-center">Tedarikçi</td>
            </tr>
            <tr>
                <td class="font-bold" style="width: 15%;">Firma Adı</td>
                <td colspan="2" style="width: 35%;">{{ $supplier->company_name }}</td>
                <td class="font-bold" style="width: 10%;">Tel</td>
                <td colspan="2" style="width: 40%;">{{ $supplier->phone ?? '-' }}</td>
            </tr>
            <tr>
                <td class="font-bold">İlgili/Unvan</td>
                <td colspan="2">{{ $supplier->contact_person ?? '-' }}</td>
                <td class="font-bold">E-mail</td>
                <td colspan="2">{{ $supplier->email ?? '-' }}</td>
            </tr>
            <tr>
                <td colspan="4" class="font-bold">Temin Edilen Ürün/Hizmet/Laboratuvarlar Arası İş Birliği-Taşeron:</td>
                <td class="font-bold text-center">Talep Tarihi</td>
                <td class="text-center">
                    {{ $eval ? $eval->evaluation_date->format('d.m.Y') : date('d.m.Y') }}
                </td>
            </tr>
            <tr>
                <td colspan="6" class="text-center">{{ str_replace(',', ', ', $supplier->category ?? '-') }}</td>
            </tr>
            <tr>
                <td colspan="6" class="bg-custom font-bold text-center">
                    {{ $supplier->supplierClass->name ?? 'DEĞERLENDİRME SORULARI' }} 
                    @if($supplier->supplierClass)
                        ({{ $supplier->supplierClass->description ?? '' }})
                    @endif
                </td>
            </tr>
        </table>

        {{-- DEĞERLENDİRME SORULARI TABLOSU --}}
        <table>
            <tr class="bg-custom font-bold text-center">
                <td colspan="3" style="width: 60%;">DEĞERLENDİRME KONULARI</td>
                <td style="width: 10%;">ÜST PUAN SINIRI</td>
                <td style="width: 10%;">VERİLEN PUAN</td>
                <td style="width: 20%;">NOTLAR</td>
            </tr>

            @if($supplier->supplierClass && $supplier->supplierClass->questions)
                @foreach($supplier->supplierClass->questions as $q)
                <tr>
                    <td colspan="3">{{ $q->question }}</td>
                    <td class="text-center">{{ $q->max_score }}</td>
                    
                    {{-- Değerlendirme puanını bul --}}
                    @php
                        $givenScore = '';
                        if($eval && $eval->scores) {
                            $decodedScores = is_string($eval->scores) ? json_decode($eval->scores, true) : $eval->scores;
                            if(isset($decodedScores[$q->id])) {
                                $givenScore = $decodedScores[$q->id];
                            }
                        }
                    @endphp
                    
                    <td class="text-center font-bold">{{ $givenScore }}</td>
                    <td></td>
                </tr>
                @endforeach

                {{-- Tabloyu doldurmak için boş satırlar --}}
                @for($i = $supplier->supplierClass->questions->count(); $i < 10; $i++)
                <tr>
                    <td colspan="3" style="height: 22px;"></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                @endfor
            @else
                <tr>
                    <td colspan="6" class="text-center" style="height: 100px;">Bu tedarikçiye atanmış bir sınıf/soru bulunamadı.</td>
                </tr>
            @endif

            {{-- TOPLAM PUAN SATIRI --}}
            <tr class="bg-custom font-bold">
                <td colspan="3" class="text-right">TOPLAM PUAN</td>
                <td class="text-center">100</td>
                <td class="text-center">{{ $eval ? $eval->total_score : '-' }}</td>
                <td></td>
            </tr>
        </table>

        {{-- SONUÇ TABLOSU --}}
        <table>
            <tr>
                <td colspan="6" class="bg-custom font-bold text-center">Yukarıdaki Verilen Puan Sütunu Toplam Puanına Göre:</td>
            </tr>
            <tr>
                <td colspan="3" class="font-bold text-center" style="width: 50%;">Ortalama Liste Puanı:</td>
                <td colspan="3" style="width: 50%; padding-left: 20px;">
                    <div style="margin-bottom: 5px;">
                        {!! ($eval && $eval->total_score >= 80) ? '☑' : '□' !!} 80≤ ÇOK İYİ (A Grubu)
                    </div>
                    <div style="margin-bottom: 5px;">
                        {!! ($eval && $eval->total_score >= 60 && $eval->total_score < 80) ? '☑' : '□' !!} 60-80 İYİ (B Grubu)
                    </div>
                    <div>
                        {!! ($eval && $eval->total_score < 60) ? '☑' : '□' !!} ≤60 KÖTÜ (C Grubu)
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="3" style="height: 70px; vertical-align: top;">
                    <div class="font-bold text-center" style="margin-bottom: 5px;">Değerlendirmeyi Yapan</div>
                    <div class="text-center">Ad/Soyad ve Tarih/İmza</div>
                    <div class="text-center font-bold" style="margin-top: 15px;">{{ $eval->evaluator->name ?? '' }}</div>
                </td>
                <td colspan="3" style="vertical-align: top;">
                    <div class="font-bold text-center" style="margin-bottom: 5px;">Onaylayan</div>
                    <div class="text-center">Ad/Soyad ve Tarih/İmza</div>
                </td>
            </tr>
        </table>

    </div>
</body>
</html>