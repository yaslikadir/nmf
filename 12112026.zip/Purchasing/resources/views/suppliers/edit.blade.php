@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h3 mb-0 text-gray-800"><i class="fas fa-edit me-2 text-warning"></i>Tedarikçi Düzenle</h2>
        <a href="{{ route('admin.suppliers.show', $supplier->id) }}" class="btn btn-secondary btn-sm shadow-sm">
            <i class="fas fa-arrow-left me-1"></i> İptal ve Dön
        </a>
    </div>

    {{-- DİKKAT: update rotası ve enctype --}}
    <form action="{{ route('admin.suppliers.update', $supplier->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT') 
        
        <div class="row">
            {{-- SOL KOLON: TEMEL BİLGİLER --}}
            <div class="col-lg-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold text-uppercase small">
                        <i class="fas fa-building me-1"></i> Firma Kimlik Bilgileri
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label fw-bold small">Firma Ünvanı <span class="text-danger">*</span></label>
                                <input type="text" name="company_name" class="form-control" value="{{ $supplier->company_name }}" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small">Vergi No / V.D.</label>
                                <input type="text" name="tax_no" class="form-control" value="{{ $supplier->tax_no }}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Yetkili Kişi</label>
                                <input type="text" name="contact_person" class="form-control" value="{{ $supplier->contact_person }}">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">E-Posta Adresi</label>
                                <input type="email" name="email" class="form-control" value="{{ $supplier->email }}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Telefon</label>
                                <input type="text" name="phone" class="form-control" value="{{ $supplier->phone }}">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Web Sitesi</label>
                                <input type="text" name="website" class="form-control" value="{{ $supplier->website }}">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-bold small">Açık Adres</label>
                                <textarea name="address" class="form-control" rows="2">{{ $supplier->address }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold text-uppercase small">
                        <i class="fas fa-sticky-note me-1"></i> Notlar
                    </div>
                    <div class="card-body">
                        <textarea name="notes" class="form-control" rows="3">{{ $supplier->notes }}</textarea>
                    </div>
                </div>
            </div>

            {{-- SAĞ KOLON: BELGELER VE SINIFLANDIRMA --}}
            <div class="col-lg-4">
                
                {{-- KATEGORİZASYON VE SINIFLANDIRMA --}}
                <div class="card shadow-sm mb-4 border-top-lg border-warning">
                    <div class="card-header bg-white fw-bold text-dark">
                        <i class="fas fa-tags me-1"></i> Sınıflandırma ve Kategori
                    </div>
                    <div class="card-body">
                        
                        {{-- YENİ EKLENEN TEDARİKÇİ SINIFI (DEĞERLENDİRME) ALANI --}}
                        <div class="mb-3 border-bottom pb-3">
                            <label class="form-label fw-bold small text-primary">Tedarikçi Sınıfı (Değerlendirme Tipi) <span class="text-danger">*</span></label>
                            <select name="supplier_class_id" class="form-select border-primary fw-bold" required>
                                <option value="">Lütfen Sınıf Seçiniz...</option>
                                @if(isset($supplierClasses))
                                    @foreach($supplierClasses as $sClass)
                                        <option value="{{ $sClass->id }}" {{ $supplier->supplier_class_id == $sClass->id ? 'selected' : '' }}>
                                            {{ $sClass->name }}
                                        </option>
                                    @endforeach
                                @endif
                            </select>
                            <small class="text-muted mt-1 d-block">Tedarikçinin değerlendirme sorularını ve kriterlerini belirler.</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small">Tedarikçi Kategorisi (Eski Sistem) <span class="text-danger">*</span></label>
                            @php
                                // Veritabanındaki "Kalibrasyon, Kimyasal" formatını diziye çeviriyoruz
                                $selectedCategories = explode(', ', $supplier->category ?? '');
                            @endphp
                            <select name="category[]" id="categorySelect" class="form-select" multiple="multiple" size="6" required>
                                <option value="Kalibrasyon" {{ in_array('Kalibrasyon', $selectedCategories) ? 'selected' : '' }}>Kalibrasyon</option>
                                <option value="CRM" {{ in_array('CRM', $selectedCategories) ? 'selected' : '' }}>CRM</option>
                                <option value="Kimyasal" {{ in_array('Kimyasal', $selectedCategories) ? 'selected' : '' }}>Kimyasal</option>
                                <option value="Sarf Malzeme" {{ in_array('Sarf Malzeme', $selectedCategories) ? 'selected' : '' }}>Sarf Malzeme</option>
                                <option value="Cihaz" {{ in_array('Cihaz', $selectedCategories) ? 'selected' : '' }}>Cihaz</option>
                                <option value="YT Testi" {{ in_array('YT Testi', $selectedCategories) ? 'selected' : '' }}>YT Testi</option>
                                <option value="LAK" {{ in_array('LAK', $selectedCategories) ? 'selected' : '' }}>LAK</option>
                                <option value="Ofis Malzemesi" {{ in_array('Ofis Malzemesi', $selectedCategories) ? 'selected' : '' }}>Ofis Malzemesi</option>
                                <option value="Diğer" {{ in_array('Diğer', $selectedCategories) ? 'selected' : '' }}>Diğer</option>
                            </select>
                            <small class="text-muted mt-1 d-block"><i class="fas fa-info-circle text-primary"></i> Birden fazla seçmek için <b>CTRL</b> (Mac: CMD) tuşuna basılı tutarak tıklayın.</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Analiz Sonucunu Etkiliyor mu?</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="affects_analysis" value="1" id="affectsSwitch" {{ $supplier->affects_analysis ? 'checked' : '' }}>
                                <label class="form-check-label" for="affectsSwitch">Evet, Etkiler</label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-danger">Onay Durumu (Manuel Müdahale)</label>
                            <select name="status" class="form-select form-select-sm border-danger">
                                <option value="Pending" {{ $supplier->status == 'Pending' ? 'selected' : '' }}>Bekliyor</option>
                                <option value="Approved" {{ $supplier->status == 'Approved' ? 'selected' : '' }}>Onaylı</option>
                                <option value="Conditional" {{ $supplier->status == 'Conditional' ? 'selected' : '' }}>Şartlı</option>
                                <option value="Rejected" {{ $supplier->status == 'Rejected' ? 'selected' : '' }}>Red</option>
                            </select>
                        </div>
                    </div>
                </div>

                {{-- KALİTE VE RESMİ BELGELER --}}
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold text-uppercase small">
                        <i class="fas fa-file-contract me-1"></i> Belgeler
                    </div>
                    <div class="card-body">
                        
                        {{-- 1. VERGİ LEVHASI --}}
                        <div class="mb-3 border-bottom pb-3">
                            <label class="form-label fw-bold small text-dark">Vergi Levhası</label>
                            @if($supplier->tax_plate_file)
                                <div class="mb-2 small">
                                    <a href="{{ asset('storage/' . $supplier->tax_plate_file) }}" target="_blank" class="text-success fw-bold">
                                        <i class="fas fa-check-circle"></i> Mevcut Dosyayı Gör
                                    </a>
                                </div>
                            @endif
                            <input type="file" name="tax_plate_file" class="form-control form-control-sm">
                            <div class="form-check mt-1">
                                <input class="form-check-input" type="checkbox" name="has_tax_plate" value="1" id="taxPlateCheck" {{ $supplier->has_tax_plate ? 'checked' : '' }}>
                                <label class="form-check-label small" for="taxPlateCheck">Levha Mevcut (Dosya yoksa)</label>
                            </div>
                        </div>

                        {{-- 2. ISO 9001 --}}
                        <div class="mb-3 border-bottom pb-3">
                            <label class="form-label fw-bold small text-dark">ISO 9001 Belgesi</label>
                            @if($supplier->iso_9001_file)
                                <div class="mb-2 small">
                                    <a href="{{ asset('storage/' . $supplier->iso_9001_file) }}" target="_blank" class="text-success fw-bold">
                                        <i class="fas fa-check-circle"></i> Mevcut Dosyayı Gör
                                    </a>
                                </div>
                            @endif
                            <input type="file" name="iso_9001_file" class="form-control form-control-sm">
                            <div class="form-check mt-1">
                                <input class="form-check-input" type="checkbox" name="has_iso_9001" value="1" id="iso9001" {{ $supplier->has_iso_9001 ? 'checked' : '' }}>
                                <label class="form-check-label small" for="iso9001">Belge Mevcut</label>
                            </div>
                        </div>

                        {{-- 3. ISO 17025 --}}
                        <div class="mb-2">
                            <label class="form-label fw-bold small text-dark">ISO 17025 Akreditasyon</label>
                            @if($supplier->iso_17025_file)
                                <div class="mb-2 small">
                                    <a href="{{ asset('storage/' . $supplier->iso_17025_file) }}" target="_blank" class="text-success fw-bold">
                                        <i class="fas fa-check-circle"></i> Mevcut Dosyayı Gör
                                    </a>
                                </div>
                            @endif
                            <input type="file" name="iso_17025_file" class="form-control form-control-sm">
                            <div class="form-check mt-1">
                                <input class="form-check-input" type="checkbox" name="has_iso_17025" value="1" id="iso17025" {{ $supplier->has_iso_17025 ? 'checked' : '' }}>
                                <label class="form-check-label small fw-bold text-primary" for="iso17025">Akreditasyon Var</label>
                            </div>
                            {{-- Kapsam --}}
                            <div class="mt-2" id="scopeDiv" style="{{ $supplier->has_iso_17025 ? '' : 'display: none;' }}">
                                <textarea name="accreditation_scope" class="form-control form-control-sm" rows="2" placeholder="Kapsam">{{ $supplier->accreditation_scope }}</textarea>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- GÜNCELLE BUTONU --}}
                <div class="d-grid">
                    <button type="submit" class="btn btn-warning fw-bold shadow-sm py-2 text-dark">
                        <i class="fas fa-sync-alt me-2"></i> GÜNCELLE
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
    // ISO 17025 seçilince kapsam alanını aç/kapa
    document.getElementById('iso17025').addEventListener('change', function() {
        const scopeDiv = document.getElementById('scopeDiv');
        if(this.checked) {
            scopeDiv.style.display = 'block';
        } else {
            scopeDiv.style.display = 'none';
        }
    });

    // Select2 Kütüphanesi varsa daha şık bir çoklu seçim için (create sayfasındaki gibi)
    $(document).ready(function() {
        if($.fn.select2) {
            $('#categorySelect').select2({
                placeholder: "Kategorileri Seçiniz",
                allowClear: true,
                width: '100%'
            });
            $('#categorySelect').next('.text-muted').hide();
        }
    });
</script>
@endpush