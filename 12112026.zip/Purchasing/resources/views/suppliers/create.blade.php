@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    {{-- BAŞLIK --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h3 mb-0 text-gray-800"><i class="fas fa-truck-loading me-2 text-primary"></i>Yeni Tedarikçi Kartı</h2>
        <a href="{{ route('admin.suppliers.index') }}" class="btn btn-secondary btn-sm shadow-sm">
            <i class="fas fa-arrow-left me-1"></i> Listeye Dön
        </a>
    </div>

    {{-- HATA GÖSTERİMİ --}}
    @if ($errors->any())
        <div class="alert alert-danger border-left-danger">
            <ul class="mb-0 small">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.suppliers.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        
        <div class="row">
            {{-- SOL KOLON: TEMEL BİLGİLER --}}
            <div class="col-lg-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold text-uppercase small">
                        <i class="fas fa-building me-1"></i> Firma Kimlik Bilgileri
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label fw-bold small">Firma Ünvanı <span class="text-danger">*</span></label>
                                <input type="text" name="company_name" class="form-control" placeholder="Örn: ABC Kimya San. Tic. A.Ş." required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small">Vergi No / V.D.</label>
                                <input type="text" name="tax_no" class="form-control" placeholder="Vergi kimlik numarası">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Yetkili Kişi</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" name="contact_person" class="form-control" placeholder="Satış Temsilcisi Adı">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">E-Posta Adresi</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                    <input type="email" name="email" class="form-control" placeholder="info@tedarikci.com">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Telefon</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                    <input type="text" name="phone" class="form-control" placeholder="0212...">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Web Sitesi</label>
                                <input type="text" name="website" class="form-control" placeholder="www...">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-bold small">Açık Adres</label>
                                <textarea name="address" class="form-control" rows="2"></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold text-uppercase small">
                        <i class="fas fa-sticky-note me-1"></i> Notlar
                    </div>
                    <div class="card-body">
                        <textarea name="notes" class="form-control" rows="3" placeholder="Firma hakkında özel notlar, çalışma koşulları vb."></textarea>
                    </div>
                </div>
            </div>

            {{-- SAĞ KOLON: BELGELER VE SINIFLANDIRMA --}}
            <div class="col-lg-4">
                
                {{-- KATEGORİZASYON VE SINIFLANDIRMA --}}
                <div class="card shadow-sm mb-4 border-top-lg border-primary">
                    <div class="card-header bg-white fw-bold text-primary">
                        <i class="fas fa-tags me-1"></i> Sınıflandırma ve Kategori
                    </div>
                    <div class="card-body">
                        
                        {{-- YENİ EKLENEN TEDARİKÇİ SINIFI ALANI --}}
                        <div class="mb-3 border-bottom pb-3">
                            <label class="form-label fw-bold small text-primary">Tedarikçi Sınıfı (Değerlendirme Tipi) <span class="text-danger">*</span></label>
                            <select name="supplier_class_id" class="form-select border-primary fw-bold" required>
                                <option value="">Lütfen Sınıf Seçiniz...</option>
                                @if(isset($supplierClasses))
                                    @foreach($supplierClasses as $sClass)
                                        <option value="{{ $sClass->id }}">{{ $sClass->name }}</option>
                                    @endforeach
                                @endif
                            </select>
                            <small class="text-muted mt-1 d-block">Tedarikçinin değerlendirme sorularını ve kriterlerini belirler.</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small">Tedarikçi Kategorisi <span class="text-danger">*</span></label>
                            <select name="category[]" id="categorySelect" class="form-select" multiple="multiple" size="6" required>
                                
                                <option value="urun">Ürün</option>
                                <option value="hizmet">Hizmet</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                            <small class="text-muted mt-1 d-block"><i class="fas fa-info-circle text-primary"></i> Birden fazla seçmek için <b>CTRL</b> (Mac: CMD) tuşuna basılı tutarak tıklayın.</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Analiz Sonucunu Etkiliyor mu?</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="affects_analysis" value="1" id="affectsSwitch">
                                <label class="form-check-label" for="affectsSwitch">Evet, Analize Etkisi Var</label>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- KALİTE VE RESMİ BELGELER --}}
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold text-uppercase small">
                        <i class="fas fa-file-contract me-1"></i> Resmi & Kalite Belgeleri
                    </div>
                    <div class="card-body">
                        
                        {{-- 1. VERGİ LEVHASI --}}
                        <div class="mb-3 border-bottom pb-3">
                            <label class="form-label fw-bold small text-dark">Vergi Levhası</label>
                            <div class="input-group input-group-sm">
                                <input type="file" name="tax_plate_file" class="form-control" accept=".pdf,.jpg,.png">
                            </div>
                            <div class="form-check mt-1">
                                <input class="form-check-input" type="checkbox" name="has_tax_plate" value="1" id="taxPlateCheck">
                                <label class="form-check-label small" for="taxPlateCheck">Levha Mevcut (Dosya yoksa işaretle)</label>
                            </div>
                        </div>

                        {{-- 2. ISO 9001 --}}
                        <div class="mb-3 border-bottom pb-3">
                            <label class="form-label fw-bold small text-dark">ISO 9001 Belgesi</label>
                            <div class="input-group input-group-sm">
                                <input type="file" name="iso_9001_file" class="form-control" accept=".pdf,.jpg,.png">
                            </div>
                            <div class="form-check mt-1">
                                <input class="form-check-input" type="checkbox" name="has_iso_9001" value="1" id="iso9001">
                                <label class="form-check-label small" for="iso9001">Belge Mevcut</label>
                            </div>
                        </div>

                        {{-- 3. ISO 17025 --}}
                        <div class="mb-2">
                            <label class="form-label fw-bold small text-dark">ISO 17025 Akreditasyon</label>
                            <div class="input-group input-group-sm">
                                <input type="file" name="iso_17025_file" class="form-control" accept=".pdf,.jpg,.png">
                            </div>
                            <div class="form-check mt-1">
                                <input class="form-check-input" type="checkbox" name="has_iso_17025" value="1" id="iso17025">
                                <label class="form-check-label small fw-bold text-primary" for="iso17025">Akreditasyon Var</label>
                            </div>
                            {{-- Kapsam --}}
                            <div class="mt-2" id="scopeDiv" style="display: none;">
                                <textarea name="accreditation_scope" class="form-control form-control-sm" rows="2" placeholder="Kapsam (Örn: Su Analizi, Kalibrasyon...)"></textarea>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- KAYDET BUTONU --}}
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary fw-bold shadow-sm py-2">
                        <i class="fas fa-save me-2"></i> TEDARİKÇİYİ KAYDET
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
    // ISO 17025 seçilince kapsam alanını aç/kapa
    document.getElementById('iso17025').addEventListener('change', function() {
        const scopeDiv = document.getElementById('scopeDiv');
        if(this.checked) {
            scopeDiv.style.display = 'block';
        } else {
            scopeDiv.style.display = 'none';
        }
    });

    // Sayfa yüklendiğinde Select2 kütüphanesi projenizde mevcutsa daha şık çoklu seçim için aktif eder
    $(document).ready(function() {
        if($.fn.select2) {
            $('#categorySelect').select2({
                placeholder: "Kategorileri Seçiniz",
                allowClear: true,
                width: '100%'
            });
            // Select2 kullanılıyorsa aşağıdaki bilgi notunu gizleyebiliriz
            $('#categorySelect').next('.text-muted').hide();
        }
    });
</script>
@endpush