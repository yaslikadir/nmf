<?php

use Illuminate\Support\Facades\Route;
use Modules\Purchasing\Http\Controllers\SupplierController;
use Modules\Purchasing\Http\Controllers\SupplierClassController;
use Modules\Purchasing\Http\Controllers\PurchaseController;
use Modules\Purchasing\Http\Controllers\PurchaseOfferController;
use Modules\Purchasing\Http\Controllers\PurchaseOrderController;
use Modules\Purchasing\Http\Middleware\PurchasingBranchAccess;

Route::middleware(PurchasingBranchAccess::class)->group(function () {

// ==================================================
//  TEDARİKÇİ YÖNETİMİ
// ==================================================
Route::controller(SupplierController::class)->prefix('suppliers')->name('suppliers.')->group(function () {
    Route::get('/', 'index')->name('index');
    Route::get('/create', 'create')->name('create');
    Route::post('/', 'store')->name('store');
    Route::get('/{id}', 'show')->name('show');
    Route::get('/{id}/edit', 'edit')->name('edit');
    Route::put('/{id}', 'update')->name('update');
    // YENİ EKLENEN YAZDIRMA ROTASI (mutlaka /{id} den önce gelmeli)
    Route::get('/print/list', 'printList')->name('print-list');
    Route::get('/{id}/print-eval/{evalId}', 'printEvaluation')->name('print-eval');
    
    // YENİ EKLENEN: Tedarikçi Silme Rotası (DOĞRU YER)
    Route::delete('/{id}', 'destroy')->name('destroy');
    
    Route::post('/{id}/evaluate', 'storeEvaluation')->name('evaluate');
    
    // Geçmiş Değerlendirme (Karne) Düzenleme ve Silme Rotaları
    Route::put('/evaluations/{id}', 'updateEvaluation')->name('evaluations.update');
    Route::delete('/evaluations/{id}', 'destroyEvaluation')->name('evaluations.destroy');
});

// ==================================================
//  TEDARİKÇİ SINIFLARI, SORULARI VE KRİTERLERİ
// ==================================================
Route::controller(SupplierClassController::class)->prefix('supplier-classes')->name('supplier-classes.')->group(function () {
    Route::get('/', 'index')->name('index');
    Route::post('/', 'store')->name('store');
    Route::get('/{id}', 'show')->name('show');
    
    // Sorular İçin
    Route::post('/{id}/questions', 'storeQuestion')->name('questions.store');
    Route::delete('/questions/{id}', 'destroyQuestion')->name('questions.destroy');
    
    // Kriterler İçin
    Route::post('/{id}/criteria', 'storeCriterion')->name('criteria.store');
    Route::delete('/criteria/{id}', 'destroyCriterion')->name('criteria.destroy');
});

// ==================================================
//  SATIN ALMA YÖNETİMİ (Purchase Management)
// ==================================================
Route::prefix('purchase')->name('purchase.')->group(function() {
    
    // 1. Talepler
    Route::controller(PurchaseController::class)->prefix('requests')->name('requests.')->group(function() {
        Route::get('/', 'index')->name('index');
        Route::get('/create', 'create')->name('create');
        Route::post('/', 'store')->name('store');
        Route::get('/{id}', 'show')->name('show');
        
        // Talep Düzenleme ve Silme Rotaları
        Route::get('/{id}/edit', 'edit')->name('edit');
        Route::put('/{id}', 'update')->name('update');
        Route::delete('/{id}', 'destroy')->name('destroy');
        
        Route::get('/{id}/print', 'printForm')->name('print'); 
        Route::post('/{id}/status', 'updateStatus')->name('update-status');
    });

    // 2. Teklifler
    Route::controller(PurchaseOfferController::class)->prefix('offers')->name('offers.')->group(function() {
        Route::get('/', 'index')->name('index'); 
        Route::get('/create', 'create')->name('create');
        Route::post('/', 'store')->name('store');
        
        // Teklif Fiyat Güncelleme ve Silme Rotaları
        Route::put('/{id}', 'update')->name('update');
        Route::delete('/{id}', 'destroy')->name('destroy');
        
        Route::post('/{id}/select-winner', 'selectWinner')->name('select-winner');
    });

    // 3. Siparişler
    Route::controller(PurchaseOrderController::class)->prefix('orders')->name('orders.')->group(function() {
        Route::get('/', 'index')->name('index');
        Route::get('/{id}', 'show')->name('show');
        Route::get('/{id}/delivery', 'deliveryForm')->name('delivery-form');
        Route::post('/{id}/delivery', 'storeDelivery')->name('store-delivery');
        Route::post('/{id}/update-delivery', 'updateDelivery')->name('update-delivery'); 
        Route::post('/{id}/complete', 'completeOrder')->name('complete'); 
        
        // YENİ EKLENEN: Döküman Yükleme Rotası
        Route::post('/{id}/upload-document', 'uploadDocument')->name('upload-document');
    });
});

});