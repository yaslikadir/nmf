<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. TEDARİKÇİ SINIFLARI
        if (!Schema::hasTable('supplier_classes')) {
            Schema::create('supplier_classes', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->text('description')->nullable();
                $table->timestamps();
            });
        }

        // 2. TEDARİKÇİLER
        if (!Schema::hasTable('suppliers')) {
            Schema::create('suppliers', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('supplier_class_id')->nullable()->index();
                $table->string('company_name');
                $table->string('contact_person')->nullable();
                $table->integer('score')->default(0);
                $table->string('performance_note', 255)->nullable();
                $table->string('risk_level', 50)->default('Belirsiz');
                $table->string('email')->nullable();
                $table->string('phone')->nullable();
                $table->string('website')->nullable();
                $table->text('address')->nullable();
                $table->text('notes')->nullable();
                $table->string('category', 255)->nullable();
                
                // Kalite & Belge Takibi
                $table->boolean('iso_certified')->default(false);
                $table->date('iso_certificate_date')->nullable();
                $table->date('iso_certificate_expiry')->nullable();
                $table->string('supplier_category')->nullable();
                $table->date('last_audit_date')->nullable();
                $table->string('tax_no')->nullable();
                $table->boolean('has_tax_plate')->default(false);
                $table->text('accreditation_scope')->nullable();
                $table->boolean('has_signature_circular')->default(false);
                $table->boolean('has_trade_registry')->default(false);
                $table->boolean('has_activity_certificate')->default(false);
                $table->boolean('has_iso_files')->default(false);
                $table->boolean('affects_analysis')->default(false)->nullable();
                $table->boolean('has_iso_9001')->default(false)->nullable();
                $table->boolean('has_iso_17025')->default(false)->nullable();
                
                // Dosyalar
                $table->string('tax_plate_file', 255)->nullable();
                $table->string('iso_9001_file', 255)->nullable();
                $table->string('iso_17025_file', 255)->nullable();
                
                // Performans ve Durum
                $table->string('status', 50)->default('Pending');
                $table->integer('performance_score')->default(0)->nullable();
                $table->dateTime('last_evaluation_date')->nullable();
                $table->unsignedBigInteger('approved_by')->nullable();
                
                $table->timestamps();
            });
        }

        // 3. TEDARİKÇİ DEĞERLENDİRMELERİ
        if (!Schema::hasTable('supplier_evaluations')) {
            Schema::create('supplier_evaluations', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('supplier_id');
                $table->unsignedBigInteger('evaluator_id');
                $table->date('evaluation_date');
                $table->integer('score_technical')->nullable();
                $table->integer('score_cert')->nullable();
                $table->integer('score_quality')->nullable();
                $table->integer('score_delivery')->nullable();
                $table->integer('score_docs')->nullable();
                $table->integer('score_complaint')->nullable();
                $table->integer('total_score');
                $table->string('result');
                $table->text('comments')->nullable();
                $table->text('dynamic_scores')->nullable();
                $table->timestamps();

                $table->foreign('supplier_id')->references('id')->on('suppliers')->onDelete('cascade');
                $table->foreign('evaluator_id')->references('id')->on('users');
            });
        }

        $isPurchaseRequestsNewlyCreated = false;

        // 4. SATIN ALMA TALEPLERİ
        if (!Schema::hasTable('purchase_requests')) {
            Schema::create('purchase_requests', function (Blueprint $table) {
                $table->id();
                $table->string('request_no')->unique();
                $table->unsignedBigInteger('requester_id');
                $table->unsignedBigInteger('department_id');
                $table->string('priority')->default('Normal');
                $table->enum('status', ['Pending','Approved','Rejected','Ordered','Completed'])->default('Pending');
                $table->unsignedBigInteger('converted_offer_id')->nullable();
                $table->text('reason')->nullable();
                $table->decimal('estimated_budget', 15, 2)->nullable();
                $table->unsignedBigInteger('approver_id')->nullable();
                $table->date('requested_by_date')->nullable();
                $table->text('approval_note')->nullable();
                $table->dateTime('responded_at')->nullable();
                $table->timestamps();

                $table->foreign('requester_id')->references('id')->on('users');
                $table->foreign('department_id')->references('id')->on('departments');
                $table->foreign('approver_id')->references('id')->on('users');
            });
            
            $isPurchaseRequestsNewlyCreated = true;
        }

        // 5. TALEP KALEMLERİ
        if (!Schema::hasTable('purchase_request_items')) {
            Schema::create('purchase_request_items', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('purchase_request_id');
                $table->unsignedBigInteger('material_id');
                $table->decimal('quantity', 15, 2);
                $table->string('unit');
                $table->text('technical_specifications')->nullable();
                $table->timestamps();

                $table->foreign('purchase_request_id')->references('id')->on('purchase_requests')->onDelete('cascade');
                $table->foreign('material_id')->references('id')->on('materials');
            });
        }

        // 6. TEKLİFLER
        if (!Schema::hasTable('purchase_offers')) {
            Schema::create('purchase_offers', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('purchase_request_id');
                $table->unsignedBigInteger('supplier_id');
                $table->string('offer_no');
                $table->string('supplier_offer_ref')->nullable();
                $table->date('offer_date');
                $table->date('valid_until')->nullable();
                $table->string('currency')->default('TL');
                $table->decimal('exchange_rate', 10, 4)->default(1.0000);
                $table->decimal('sub_total', 15, 2)->default(0.00);
                $table->decimal('tax_total', 15, 2)->default(0.00);
                $table->decimal('grand_total', 15, 2)->default(0.00);
                $table->enum('status', ['Pending','Won','Lost'])->default('Pending');
                $table->text('notes')->nullable();
                $table->timestamps();

                $table->foreign('purchase_request_id')->references('id')->on('purchase_requests')->onDelete('cascade');
                $table->foreign('supplier_id')->references('id')->on('suppliers')->onDelete('cascade');
            });
        }

        // 6.1. TALEP -> TEKLİF BAĞINI (FOREIGN KEY) SADECE TABLO YENİ OLUŞMUŞSA EKLİYORUZ
        if ($isPurchaseRequestsNewlyCreated) {
            Schema::table('purchase_requests', function (Blueprint $table) {
                $table->foreign('converted_offer_id')->references('id')->on('purchase_offers')->onDelete('set null');
            });
        }

        // 7. TEKLİF KALEMLERİ
        if (!Schema::hasTable('purchase_offer_items')) {
            Schema::create('purchase_offer_items', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('purchase_offer_id');
                $table->unsignedBigInteger('purchase_request_item_id');
                $table->decimal('quantity', 10, 2);
                $table->decimal('unit_price', 15, 2);
                $table->decimal('tax_rate', 5, 2)->default(20.00);
                $table->decimal('net_total', 15, 2);
                $table->text('description')->nullable();
                $table->timestamps();

                $table->foreign('purchase_offer_id')->references('id')->on('purchase_offers')->onDelete('cascade');
                $table->foreign('purchase_request_item_id', 'poi_req_item_fk')->references('id')->on('purchase_request_items')->onDelete('cascade');
            });
        }

        // 8. SİPARİŞLER
        if (!Schema::hasTable('purchase_orders')) {
            Schema::create('purchase_orders', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('purchase_request_id');
                $table->unsignedBigInteger('purchase_offer_id');
                $table->unsignedBigInteger('supplier_id');
                $table->string('order_no')->unique();
                $table->dateTime('ordered_at')->useCurrent();
                $table->string('delivery_note_no')->nullable();
                $table->date('delivery_date')->nullable();
                $table->string('invoice_no')->nullable();
                $table->date('invoice_date')->nullable();
                $table->string('invoice_file')->nullable();
                $table->enum('status', ['Ordered','GoodsReceived','Completed','Cancelled'])->default('Ordered');
                $table->timestamps();

                $table->foreign('purchase_request_id')->references('id')->on('purchase_requests')->onDelete('cascade');
                $table->foreign('purchase_offer_id')->references('id')->on('purchase_offers')->onDelete('cascade');
                $table->foreign('supplier_id')->references('id')->on('suppliers')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('purchase_orders');
        Schema::dropIfExists('purchase_offer_items');
        Schema::dropIfExists('purchase_offers');
        Schema::dropIfExists('purchase_request_items');
        Schema::dropIfExists('purchase_requests');
        Schema::dropIfExists('supplier_evaluations');
        Schema::dropIfExists('suppliers');
        Schema::dropIfExists('supplier_classes');
        Schema::enableForeignKeyConstraints();
    }
};