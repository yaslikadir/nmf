<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('purchase_deliveries')) {
            Schema::create('purchase_deliveries', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('branch_id')->nullable()->index();
                $table->unsignedBigInteger('purchase_order_id');
                $table->string('delivery_note_no');
                $table->date('delivery_date');
                $table->text('notes')->nullable();
                $table->unsignedBigInteger('received_by')->nullable();
                $table->timestamps();

                $table->foreign('purchase_order_id')->references('id')->on('purchase_orders')->onDelete('cascade');
                $table->foreign('received_by')->references('id')->on('users')->nullOnDelete();
            });
        }

        if (!Schema::hasTable('purchase_delivery_items')) {
            Schema::create('purchase_delivery_items', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('branch_id')->nullable()->index();
                $table->unsignedBigInteger('purchase_delivery_id');
                $table->unsignedBigInteger('purchase_offer_item_id');
                $table->decimal('quantity_received', 15, 2);
                $table->decimal('quantity_accepted', 15, 2)->default(0);
                $table->decimal('quantity_rejected', 15, 2)->default(0);
                $table->text('rejection_reason')->nullable();
                $table->timestamps();

                $table->foreign('purchase_delivery_id')->references('id')->on('purchase_deliveries')->onDelete('cascade');
                $table->foreign('purchase_offer_item_id')->references('id')->on('purchase_offer_items')->onDelete('cascade');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('purchase_delivery_items');
        Schema::dropIfExists('purchase_deliveries');
    }
};
