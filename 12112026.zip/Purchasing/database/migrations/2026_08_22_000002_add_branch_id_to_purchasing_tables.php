<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        foreach ([
            'supplier_classes', 'suppliers', 'supplier_evaluations',
            'supplier_questions', 'supplier_criteria', 'purchase_requests',
            'purchase_request_items', 'purchase_offers', 'purchase_offer_items',
            'purchase_orders', 'purchase_deliveries', 'purchase_delivery_items',
        ] as $tableName) {
            if (!Schema::hasTable($tableName) || Schema::hasColumn($tableName, 'branch_id')) {
                continue;
            }

            Schema::table($tableName, function (Blueprint $table): void {
                $table->unsignedBigInteger('branch_id')->nullable()->index()->after('id');
            });
        }
    }

    public function down(): void
    {
        foreach ([
            'supplier_classes', 'suppliers', 'supplier_evaluations',
            'supplier_questions', 'supplier_criteria', 'purchase_requests',
            'purchase_request_items', 'purchase_offers', 'purchase_offer_items',
            'purchase_orders', 'purchase_deliveries', 'purchase_delivery_items',
        ] as $tableName) {
            if (!Schema::hasTable($tableName) || !Schema::hasColumn($tableName, 'branch_id')) {
                continue;
            }

            Schema::table($tableName, function (Blueprint $table): void {
                $table->dropColumn('branch_id');
            });
        }
    }
};
