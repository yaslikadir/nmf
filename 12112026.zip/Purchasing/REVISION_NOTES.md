# Purchasing Revizyon Notları

## Sidebar kapsamı

Modül; Tedarikçiler, Tedarikçi Sınıfları, Satın Alma Talepleri, Alınan Teklifler, Siparişler ve Teslimat ekranlarını içerir. Route ve view isimleri sidebar’daki `admin.suppliers.*`, `admin.purchase.requests.*`, `admin.purchase.offers.*` ve `admin.purchase.orders.*` bağlantılarıyla uyumludur.

## Uygulanan düzeltmeler

Purchasing’e ait 12 model `Modules\\Purchasing\\Models` namespace’ine taşındı. Inventory’den kullanılan Material modeli `Modules\\Inventory\\Models\\Material` sınıfına bağlandı; User ve Department ana uygulamadaki shared modeller olarak bırakıldı. Eski App model çağrılarını kullanan ekranlar için provider içinde compatibility alias oluşturuldu.

Tüm purchasing modellerine aktif şube global scope’u eklendi. Aktif şube bulunmadığında sorgular boş döner ve yeni kayıt oluşturulması engellenir. Route’lar PurchasingBranchAccess middleware’i ile korunur; satın alma ve tedarikçi işlemleri HTTP işlem türüne göre permission seviyesine bağlanır.

Tüm purchasing tablolarına branch_id ekleyen migration oluşturuldu. İlk migration’da controller’lar tarafından kullanılan teslimat tabloları bulunmadığı için purchase_deliveries ve purchase_delivery_items tablolarını oluşturan ayrı migration eklendi.

PurchaseOrderController’daki eksik DB facade importu düzeltildi. Teslimat kaydı sırasında teklif kalemi ID’sinin ilgili siparişin teklifine ait olduğu doğrulanıyor; negatif, sıfır ve geçersiz teslimat miktarları reddediliyor.

SupplierController’daki geniş request except kullanımları izinli alan listeleriyle değiştirildi. Böylece status, score, approved_by ve branch_id gibi sistem alanları form verisiyle değiştirilemez.

## Deployment

```bash
cd /var/www/projem
rm -rf modules/Purchasing
unzip Purchasing_revised_v1.zip -d modules
composer dump-autoload -o
php artisan migrate --force
php artisan optimize:clear
```

Mevcut üretim kayıtlarının branch_id alanı otomatik tahmin edilmez. Satın alma talepleri, teklifler, siparişler, tedarikçiler ve child kayıtlar için kontrollü bir şube backfill yapılmalıdır. Backfill tamamlanana kadar aktif branch scope’u eski kayıtları göstermeyebilir; bu fail-closed güvenlik davranışıdır.
