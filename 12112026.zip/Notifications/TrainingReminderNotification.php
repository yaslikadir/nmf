<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\TrainingPlan;

class TrainingReminderNotification extends Notification
{
    use Queueable;

    protected $plan;

    public function __construct(TrainingPlan $plan)
    {
        $this->plan = $plan;
    }

    public function via($notifiable)
    {
        return ['mail', 'database']; // Hem mail at hem panele düşür
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject('⏰ Hatırlatma: Eğitiminiz Yarın Başlıyor!')
                    ->greeting('Merhaba ' . $notifiable->name . ',')
                    ->line('Yarın katılmanız gereken planlı bir eğitiminiz bulunmaktadır.')
                    ->line('-------------------------------------------------------')
                    ->line('📚 Eğitim: ' . $this->plan->training->title)
                    ->line('📅 Başlangıç: ' . $this->plan->start_date->format('d.m.Y H:i'))
                    ->line('📍 Yer/Link: ' . $this->plan->location)
                    ->line('-------------------------------------------------------')
                    ->action('Eğitim Detayları', route('admin.qms.plans.show', $this->plan->id))
                    ->line('Lütfen eğitim saatinden 10 dakika önce hazır bulununuz.');
    }

    public function toArray($notifiable)
    {
        return [
            'title' => 'Eğitim Hatırlatması',
            'message' => 'Yarın ' . $this->plan->start_date->format('H:i') . ' saatinde eğitiminiz var.',
            'url' => route('admin.qms.plans.show', $this->plan->id),
            'icon' => 'fas fa-clock',
            'color' => 'warning'
        ];
    }
}