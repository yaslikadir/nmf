<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use App\Models\QmsDocument;

class DocumentDistributedNotification extends Notification
{
    use Queueable;

    protected $document;
    protected $versionId;

    /**
     * DÜZELTİLDİ: $document için QmsDocument tip tanımlaması (Type Hinting) eklendi.
     * Bu sayede Laravel bu değişkenin ne olduğunu kesin olarak bilir ve hata vermez.
     */
    public function __construct(QmsDocument $document, $versionId)
    {
        $this->document = $document;
        $this->versionId = $versionId;
    }

    public function via($notifiable)
    {
        return ['database']; // Sadece çan ikonuna (veritabanına) düşer
    }

    public function toArray($notifiable)
    {
        return [
            'title' => 'Yeni Doküman Tebliğ Edildi',
            'message' => "{$this->document->document_code} - {$this->document->name} adlı doküman erişiminize açıldı.",
            'url' => route('admin.qms.documents.show', $this->document->id),
            'icon' => 'fas fa-file-contract', 
            'color' => 'text-primary' 
        ];
    }
}