<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;
use App\Models\QmsDocument;         // <-- EKLENDİ
use App\Models\QmsDocumentVersion;  // <-- EKLENDİ

class DocumentApprovalPendingNotification extends Notification
{
    use Queueable;

    protected $document;
    protected $version;

    /**
     * DÜZELTME: Type Hinting (Tip Tanımlaması) eklendi.
     * Artık Laravel bu değişkenlerin Qms modelleri olduğunu kesin olarak biliyor.
     */
    public function __construct(QmsDocument $document, QmsDocumentVersion $version)
    {
        $this->document = $document;
        $this->version = $version;
    }

    public function via($notifiable)
    {
        // Hem Veritabanı (Çan) hem de E-Posta ile gönderilecek
        return ['database', 'mail']; 
    }

    /**
     * E-POSTA İÇERİĞİ
     */
    public function toMail($notifiable)
    {
        $url = route('admin.qms.documents.show', $this->document->id);

        return (new MailMessage)
                    ->subject('Yeni Doküman Onay Talebi: ' . $this->document->document_code)
                    ->greeting('Merhaba ' . ($notifiable->name ?? 'Personel') . ',')
                    ->line("{$this->document->document_code} kodlu ve \"{$this->document->name}\" isimli doküman (Rev{$this->version->version_no}) onayınız için sunulmuştur.")
                    ->action('Dokümanı İncele ve Onayla', $url)
                    ->line('İyi çalışmalar dileriz.');
    }

    /**
     * VERİTABANI (ÇAN İKONU) İÇERİĞİ - Senin yapına BİREBİR uyumlu
     */
    public function toArray($notifiable)
    {
        return [
            'title' => 'Doküman Onay Talebi',
            'message' => "{$this->document->document_code} - {$this->document->name} (Rev{$this->version->version_no}) onayınızı bekliyor.",
            'url' => route('admin.qms.documents.show', $this->document->id),
            'icon' => 'fas fa-signature', // İmza ikonu
            'color' => 'text-warning' // Dikkat çeksin diye sarı (warning) yapıldı
        ];
    }
}