<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue; // Mail gönderimi yavaşlamasın dersen bunu açabilirsin
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\TrainingPlan;

class NewTrainingAssignedNotification extends Notification
{
    use Queueable;

    protected $plan;

    // 1. Plan verisini içeri alalım
    public function __construct(TrainingPlan $plan)
    {
        $this->plan = $plan;
    }

    // 2. Hangi kanallardan gidecek? (Mail + Veritabanı)
    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    // 3. E-Posta Tasarımı
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject('📅 Yeni Eğitim Ataması: ' . $this->plan->training->title)
                    ->greeting('Merhaba ' . $notifiable->name . ',')
                    ->line('Size yeni bir eğitim planlaması atanmıştır. Katılımınız zorunludur.')
                    ->line('-------------------------------------------------------')
                    ->line('📌 Eğitim: ' . $this->plan->training->title)
                    ->line('👨‍🏫 Eğitmen: ' . $this->plan->instructor)
                    ->line('🕒 Başlangıç: ' . $this->plan->start_date->format('d.m.Y H:i'))
                    ->line('📍 Konum/Link: ' . $this->plan->location)
                    ->line('-------------------------------------------------------')
                    ->action('Eğitim Detaylarını İncele', route('admin.qms.plans.show', $this->plan->id))
                    ->line('Eğitim saatinde hazır bulunmanızı rica ederiz.');
    }

    // 4. Panel Bildirimi (Zil İkonu İçin)
    public function toArray($notifiable)
    {
        return [
            'title' => 'Yeni Eğitim: ' . $this->plan->training->code,
            'message' => $this->plan->training->title . ' eğitimi size atandı.',
            'url' => route('admin.qms.plans.show', $this->plan->id),
            'icon' => 'fas fa-graduation-cap', // İkonumuz
            'color' => 'success' // Renk
        ];
    }
}