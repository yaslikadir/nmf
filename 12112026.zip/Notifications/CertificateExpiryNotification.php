<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\TrainingRecord;

class CertificateExpiryNotification extends Notification
{
    use Queueable;

    protected $record;
    protected $daysLeft;

    public function __construct(TrainingRecord $record, $daysLeft)
    {
        $this->record = $record;
        $this->daysLeft = $daysLeft;
    }

    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    public function toMail($notifiable)
    {
        $trainingTitle = $this->record->plan->training->title;
        $expiryDate = $this->record->updated_at->addMonths($this->record->plan->training->validity_months)->format('d.m.Y');

        return (new MailMessage)
                    ->subject('⚠️ Dikkat: Sertifika Süreniz Dolmak Üzere! (' . $this->daysLeft . ' Gün Kaldı)')
                    ->greeting('Merhaba ' . $notifiable->name . ',')
                    ->line('Aşağıdaki eğitim için aldığınız sertifikanın geçerlilik süresi dolmak üzeredir.')
                    ->line('-------------------------------------------------------')
                    ->line('📜 Sertifika: ' . $trainingTitle)
                    ->line('⏳ Bitiş Tarihi: ' . $expiryDate)
                    ->line('🔻 Kalan Süre: ' . $this->daysLeft . ' Gün')
                    ->line('-------------------------------------------------------')
                    ->line('Yetkinliğinizin devamı için lütfen Eğitim Talep ekranından yenileme eğitimi talep ediniz.')
                    ->action('Eğitim Talep Et', route('admin.qms.my-trainings.index'));
    }

    public function toArray($notifiable)
    {
        return [
            'title' => 'Sertifika Uyarısı',
            'message' => $this->record->plan->training->title . ' sertifikanızın süresi ' . $this->daysLeft . ' gün içinde dolacak.',
            'url' => route('admin.qms.my-trainings.index'),
            'icon' => 'fas fa-exclamation-triangle',
            'color' => 'danger'
        ];
    }
}