<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ComplaintResolvedNotification extends Notification
{
    use Queueable;

    protected $feedback;

    public function __construct($feedback)
    {
        $this->feedback = $feedback;
    }

    public function via($notifiable)
    {
        return ['mail']; // Sadece mail yeterli (Müşteri sisteme kayıtlı olmayabilir)
    }

    public function toMail($notifiable)
    {
        // Anket Linki: /form/genel-memnuniyet
        $surveyUrl = route('public.feedback.show', 'genel-memnuniyet');

        return (new MailMessage)
                    ->subject('✅ Şikayetiniz Çözümlendi: ' . $this->feedback->tracking_code)
                    ->greeting('Sayın ' . ($this->feedback->guest_name ?? 'Müşterimiz') . ',')
                    ->line($this->feedback->tracking_code . ' referans numaralı bildiriminiz tarafımızca incelenmiş ve çözüme kavuşturulmuştur.')
                    ->line('Süreçle ilgili detaylı bilgiye, size iletilen takip kodu ile web sitemizden ulaşabilirsiniz.')
                    ->line('-------------------------------------------------------')
                    ->line('Hizmet kalitemizi artırmak için süreci değerlendirmeniz bizim için çok önemli.')
                    ->action('Memnuniyet Anketini Doldur', $surveyUrl)
                    ->line('Bizi tercih ettiğiniz için teşekkür ederiz.');
    }
}