<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\EmergencyPlan;

class EmergencyTeamAssignedNotification extends Notification
{
    use Queueable;

    protected $plan;

    public function __construct(EmergencyPlan $plan)
    {
        $this->plan = $plan;
    }

    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject('🚨 Acil Durum Görevi Ataması: ' . $this->plan->title)
                    ->greeting('Merhaba ' . $notifiable->name . ',')
                    ->line('Kurumumuzun Acil Durum Yönetim Sistemi kapsamında bir acil müdahale ekibine atandınız.')
                    ->line('-------------------------------------------------------')
                    ->line('📋 Plan Adı: ' . $this->plan->title)
                    ->line('🔥 Senaryo: ' . $this->plan->scenario)
                    ->line('-------------------------------------------------------')
                    ->action('Planı ve Görevini İncele', route('admin.qms.emergency-plans.show', $this->plan->id))
                    ->line('Lütfen acil durum prosedürünü dikkatlice okuyunuz.');
    }

    public function toArray($notifiable)
    {
        return [
            'title' => 'Acil Durum Görevi',
            'message' => $this->plan->title . ' planında görevlendirildiniz.',
            'url' => route('admin.qms.emergency-plans.show', $this->plan->id),
            'icon' => 'fas fa-first-aid',
            'color' => 'danger'
        ];
    }
}