<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue; // Arka planda çalışması için
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\MeasurementPlan;

class NewMeasurementPlanAssignedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $plan;

    // 1. Plan verisini içeri alalım
    public function __construct(MeasurementPlan $plan)
    {
        $this->plan = $plan;
    }

    // 2. Hangi kanallardan gidecek? (Mail + Veritabanı)
    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    // 3. E-Posta Tasarımı
    public function toMail($notifiable)
    {
        $customerName = $this->plan->offer->customer->company_name ?? $this->plan->offer->customer->name ?? 'Bilinmeyen Müşteri';
        $city = $this->plan->offer->customer->city ?? '-';

        return (new MailMessage)
                    ->subject('📋 Yeni Saha / Ölçüm Görevi: ' . $this->plan->plan_code)
                    ->greeting('Merhaba ' . $notifiable->name . ',')
                    ->line('Size yeni bir numune alma / saha ölçüm görevi atanmıştır.')
                    ->line('-------------------------------------------------------')
                    ->line('📌 Plan Kodu: **' . $this->plan->plan_code . '**')
                    ->line('🏢 Müşteri: **' . $customerName . '**')
                    ->line('📍 Şehir / Konum: **' . $city . '**')
                    ->line('📅 Planlanan Tarihler: **' . \Carbon\Carbon::parse($this->plan->start_date)->format('d.m.Y') . ' - ' . \Carbon\Carbon::parse($this->plan->end_date)->format('d.m.Y') . '**')
                    ->line('-------------------------------------------------------')
                    ->action('Görevi ve Detayları Görüntüle', route('admin.planning.show', $this->plan->id))
                    ->line('Lütfen saha görevine gitmeden önce gerekli numune kaplarını ve cihazlarınızı hazırlayınız. İyi çalışmalar dileriz.');
    }

    // 4. Panel Bildirimi (Sistemdeki Zil İkonu İçin)
    public function toArray($notifiable)
    {
        $customerName = $this->plan->offer->customer->company_name ?? $this->plan->offer->customer->name ?? '-';

        return [
            'title' => 'Yeni Görev: ' . $this->plan->plan_code,
            'message' => $customerName . ' firması için saha/ölçüm görevine atandınız.',
            'url' => route('admin.planning.show', $this->plan->id),
            'icon' => 'fas fa-clipboard-list', // Pano/Görev ikonu
            'color' => 'primary' // Mavi renk
        ];
    }
}