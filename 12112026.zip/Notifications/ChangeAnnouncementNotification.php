<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ChangeAnnouncementNotification extends Notification
{
    use Queueable;

    protected $change;
    protected $customMessage;
    protected $senderName;

    public function __construct($change, $customMessage, $senderName)
    {
        $this->change = $change;
        $this->customMessage = $customMessage;
        $this->senderName = $senderName;
    }

    public function via($notifiable)
    {
        return ['mail', 'database']; // Hem Mail hem Çan Bildirimi
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject('⚠️ DEĞİŞİKLİK DUYURUSU: ' . $this->change->code)
                    ->greeting('Sayın ' . $notifiable->name . ',')
                    ->line('Sistemde onaylanan ve yürürlüğe giren bir değişiklik hakkında bilgilendirme:')
                    ->line('--------------------------------------------------')
                    ->line('📢 DUYURU MESAJI:')
                    ->line($this->customMessage)
                    ->line('--------------------------------------------------')
                    ->action('Değişiklik Detayını İncele (' . $this->change->code . ')', route('admin.qms.changes.show', $this->change->id))
                    ->line('🔹 Değişiklik Konusu: ' . $this->change->title)
                    ->line('🔹 İlgili Birim: ' . ($this->change->department->name ?? 'Genel'))
                    ->action('Değişiklik Detayını İncele', route('admin.qms.changes.show', $this->change->id))
                    ->line('Bilgilerinize sunarız.')
                    ->salutation($this->senderName);
    }

    public function toArray($notifiable)
    {
        return [
            'title' => 'Değişiklik Duyurusu: ' . $this->change->code,
            'message' => 'Yürürlüğe giren değişiklik: ' . $this->change->title,
            'url' => route('admin.qms.changes.show', $this->change->id),
            'icon' => 'fas fa-bullhorn', // Duyuru ikonu
            'color' => 'info'
        ];
    }
}