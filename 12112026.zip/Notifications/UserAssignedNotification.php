<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class UserAssignedNotification extends Notification
{
    use Queueable;

    protected $details;

    // Bildirime gelecek veriler: ['title' => 'DÖF Atandı', 'message' => '...', 'url' => '...']
    public function __construct($details)
    {
        $this->details = $details;
    }

    public function via($notifiable)
    {
        // Hem Veritabanı (Çan) hem Mail
        return ['database', 'mail'];
    }

    // 1. MAIL GÖNDERİMİ
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject($this->details['title'] . ' - ' . config('app.name'))
                    ->greeting('Merhaba ' . $notifiable->name . ',')
                    ->line($this->details['message'])
                    ->action('Görevi Görüntüle', $this->details['url'])
                    ->line('İyi çalışmalar dileriz.');
    }

    // 2. VERİTABANI (ÇAN) KAYDI
    public function toArray($notifiable)
    {
        return [
            'title' => $this->details['title'],
            'message' => $this->details['message'],
            'url' => $this->details['url'],
            'icon' => 'fas fa-tasks', // İkon tipi
            'color' => 'primary' // Renk
        ];
    }
}