<?php

namespace App\Observers;

use App\Models\Risk;
use App\Models\RiskHistory;
use Illuminate\Support\Facades\Auth;

class RiskObserver
{
    /**
     * Risk ilk oluşturulduğunda çalışır.
     */
    public function created(Risk $risk)
    {
        RiskHistory::create([
            'risk_id' => $risk->id,
            'user_id' => Auth::id(),
            'action'  => 'Oluşturuldu',
            'changes' => null,
            'comment' => 'Risk kaydı sisteme girildi.'
        ]);
    }

    /**
     * Risk güncellendiğinde çalışır.
     */
    public function updated(Risk $risk)
    {
        // Hangi alanlar değişti? (updated_at hariç)
        $dirty = $risk->getDirty();
        $changes = [];

        // Takip etmek istemediğimiz alanları çıkaralım
        unset($dirty['updated_at']); 

        foreach ($dirty as $field => $newValue) {
            $oldValue = $risk->getOriginal($field);
            
            // Sadece önemli değişiklikleri al (Olasılık, Şiddet, Durum vb.)
            if ($oldValue != $newValue) {
                // Alan isimlerini Türkçeleştirelim (İsteğe bağlı)
                $fieldNameTR = $this->translateField($field);
                
                $changes[] = [
                    'field' => $fieldNameTR,
                    'old'   => $oldValue,
                    'new'   => $newValue
                ];
            }
        }

        if (!empty($changes)) {
            RiskHistory::create([
                'risk_id' => $risk->id,
                'user_id' => Auth::id(),
                'action'  => 'Güncellendi',
                'changes' => $changes,
                'comment' => 'Risk parametrelerinde değişiklik yapıldı.'
            ]);
        }
    }

    private function translateField($field) {
        $map = [
            'probability' => 'Olasılık',
            'impact'      => 'Şiddet / Etki',
            'risk_score'  => 'Risk Skoru',
            'status'      => 'Durum',
            'title'       => 'Başlık',
            'description' => 'Açıklama',
            // Diğer alanlar...
        ];
        return $map[$field] ?? $field;
    }
}