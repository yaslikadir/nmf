<?php

namespace App\Imports;

use App\Models\Customer;
use App\Models\Contact;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Auth;

class CustomerImport implements ToCollection, WithHeadingRow
{
    private $currentNumber = 0;

    public function __construct()
    {
        // Import başlamadan önce son müşteri numarasını hafızaya al
        $lastCustomer = Customer::withoutGlobalScopes()->orderBy('id', 'desc')->first();

        if ($lastCustomer && preg_match('/(\d+)/', $lastCustomer->customer_code, $matches)) {
            $this->currentNumber = intval($matches[0]);
        }
    }

    /**
     * @param Collection $rows
     */
    public function collection(Collection $rows)
    {
        $userId = Auth::id(); // Auth::id()'yi döngü dışında bir kez almak performansı artırır

        foreach ($rows as $row) {
            // Müşteri adı boşsa bu satırı tamamen atla (Boş satırları engeller)
            if (empty($row['musteri_adi'])) {
                continue;
            }

            // ---------------------------------------------------
            // 1. AŞAMA: MÜŞTERİYİ BUL VEYA YENİ OLUŞTUR
            // ---------------------------------------------------
            $customer = Customer::withoutGlobalScopes()
                ->where('name', $row['musteri_adi'])
                ->first();

            // Eğer müşteri sistemde yoksa yeni oluştur
            if (!$customer) {
                $this->currentNumber++;
                $customerCode = 'MST-' . str_pad($this->currentNumber, 4, '0', STR_PAD_LEFT);

                // Çakışma önleyici güvenlik döngüsü
                while (Customer::withoutGlobalScopes()->where('customer_code', $customerCode)->exists()) {
                    $this->currentNumber++;
                    $customerCode = 'MST-' . str_pad($this->currentNumber, 4, '0', STR_PAD_LEFT);
                }

                $customer = Customer::create([
                    'customer_code'  => $customerCode,
                    'name'           => $row['musteri_adi'],
                    'official_title' => $row['firma_unvani'] ?? null,
                    'customer_type'  => $row['musteri_tipi'] ?? null,
                    'category'       => $row['kategori'] ?? null,
                    'sector'         => $row['sektor'] ?? null,
                    'description'    => $row['aciklama'] ?? null,
                    'phone1'         => $row['telefon'] ?? null,
                    'email'          => $row['email'] ?? null,
                    'city'           => $row['sehir'] ?? null,
                    'address1'       => $row['adres'] ?? null,
                    'tax_office'     => $row['vergi_dairesi'] ?? null,
                    'tax_number'     => $row['vergi_numarasi'] ?? null,
                    'linkedin'       => $row['linkedin'] ?? null,
                    'created_by'     => $userId,
                    'is_active'      => true,
                ]);
            }

            // ---------------------------------------------------
            // 2. AŞAMA: KONTAĞI OLUŞTUR VE MÜŞTERİYE BAĞLA
            // ---------------------------------------------------
            // Excel'de "Kontak Adı" sütunu doluysa işleme al
            if (!empty($row['kontak_adi'])) {
                
                // Müşterinin içinde bu isimde bir kontak zaten var mı kontrol et 
                // (Mükerrer kaydı önlemek için Global Scope'u atlayarak kontrol ediyoruz)
                $contactExists = Contact::withoutGlobalScopes()
                                        ->where('customer_id', $customer->id)
                                        ->where('full_name', $row['kontak_adi'])
                                        ->exists();

                if (!$contactExists) {
                    Contact::create([
                        'customer_id'  => $customer->id, // Müşteri ile bağlantı sağlandı!
                        'full_name'    => $row['kontak_adi'],
                        'title'        => $row['kontak_unvani'] ?? null,
                        'department'   => $row['kontak_departmani'] ?? null,
                        'work_phone'   => $row['kontak_is_telefonu'] ?? null,
                        'mobile_phone' => $row['kontak_gsm'] ?? null,
                        'email'        => $row['kontak_email'] ?? null,
                        'created_by'   => $userId,
                        'is_active'    => true,
                    ]);
                }
            }
        }
    }
}