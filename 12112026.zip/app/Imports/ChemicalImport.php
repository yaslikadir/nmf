<?php

namespace App\Imports;

use App\Models\Material;
use App\Models\InventoryCategory;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Carbon\Carbon;

class ChemicalImport implements ToModel, WithHeadingRow
{
    private $categoryId;
    private $currentSequence;
    private $year;
    private $prefix = 'STK-';

    public function __construct()
    {
        // 1. Kimyasal kategorisinin ID'sini bulalım
        $category = InventoryCategory::where('slug', 'kimyasal')->first();
        $this->categoryId = $category ? $category->id : null;
        
        // 2. Stok Kodu (SKU) sayacını ayarlayalım (Kayıtlar üst üste binmesin diye)
        $this->year = date('Y');
        $lastMaterial = Material::whereYear('created_at', $this->year)
            ->where('sku', 'like', $this->prefix . '%')
            ->latest('id')
            ->first();

        $this->currentSequence = $lastMaterial ? (int) substr($lastMaterial->sku, -4) : 0;
    }

    public function model(array $row)
    {
        // Excel'de "tam_adi" sütunu boşsa o satırı atla
        if (!isset($row['tam_adi']) || empty($row['tam_adi'])) {
            return null;
        }

        // Kategori bulunamadıysa patlamasın diye kontrol (Eğer yoksa kaydetme)
        if (!$this->categoryId) {
            return null; 
        }

        // Yeni Stok Kodunu Üret
        $this->currentSequence++;
        $sku = $this->prefix . $this->year . '-' . str_pad($this->currentSequence, 4, '0', STR_PAD_LEFT);

        // Excel'den gelen tarihi düzgün formata çevir (Bazen 44123 gibi sayı gelir)
        $expiryDate = null;
        if (isset($row['son_kullanma_tarihi'])) {
            if (is_numeric($row['son_kullanma_tarihi'])) {
                $expiryDate = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['son_kullanma_tarihi']);
            } else {
                try {
                    $expiryDate = Carbon::parse($row['son_kullanma_tarihi']);
                } catch (\Exception $e) {
                    $expiryDate = null;
                }
            }
        }

        return new Material([
            'category_id'       => $this->categoryId,
            'sku'               => $sku, // Otomatik Üretildi
            'name'              => $row['tam_adi'],
            'cas_no'            => $row['cas_no'] ?? null,
            'manufacturer'      => $row['uretici_firma'] ?? null,
            'lot_no'            => $row['lot_no'] ?? null,
            'storage_condition' => $row['saklama_kosulu'] ?? null,
            'shelf_no'          => $row['raf_no'] ?? null,
            'expiry_date'       => $expiryDate,
            'is_active'         => true,
        ]);
    }
}