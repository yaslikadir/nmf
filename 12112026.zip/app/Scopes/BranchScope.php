<?php

namespace App\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;

class BranchScope implements Scope
{
    /**
     * Tüm Eloquent sorgularına otomatik olarak şube filtresini uygular.
     */
    public function apply(Builder $builder, Model $model)
    {
        // Eğer session'da aktif bir şube varsa filtreyi uygula
        if (session()->has('active_branch_id')) {
            // Tablo adını alarak ('customers.branch_id' gibi) çakışmaları önlüyoruz
            $builder->where($model->getTable() . '.branch_id', session('active_branch_id'));
        }
    }
}