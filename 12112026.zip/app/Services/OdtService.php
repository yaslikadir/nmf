<?php

namespace App\Services;

use ZipArchive;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class OdtService
{
    protected $zip;
    protected $tempPath;
    protected $xmlContent;

    public function __construct($templatePath)
    {
        $originalFullPath = Storage::path($templatePath);

        if (!File::exists($originalFullPath)) {
            throw new \Exception("Şablon dosyası bulunamadı: " . $originalFullPath);
        }

        $tempDir = storage_path('app/temp');
        if (!File::exists($tempDir)) {
            File::makeDirectory($tempDir, 0755, true);
        }

        $this->tempPath = $tempDir . '/temp_' . uniqid() . '.odt';
        File::copy($originalFullPath, $this->tempPath);

        $this->zip = new ZipArchive;
        if ($this->zip->open($this->tempPath) === TRUE) {
            $this->xmlContent = $this->zip->getFromName('content.xml');
        } else {
            throw new \Exception("ODT dosyası açılamadı.");
        }
    }

    public function setVar($key, $value)
    {
        $safeValue = htmlspecialchars($value ?? '', ENT_XML1, 'UTF-8');
        $safeValue = str_replace("\n", '<text:line-break/>', $safeValue);
        $this->xmlContent = str_replace('{' . $key . '}', $safeValue, $this->xmlContent);
    }

    /**
     * GÜNCELLENMİŞ VERSİYON: Tablo satırlarını hatasız çoğaltır.
     */
    public function setRows(array $list, array $mapping)
    {
        if (empty($list) || empty($mapping)) {
            return;
        }

        // 1. Referans alınacak değişkenin belgedeki konumunu bul
        $searchKey = array_key_first($mapping); // Örn: {urun_adi}
        $pos = strpos($this->xmlContent, $searchKey);

        if ($pos === false) {
            return; // Değişken şablonda bulunamadıysa işlem yapma
        }

        // 2. Bu değişkenin içinde olduğu satırın başlangıcını (geriye doğru) bul
        // <table:table-row ... > etiketini arıyoruz
        $startPos = strrpos(substr($this->xmlContent, 0, $pos), '<table:table-row');
        
        // 3. Satırın bitişini (ileriye doğru) bul
        // </table:table-row> etiketini arıyoruz
        $endPos = strpos($this->xmlContent, '</table:table-row>', $pos);

        if ($startPos !== false && $endPos !== false) {
            // Tam bitiş etiketinin uzunluğunu da ekleyerek satırı komple al
            $endTagLength = strlen('</table:table-row>');
            $length = ($endPos + $endTagLength) - $startPos;
            
            // İşte kopyalanacak şablon satırımız:
            $templateRow = substr($this->xmlContent, $startPos, $length);
            
            $newRowsXml = '';

            // 4. Döngüyle satırları oluştur
            foreach ($list as $item) {
                $currentRow = $templateRow;

                foreach ($mapping as $placeholder => $dataKey) {
                    $value = is_array($item) ? ($item[$dataKey] ?? '') : ($item->$dataKey ?? '');
                    $safeValue = htmlspecialchars($value, ENT_XML1, 'UTF-8');
                    $currentRow = str_replace($placeholder, $safeValue, $currentRow);
                }
                
                $newRowsXml .= $currentRow;
            }

            // 5. Orijinal satırı sil, yerine yenilerini koy
            $this->xmlContent = str_replace($templateRow, $newRowsXml, $this->xmlContent);
        }
    }

    /**
     * DÜZELTİLEN ALAN: Senin ZipArchive altyapına uygun resim ekleme (Injection) mantığı
     */
    public function setImage($variable, $path)
    {
        if (!file_exists($path)) {
            $this->setVar($variable, ''); // Dosya yoksa değişkeni temizle
            return;
        }

        // 1. Resmi zip dosyasının içine 'Pictures' klasörüne ekliyoruz
        $extension = pathinfo($path, PATHINFO_EXTENSION);
        $imageName = 'Pictures/sig_' . uniqid() . '.' . $extension;
        $this->zip->addFile($path, $imageName);

        // 2. ODT standartları gereği yeni dosyayı manifest'e bildirmeliyiz
        $manifestContent = $this->zip->getFromName('META-INF/manifest.xml');
        if ($manifestContent) {
            $mimeType = mime_content_type($path) ?: 'image/jpeg';
            $manifestEntry = '<manifest:file-entry manifest:full-path="'.$imageName.'" manifest:media-type="'.$mimeType.'"/>';
            $manifestContent = str_replace('</manifest:manifest>', $manifestEntry . '</manifest:manifest>', $manifestContent);
            $this->zip->addFromString('META-INF/manifest.xml', $manifestContent);
        }

        // 3. content.xml içinde {personel_imza} metnini XML resim objesiyle değiştiriyoruz
        // width ve height değerlerini imzanın boyutuna göre değiştirebilirsin (Şu an 4cm x 2cm)
        $xmlImageTag = '<draw:frame text:anchor-type="as-char" svg:width="4cm" svg:height="2cm" draw:z-index="0"><draw:image xlink:href="'.$imageName.'" xlink:type="simple" xlink:show="embed" xlink:actuate="onLoad"/></draw:frame>';
        
        $this->xmlContent = str_replace('{' . $variable . '}', $xmlImageTag, $this->xmlContent);
    }

    public function save()
    {
        $this->zip->addFromString('content.xml', $this->xmlContent);
        $this->zip->close();
        return $this->tempPath;
    }
}