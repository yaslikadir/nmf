<?php

namespace App\Services;

use App\Models\QmsDocument;
use App\Models\QmsDocumentVersion;
use App\Models\QmsDocumentLog;
use App\Models\QmsDocumentFolder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Auth;

class QmsDocumentService
{
    public function createDocument(array $data, $file)
    {
        return DB::transaction(function () use ($data, $file) {
            
            if (!empty($data['document_code'])) {
                $uniqueCode = $data['document_code'];
            } else {
                $folder = QmsDocumentFolder::find($data['folder_id']);
                $codePrefix = $folder->code_prefix ?? 'DOC';
                $uniqueCode = $this->generateDocumentCode($codePrefix);
            }

            $document = QmsDocument::create([
                'document_code'          => $uniqueCode,
                'name'                   => $data['name'],
                'folder_id'              => $data['folder_id'],
                'security_level'         => $data['security_level'],
                'owner_id'               => Auth::id(),
                'status'                 => 'Draft',
                'retention_period_years' => $data['retention_period_years'] ?? 5,
            ]);

            $this->createVersion($document->id, $file, '0.1', 'İlk Oluşturma', $data['approvers'] ?? []);

            $this->logAction($document->id, 'CREATE', 'Doküman oluşturuldu. Kod: ' . $uniqueCode);

            return $document;
        });
    }

    public function createVersion($documentId, $file, $versionNo, $reason, array $approvers)
    {
        $path = $file->store('qms_documents/' . date('Y'), 'local'); 

        $version = QmsDocumentVersion::create([
            'document_id' => $documentId,
            'version_no' => $versionNo,
            'file_path' => $path,
            'file_hash' => md5_file($file->getRealPath()), 
            'revision_reason' => $reason,
            'created_by' => Auth::id(),
            'is_current' => false, 
        ]);

        // Onaycıları Kaydet
        foreach ($approvers as $index => $userId) {
            $version->approvals()->create([
                'user_id' => $userId,
                'order' => $index + 1,
                'status' => 'Pending'
            ]);
        }

        // ONAYCILARA MAİL VE ÇAN BİLDİRİMİ GÖNDER!
        if (count($approvers) > 0) {
            $users = \App\Models\User::whereIn('id', $approvers)->get();
            \Illuminate\Support\Facades\Notification::send(
                $users, 
                new \App\Notifications\DocumentApprovalPendingNotification($version->document, $version)
            );
        }

        return $version;
    }

    public function approveVersion($versionId, $comments = null)
    {
        $version = QmsDocumentVersion::findOrFail($versionId);
        $userId = Auth::id();

        $approval = $version->approvals()
                            ->where('user_id', $userId)
                            ->where('status', 'Pending')
                            ->orderBy('order')
                            ->first();

        if (!$approval) {
            throw new \Exception("Onay sırası sizde değil veya yetkiniz yok.");
        }

        $approval->update([
            'status' => 'Approved',
            'action_date' => now(),
            'comments' => $comments
        ]);

        $this->logAction($version->document_id, 'APPROVE', "Rev{$version->version_no} kullanıcı tarafından onaylandı.");

        if ($version->approvals()->where('status', 'Pending')->count() == 0) {
            $this->publishVersion($version->id);
        }

        return true;
    }

    protected function publishVersion($versionId)
    {
        return DB::transaction(function () use ($versionId) {
            $newVersion = QmsDocumentVersion::with('document')->findOrFail($versionId);
            $document = $newVersion->document;

            QmsDocumentVersion::where('document_id', $document->id)
                ->where('status', 'Published')
                ->update(['status' => 'Obsolete', 'is_current' => false]);

            $newVersion->update([
                'status' => 'Published',
                'is_current' => true,
                'approved_by' => Auth::id(),
                'published_at' => now(),
                'valid_from' => now(),
            ]);

            $document->update(['status' => 'Published']);

            $this->logAction($document->id, 'PUBLISH', "Rev{$newVersion->version_no} yayınlandı.");
        });
    }

    /**
     * DÜZELTİLDİ: Kurşun Geçirmez Numara Üretici
     */
    protected function generateDocumentCode($prefix)
    {
        $year = date('Y');
        $pattern = "$prefix-$year-";

        // İlgili yıla ait tüm kodları çek
        $docs = QmsDocument::withTrashed()
                    ->where('document_code', 'like', $pattern . '%')
                    ->lockForUpdate() 
                    ->get(['document_code']);
        
        $maxNum = 0;

        foreach ($docs as $doc) {
            $parts = explode('-', $doc->document_code);
            $lastPart = end($parts);

            // Sadece son kısmı tamamen RAKAM olanları (001, 002) değerlendir.
            // A8X2 gibi harfli kılıfları pas geç!
            if (is_numeric($lastPart)) {
                $num = (int) $lastPart;
                if ($num > $maxNum) {
                    $maxNum = $num;
                }
            }
        }

        // Bulunan en büyük sayının 1 fazlasını 3 haneli olarak yaz (Örn: 005)
        $newNum = str_pad($maxNum + 1, 3, '0', STR_PAD_LEFT);

        return "$prefix-$year-$newNum";
    }

    public function logAction($docId, $action, $details = null)
    {
        QmsDocumentLog::create([
            'document_id' => $docId,
            'user_id' => Auth::id(),
            'action' => $action,
            'details' => $details,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent()
        ]);
    }
}