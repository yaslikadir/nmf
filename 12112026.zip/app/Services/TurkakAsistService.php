<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class TurkakAsistService
{
    protected $baseUrl = 'https://api.turkak.org.tr';
    protected $token;
    
    // Senin CSV'den çıkan File ID
    protected $fileId = '848bf5cb-6404-4249-ef29-08dd39ef4fb1'; 

    public function __construct()
    {
        // Önce Veritabanına bak, yoksa .env dosyasına bak
        $dbToken = \App\Models\Setting::where('key', 'turkak_asist_token')->value('value');
        
        $this->token = $dbToken ?: env('TURKAK_ASIST_TOKEN');
    }
    // Ortak GET isteği
    protected function get($endpoint, $params = [])
    {
        $response = Http::withToken($this->token)
            ->withHeaders([
                'Accept' => 'application/json',
                'Origin' => 'https://asist.turkak.org.tr', // CORS hatası yememek için
            ])
            ->timeout(30)
            ->get($this->baseUrl . $endpoint, $params);

        if ($response->failed()) {
            throw new \Exception("API Hatası (" . $response->status() . "): " . $response->body());
        }

        return $response->json();
    }

    /**
     * Kullanıcı Bilgisi (Token Kontrolü İçin)
     * CSV 1 - Satır 2'den alındı
     */
    public function getUserInfo()
    {
        return $this->get('/Account/GetUserInfo');
    }

    /**
     * Belirli bir kategorideki dokümanları getirir
     * CSV 2 - Satır 2,3,4'ten alındı
     * Örn: T17, T18, T19
     */
    public function getDocumentsByCategory($categoryCode = 'T17')
    {
        // URL: /Resources/api/v1/Document/getDocsByEntity/{FileID}?prm=T17&uplr=true
        $endpoint = "/Resources/api/v1/Document/getDocsByEntity/{$this->fileId}";
        
        return $this->get($endpoint, [
            'prm' => $categoryCode,
            'uplr' => 'true' // Uploaded: true (Yüklenmiş olanlar)
        ]);
    }
}