<?php

namespace App\Services;

class EmissionReportService
{
    /**
     * VOC Kimyasal Kütüphanesi (Excel'deki VOC Hamveri Sayfası)
     * Alt parametre adını buradan bulup formüle otomatik katar.
     */
    protected $vocLibrary = [
        'benzen'       => ['class' => '1. Sınıf', 'mol_weight' => 78.11, 'carbon_weight' => 72.0],
        'aseton'       => ['class' => '3. Sınıf', 'mol_weight' => 58.08, 'carbon_weight' => 36.0],
        'etilbenzen'   => ['class' => '2. Sınıf', 'mol_weight' => 106.16, 'carbon_weight' => 96.0],
        'toluen'       => ['class' => '2. Sınıf', 'mol_weight' => 92.14, 'carbon_weight' => 84.0],
        'ksilen'       => ['class' => '2. Sınıf', 'mol_weight' => 106.16, 'carbon_weight' => 96.0],
        'diklorometan' => ['class' => '3. Sınıf', 'mol_weight' => 84.93, 'carbon_weight' => 12.0],
        'etanol'       => ['class' => '3. Sınıf', 'mol_weight' => 46.07, 'carbon_weight' => 24.0],
    ];

    public function calculateVocMetrics(?string $jsonResult, float $dryFlowRateNm3h)
    {
        // 1. Veriyi JSON'dan çöz
        $data = json_decode($jsonResult, true);
        
        // 2. YENİ GÜVENLİK ZIRHI: Eğer dönen değer bir dizi (array) değilse (Örn: senin yazdığın "1" ise)
        // sistemi çökertmek yerine $data'yı boş bir diziye eşitle.
        if (!is_array($data)) {
            $data = [];
        }
        
        $calculatedItems = [];
        $totalsByClass = [
            '1. Sınıf' => ['concentration' => 0, 'mass_flow' => 0, 'carbon_flow' => 0],
            '2. Sınıf' => ['concentration' => 0, 'mass_flow' => 0, 'carbon_flow' => 0],
            '3. Sınıf' => ['concentration' => 0, 'mass_flow' => 0, 'carbon_flow' => 0],
            'Toplam'   => ['concentration' => 0, 'mass_flow' => 0, 'carbon_flow' => 0],
        ];

        foreach ($data as $row) {
            $name = $row['name'] ?? ($row['code'] ?? 'Bilinmeyen Madde');
            
            // Eğer analist M1, M2 veya M3'e hiçbir şey girmemişse atla
if (!isset($row['m1']) || ($row['m1'] === '' && $row['m2'] === '' && $row['m3'] === '')) {
    continue;
}

$searchName = mb_strtolower(trim($name), 'UTF-8');
$chemicalProps = $this->vocLibrary[$searchName] ?? [
    'class' => '3. Sınıf', 'mol_weight' => 1.0, 'carbon_weight' => 1.0
];

// YENİ: Değerleri doğrudan M1, M2, M3 olarak çek (Küsürat için virgülü noktaya çevirerek)
$val1 = (float) str_replace(',', '.', ($row['m1'] ?: '0'));
$val2 = (float) str_replace(',', '.', ($row['m2'] ?: '0'));
$val3 = (float) str_replace(',', '.', ($row['m3'] ?: '0'));

// Excel Formülü (3'ünün ortalamasını alır)
$concentration = ($val1 + $val2 + $val3) / 3; 

$massFlow = ($concentration * $dryFlowRateNm3h) / 1000000;
$carbonFlow = $massFlow * ($chemicalProps['carbon_weight'] / $chemicalProps['mol_weight']);
$class = $chemicalProps['class'];

$calculatedItems[] = [
    'name'           => $name,
    'class'          => $class,
    'measurements'   => ['m1' => $val1, 'm2' => $val2, 'm3' => $val3],
    'concentration'  => $concentration,
    'mass_flow'      => $massFlow,
    'carbon_flow'    => $carbonFlow
];

            if (array_key_exists($class, $totalsByClass)) {
                $totalsByClass[$class]['concentration'] += $concentration;
                $totalsByClass[$class]['mass_flow'] += $massFlow;
                $totalsByClass[$class]['carbon_flow'] += $carbonFlow;
            }

            $totalsByClass['Toplam']['concentration'] += $concentration;
            $totalsByClass['Toplam']['mass_flow'] += $massFlow;
            $totalsByClass['Toplam']['carbon_flow'] += $carbonFlow;
        }

        return [
            'items'   => $calculatedItems,
            'summary' => $totalsByClass
        ];
    }
}