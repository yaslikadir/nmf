<?php

namespace App\Services;

use CURLFile;
use Exception;

class Pdf24Merger
{
    private string $baseUrl = 'https://filetools.pdf24.org/client.php';
    
    /**
     * PDF dosyalarını birleştirir
     * * @param array $pdfPaths Birleştirilecek PDF dosya yolları (Tam yol)
     * @param string $outputPath Çıktı dosyası yolu (Tam yol)
     * @return array ['success' => bool, 'message' => string]
     */
    public function merge(array $pdfPaths, string $outputPath): array
    {
        try {
            // 1. Dosyaları yükle ve job oluştur
            $jobId = $this->uploadAndCreateJob($pdfPaths);
            
            if (!$jobId) {
                return ['success' => false, 'message' => 'Dosyalar PDF24 sunucusuna yüklenemedi.'];
            }
            
            // 2. İşlem tamamlanana kadar bekle
            $resultUrl = $this->waitForCompletion($jobId);
            
            if (!$resultUrl) {
                return ['success' => false, 'message' => 'Birleştirme işlemi zaman aşımına uğradı.'];
            }
            
            // 3. Sonucu indir
            $downloaded = $this->downloadFile($resultUrl, $outputPath);
            
            if ($downloaded) {
                return ['success' => true, 'message' => 'PDF başarıyla birleştirildi.'];
            }
            
            return ['success' => false, 'message' => 'Birleştirilen dosya indirilemedi.'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Hata: ' . $e->getMessage()];
        }
    }
    
    private function uploadAndCreateJob(array $pdfPaths): ?string
    {
        $postFields = [
            'action' => 'joinPdf'
        ];
        
        // Dosyaları ekle
        foreach ($pdfPaths as $index => $path) {
            if (!file_exists($path)) {
                throw new Exception("Dosya bulunamadı: {$path}");
            }
            // CURLFile kullanımı
            $postFields["file[{$index}]"] = new CURLFile(
                realpath($path),
                'application/pdf', // PDF24 genelde PDF bekler ama resim de atılabilir
                basename($path)
            );
        }
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->baseUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postFields,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_SSL_VERIFYPEER => false // SSL hatası almamak için (gerekirse true yapın)
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200 || !$response) {
            return null;
        }
        
        $data = json_decode($response, true);
        
        return $data['jobId'] ?? null;
    }
    
    private function waitForCompletion(string $jobId, int $maxAttempts = 60): ?string
    {
        $attempt = 0;
        
        while ($attempt < $maxAttempts) {
            $status = $this->checkStatus($jobId);
            
            if ($status === null) {
                return null;
            }
            
            if (isset($status['status']) && $status['status'] === 'done') {
                // job['output'] indirme linkini verir
                // Bazen tam URL, bazen relative gelir, kontrol etmek lazım ama PDF24 genelde tam URL verir mi?
                // API dökümanına göre bazen base url eklemek gerekebilir ama client.php genelde path döner.
                // Biz gelen veriyi olduğu gibi alalım, download kısmında bakarız.
                $url = $status['job']['url'] ?? null; // 'output' yerine 'url' olabilir, response'a dikkat.
                // Standart PDF24 yanıtında indirme linki genellikle job objesi içindedir.
                
                // NOT: PDF24 yapısında genelde status 'done' olduğunda indirme linki oluşturulur.
                // Dönen JSON'u debug etmek gerekebilir ama standart yapı şöyledir:
                // https://filetools.pdf24.org/client.php?action=download&jobId=...
                
                return $this->baseUrl . '?action=download&jobId=' . $jobId;
            }
            
            // Hata durumu
            if (isset($status['status']) && $status['status'] === 'error') {
                throw new Exception($status['error'] ?? 'PDF24 sunucusunda hata oluştu.');
            }
            
            $attempt++;
            sleep(1); // 1 saniye bekle
        }
        
        return null;
    }
    
    private function checkStatus(string $jobId): ?array
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->baseUrl . '?' . http_build_query([
                'action' => 'getStatus',
                'jobId' => $jobId
            ]),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response ? json_decode($response, true) : null;
    }
    
    private function downloadFile(string $url, string $outputPath): bool
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        $content = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200 && $content) {
            // Klasör yoksa oluştur
            $dir = dirname($outputPath);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            
            return file_put_contents($outputPath, $content) !== false;
        }
        
        return false;
    }
}