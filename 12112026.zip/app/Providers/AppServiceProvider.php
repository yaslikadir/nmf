<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\Paginator; 
use App\Models\Setting;
use App\Models\Risk;
use App\Observers\RiskObserver;
use Carbon\Carbon;
use Illuminate\Support\Facades\View;

// YENİ EKLENENLER: Akıllı Şube Hafızası için gereken sınıflar
use Illuminate\Auth\Events\Login;
use Illuminate\Support\Facades\Event;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // YENİ EKLENEN: AKILLI MODÜL YÜKLEYİCİ
        $modulesPath = base_path('modules');
        
        if (\Illuminate\Support\Facades\File::exists($modulesPath)) {
            $directories = \Illuminate\Support\Facades\File::directories($modulesPath);
            
            foreach ($directories as $dir) {
                $manifestPath = $dir . '/manifest.json';
                
                if (\Illuminate\Support\Facades\File::exists($manifestPath)) {
                    $manifest = json_decode(\Illuminate\Support\Facades\File::get($manifestPath), true);
                    
                    // Modül aktifse Provider'ını bul ve sisteme kaydet
                    if (isset($manifest['enabled']) && $manifest['enabled'] === true) {
                        $slug = $manifest['slug'];
                        
                        // İsimlendirme ihtimallerini kontrol et (CustomersServiceProvider veya CustomerServiceProvider)
                        $singularSlug = rtrim($slug, 's');
                        $providerClasses = [
                            "Modules\\{$slug}\\Providers\\{$slug}ServiceProvider",
                            "Modules\\{$slug}\\Providers\\{$singularSlug}ServiceProvider",
                            "Modules\\{$slug}\\{$slug}ServiceProvider"
                        ];

                        foreach ($providerClasses as $providerClass) {
                            if (class_exists($providerClass)) {
                                $this->app->register($providerClass);
                                break; // Doğru provider'ı bulduğunda döngüden çık
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // ---------------------------------------------------------
        // 1. GENEL AYARLAR
        // ---------------------------------------------------------
        View::composer('layouts.partials.sidebar_user', function ($view) {
        // Yetki kontrolü mantığınızı buraya yazın (Örn: Spatie Permission kullanıyorsanız)
        $isAuthorized = auth()->check() && auth()->user()->can('knowledge_base_access');
        
        $view->with('isKnowledgeBaseAuthorized', $isAuthorized);
    });
        // Türkçe Tarih Ayarı
        try {
            Carbon::setLocale(config('app.locale'));
            setlocale(LC_TIME, 'tr_TR.utf8', 'tr_TR', 'turkish');
        } catch (\Exception $e) {
            // Sunucuda TR locale yüklü değilse hata vermesin
        }

        // Veritabanı String Uzunluğu (Eski MySQL sürümleri için)
        Schema::defaultStringLength(191);

        // Risk Gözlemcisi (Model varsa)
        if (class_exists(Risk::class) && class_exists(RiskObserver::class)) {
            Risk::observe(RiskObserver::class);
        }

        // *** SAYFALAMA TASARIM DÜZELTMESİ ***
        // Bootstrap 5 kullanıldığını belirtiyoruz.
        Paginator::useBootstrapFive();
        // Eğer temanız Bootstrap 4 ise üsttekini kapatıp alttakini açın:
        // Paginator::useBootstrapFour();


        // ---------------------------------------------------------
        // 2. YETKİLENDİRME (GATES)
        // ---------------------------------------------------------

        // A) SÜPER ADMİN YETKİSİ
        Gate::before(function ($user, $ability) {
            if (method_exists($user, 'hasRole') && $user->hasRole('admin')) {
                return true;
            }
        });

        // B) MODÜL VE KAYIT BAZLI YETKİ KONTROLÜ
        Gate::define('view-module', function ($user, $moduleKey, $record = null) {

            // 1. Spatie Rol Kontrolü
            if (str_starts_with($moduleKey, 'qms_') && method_exists($user, 'hasRole') && $user->hasRole('quality_manager')) {
                return true;
            }

            // 2. Özel İzin Tablosu Kontrolü
            $permission = DB::table('user_permissions')
                ->join('modules', 'user_permissions.module_id', '=', 'modules.id')
                ->where('user_permissions.user_id', $user->id)
                ->where('modules.module_key', $moduleKey)
                ->select('user_permissions.*')
                ->first();

            // İzin yoksa veya seviye 0 ise
            if (!$permission || $permission->view_level == 0) {
                return false;
            }

            // --- SEVİYE KONTROLLERİ ---
            // Seviye 3: Tüm Kayıtlar
            if ($permission->view_level == 3) return true;

            // Kayıt kontrolü gerekmiyorsa (Genel modül girişi)
            if ($record === null) return true;

            // Seviye 2: Departman Kayıtları
            if ($permission->view_level == 2) {
                if (isset($record->department_id) && $record->department_id == $user->department_id) return true;
                if (isset($record->user) && $record->user->department_id == $user->department_id) return true;
            }

            // Seviye 1: Sadece Kendi Kayıtları
            if ($permission->view_level == 1) {
                if (isset($record->user_id) && $record->user_id == $user->id) return true;
                if (isset($record->owner_id) && $record->owner_id == $user->id) return true;
            }

            return false;
        });


        // ---------------------------------------------------------
        // 3. DİNAMİK AYARLAR (SETTINGS)
        // ---------------------------------------------------------
        try {
            if (Schema::hasTable('settings')) {
                // Cache (1 saat)
                $settings = Cache::remember('global_settings', 60*60, function () {
                    return Setting::all()->pluck('value', 'key');
                });

                if ($settings->count() > 0) {
                    if(isset($settings['mail_host'])) Config::set('mail.mailers.smtp.host', $settings['mail_host']);
                    if(isset($settings['mail_port'])) Config::set('mail.mailers.smtp.port', $settings['mail_port']);
                    if(isset($settings['mail_username'])) Config::set('mail.mailers.smtp.username', $settings['mail_username']);
                    if(isset($settings['mail_password'])) Config::set('mail.mailers.smtp.password', $settings['mail_password']);
                    if(isset($settings['mail_encryption'])) Config::set('mail.mailers.smtp.encryption', $settings['mail_encryption']);

                    if(isset($settings['mail_from_address'])) {
                        Config::set('mail.from.address', $settings['mail_from_address']);
                    }

                    $siteTitle = $settings['site_title'] ?? config('app.name');
                    Config::set('mail.from.name', $siteTitle);
                    Config::set('app.name', $siteTitle);
                }
            }
        } catch (\Exception $e) {
            // Sessiz geç
        }

        // ---------------------------------------------------------
        // 4. AKILLI ŞUBE HAFIZASI (GİRİŞ YAPILDIĞINDA)
        // ---------------------------------------------------------
        Event::listen(function (Login $event) {
            $user = $event->user;

            // 1. Kullanıcının hafızasındaki son şubeyi yetkileri arasından bulmaya çalış
            $branch = null;
            if ($user->last_branch_id) {
                $branch = $user->branches()->find($user->last_branch_id);
            }

            // 2. Eğer son şube bulunamazsa (veya silinmişse/yetkisi alınmışsa), yetkisi olan İLK şubeyi al
            if (!$branch) {
                $branch = $user->branches()->first();
                
                // İlk şubeyi bulduysak, kalıcı hafızasına da yazalım ki bir dahaki sefere hatırlasın
                if ($branch) {
                    $user->last_branch_id = $branch->id;
                    $user->save();
                }
            }

            // 3. Şubeyi oturuma (Session) kaydet
            if ($branch) {
                session(['active_branch_id' => $branch->id]);
                session(['active_branch_name' => $branch->name]);
            }
        });
    }
}