<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsChangeRisk extends Model
{
    protected $guarded = [];

    // Risk Seviyesi Hesaplama (1-25)
    public function getRiskLevelAttribute() {
        $score = $this->risk_score;
        if($score >= 15) return ['text' => 'Yüksek', 'class' => 'bg-danger text-white'];
        if($score >= 8) return ['text' => 'Orta', 'class' => 'bg-warning text-dark'];
        return ['text' => 'Düşük', 'class' => 'bg-success text-white'];
    }
}