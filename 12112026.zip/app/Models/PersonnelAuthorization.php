<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelAuthorization extends Model
{
    protected $fillable = [
        'user_id', 'authorization_scope', 'experiment_name', 'objective_evidence',
        'document_name', 'document_uploaded_at', 'document_path', 'evaluation_result',
        'authorization_type', 'title', 'method_reference', 'equipment_reference', 'location',
        'level', 'status', 'authorized_from', 'review_date', 'suspended_at', 'revoked_at',
        'authorized_by', 'conditions', 'decision_reason',
    ];

    protected function casts(): array
    {
        return [
            'document_uploaded_at' => 'date',
            'authorized_from' => 'date',
            'review_date' => 'date',
            'suspended_at' => 'date',
            'revoked_at' => 'date',
        ];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function authorizer()
    {
        return $this->belongsTo(User::class, 'authorized_by');
    }

    public function documents()
    {
        return $this->hasMany(PersonnelAuthorizationDocument::class, 'authorization_id')->latest();
    }
}
