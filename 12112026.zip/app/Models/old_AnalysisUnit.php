<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AnalysisUnit extends Model
{
    protected $guarded = [];
}