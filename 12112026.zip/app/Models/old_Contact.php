<?php

namespace App\Models;

use App\Traits\HasPermissionScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class Contact extends Model
{
    use HasPermissionScope;

    protected $fillable = [
        'customer_id',
        'full_name',
        'title',
        'department',
        'work_phone',
        'extension',
        'mobile_phone', // Formdaki isim 'mobile_phone'
        'email',
        'email2',
        'fax',
        'address_type',
        'decision_status',
        'relationship_status',
        'is_active',
        'gender',
        'birth_date',
        'notes',
        'assistant_name',
        'assistant_phone',
        'business_card_path',
        'created_by'
    ];

    /**
     * OTOMATİK YETKİ FİLTRESİ (Global Scope)
     * Bu kalkan, kullanıcının sadece kendi eklediği kontakları görmesini sağlar.
     */
    protected static function booted()
    {
        static::addGlobalScope('permission_filter', function (Builder $builder) {
            if (Auth::check() && !app()->runningInConsole()) {
                // Trait üzerinden 'contacts' modülü için filtre uygula
                $builder->withPermission('contacts');
            }
        });
    }

    /**
     * Müşteri İlişkisi (KRİTİK REVİZE)
     * withoutGlobalScopes() ekleyerek, kontak listelenirken bağlı olduğu 
     * müşterinin kalkanına takılmamasını sağlıyoruz.
     */
    public function customer()
    {
        return $this->belongsTo(Customer::class)->withoutGlobalScopes();
    }

    /**
     * Kontağı oluşturan kullanıcıya erişim
     */
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}