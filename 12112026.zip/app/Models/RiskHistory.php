<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RiskHistory extends Model
{
    protected $fillable = ['risk_id', 'user_id', 'action', 'changes', 'comment'];

    protected $casts = [
        'changes' => 'array', // JSON verisini dizi olarak çekmek için
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}