<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExamQuestionOption extends Model
{
    // Tüm alanların doldurulmasına izin ver
    protected $guarded = [];

    // 'is_correct' alanını true/false (boolean) olarak algıla
    protected $casts = [
        'is_correct' => 'boolean',
    ];

    // --- İLİŞKİLER ---

    // Bu şık hangi soruya ait?
    public function question()
    {
        return $this->belongsTo(ExamQuestion::class, 'question_id');
    }
}