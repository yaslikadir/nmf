<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class QmsDocumentFolder extends Model
{
    // SoftDeletes trait'i tablonuzda varsa ekli kalsın, yoksa silebilirsiniz
    // use SoftDeletes; 

    protected $guarded = [];

    protected $casts = [
        'access_rules' => 'array', // JSON veriyi diziye çevirir
    ];

    // Üst Klasör
    public function parent()
    {
        return $this->belongsTo(QmsDocumentFolder::class, 'parent_id');
    }

    // Alt Klasörler
    public function children()
    {
        return $this->hasMany(QmsDocumentFolder::class, 'parent_id');
    }

    // Bu klasörün içindeki dokümanlar
    public function documents()
    {
        return $this->hasMany(QmsDocument::class, 'folder_id');
    }

    /**
     * MİRAS MANTIĞI 1: Klasör şifreli mi? (Kendisinin veya Atalarının şifresi var mı?)
     */
    public function hasPasswordProtection()
    {
        $folder = $this;
        while ($folder) {
            if (isset($folder->access_rules['password']) && !empty($folder->access_rules['password'])) {
                return true;
            }
            $folder = $folder->parent;
        }
        return false;
    }

    /**
     * Şifreyi getir (Kendisinde veya en yakın atada olan şifreyi)
     */
    public function getEffectivePassword()
    {
        $folder = $this;
        while ($folder) {
            if (isset($folder->access_rules['password']) && !empty($folder->access_rules['password'])) {
                return $folder->access_rules['password'];
            }
            $folder = $folder->parent;
        }
        return null;
    }

    /**
     * MİRAS MANTIĞI 2: Klasöre kullanıcının yetkisi var mı? (Rol + Kullanıcı Bazlı)
     */
    public function userHasAccess($user)
    {
        // Admin ve Kalite Yöneticisi her yeri görür (God Mode)
        if (in_array($user->role, ['admin', 'Kalite Yöneticisi'])) {
            return true;
        }

        $folder = $this;
        while ($folder) {
            $rules = $folder->access_rules;
            
            // Eğer bu atada/klasörde kural varsa ve (roles veya users dizisi boş değilse) kontrol et
            if (!empty($rules) && (!empty($rules['roles']) || !empty($rules['users']))) {
                
                // Kullanıcının rolü izin verilen rollerin içinde mi?
                $hasRole = !empty($rules['roles']) && in_array($user->role, $rules['roles']);
                
                // Kullanıcının ID'si izin verilen kullanıcıların içinde mi?
                $hasUser = !empty($rules['users']) && in_array($user->id, $rules['users']);
                
                // Eğer bu klasörde bir kısıtlama varsa ve kullanıcı ne role ne de isme göre yetkili değilse, İZİN YOK!
                if (!$hasRole && !$hasUser) {
                    return false;
                }
            }
            $folder = $folder->parent; // Bir üst ataya geç ve onu da kontrol et
        }
        return true; // Hiçbir atada engelleyici bir kural bulunamadıysa izin ver
    }
}