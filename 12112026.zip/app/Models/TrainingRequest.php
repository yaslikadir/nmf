<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingRequest extends Model
{
    protected $guarded = [];

    // İlişki: Talebi yapan personel
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}