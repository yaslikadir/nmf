<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use App\Models\Department;
use App\Models\UserPermission;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasRoles, SoftDeletes;

    /**
     * Toplu Atama Yapılabilir Alanlar
     */
    protected $fillable = [
        'name', 'username', 'email', 'password', 'role', 
        'department_id', 'title', 'user_code', 'is_active', 
        'gender', 'tc_no', 'home_phone', 'mobile_phone', 'address', 
        'birth_place', 'birth_date', 'hire_date', 'blood_group', 
        'education_status', 'graduated_school', 'graduated_department', 
        'graduation_date', 'marital_status', 'marriage_date', 'settings',
        'bank_account', 'profile_photo', 'signature_stamp',
        'menu_permissions',
        'active_role_id'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Veri Tipi Dönüşümleri (Laravel 11+ tarzı)
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
            'hire_date' => 'date',
            'birth_date' => 'date',
            'graduation_date' => 'date',
            'marriage_date' => 'date',
            'settings' => 'array',
            'menu_permissions' => 'array',
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | İLİŞKİLER (RELATIONSHIPS)
    |--------------------------------------------------------------------------
    */

    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class, 'department_id', 'id')->withTrashed();
    }

    public function userPermissions(): HasMany
    {
        return $this->hasMany(UserPermission::class);
    }

    public function activeRole(): BelongsTo
    {
        return $this->belongsTo(\App\Models\Role::class, 'active_role_id');
    }

    /*
    |--------------------------------------------------------------------------
    | YARDIMCI METODLAR (GLOBAL ADMIN VE ROL GÜCÜ)
    |--------------------------------------------------------------------------
    */

    public function isAdmin(): bool
    {
        // 1. Eğer bir aktif rol seçilmişse, O ROLÜN admin olup olmadığına bak.
        // Bu sayede admin başka role geçtiğinde sistem onu o rolün yetkisiyle çalıştırır!
        if ($this->activeRole) {
            return mb_strtolower(trim($this->activeRole->name)) === 'admin';
        }

        // 2. Henüz aktif rol seçilmemişse genel adminliğine bak
        return mb_strtolower((string) $this->role) === 'admin' || $this->hasRole('admin');
    }

    public function hasModuleAccess($moduleKey): bool
    {
        // Admin her şeye erişir (Yukarıdaki isAdmin seçili role göre çalışır)
        if ($this->isAdmin()) {
            return true;
        }

        // Aktif rol yoksa ve kullanıcının rolleri varsa ilkini ata
        if (!$this->active_role_id && $this->roles && $this->roles->count() > 0) {
            $this->active_role_id = $this->roles->first()->id;
            $this->saveQuietly();
        }

        if (!$this->active_role_id) {
            return false;
        }

        $module = \App\Models\Module::where('module_key', $moduleKey)->first();
        if (!$module) {
            return false;
        }

        // SADECE aktif rolün yetkisine bak
        return \App\Models\RolePermission::where('role_id', $this->active_role_id)
            ->where('module_id', $module->id)
            ->where('view_level', '>', 0)
            ->exists();
    }

    public function hasMenuAccess($menuKey): bool
    {
        if ($this->isAdmin()) {
            return true;
        }

        if (!$this->activeRole) {
            return false;
        }

        $perms = $this->activeRole->menu_permissions ?? [];
        if (is_string($perms)) {
            $perms = json_decode($perms, true) ?? [];
        }

        return (isset($perms[$menuKey]) && $perms[$menuKey] == 1) || in_array($menuKey, (array) $perms, true);
    }

    public function hasPermissionToAccessModule($moduleKey): bool
    {
        // 1. Seçili aktif rol Admin ise direkt geç
        if ($this->isAdmin()) {
            return true;
        }
        
        // 2. Aktif rolü kontrol et
        $role = $this->activeRole;
        if (!$role) {
            return false;
        }

        // 3. Modülü 'module_key' üzerinden bul
        $module = \App\Models\Module::where('module_key', $moduleKey)->first();
        if (!$module) {
            return false;
        }

        // 4. Bulduğumuz modül ID'si ile aktif rolün yetkisini sorgula
        return $role->rolePermissions()
            ->where('module_id', $module->id)
            ->where('view_level', '>', 0)
            ->exists();
    }

    /**
     * Kullanıcının yetkili olduğu şubeler
     */
    public function branches()
    {
        return $this->belongsToMany(\Modules\Branches\Models\Branch::class, 'branch_user')
                    ->withPivot('is_default')
                    ->withTimestamps();
    }

    /*
    |--------------------------------------------------------------------------
    | EĞİTİM, KAPSAM VE PERSONEL İLİŞKİLERİ
    |--------------------------------------------------------------------------
    */

    /**
     * Personelin aldığı eğitimler
     */
    public function trainings()
    {
        return $this->hasMany(UserTraining::class)->orderBy('start_date', 'desc');
    }

    /**
     * Eğitim planlarına katılımcı olarak atanmış personel kayıtları.
     */
    public function trainingRecords(): HasMany
    {
        return $this->hasMany(TrainingRecord::class, 'user_id');
    }

    /**
     * Personelin yetkili olduğu kapsam tipleri
     */
    public function scopes()
    {
        return $this->hasMany(UserScope::class)->orderBy('created_at', 'desc');
    }

    public function personnelDocuments()
    {
        return $this->hasMany(\App\Models\PersonnelDocument::class);
    }

    public function orientationRecords()
    {
        return $this->hasMany(\App\Models\PersonnelOrientationRecord::class);
    }

    public function competencyAssessments()
    {
        return $this->hasMany(\App\Models\PersonnelCompetencyAssessment::class);
    }

    public function personnelAuthorizations()
    {
        return $this->hasMany(\App\Models\PersonnelAuthorization::class);
    }

    public function scopeAuthorizations()
    {
        return $this->hasMany(\App\Models\PersonnelScopeAuthorization::class);
    }
}