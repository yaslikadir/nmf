<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Task extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'code', 'title', 'description', 'created_by', 
        'customer_id', 'offer_id', 'measurement_plan_id',
        'type', 'status', 'priority', 
        'start_date', 'due_date', 'reminder_date', 'actual_end_date',
        'progress', 'is_calendar'
    ];

    protected $casts = [
        'start_date' => 'datetime',
        'due_date' => 'datetime',
        'reminder_date' => 'datetime',
        'actual_end_date' => 'datetime',
        'is_calendar' => 'boolean',
    ];

    // --- İLİŞKİLER ---

    // Görevi Atayan
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    // Sorumlular (Çoklu)
    public function responsibles()
    {
        return $this->belongsToMany(User::class, 'task_responsibles', 'task_id', 'user_id');
    }

    // Bilgilendirilecekler (Çoklu)
    public function observers()
    {
        return $this->belongsToMany(User::class, 'task_observers', 'task_id', 'user_id');
    }

    // Bağlı Müşteri
    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    // Bağlı Teklif
    public function offer()
    {
        return $this->belongsTo(Offer::class);
    }

    // Bağlı Plan
    public function plan()
    {
        return $this->belongsTo(MeasurementPlan::class, 'measurement_plan_id');
    }

    public function department()
{
    return $this->belongsTo(Department::class, 'department_id');
}

}