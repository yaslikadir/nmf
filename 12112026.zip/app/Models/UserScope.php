<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserScope extends Model
{
    protected $guarded = [];
    
    protected function casts(): array
    {
        return [
            'authorization_date' => 'date',
        ];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function scopeType()
    {
        return $this->belongsTo(ScopeType::class, 'scope_type_id');
    }
}