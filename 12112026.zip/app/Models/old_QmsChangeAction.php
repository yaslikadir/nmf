<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsChangeAction extends Model
{
    protected $guarded = [];
    protected $casts = ['due_date' => 'date', 'completed_at' => 'datetime'];

    public function responsible() {
        return $this->belongsTo(User::class, 'responsible_user_id');
    }
    
    // Aksiyon Tipi Türkçesi
    public function getTypeLabelAttribute() {
        $map = [
            'Training' => 'Eğitim',
            'Document_Revision' => 'Doküman Revizyonu',
            'Purchase' => 'Satın Alma',
            'Other' => 'Diğer'
        ];
        return $map[$this->action_type] ?? $this->action_type;
    }
}