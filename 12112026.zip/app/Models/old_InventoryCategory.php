<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InventoryCategory extends Model
{
    protected $guarded = [];

    // Bu kategoriye ait tüm malzemeler
    public function materials()
    {
        return $this->hasMany(Material::class, 'category_id');
    }
}