<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmergencyDrill extends Model
{
    protected $guarded = [];

    protected $casts = [
        'drill_date' => 'date',
        'checklist_results' => 'array'
    ];

    public function plan()
    {
        return $this->belongsTo(EmergencyPlan::class, 'emergency_plan_id');
    }

    public function conductor()
    {
        return $this->belongsTo(User::class, 'conducted_by');
    }
}