<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SupplierCriterion extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function supplierClass()
    {
        return $this->belongsTo(SupplierClass::class);
    }
}