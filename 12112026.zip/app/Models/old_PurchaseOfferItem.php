<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PurchaseOfferItem extends Model
{
    protected $guarded = [];
    
    // Hangi talep kalemine fiyat verdik?
    public function requestItem() { return $this->belongsTo(PurchaseRequestItem::class, 'purchase_request_item_id'); }
}