<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\HasPermissionScope; // <-- 1. KALKAN DAHİL EDİLDİ

class PurchaseRequest extends Model
{
    use HasFactory, HasPermissionScope; // <-- 2. KULLANIMA AÇILDI

    // 3. KALKANA "Benim oluşturan sütunum created_by değil, requester_id'dir" DİYORUZ
    public $ownerColumn = 'requester_id';

    protected $guarded = [];

    protected $casts = [
        'requested_by_date' => 'date',
        'responded_at' => 'datetime',
    ];

    // --- İLİŞKİLER ---

    // YENİ EKLENDİ: RBAC Seviye 2 (Departman) yetkisi için zorunlu ilişki
    // Kalkan "creator" aradığı için, mevcut requester_id'yi creator olarak da tanıtıyoruz
    public function creator()
    {
        return $this->belongsTo(User::class, 'requester_id');
    }

    // 1. Talebi Yapan Kişi
    public function requester()
    {
        return $this->belongsTo(User::class, 'requester_id');
    }

    // 2. Departman
    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    // 3. Onaylayacak Yönetici
    public function approver()
    {
        return $this->belongsTo(User::class, 'approver_id');
    }

    // 4. Talep Edilen Ürünler (Kalemler)
    public function items()
    {
        return $this->hasMany(PurchaseRequestItem::class);
    }

    // 5. Bu Talebe Verilen Teklifler (Teklif Havuzu İçin) - EKLENDİ
    public function offers()
    {
        return $this->hasMany(PurchaseOffer::class, 'purchase_request_id');
    }

    // 6. Kabul Edilen / Dönüştürülen Teklif (Varsa) - EKLENDİ
    public function offer()
    {
        return $this->belongsTo(PurchaseOffer::class, 'converted_offer_id');
    }

    // --- ACCESSORS ---

    // Sanal Durum (Görünüm İçin)
    public function getDisplayStatusAttribute()
    {
        if ($this->status == 'Approved') {
            if ($this->offers()->count() > 0 && !$this->converted_offer_id) {
                return 'Collecting Offers'; // Teklif Toplanıyor
            }
        }
        return $this->status;
    }
}