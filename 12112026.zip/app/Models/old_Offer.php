<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Modules\Customers\Models\Customer;
use Modules\Customers\Models\Contact;

class Offer extends Model 
{
    use SoftDeletes;

    // Güvenlik için izin verilen alanlar (fillable)
    protected $fillable = [
        'offer_no',
        'revision_number',
        'request_no',
        'customer_id',
        'contact_id',
        'scope_type_id',
        'subject',
        'offer_date',
        'document_discount',
        'valid_until',
        'reminder_date',
        'payment_method',
        'status',
        'description',
        'revision_note',
        'probability',
        'probability_date',
        'consultant_name',
        'consultant_1_contact',
        'consultant_2',
        'consultant_2_contact',
        'consultant_notes',
        'loss_reason',
        'address_type',
        'address',
        'subtotal',
        'discount_total',
        'tax_total',
        'grand_total',
        'currency',
        'created_by',
        
        // --- YENİ EKLENEN ALAN ---
        'has_samples', // Numune barkodları oluşturuldu mu? (0/1)
    ];

    // Veri tipi dönüşümleri
    protected $casts = [
        'offer_date'       => 'date',
        'valid_until'      => 'date',
        'reminder_date'    => 'date',
        'probability_date' => 'date',
        'has_samples'      => 'boolean', // 1/0 değerini true/false olarak kullanmak için
    ];

    /**
     * Teklif Satırları (Analiz Parametreleri)
     * Not: Controller tarafında 'offerItems' olarak çağırdığımız için ismi güncellendi.
     */
    public function offerItems(): HasMany
    {
        return $this->hasMany(OfferItem::class);
    }

    /**
     * Teklif Satırları (ESKİ SİSTEM / OfferController İÇİN)
     * !!! BU FONKSİYONU EKLEMEN GEREKİYOR !!!
     */
    public function items(): HasMany
    {
        return $this->hasMany(OfferItem::class);
    }

    /**
     * Teklife Ait Numuneler (Barkodlar)
     * SampleController ve Planlama sayfasında kullanılıyor.
     */
    public function samples(): HasMany
    {
        return $this->hasMany(Sample::class);
    }

    /**
     * Teklifin Ait Olduğu Müşteri
     */
    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    /**
     * Teklifteki İlgili Kontak Kişisi
     */
    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class);
    }

    /**
     * Teklifin Kapsam Tipi (AR-GE, Atıksu vb.)
     */
    public function scopeType(): BelongsTo
    {
        return $this->belongsTo(ScopeType::class);
    }

    /**
     * Teklifi Oluşturan Kullanıcı (Müşteri Temsilcisi)
     */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /**
     * Bağlı Olduğu Talep Kaydı
     */
    public function customerRequest()
    {
        return $this->belongsTo(CustomerRequest::class, 'request_no', 'request_no');
    }

    /**
     * Teklifin içindeki Parametrelere Doğrudan Erişim (Deep Relationship)
     * Offer -> OfferItems -> ScopeParameter
     * Bu sayede $offer->scopeParameters diyerek parametre listesini alabiliriz.
     */
    public function scopeParameters(): HasManyThrough
    {
        return $this->hasManyThrough(
            ScopeParameter::class, // Hedef Model (Parametre)
            OfferItem::class,      // Aracı Model (Teklif Satırı)
            'offer_id',            // OfferItem tablosundaki offer_id (Aracıdaki foreign key)
            'id',                  // ScopeParameter tablosundaki id (Hedefin primary key)
            'id',                  // Offer tablosundaki id (Bizim primary key)
            'parameter_id'         // OfferItem tablosundaki parameter_id (Hedefin foreign key'i)
        );
    }

    public function consultant()
{
    return $this->belongsTo(User::class, 'consultant_id');
}

public function measurementPlans()
{
    return $this->hasMany(MeasurementPlan::class);
}

public function revisions(): \Illuminate\Database\Eloquent\Relations\HasMany
{
    return $this->hasMany(OfferRevision::class, 'offer_id')->latest();
}


    
}