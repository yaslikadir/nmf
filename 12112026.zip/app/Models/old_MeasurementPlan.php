<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\HasPermissionScope; // <-- 1. Trait'i buraya dahil ettik

class MeasurementPlan extends Model
{
    use SoftDeletes, HasPermissionScope; // <-- 2. Sınıfın içinde kullanıma açtık

    // user_id artık burada yok, çünkü ara tabloda tutulacak.
    protected $fillable = [
        'plan_code',
        'offer_id',
        'created_by',
        // 'user_id', <-- BU KALDIRILDI
        'start_date',
        'end_date',
        'status',
        'description',
        'attachment'
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date'   => 'date',
    ];

    // --- İLİŞKİLER ---

    // RBAC Seviye 2 (Departman) kontrolü için zorunlu ilişki
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function offer()
{
    return $this->belongsTo(\Modules\Sales\Models\Offer::class, 'offer_id');
}

    // ARTIK TEKİL DEĞİL, ÇOĞUL İLİŞKİ (ÇOKLU SEÇİM İÇİN)
    public function users()
    {
        return $this->belongsToMany(User::class, 'measurement_plan_user');
    }

    public function devices()
    {
        return $this->belongsToMany(Device::class, 'measurement_plan_device');
    }
}