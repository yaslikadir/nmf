<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SampleTransfer extends Model
{
    protected $guarded = [];

    protected $casts = [
        'transfer_date' => 'datetime',
        'received_date' => 'datetime',
    ];

    public function sample()
    {
        return $this->belongsTo(Sample::class);
    }

    public function fromLocation()
    {
        return $this->belongsTo(StorageLocation::class, 'from_location_id');
    }

    public function toLocation()
    {
        return $this->belongsTo(StorageLocation::class, 'to_location_id');
    }

    public function requester()
    {
        return $this->belongsTo(User::class, 'requested_by');
    }

    public function receiver()
    {
        return $this->belongsTo(User::class, 'received_by');
    }

    public function transporter()
{
    
    return $this->belongsTo(User::class, 'transferred_by');
}
}