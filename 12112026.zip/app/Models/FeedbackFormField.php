<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FeedbackFormField extends Model
{
    protected $guarded = [];

    // Seçenekleri otomatik diziye çevir
    protected $casts = [
        'options' => 'array',
        'is_required' => 'boolean'
    ];

    public function form()
    {
        return $this->belongsTo(FeedbackForm::class);
    }
}