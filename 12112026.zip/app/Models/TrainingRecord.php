<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingRecord extends Model {
    protected $guarded = [];
    protected $casts = [
        'valid_until' => 'date',
        'exam_date' => 'datetime',
        'completed_at' => 'datetime',
    ];

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function plan() {
        return $this->belongsTo(TrainingPlan::class);
    }

    public function evaluation()
{
    return $this->hasOne(TrainingEvaluation::class, 'training_record_id');
}
}