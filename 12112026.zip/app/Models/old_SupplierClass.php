<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SupplierClass extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function questions()
    {
        return $this->hasMany(SupplierQuestion::class);
    }

    public function criteria()
    {
        return $this->hasMany(SupplierCriterion::class);
    }

    public function suppliers()
    {
        return $this->hasMany(Supplier::class);
    }
}