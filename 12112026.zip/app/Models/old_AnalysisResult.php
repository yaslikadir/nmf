<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AnalysisResult extends Model
{
    use SoftDeletes;

    protected $guarded = [];

    // Hangi iş emrine ait?
    public function workOrder()
    {
        return $this->belongsTo(AnalysisWorkOrder::class, 'analysis_work_order_id');
    }

    // Kaydeden personel
    public function recorder()
    {
        return $this->belongsTo(User::class, 'recorded_by');
    }
}