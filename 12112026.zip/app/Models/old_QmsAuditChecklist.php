<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsAuditChecklist extends Model
{
    protected $guarded = [];

    public function questions()
    {
        return $this->hasMany(QmsAuditQuestion::class, 'checklist_id')->orderBy('order');
    }
}