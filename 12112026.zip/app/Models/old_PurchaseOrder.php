<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PurchaseOrder extends Model
{
    protected $guarded = [];
    protected $casts = ['ordered_at' => 'datetime', 'delivery_date' => 'date', 'invoice_date' => 'date'];

    public function request() { return $this->belongsTo(PurchaseRequest::class, 'purchase_request_id'); }
    public function offer() { return $this->belongsTo(PurchaseOffer::class, 'purchase_offer_id'); }
    public function supplier() { return $this->belongsTo(Supplier::class); }

    // Siparişe ait teslimatlar
    public function deliveries()
    {
        return $this->hasMany(PurchaseDelivery::class);
    }
}

