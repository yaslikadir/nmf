<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Module extends Model
{
    // Bu dizi içindeki alanların dışarıdan doldurulmasına izin veriyoruz
    protected $fillable = ['name', 'module_key'];

    // Yetki ilişkisini de şimdiden ekleyelim
    public function permissions()
    {
        return $this->hasMany(RolePermission::class);
    }
}