<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsAuditQuestion extends Model
{
    protected $guarded = [];

    public function checklist()
    {
        return $this->belongsTo(QmsAuditChecklist::class);
    }
}