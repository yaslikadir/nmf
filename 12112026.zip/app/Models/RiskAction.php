<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RiskAction extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'risk_id', 'action_description', 'type', 
        'assigned_to', 'due_date', 'completed_at', 'result_notes'
    ];
    
    protected $casts = [
        'due_date' => 'date',
        'completed_at' => 'datetime',
    ];

    public function risk() {
        return $this->belongsTo(Risk::class);
    }

    public function responsible() {
        return $this->belongsTo(User::class, 'assigned_to');
    }
}