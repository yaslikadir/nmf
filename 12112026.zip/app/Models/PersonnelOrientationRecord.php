<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelOrientationRecord extends Model
{
    protected $fillable = [
        'user_id', 'title', 'category', 'content', 'planned_date', 'completed_date', 'end_date', 'duration_minutes',
        'trainer_name', 'trainer_id', 'status', 'score', 'passed', 'evidence_notes', 'evidence_path',
        'video_url', 'video_path',
        'approved_by', 'approved_at',
    ];

    protected function casts(): array
    {
        return [
            'planned_date' => 'date',
            'completed_date' => 'date',
            'end_date' => 'date',
            'approved_at' => 'datetime',
            'passed' => 'boolean',
            'score' => 'decimal:2',
        ];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function trainer()
    {
        return $this->belongsTo(User::class, 'trainer_id');
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function documents()
    {
        return $this->hasMany(PersonnelOrientationDocument::class, 'personnel_orientation_record_id');
    }
}
