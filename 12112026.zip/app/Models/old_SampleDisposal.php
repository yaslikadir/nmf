<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SampleDisposal extends Model
{
    use SoftDeletes;
    protected $guarded = [];
    protected $casts = [
        'request_date' => 'datetime',
        'approval_date' => 'datetime',
        'disposal_date' => 'datetime',
    ];

    public function sample() { return $this->belongsTo(Sample::class); }
    public function requester() { return $this->belongsTo(User::class, 'requested_by'); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
    public function executor() { return $this->belongsTo(User::class, 'disposed_by'); }
}