<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelOrientationDocument extends Model
{
    protected $fillable = [
        'personnel_orientation_record_id',
        'document_name',
        'file_path',
        'original_name',
        'mime_type',
        'file_size',
        'uploaded_by',
    ];

    public function orientationRecord()
    {
        return $this->belongsTo(PersonnelOrientationRecord::class, 'personnel_orientation_record_id');
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }
}
