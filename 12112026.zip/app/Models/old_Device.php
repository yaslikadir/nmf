<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Device extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'brand',
        'model',
        'serial_no',
        'inventory_no',
        'device_location_id', // İsim değişikliği yapılmıştı
        'responsible_id',
        'status',
        'purchase_date',
        'warranty_end_date',
        
        // --- BAKIM & KALİBRASYON ---
        'maintenance_period_days',
        'last_maintenance_date',
        'next_maintenance_date',
        
        'calibration_period_days',
        'last_calibration_date',
        'next_calibration_date',

        // --- YENİ EKLENENLER (Eksik Olanlar Bunlardı) ---
        'verification_period_days', // <-- İşte aradığın haylaz :)
        'last_verification_date',
        'next_verification_date',
        'measurement_scope', 
        'entry_date',// Bunu da ekleyelim
        
        'technical_specs',
        'image'
    ];

    protected $casts = [
        'purchase_date' => 'date',
        'warranty_end_date' => 'date',
        'last_maintenance_date' => 'date',
        'next_maintenance_date' => 'date',
        'last_calibration_date' => 'date',
        'next_calibration_date' => 'date',
        // Yeni Tarihler için Cast
        'last_verification_date' => 'date',
        'next_verification_date' => 'date',
        'technical_specs' => 'array', 
        'entry_date' => 'date',
    ];

    // İlişkiler
    public function responsible()
    {
        return $this->belongsTo(User::class, 'responsible_id');
    }

    public function location()
    {
        // Yeni yapı: Definition tablosuna bağlanıyor
        return $this->belongsTo(Definition::class, 'device_location_id');
    }

  

    public function maintenances()
    {
        return $this->hasMany(DeviceMaintenance::class)->latest('maintenance_date');
    }

    public function calibrations()
    {
        return $this->hasMany(DeviceCalibration::class)->latest('calibration_date');
    }

    public function actions()
    {
        return $this->hasMany(DeviceAction::class)->latest('action_date');
    }

    public function responsibles()
{
    // Cihaz ve Kullanıcı arasındaki pivot tablo: device_user
    return $this->belongsToMany(User::class, 'device_user', 'device_id', 'user_id');
}
}