<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingPlan extends Model
{
    // Tüm alanların doldurulmasına izin ver (Mass Assignment)
    protected $guarded = [];

    // Tarih alanlarını Carbon objesine çevir (Formatlama kolaylığı için)
    protected $casts = [
        'start_date' => 'datetime',
        'end_date' => 'datetime',
    ];

    // --- İLİŞKİLER ---

    // 1. Bu plan hangi ana eğitim tanımına ait?
    public function training()
    {
        return $this->belongsTo(Training::class, 'training_id');
    }

    // 2. Bu plana katılan personeller ve sonuçları (Kayıtlar)
    public function records()
    {
        return $this->hasMany(TrainingRecord::class, 'plan_id');
    }

    // --- YARDIMCI ACCESSOR (Opsiyonel) ---
    
    // Durumu Türkçe ve renkli göstermek için
    public function getStatusLabelAttribute()
    {
        $map = [
            'Planned'   => ['text' => 'Planlandı', 'class' => 'bg-info text-dark'],
            'Completed' => ['text' => 'Tamamlandı', 'class' => 'bg-success text-white'],
            'Cancelled' => ['text' => 'İptal Edildi', 'class' => 'bg-danger text-white'],
        ];

        return $map[$this->status] ?? ['text' => $this->status, 'class' => 'bg-secondary'];
    }
}