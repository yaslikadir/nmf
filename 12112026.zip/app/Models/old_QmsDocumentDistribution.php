<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsDocumentDistribution extends Model
{
    protected $guarded = [];

    protected $casts = [
        'read_at' => 'datetime',
        'is_read_required' => 'boolean',
        'is_read' => 'boolean',
    ];

    public function version()
    {
        return $this->belongsTo(QmsDocumentVersion::class, 'document_version_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }
}