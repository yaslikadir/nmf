<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PersonnelDocument extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'user_id','document_type','title','document_no','document_date','valid_from','valid_until',
        'status','file_path','original_name','mime_type','file_size','file_hash','notes',
        'verified_by','verified_at','uploaded_by',
    ];

    protected function casts(): array
    {
        return [
            'document_date' => 'date', 'valid_from' => 'date', 'valid_until' => 'date',
            'verified_at' => 'datetime',
        ];
    }

    public function user() { return $this->belongsTo(User::class); }
    public function verifier() { return $this->belongsTo(User::class, 'verified_by'); }
    public function uploader() { return $this->belongsTo(User::class, 'uploaded_by'); }
}
