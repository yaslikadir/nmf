<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeviceCalibration extends Model
{
    use HasFactory;

    protected $fillable = [
        'device_id',
        'calibration_date',
        'valid_until',
        'certificate_no',
        'lab_name',
        'result', // Geçti, Kaldı
        'notes',
        'document'
    ];

    protected $casts = [
        'calibration_date' => 'date',
        'valid_until' => 'date'
    ];

    public function device()
    {
        return $this->belongsTo(Device::class);
    }
}