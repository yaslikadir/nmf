<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeviceMaintenance extends Model
{
    use HasFactory;

    protected $fillable = [
        'device_id',
        'type', // Periyodik, Arıza Sonrası, Önleyici
        'maintenance_date',
        'value',
        'description',
        'performed_by',
        'result', // Başarılı, Sorunlu
        'cost',
        'document'
    ];

    protected $casts = [
        'maintenance_date' => 'date',
        'cost' => 'decimal:2'
    ];

    public function device()
    {
        return $this->belongsTo(Device::class);
    }
}