<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelCompetencyAssessment extends Model
{
    protected $fillable = [
        'user_id', 'matrix_id', 'activity_title', 'assessment_type', 'level', 'assessment_date',
        'planned_assessment_date', 'next_review_date', 'monitoring_period_years', 'assessor_id', 'assessor_name', 'result', 'criteria',
        'evidence', 'evidence_path', 'limitations',
    ];

    protected function casts(): array
    {
        return ['assessment_date' => 'date', 'planned_assessment_date' => 'date', 'next_review_date' => 'date'];
    }

    public function user() { return $this->belongsTo(User::class); }
    public function matrix() { return $this->belongsTo(PersonnelAuthorizationMatrix::class, 'matrix_id'); }
    public function assessor() { return $this->belongsTo(User::class, 'assessor_id'); }
    public function renewalLogs() { return $this->hasMany(PersonnelCompetencyRenewalLog::class, 'assessment_id'); }
}
