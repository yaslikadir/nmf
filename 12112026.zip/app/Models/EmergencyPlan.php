<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmergencyPlan extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'title', 'scenario', 'procedure', 'response_team',
        'drill_frequency_months', 'last_drill_date', 'next_drill_date', 'is_active','checklist_items'
    ];

    protected $casts = [
        'last_drill_date' => 'date',
        'next_drill_date' => 'date',
        'drill_frequency_months' => 'integer',
        'checklist_items' => 'array',
    ];

    public function teamMembers()
{
    return $this->belongsToMany(User::class, 'emergency_plan_user', 'emergency_plan_id', 'user_id');
}

public function drills()
{
    return $this->hasMany(EmergencyDrill::class)->orderBy('drill_date', 'desc');
}

}