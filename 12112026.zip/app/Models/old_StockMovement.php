<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockMovement extends Model
{
    protected $guarded = [];

    // Hareketi yapan personel
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // TERS İLİŞKİ: Her stok hareketi bir envanter kaydına aittir.
    public function inventory()
    {
        return $this->belongsTo(Inventory::class);
    }

    // Hareket hangi malzemeye yapıldı?
    public function material()
    {
        return $this->belongsTo(Material::class);
    }
}