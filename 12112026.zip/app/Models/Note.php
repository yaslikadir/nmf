<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Note extends Model
{
    use HasFactory;

    // Tabloya toplu ekleme yapılabilecek alanlar
    protected $fillable = ['user_id', 'content'];

    // Notun sahibi olan kullanıcıyı tanımlayalım
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}