<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Inventory extends Model
{
    protected $guarded = [];

    // Bu stok satırı hangi malzemeye ait?
    public function material()
    {
        return $this->belongsTo(Material::class);
    }

    // Stok hareket geçmişi
    public function movements()
    {
        return $this->hasMany(StockMovement::class);
    }
}