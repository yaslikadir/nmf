<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Material extends Model
{
    // Fillable yerine guarded kullanımı tüm alanları serbest bırakır (Güvenli ve pratik)
    protected $guarded = [];

    // Hangi kategoriye ait?
    public function category() {
        return $this->belongsTo(InventoryCategory::class, 'category_id');
    }

    // Bu malzemenin eldeki tüm stok hareketleri/kalemleri
    public function stocks() {
        return $this->hasMany(Inventory::class);
    }

    // YENİ EKLENEN: Bu malzemenin Girdi/Çıktı kullanım logları (HAREKET GEÇMİŞİ)
    public function movements() {
        return $this->hasMany(StockMovement::class)->orderBy('created_at', 'desc');
    }
    
    // Toplam stok miktarını hesapla ($material->total_stock)
    public function getTotalStockAttribute() {
        return $this->stocks_sum_quantity ?? $this->stocks->sum('quantity');
    }

    protected $casts = [
        'is_active' => 'boolean',
        'expiry_date' => 'date', // SKT'yi tarih formatına çevir
    ];
}