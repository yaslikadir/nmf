<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelAuthorizationMatrix extends Model
{
    protected $fillable = [
        'user_id', 'authorization_id', 'experiment_name', 'tested_product', 'material',
        'test_method', 'authorization_date', 'status',
    ];

    protected function casts(): array
    {
        return ['authorization_date' => 'date'];
    }

    public function user() { return $this->belongsTo(User::class); }
    public function authorization() { return $this->belongsTo(PersonnelAuthorization::class, 'authorization_id'); }
    public function competencyAssessments() { return $this->hasMany(PersonnelCompetencyAssessment::class, 'matrix_id'); }
}
