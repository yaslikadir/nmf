<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SampleAnalysis extends Model
{
    protected $table = 'analysis_results';
}
