<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class SupplierEvaluation extends Model
{
    protected $guarded = [];
    protected $casts = ['evaluation_date' => 'date'];

    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function evaluator() { return $this->belongsTo(User::class, 'evaluator_id'); }
}