<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AnalysisWorkOrder extends Model
{
    use SoftDeletes;

    protected $guarded = [];

    protected $casts = [
        'target_date' => 'date',
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
    ];

    // Numune İlişkisi
    public function sample() {
        return $this->belongsTo(Sample::class);
    }

    // Parametre İlişkisi
    public function parameter() {
        return $this->belongsTo(ScopeParameter::class, 'scope_parameter_id');
    }

    // Metot İlişkisi
    public function method() {
        return $this->belongsTo(AnalysisMethod::class, 'analysis_method_id');
    }

    // Analist İlişkisi
    public function analyst() {
        return $this->belongsTo(User::class, 'analyst_id');
    }
    
    // Atayan Yönetici
    public function assigner() {
        return $this->belongsTo(User::class, 'assigned_by');
    }

    // Sonuç İlişkisi (Bire-Bir: Bir iş emrinin bir sonucu olur)
    public function result()
    {
        return $this->hasOne(AnalysisResult::class, 'analysis_work_order_id');
    }
}