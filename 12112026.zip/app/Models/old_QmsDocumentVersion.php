<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsDocumentVersion extends Model
{
    protected $guarded = [];

    protected $casts = [
        'change_logs' => 'array',
        'valid_from' => 'date',
        'valid_until' => 'date',
        'is_current' => 'boolean',
    ];

    // Hangi ana dokümana ait?
    public function document()
    {
        return $this->belongsTo(QmsDocument::class, 'document_id');
    }

    // Versiyonu oluşturan
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    // Nihai onayı veren (Yayınlayan)
    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    // Onay Akışı (Sıralı Liste)
    public function approvals()
    {
        return $this->hasMany(QmsDocumentApproval::class, 'document_version_id')->orderBy('order', 'asc');
    }

    // Dağıtım Listesi (Okuması Gerekenler)
    public function distributions()
    {
        return $this->hasMany(QmsDocumentDistribution::class, 'document_version_id');
    }

    // --- HELPER ---
    
    // Dosyanın tam yolu (Storage linki için)
    public function getDownloadUrlAttribute()
    {
        // Güvenlik için direkt link vermek yerine, route üzerinden kontrolle indirme yaptıracağız.
        return route('admin.qms.documents.download', $this->id);
    }
}