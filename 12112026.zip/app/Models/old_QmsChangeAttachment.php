<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsChangeAttachment extends Model
{
    // Mass Assignment hatasını çözen satır:
    // Tüm sütunların doldurulmasına izin ver.
    protected $guarded = [];

    // --- İLİŞKİLER (Opsiyonel ama faydalı) ---

    public function change()
    {
        return $this->belongsTo(QmsChange::class, 'change_id');
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }
}