<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AnalysisMethod extends Model
{
    use SoftDeletes;

    // guarded = [] yerine fillable kullanarak alanları netleştiriyoruz.
    protected $fillable = [
        'code',
        'name',
        'technique', // <--- YENİ EKLENEN ALAN
        'version',
        'status',
        'description',
        'procedure',
        'equipment_needs',
        'procedure_pdf',
        'chemical_needs',
        'calculation_formula',
        'created_by',
        'approved_by',
        'approved_at'
    ];

    protected $casts = [
        'approved_at' => 'datetime',
    ];

    // Hazırlayan
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    // Onaylayan
    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    /**
     * Metoda bağlı cihazlar (Many-to-Many)
     */
    public function devices()
    {
        // Eğer pivot tablonun adı farklıysa 'analysis_method_device' kısmını kendi tablo adına göre değiştir.
        return $this->belongsToMany(Device::class, 'analysis_method_device', 'analysis_method_id', 'device_id');
    }

    /**
     * Metoda bağlı kimyasallar/malzemeler (Many-to-Many)
     */
    public function materials()
    {
        // Eğer pivot tablonun adı farklıysa 'analysis_method_material' kısmını kendi tablo adına göre değiştir.
        return $this->belongsToMany(Material::class, 'analysis_method_material', 'analysis_method_id', 'material_id');
    }
}