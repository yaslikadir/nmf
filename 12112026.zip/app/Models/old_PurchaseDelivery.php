<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PurchaseDelivery extends Model
{
    protected $guarded = [];
    protected $casts = ['delivery_date' => 'date'];

    public function order() { return $this->belongsTo(PurchaseOrder::class, 'purchase_order_id'); }
    public function items() { return $this->hasMany(PurchaseDeliveryItem::class); }
    public function receiver() { return $this->belongsTo(User::class, 'received_by'); }
}