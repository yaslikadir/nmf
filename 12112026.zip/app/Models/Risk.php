<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Risk extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'code', 'type', 'category', 'description', 'source', 'potential_impact',
        'department_id', 'probability', 'impact', 'risk_score', 'risk_level',
        'status', 'owner_id', 'created_by', 'review_date'
    ];
    
    // İlişkiler
    public function owner() {
        return $this->belongsTo(User::class, 'owner_id');
    }
    
    public function creator() {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function department() {
        return $this->belongsTo(Department::class);
    }

    public function actions() {
        return $this->hasMany(RiskAction::class);
    }

    // DÖF (CAPA) İlişkisi - DÜZELTİLDİ
    public function capas()
    {
        // 'rreturn' hatası düzeltildi -> 'return'
        return $this->hasMany(QmsCapa::class, 'risk_id');
    }

    // Skor ve Seviye Hesaplama Fonksiyonu
    public static function calculateLevel($score) {
        if ($score >= 15) return 'Critical'; // 15-25: Kritik
        if ($score >= 8) return 'High';      // 8-12: Yüksek
        if ($score >= 4) return 'Medium';    // 4-6: Orta
        return 'Low';                        // 1-3: Düşük
    }

    // Model kaydedilirken otomatik hesaplama
    protected static function boot()
    {
        parent::boot();

        static::saving(function ($risk) {
            // Skoru hesapla: Olasılık x Etki
            $risk->risk_score = $risk->probability * $risk->impact;
            // Seviyeyi belirle
            $risk->risk_level = self::calculateLevel($risk->risk_score);
            
            // Eğer kod yoksa oluştur (Sadece yeni kayıtta)
            if (empty($risk->code)) {
                $risk->code = 'RSK-' . date('Y') . '-' . rand(1000, 9999);
            }
        });
    }

    public function histories()
{
    return $this->hasMany(RiskHistory::class);
}
}