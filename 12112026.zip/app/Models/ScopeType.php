<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ScopeType extends Model
{
    use SoftDeletes;

    protected $table = 'scope_types';
    protected $fillable = ['name', 'code', 'is_active'];

    /**
     * Bu Kapsam Tipine Ait Tablolar
     */
    public function tables(): HasMany
    {
        return $this->hasMany(ScopeTable::class, 'scope_type_id');
    }

    /**
     * Bu Kapsam Tipine Ait Tüm Parametreler
     */
    public function parameters(): HasMany
    {
        return $this->hasMany(ScopeParameter::class, 'scope_type_id');
    }
}