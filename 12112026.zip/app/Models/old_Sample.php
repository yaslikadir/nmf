<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Sample extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'barcode', 'offer_id', 'customer_id', 'status', 'report_file', 
        'accepted_at', 'completed_at', 'expiration_date', 'accepted_by', 'storage_location_id',
        'arrival_type', 'sampler_id', 'description', 'analysis_summary', 
        'sampling_location', 'sampling_time', 'sampling_method', 'sampling_notes',
        'global_status', 'acceptor_id','selected_sub_parameters',
        
        // YENİ EKLENEN SAHA VE GELİŞMİŞ DETAY ALANLARI
        'packaging_type', 'coordinate_x', 'coordinate_y', 
        'sampling_start_date', 'sampling_end_date', 'sampling_purpose', 
        'sampling_standard', 'is_protected', 'transport_method', 
        'seal_number', 'total_volume', 'environment_temp', 
        'has_witness_sample', 'witness_seal_number', 'report_number', 
        'pre_treatments',

        // YENİ EKLENEN DİJİTAL AYAK İZİ ALANLARI
        'lab_accepted_by', 'lab_accepted_at', 'lab_acceptance_note'
    ];

    protected $casts = [
        'created_at' => 'datetime', 'updated_at' => 'datetime',
        'accepted_at' => 'datetime', 'completed_at' => 'datetime',
        'expiration_date' => 'date', 'sampling_time' => 'datetime',
        'lab_accepted_at' => 'datetime', 
        'selected_sub_parameters' => 'array',// YENİ
    ];

    public function offer() { return $this->belongsTo(Offer::class); }
    public function items() { return $this->hasMany(SampleItem::class); }
    public function workOrders() { return $this->hasMany(AnalysisWorkOrder::class, 'sample_id'); }
    
    // Kabulü Yapan Depo/Numune Kabul Personeli
    public function acceptor() { return $this->belongsTo(User::class, 'acceptor_id'); }
    
    // YENİ: Laboratuvarda Teslim Alan Analist
    public function labAcceptor() { return $this->belongsTo(User::class, 'lab_accepted_by'); }
    
    public function storageLocation() { return $this->belongsTo(StorageLocation::class); }
    public function measurementPlan() { return $this->hasOne(MeasurementPlan::class, 'sample_id'); }
    public function preparations() { return $this->hasMany(SamplePreparation::class, 'sample_id'); }

    public function getSampleDetails($id)
    {
        $sample = \App\Models\Sample::with(['offer.customer', 'storageLocation'])->find($id);
        if(!$sample) return response()->json(['status' => 'error', 'message' => 'Numune bulunamadı.']);
        return response()->json(['status' => 'success', 'data' => $sample]);
    }
}