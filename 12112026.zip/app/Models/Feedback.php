<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Feedback extends Model
{
    use SoftDeletes;
    protected $guarded = [];
    protected $table = 'feedbacks';

    // Dinamik verileri otomatik diziye çevir
    protected $casts = [
        'data' => 'array'
        
    ];

    // Hangi forma ait?
    public function form()
    {
        return $this->belongsTo(FeedbackForm::class, 'feedback_form_id');
    }

    // Kime atandı?
    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_user_id');
    }
    
    // Tarihçe
    public function activities()
    {
        return $this->hasMany(FeedbackActivity::class);
    }
}