<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsDocumentApproval extends Model
{
    protected $guarded = [];

    protected $casts = [
        'action_date' => 'datetime',
    ];

    public function version()
    {
        return $this->belongsTo(QmsDocumentVersion::class, 'document_version_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    // Onay bekleyen kayıtları bulmak için scope
    public function scopePending($query)
    {
        return $query->where('status', 'Pending');
    }
}