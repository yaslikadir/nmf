<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TurkakDocument extends Model
{
    use HasFactory;
    protected $guarded = [];
    protected $casts = ['raw_data' => 'array', 'uploaded_at' => 'datetime'];
}