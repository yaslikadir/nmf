<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Setting extends Model
{
    protected $guarded = [];

    // Ayarı getirmek için yardımcı metod (Cache kullanarak hızlandırıyoruz)
    public static function get($key, $default = null)
    {
        return Cache::rememberForever('setting_' . $key, function () use ($key, $default) {
            $setting = self::where('key', $key)->first();
            return $setting ? $setting->value : $default;
        });
    }

    // Ayar güncellendiğinde Cache'i temizle
    protected static function boot()
    {
        parent::boot();
        static::saved(function ($setting) {
            Cache::forget('setting_' . $setting->key);
        });
    }
}