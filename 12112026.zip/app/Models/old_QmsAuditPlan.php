<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class QmsAuditPlan extends Model
{
    use SoftDeletes;
    protected $guarded = [];

    public function audits()
    {
        return $this->hasMany(QmsAudit::class, 'audit_plan_id');
    }
    
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}