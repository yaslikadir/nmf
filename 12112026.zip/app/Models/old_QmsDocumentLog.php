<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsDocumentLog extends Model
{
    // Log tablosu olduğu için timestamps false yapılabilir, 
    // ama created_at'i migration'da useCurrent() yaptık, o yüzden dokunmuyoruz.
    public $timestamps = false; 

    protected $guarded = [];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    public function document()
    {
        return $this->belongsTo(QmsDocument::class, 'document_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}