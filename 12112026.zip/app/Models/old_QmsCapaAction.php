<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsCapaAction extends Model
{
    protected $guarded = [];
    protected $casts = ['due_date' => 'date', 'completed_at' => 'date'];

    public function capa()
    {
        return $this->belongsTo(QmsCapa::class);
    }

    public function responsible()
    {
        return $this->belongsTo(User::class, 'responsible_user_id');
    }
}