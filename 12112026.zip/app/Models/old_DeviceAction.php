<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeviceAction extends Model
{
    use HasFactory;

    protected $fillable = [
        'device_id',
        'action_type', // Arıza, Taşıma, Kullanım
        'description',
        'user_id',
        'action_date',
        'status' // Açık, Çözüldü
    ];

    protected $casts = [
        'action_date' => 'datetime'
    ];

    public function device()
    {
        return $this->belongsTo(Device::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}