<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class OfferItem extends Model {
    protected $guarded = [];
    
    public function parameter()
    {
        return $this->belongsTo(ScopeParameter::class, 'scope_parameter_id');
    }

    public function scopeParameter()
    {
        return $this->belongsTo(ScopeParameter::class, 'scope_parameter_id');
    }
    
    // Düzeltildi: Null-safe operator eklendi
    public function getNameAttribute()
    {
        return $this->scopeParameter?->name ?? 'Tanımsız Hizmet'; 
    }
}