<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingEvaluation extends Model
{
    protected $guarded = [];

    public function record()
    {
        return $this->belongsTo(TrainingRecord::class, 'training_record_id');
    }
}