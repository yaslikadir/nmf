<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PurchaseDeliveryItem extends Model
{
    protected $guarded = [];
    // Teklif kalemiyle (Sipariş satırı) ilişki
    public function orderItem() { return $this->belongsTo(PurchaseOfferItem::class, 'purchase_offer_item_id'); }
}