<?php

namespace App\Models;

use App\Traits\HasPermissionScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes; // Eklendi
use Illuminate\Support\Facades\Auth;

class Activity extends Model
{
    use HasPermissionScope, SoftDeletes; // SoftDeletes eklendi

    protected $fillable = [
        'customer_id', 
        'contact_id', 
        'type', 
        'subject', 
        'description', 
        'date', 
        'status', 
        'created_by'
    ];

    protected $casts = [
        'date' => 'datetime',
        'created_at' => 'datetime'
    ];

    /**
     * MODEL BOOT METODU
     */
    protected static function booted()
    {
        // 1. OTOMATİK YETKİ FİLTRESİ
        static::addGlobalScope('permission_filter', function (Builder $builder) {
            if (Auth::check() && !app()->runningInConsole()) {
                $builder->withPermission('activities');
            }
        });

        // 2. VARSAYILAN SIRALAMA (En yeni görüşme en üstte)
        static::addGlobalScope('latest_first', function (Builder $builder) {
            $builder->orderBy('date', 'desc');
        });

        // 3. KAYIT SIRASINDA OTOMATİK ATAMALAR
        static::creating(function ($activity) {
            if (Auth::check()) {
                $activity->created_by = Auth::id();
            }
        });
    }

    
    /*
    |--------------------------------------------------------------------------
    | İLİŞKİLER
    |--------------------------------------------------------------------------
    */

    public function customer()
    {
        // Aktivitenin bağlı olduğu müşteri gizli olmasın
        return $this->belongsTo(Customer::class)->withoutGlobalScopes();
    }

    public function contact()
    {
        // Aktivitenin bağlı olduğu kontak gizli olmasın
        return $this->belongsTo(Contact::class)->withoutGlobalScopes();
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by')->withTrashed();
    }
}