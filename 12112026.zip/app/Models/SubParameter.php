<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubParameter extends Model
{
    protected $fillable = ['scope_parameter_id', 'code', 'name', 'unit', 'limit_min', 'limit_max'];

    public function mainParameter()
    {
        return $this->belongsTo(ScopeParameter::class, 'scope_parameter_id');
    }
}