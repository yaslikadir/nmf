<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Builder;

class Department extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * Tablo ismi açıkça belirtilirse Laravel yanılmaz.
     */
    protected $table = 'departments';

    /**
     * Toplu atama yapılacak alanlar.
     */
    protected $fillable = [
        'name', 
        'code', 
        'is_active'
    ];

    /**
     * Veri tipi dönüşümleri.
     * is_active alanını otomatik boolean yaparak 1/0 karmaşasını çözeriz.
     */
    protected $casts = [
        'is_active' => 'boolean',
    ];

    /*
    |--------------------------------------------------------------------------
    | SCOPES (Sorgu Kapsamları)
    |--------------------------------------------------------------------------
    */

    /**
     * "active()" metodunun çalışmasını sağlayan Local Scope.
     * Kullanımı: Department::active()->get();
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    /*
    |--------------------------------------------------------------------------
    | İLİŞKİLER (RELATIONSHIPS)
    |--------------------------------------------------------------------------
    */

    /**
     * İlişki: Bu departmana bağlı kullanıcılar/personeller.
     */
    public function users(): HasMany
    {
        // Dış anahtarı (foreign key) açıkça belirtmek ilişkiyi garantiye alır.
        return $this->hasMany(User::class, 'department_id', 'id');
    }

    public function tasks()
{
    return $this->hasMany(Task::class, 'department_id');
}




}