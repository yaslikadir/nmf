<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class ScopeTable extends Model
{
    use SoftDeletes;

    protected $table = 'scope_tables';
    protected $fillable = ['scope_type_id', 'name', 'is_active'];

    /**
     * Bu Tablonun Ait Olduğu Kapsam Tipi
     */
    public function scopeType(): BelongsTo
    {
        return $this->belongsTo(ScopeType::class, 'scope_type_id');
    }

    /**
     * Tabloya bağlı parametreler (Çok-a-Çok İlişkisi)
     * Pivot tablo adını 'scope_table_parameter' olarak sabitledik.
     */
    public function parameters(): BelongsToMany
    {
        return $this->belongsToMany(
            ScopeParameter::class, 
            'scope_table_parameter', 
            'scope_table_id', 
            'scope_parameter_id'
        )->withTimestamps();
    }
}