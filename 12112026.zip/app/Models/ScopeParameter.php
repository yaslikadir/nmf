<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class ScopeParameter extends Model
{
    use SoftDeletes;

    protected $table = 'scope_parameters';

    protected $fillable = [
        'scope_type_id', 
        'name', 
        'scope_category', // <--- Yeni eklediğimiz alan
        'unit',             
        'limit_min',        
        'limit_max', 
        'analysis_duration',    
        'can_be_urgent',
        'duration_unit',
        'standard_ref',     
        'tat',              
        'is_accredited',
        'gov_price', 
        'external_price', 
        'analysis_methods', 
        'analysis_techniques', 
        'storage_conditions', 
        'needs_sample', 
        'is_active'
    ];

    /**
     * Parametrenin bağlı olduğu Kapsam Tipi
     */
    public function scopeType(): BelongsTo
    {
        return $this->belongsTo(ScopeType::class, 'scope_type_id');
    }
    
    /**
     * Bu parametrenin kullanıldığı tablolar (ScopeTable)
     * Pivot tablo adını 'scope_table_parameter' olarak sabitledik (ScopeTable ile uyumlu).
     */
    public function tables(): BelongsToMany
    {
        return $this->belongsToMany(
            ScopeTable::class, 
            'scope_table_parameter', 
            'scope_parameter_id', 
            'scope_table_id'
        )->withTimestamps();
    }

    public function subParameters()
    {
        return $this->hasMany(SubParameter::class, 'scope_parameter_id');
    }
}