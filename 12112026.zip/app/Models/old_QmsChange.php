<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class QmsChange extends Model
{
    use SoftDeletes;
    protected $guarded = [];

    protected $casts = [
        'approved_at' => 'datetime',
        'closed_date' => 'date',
    ];

    // İlişkiler
    public function requester() {
        return $this->belongsTo(User::class, 'request_user_id');
    }

    public function approver() {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function department() {
        return $this->belongsTo(Department::class);
    }

    public function risks() {
        return $this->hasMany(QmsChangeRisk::class, 'change_id');
    }

    public function actions() {
        return $this->hasMany(QmsChangeAction::class, 'change_id');
    }

    // Accessor: Türkçe Tip
    public function getTypeLabelAttribute() {
        $map = [
            'Procedure' => 'Prosedür / Doküman',
            'Equipment' => 'Cihaz / Ekipman',
            'Software' => 'Yazılım',
            'Personnel' => 'Personel / Organizasyon',
            'Facility' => 'Tesis / Altyapı',
            'Other' => 'Diğer'
        ];
        return $map[$this->type] ?? $this->type;
    }

    // Accessor: Türkçe Durum
    public function getStatusLabelAttribute() {
        $map = [
            'Draft' => ['text' => 'Taslak', 'class' => 'bg-secondary'],
            'Pending_Analysis' => ['text' => 'Risk Analizi Bekliyor', 'class' => 'bg-warning text-dark'],
            'Pending_Approval' => ['text' => 'Onay Bekliyor', 'class' => 'bg-info text-dark'],
            'Approved' => ['text' => 'Onaylandı / Uygulamada', 'class' => 'bg-primary'],
            'Rejected' => ['text' => 'Reddedildi', 'class' => 'bg-danger'],
            'Completed' => ['text' => 'Tamamlandı', 'class' => 'bg-success'],
            'Closed' => ['text' => 'Kapatıldı', 'class' => 'bg-dark']
        ];
        return $map[$this->status] ?? ['text' => $this->status, 'class' => 'bg-secondary'];
    }

    public function attachments() {
    return $this->hasMany(QmsChangeAttachment::class, 'change_id');
}
}