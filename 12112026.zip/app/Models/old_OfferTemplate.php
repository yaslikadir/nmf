<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class OfferTemplate extends Model
{
    use HasFactory;

    // Veritabanı tablosunun adı (Laravel otomatik bulur ama garanti olsun)
    protected $table = 'offer_templates';

    /**
     * Toplu atama yapılabilecek alanlar.
     * Eski alanları koruduk, yeni 'file_path' ve 'type' alanlarını ekledik.
     */
    protected $fillable = [
        'name',
        'file_path',    // Yeni: ODT dosyasının sunucudaki yolu
        'type',         // Yeni: 'odt' veya 'html' (Eski kayıtlarla uyumluluk için)
        'html_content', // Eski: Geriye dönük uyumluluk için kalsın
        'css_content',  // Eski: Geriye dönük uyumluluk için kalsın
        'is_default'
    ];

    /**
     * Varsayılan değerler (Opsiyonel)
     */
    protected $attributes = [
        'type' => 'odt', // Yeni eklenenler varsayılan olarak ODT olsun
        'is_default' => false,
    ];
}