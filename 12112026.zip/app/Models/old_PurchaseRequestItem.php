<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PurchaseRequestItem extends Model
{
    use HasFactory;

    protected $guarded = [];

    // İLİŞKİLER

    // 1. Hangi Talebe Ait?
    public function purchaseRequest()
    {
        return $this->belongsTo(PurchaseRequest::class);
    }

    // 2. Hangi Malzeme?
    public function material()
    {
        return $this->belongsTo(Material::class);
    }
}