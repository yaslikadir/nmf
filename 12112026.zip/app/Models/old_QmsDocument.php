<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class QmsDocument extends Model
{
    use SoftDeletes;

    protected $guarded = [];

    // İlişkiler
    public function folder()
    {
        return $this->belongsTo(QmsDocumentFolder::class, 'folder_id');
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    // Dokümanın tüm tarihçesi (Eskiden yeniye)
    public function versions()
    {
        return $this->hasMany(QmsDocumentVersion::class, 'document_id')->orderBy('id', 'desc');
    }

    // Dokümana ait loglar (Audit Trail)
    public function logs()
    {
        return $this->hasMany(QmsDocumentLog::class, 'document_id')->orderBy('created_at', 'desc');
    }

    // --- ÖZEL İLİŞKİLER (HELPERS) ---

    // Şu an YAYINDA (Published) olan geçerli versiyon
    public function publishedVersion()
    {
        return $this->hasOne(QmsDocumentVersion::class, 'document_id')
                    ->where('status', 'Published')
                    ->latest('id'); // En son yayınlanan
    }

    // Üzerinde çalışılan son TASLAK (Draft) - Varsa
    public function draftVersion()
    {
        return $this->hasOne(QmsDocumentVersion::class, 'document_id')
                    ->whereIn('status', ['Draft', 'InReview'])
                    ->latest('id');
    }

    /**
     * Dokümana ait dağıtım (tebliğ) kayıtları
     */
    /**
     * Dokümanın revizyonları üzerinden dağıtım kayıtlarını bul (HasManyThrough)
     */
    public function distributions()
    {
        return $this->hasManyThrough(
            \App\Models\QmsDocumentDistribution::class, 
            \App\Models\QmsDocumentVersion::class,
            'document_id',          // Versiyon tablosundaki foreign key
            'document_version_id',  // Dağıtım tablosundaki foreign key
            'id',                   // Doküman tablosundaki local key
            'id'                    // Versiyon tablosundaki local key
        );
    }
}