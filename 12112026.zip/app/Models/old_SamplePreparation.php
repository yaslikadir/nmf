<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SamplePreparation extends Model
{
    use HasFactory;

    /**
     * Toplu atamaya (Mass Assignment) karşı korumalı olmayan alanlar.
     * Boş bırakıldığı için tüm alanlar (secret_note dahil) otomatik eklenebilir.
     */
    protected $guarded = [];
    
    /**
     * Veri tiplerinin otomatik dönüştürülmesi (Casting).
     */
    protected $casts = [
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
    ];

    /**
     * Bu ön işlemin ait olduğu numune.
     */
    public function sample()
    {
        return $this->belongsTo(Sample::class);
    }

    /**
     * İşlemi gerçekleştiren teknisyen/analist.
     */
    public function technician()
    {
        return $this->belongsTo(User::class, 'technician_id');
    }

    /**
     * İşlem sırasında kullanılan cihaz.
     */
    public function device()
    {
        return $this->belongsTo(Device::class);
    }
    
    /**
     * Hangi teklif parametresi (analiz) için yapılıyorsa.
     */
    public function offerItem()
    {
        return $this->belongsTo(OfferItem::class);
    }
}