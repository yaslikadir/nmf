<?php

namespace App\Models;

use Spatie\Permission\Models\Role as SpatieRole;

class Role extends SpatieRole
{
    // Dinamik yetki matrisiyle olan ilişki
    public function rolePermissions()
    {
        return $this->hasMany(RolePermission::class, 'role_id');
    }

    protected $casts = [
        'menu_permissions' => 'array',
    ];

    
    
}