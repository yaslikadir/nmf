<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Training extends Model
{
    use SoftDeletes;

    protected $guarded = [];

    /** Personel dosyasında eğitimin hangi bölümde gösterileceği. */
    public const PROFILE_CATEGORIES = [
        'general' => 'Genel Eğitim',
        'orientation' => 'Oryantasyon',
        'authorization_training' => 'Yetkilendirme Eğitimi',
    ];

    public function getProfileCategoryLabelAttribute(): string
    {
        return self::PROFILE_CATEGORIES[$this->profile_category ?? 'general'] ?? 'Genel Eğitim';
    }

    // --- İLİŞKİLER ---

    // Materyaller
    public function materials() {
        return $this->hasMany(TrainingMaterial::class);
    }

    // Sorular
    public function questions() {
        return $this->hasMany(ExamQuestion::class);
    }
    
    // Planlar
    public function plans() {
        return $this->hasMany(TrainingPlan::class);
    }

    // --- DÜZELTİLEN KISIM ---
    public function getRatingStatsAttribute()
    {
        // YÖNTEM: İlişkiler zincirini kullan (Evaluation -> Record -> Plan -> Training)
        // Bu sayede 'training_plan_id' mi 'plan_id' mi diye tahmin etmeye gerek kalmaz.
        
        $evaluations = TrainingEvaluation::whereHas('record.plan', function ($query) {
            // Kaydın bağlı olduğu planın, bu eğitime (this->id) ait olup olmadığına bakar
            $query->where('training_id', $this->id);
        })->get();

        // Hesaplama
        if($evaluations->isEmpty()) {
            return ['average' => 0, 'count' => 0];
        }

        return [
            'average' => number_format($evaluations->avg('rating'), 1), // Örn: 4.5
            'count' => $evaluations->count() // Örn: 12
        ];
    }
}