<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelCompetencyRenewalLog extends Model
{
    protected $fillable = [
        'user_id', 'assessment_id', 'previous_review_date', 'new_review_date',
        'monitoring_period_years', 'result', 'notes', 'changed_by',
    ];

    protected function casts(): array
    {
        return [
            'previous_review_date' => 'date',
            'new_review_date' => 'date',
        ];
    }

    public function assessment()
    {
        return $this->belongsTo(PersonnelCompetencyAssessment::class, 'assessment_id');
    }

    public function changedBy()
    {
        return $this->belongsTo(User::class, 'changed_by');
    }
}
