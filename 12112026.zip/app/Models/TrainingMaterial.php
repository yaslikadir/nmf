<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingMaterial extends Model
{
    // Tüm alanların doldurulmasına izin ver
    protected $guarded = [];

    // --- İLİŞKİLER ---

    // Bu materyal hangi eğitime ait?
    public function training()
    {
        return $this->belongsTo(Training::class, 'training_id');
    }
}