<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelAuthorizationDocument extends Model
{
    protected $fillable = [
        'authorization_id', 'document_name', 'file_path', 'original_name',
        'mime_type', 'file_size', 'uploaded_by',
    ];

    public function authorization()
    {
        return $this->belongsTo(PersonnelAuthorization::class, 'authorization_id');
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }
}
