<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelScopeAuthorization extends Model
{
    protected $fillable = [
        'user_id', 'scope_type_id', 'scope_code', 'scope_title', 'discipline', 'matrix_material',
        'parameter', 'method_reference', 'method_version', 'equipment_reference', 'location',
        'authorization_level', 'status', 'authorized_from', 'review_date', 'expires_at',
        'approved_by', 'conditions', 'evidence_notes', 'decision_reason',
    ];

    protected function casts(): array
    {
        return [
            'authorized_from' => 'date',
            'review_date' => 'date',
            'expires_at' => 'date',
        ];
    }

    public function user() { return $this->belongsTo(User::class); }
    public function scopeType() { return $this->belongsTo(ScopeType::class); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
}
