<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OfferRevision extends Model
{
    // pdf_path alanını ekledik
    protected $fillable = ['offer_id', 'revision_number', 'revision_note', 'user_id', 'pdf_path'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}