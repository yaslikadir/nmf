<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PurchaseOffer extends Model
{
    protected $guarded = [];
    protected $casts = ['offer_date' => 'date', 'valid_until' => 'date'];

    public function request() { return $this->belongsTo(PurchaseRequest::class, 'purchase_request_id'); }
    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function items() { return $this->hasMany(PurchaseOfferItem::class); }
}