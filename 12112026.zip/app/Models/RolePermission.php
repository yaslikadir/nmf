<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RolePermission extends Model
{
    protected $fillable = [
        'role_id', 
        'module_id', 
        'view_level', 
        'can_create', 
        'update_level', 
        'delete_level', 
        'can_export'
    ];

    public function module()
    {
        return $this->belongsTo(Module::class);
    }
}