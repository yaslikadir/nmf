<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;

class Definition extends Model
{
    protected $fillable = [
        'branch_id', 'type', 'group_key', 'group_label', 'label',
        'value', 'sort_order', 'color_code', 'is_active',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope('active_branch', function (Builder $builder): void {
            $table = $builder->getModel()->getTable();
            $branchId = (int) session('active_branch_id', 1);

            if ($branchId <= 0) {
                $branchId = 1;
            }

            if (Schema::hasTable($table) && Schema::hasColumn($table, 'branch_id')) {
                $builder->where($table . '.branch_id', $branchId);
            }
        });

        static::creating(function (self $definition): void {
            $branchId = (int) session('active_branch_id', 1);
            if ($branchId <= 0) {
                $branchId = 1;
            }
            if (Schema::hasColumn($definition->getTable(), 'branch_id')) {
                $definition->setAttribute('branch_id', $branchId);
            }
        });

        static::updating(function (self $definition): void {
            if ($definition->isDirty('branch_id')) {
                $definition->setAttribute('branch_id', $definition->getOriginal('branch_id'));
            }
        });
    }

    public function scopeByGroup(Builder $query, string $group): Builder
    {
        return $query->where('group_key', $group)->orderBy('sort_order');
    }
}