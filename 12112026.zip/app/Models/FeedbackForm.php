<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class FeedbackForm extends Model
{
    use SoftDeletes;
    protected $guarded = [];

    // Formun Alanları (Soruları)
    public function fields()
    {
        return $this->hasMany(FeedbackFormField::class)->orderBy('order');
    }

    // Bu formdan gelen yanıtlar
    public function feedbacks()
    {
        return $this->hasMany(Feedback::class);
    }
}