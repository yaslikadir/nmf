<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// App\Models\StorageLocation.php
class StorageLocation extends Model {
    protected $guarded = [];
    
    public function samples() {
        return $this->hasMany(Sample::class);
    }
}