<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QmsAuditFinding extends Model
{
    protected $guarded = [];

    public function audit()
    {
        return $this->belongsTo(QmsAudit::class);
    }

    public function question()
    {
        return $this->belongsTo(QmsAuditQuestion::class);
    }
}