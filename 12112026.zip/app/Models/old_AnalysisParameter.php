<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AnalysisParameter extends Model
{
    use SoftDeletes;
    protected $guarded = [];

    // Birim ilişkisi
    public function unit()
    {
        return $this->belongsTo(AnalysisUnit::class, 'unit_id');
    }
}