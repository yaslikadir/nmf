<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Announcement extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'link', 'date_text', 'source', 'is_read', 'published_at' ];

    protected $casts = [
        'published_at' => 'datetime',
    ];
}