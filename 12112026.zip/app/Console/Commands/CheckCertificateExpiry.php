<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TrainingRecord;
use Illuminate\Support\Facades\Notification;
use App\Notifications\CertificateExpiryNotification;
use Carbon\Carbon;

class CheckCertificateExpiry extends Command
{
    protected $signature = 'qms:check-expiry';
    protected $description = 'Süresi dolmak üzere olan sertifikaları kontrol eder ve bildirim atar.';

    public function handle()
    {
        $this->info('Sertifika geçerlilik kontrolü başladı...');
        
        // 1. Sadece "Geçmiş" (Passed) olan kayıtları al
        // İlişkileri yüklüyoruz ki döngü içinde tekrar sorgu atmasın (Performance)
        $records = TrainingRecord::with(['plan.training', 'user'])
                    ->where('result', 'Passed')
                    ->get();

        $count = 0;

        foreach ($records as $record) {
            $training = $record->plan->training;

            // Eğer eğitimin bir geçerlilik süresi yoksa (null veya 0) atla
            if (!$training->validity_months) {
                continue;
            }

            // Sertifika Tarihi (Sınavı geçtiği tarih)
            $certifiedDate = $record->updated_at;
            
            // Bitiş Tarihi Hesapla
            $expiryDate = $certifiedDate->copy()->addMonths($training->validity_months);
            
            // Bugün
            $now = Carbon::now();

            // Kontrol 1: Tam 30 gün kaldıysa
            if ($expiryDate->isSameDay($now->copy()->addDays(30))) {
                $this->sendNotification($record, 30);
                $count++;
            }
            
            // Kontrol 2: Tam 7 gün kaldıysa (Son uyarı)
            if ($expiryDate->isSameDay($now->copy()->addDays(7))) {
                $this->sendNotification($record, 7);
                $count++;
            }
        }

        $this->info("İşlem tamamlandı. Toplam {$count} kişiye uyarı gönderildi.");
    }

    private function sendNotification($record, $daysLeft)
    {
        try {
            $record->user->notify(new CertificateExpiryNotification($record, $daysLeft));
            $this->info("Uyarı gönderildi: {$record->user->name} ({$daysLeft} gün kaldı)");
        } catch (\Exception $e) {
            $this->error("Hata: " . $e->getMessage());
        }
    }
}