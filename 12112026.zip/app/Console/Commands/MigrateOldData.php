<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateOldData extends Command
{
    protected $signature = 'app:migrate-old-data {--sql=eski_veriler_mysql-pro.sql}';
    protected $description = 'Eski veritabanı verilerini brand_id / branch_id = 1 olacak şekilde pro_v2 veritabanına güvenle aktarır.';

    protected array $excludedTables = [
        'migrations',
        'cache',
        'cache_locks',
        'sessions',
        'jobs',
        'job_batches',
        'failed_jobs',
        'password_reset_tokens',
        'personal_access_tokens',
        'brands',
        'branches',
    ];

    public function handle()
    {
        $sqlFile = base_path($this->option('sql'));

        if (!file_exists($sqlFile)) {$this->error("SQL dosyası bulunamadı: {$sqlFile}");
            return 1;
        }

        $targetDb = config('database.connections.mysql.database');
        $tempDb = 'temp_old_pro_migration';$dbUser = config('database.connections.mysql.username');
        $dbPass = config('database.connections.mysql.password');$dbHost = config('database.connections.mysql.host', '127.0.0.1');

        $this->info("Hedef Veritabanı: {$targetDb}");
        $this->info("1/5 - Geçici veritabanı ({$tempDb}) hazırlanıyor...");
        DB::statement("DROP DATABASE IF EXISTS `{$tempDb}`");
        DB::statement("CREATE DATABASE `{$tempDb}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

        $this->info("2/5 - Eski SQL yedek dosyası geçici veritabanına yükleniyor...");
        $passArg = $dbPass ? "-p" . escapeshellarg($dbPass) : "";
        $cmd = sprintf(
            "mysql -h %s -u %s %s %s < %s 2>&1",
            escapeshellarg($dbHost),
            escapeshellarg($dbUser),$passArg,
            escapeshellarg($tempDb),
            escapeshellarg($sqlFile)
        );
        exec($cmd, $output,$returnVar);

        if ($returnVar !== 0) {$this->error("SQL yüklenirken hata oluştu:\n" . implode("\n", $output));
            return 1;
        }

        $this->info("3/5 - Tablo yapıları eşleştiriliyor ve veriler aktarılıyor...");

        $oldTables = DB::select("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_TYPE = 'BASE TABLE'", [$tempDb]);

        // Strict mode ve Foreign Key kontrollerini geçici kapat (NOT NULL default olmayan yeni sütunların INSERT'ü engellememesi için)
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        DB::statement("SET SESSION sql_mode='';");

        foreach ($oldTables as$t) {
            $tableName =$t->TABLE_NAME;

            if (in_array($tableName,$this->excludedTables)) {
                continue;
            }

            $existsInTarget = DB::select("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?", [$targetDb,$tableName]);

            if (empty($existsInTarget)) {
                $this->warn("   [Yeni Tablo] '{$tableName}' oluşturuluyor...");
                DB::statement("CREATE TABLE `{$targetDb}`.`{$tableName}` LIKE `{$tempDb}`.`{$tableName}`");
            }

            $oldCols = DB::select("SHOW COLUMNS FROM `{$tempDb}`.`{$tableName}`");
            $targetCols = DB::select("SHOW COLUMNS FROM `{$targetDb}`.`{$tableName}`");
            $targetColNames = array_map(fn($c) => $c->Field,$targetCols);

            foreach ($oldCols as$col) {
                if (!in_array($col->Field, $targetColNames)) {$nullSql = ($col->Null === 'YES') ? 'NULL' : 'NOT NULL';$defaultSql = '';
                    if ($col->Default !== null) {
                        if (strtoupper($col->Default) === 'CURRENT_TIMESTAMP' || strtoupper($col->Default) === 'CURRENT_TIMESTAMP()') {$defaultSql = "DEFAULT CURRENT_TIMESTAMP";
                        } else {
                            $defaultSql = "DEFAULT " . DB::getPdo()->quote($col->Default);
                        }
                    } elseif ($col->Null === 'YES') {$defaultSql = "DEFAULT NULL";
                    }

                    $this->warn("   [Eksik Sütun Eklendi] {$tableName}.{$col->Field}");
                    DB::statement("ALTER TABLE `{$targetDb}`.`{$tableName}` ADD COLUMN `{$col->Field}` {$col->Type} {$nullSql} {$defaultSql}");
                    $targetColNames[] =$col->Field;
                }
            }

            $oldColNames = array_map(fn($c) => $c->Field,$oldCols);
            $insertCols =$oldColNames;
            $selectCols = array_map(fn($c) => "`{$c}`", $oldColNames);

            // Hem brand_id hem branch_id kontrolü (hangisi varsa 1 basar)
            foreach (['brand_id', 'branch_id'] as $bCol) {
                if (in_array($bCol,$targetColNames)) {
                    if (!in_array($bCol,$oldColNames)) {
                        $insertCols[] =$bCol;
                        $selectCols[] = "1 AS `{$bCol}`";
                    } else {
                        $idx = array_search($bCol,$oldColNames);
                        $selectCols[$idx] = "1 AS `{$bCol}`";
                    }
                }
            }

            $insertColsStr = implode(', ', array_map(fn($c) => "`{$c}`", $insertCols));
            $selectColsStr = implode(', ',$selectCols);

            $sourceCount = DB::selectOne("SELECT COUNT(*) as cnt FROM `{$tempDb}`.`{$tableName}`")->cnt;

            if ($sourceCount > 0) {
                try {
                    // Mevcut verileri ezmeden / varsa güncelleyerek aktar (REPLACE INTO veya INSERT ... ON DUPLICATE KEY UPDATE)
                    $updatePairs = [];
                    foreach ($insertCols as$colName) {
                        if ($colName !== 'id') {$updatePairs[] = "`{$colName}` = VALUES(`{$colName}`)";
                        }
                    }
                    $updateSql = implode(', ',$updatePairs);

                    DB::statement("INSERT INTO `{$targetDb}`.`{$tableName}` ({$insertColsStr}) SELECT {$selectColsStr} FROM `{$tempDb}`.`{$tableName}` ON DUPLICATE KEY UPDATE {$updateSql}");

                    // İçerideki tüm kayıtların brand_id / branch_id değerini garanti 1 yap
                    foreach (['brand_id', 'branch_id'] as $bCol) {
                        if (in_array($bCol,$targetColNames)) {
                            DB::statement("UPDATE `{$targetDb}`.`{$tableName}` SET `{$bCol}` = 1 WHERE `{$bCol}` IS NULL OR `{$bCol}` = 0");
                        }
                    }

                    $targetCount = DB::selectOne("SELECT COUNT(*) as cnt FROM `{$targetDb}`.`{$tableName}`")->cnt;
                    $this->info("   [Başarılı] {$tableName}: Kaynak={$sourceCount} -> Hedef Tablodaki Toplam={$targetCount}");
                } catch (\Throwable $e) {$this->error("   [HATA - {$tableName}]: " . $e->getMessage());
                }
            }
        }

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        DB::statement("DROP DATABASE IF EXISTS `{$tempDb}`");

        // Laravel önbelleklerini de temizle
        $this->call('optimize:clear');

        $this->info("İşlem tamamlandı!");
        return 0;
    }
}