<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TrainingPlan;
use Illuminate\Support\Facades\Notification;
use App\Notifications\TrainingReminderNotification;
use Carbon\Carbon;

class SendTrainingReminders extends Command
{
    // Komutun terminaldeki adı (Bunu cron'a yazacağız)
    protected $signature = 'qms:send-reminders';

    // Komutun açıklaması
    protected $description = 'Yarın başlayacak eğitimler için personele hatırlatma gönderir.';

    public function handle()
    {
        $this->info('Eğitim hatırlatıcı taraması başladı...');

        // 1. YARIN BAŞLAYACAK PLANLARI BUL
        // whereDate kullanıyoruz ki saati ne olursa olsun yarınki tarihi yakalasın.
        $tomorrowPlans = TrainingPlan::where('status', 'Planned')
                            ->whereDate('start_date', Carbon::tomorrow())
                            ->with('records.user')
                            ->get();

        if($tomorrowPlans->isEmpty()) {
            $this->info('Yarın için planlanmış eğitim bulunamadı.');
            return;
        }

        $count = 0;

        foreach ($tomorrowPlans as $plan) {
            // Planın katılımcılarını al
            // Sadece 'Pending' (Henüz işlem yapmamış) veya 'Assigned' olanlara atalım.
            // İptal edilenlere atmayalım.
            $usersToNotify = $plan->records->map(function ($record) {
                return $record->user;
            })->filter(); // Boş kullanıcıları temizle

            if($usersToNotify->isNotEmpty()) {
                // Bildirimi Gönder
                Notification::send($usersToNotify, new TrainingReminderNotification($plan));
                
                $this->info("Plan ID: {$plan->id} - {$usersToNotify->count()} kişiye bildirim gönderildi.");
                $count += $usersToNotify->count();
            }
        }

        $this->info("İşlem Tamamlandı! Toplam {$count} hatırlatma gönderildi.");
    }
}