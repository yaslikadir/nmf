<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\QmsDocument;
use Carbon\Carbon;

class CheckDocumentRetention extends Command
{
    /**
     * Komutun adı (Terminalde çalıştırılacak isim)
     */
    protected $signature = 'qms:check-retention';

    /**
     * Komutun açıklaması
     */
    protected $description = 'Saklama süresi dolan dokümanları otomatik olarak iptal/arşiv statüsüne çeker.';

    public function handle()
    {
        $this->info('Doküman saklama süreleri kontrol ediliyor...');

        // Yayında olan (Published) dokümanları çek
        $documents = QmsDocument::with('publishedVersion')
                        ->where('status', 'Published')
                        ->whereNotNull('retention_period_years') // Süre tanımlı olanlar
                        ->get();

        $count = 0;

        foreach ($documents as $doc) {
            // Dokümanın yayınlanan versiyonu yoksa atla
            if (!$doc->publishedVersion || !$doc->publishedVersion->published_at) {
                continue;
            }

            // Son kullanma tarihini hesapla (Yayın Tarihi + Saklama Yılı)
            $publishDate = Carbon::parse($doc->publishedVersion->published_at);
            $expirationDate = $publishDate->copy()->addYears($doc->retention_period_years);

            // Eğer BUGÜN, son kullanma tarihini geçtiyse
            if (now()->greaterThan($expirationDate)) {
                
                // 1. Dokümanın durumunu güncelle
                $doc->update(['status' => 'Obsolete']);
                
                // 2. Versiyonun durumunu güncelle
                $doc->publishedVersion->update(['status' => 'Obsolete']);

                // 3. Logla (Sistem tarafından yapıldığını belirtmek için user_id null olabilir veya özel bir sistem kullanıcısı atanabilir)
                // Burada basitçe bilgi veriyoruz.
                $this->line("ARŞİVLENDİ: {$doc->document_code} - {$doc->name} (Süre: {$doc->retention_period_years} Yıl)");
                
                // Log tablosuna da ekleyebiliriz (Opsiyonel, modelde user_id nullable ise)
                 \App\Models\QmsDocumentLog::create([
                     'document_id' => $doc->id,
                     'user_id' => null, // Sistem işlemi
                     'action' => 'AUTO_ARCHIVE',
                     'details' => "Saklama süresi ($expirationDate) dolduğu için sistem tarafından arşivlendi."
                 ]);

                $count++;
            }
        }

        $this->info("İşlem tamamlandı. Toplam {$count} doküman arşivlendi.");
    }
}