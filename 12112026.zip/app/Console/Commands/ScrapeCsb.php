<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use Symfony\Component\DomCrawler\Crawler;
use App\Models\Announcement;
use Carbon\Carbon;

class ScrapeCsb extends Command
{
    protected $signature = 'scrape:csb {start_date?}';
    protected $description = 'ÇŞB Duyurularını Çeker (Sağlam Tarih Parse Edici)';

    public function handle()
    {
        $startDateInput = $this->argument('start_date');
        $filterDate = $startDateInput ? Carbon::parse($startDateInput) : Carbon::now()->subYears(5);

        $this->info('ÇŞB Taraması Başlıyor... Hedef: ' . $filterDate->format('d.m.Y'));

        // Sayısal Ay Karşılıkları (En garanti yöntem)
        $monthMap = [
            'ocak' => 1, 'şubat' => 2, 'mart' => 3, 'nisan' => 4, 'mayıs' => 5, 'haziran' => 6,
            'temmuz' => 7, 'ağustos' => 8, 'eylül' => 9, 'ekim' => 10, 'kasım' => 11, 'aralık' => 12,
            // Büyük/Küçük harf toleransı için
            'OCAK' => 1, 'ŞUBAT' => 2, 'MART' => 3, 'NİSAN' => 4, 'MAYIS' => 5, 'HAZİRAN' => 6,
            'TEMMUZ' => 7, 'AĞUSTOS' => 8, 'EYLÜL' => 9, 'EKİM' => 10, 'KASIM' => 11, 'ARALIK' => 12
        ];

        $page = 1;
        $totalAdded = 0;
        $stopScraping = false;

        do {
            $url = $page === 1 ? 'https://lab.csb.gov.tr/duyurular' : "https://lab.csb.gov.tr/duyurular/{$page}";
            $this->comment("Sayfa {$page} taranıyor...");

            try {
                $response = Http::timeout(30)->get($url);
                if ($response->failed()) break;

                $crawler = new Crawler($response->body());
                $cards = $crawler->filter('.duyurular-category-card-wrapper');

                if ($cards->count() === 0) break;

                $cards->each(function (Crawler $node) use (&$totalAdded, &$stopScraping, $filterDate, $monthMap) {
                    if ($stopScraping) return;

                    try {
                        // 1. Tarih Metnini Al ve Temizle
                        $dateTextRaw = $node->filter('.duyurular-category-card-body-wrapper span')->text();
                        // Fazla boşlukları tek boşluğa indir
                        $cleanDate = trim(preg_replace('/\s+/', ' ', $dateTextRaw));

                        // 2. Tarihi Parçala ve Oluştur (Regex: Gün Ay Yıl)
                        // Örn: "16 Haziran 2023" -> Matches: [16, "Haziran", 2023]
                        $publishedAt = null;
                        if (preg_match('/^(\d{1,2})\s+([a-zA-ZçğıöşüÇĞİÖŞÜ]+)\s+(\d{4})$/u', $cleanDate, $matches)) {
                            $day = $matches[1];
                            $monthName = mb_strtolower($matches[2], 'UTF-8'); // Küçük harfe çevir
                            $year = $matches[3];

                            // Ay ismini numaraya çevir
                            // monthMap içindeki küçük harfli anahtarları kullanmak için döngü
                            $monthNum = 1; // Varsayılan
                            foreach ($monthMap as $key => $val) {
                                if (mb_strtolower($key, 'UTF-8') == $monthName) {
                                    $monthNum = $val;
                                    break;
                                }
                            }
                            
                            $publishedAt = Carbon::create($year, $monthNum, $day, 0, 0, 0);
                        } else {
                            // Parse edilemezse null bırakmayalım, şu anı verelim ama loglayalım
                            $publishedAt = now();
                        }

                        // TARİH FİLTRESİ
                        if ($publishedAt->lt($filterDate)) {
                            $stopScraping = true;
                            return;
                        }

                        // Link ve Başlık
                        $link = $node->attr('href');
                        if (!str_starts_with($link, 'http')) $link = 'https://lab.csb.gov.tr' . $link;
                        $title = $node->filter('.duyurular-category-card-body-wrapper p')->text();

                        // KAYDET
                        $exists = Announcement::where('link', trim($link))->exists();
                        if (!$exists) {
                            Announcement::create([
                                'title'        => trim($title),
                                'link'         => trim($link),
                                'date_text'    => $cleanDate,
                                'source'       => 'ÇŞB Laboratuvar',
                                'is_read'      => false,
                                'published_at' => $publishedAt, // <-- ARTIK DOLU GELECEK
                                'created_at'   => $publishedAt, // Sıralama yedeği
                                'updated_at'   => $publishedAt
                            ]);
                            $totalAdded++;
                            $this->line("✅ Eklendi: " . mb_substr(trim($title), 0, 30) . "... ($cleanDate)");
                        }

                    } catch (\Exception $e) {
                         // Hata es geç
                    }
                });

                if ($stopScraping) {
                    $this->info("Hedef tarihe ulaşıldı.");
                    break;
                }
                
                $page++;
                sleep(1);

            } catch (\Exception $e) {
                $this->error("Hata: " . $e->getMessage());
                break;
            }

        } while (true);

        $this->info("İşlem Bitti. $totalAdded yeni kayıt.");
    }
}