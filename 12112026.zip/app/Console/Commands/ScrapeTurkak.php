<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use Symfony\Component\DomCrawler\Crawler;
use App\Models\Announcement;
use Carbon\Carbon;

class ScrapeTurkak extends Command
{
    protected $signature = 'scrape:turkak {start_date?}';
    protected $description = 'TÜRKAK Duyurularını Çeker';

    public function handle()
    {
        $startDateInput = $this->argument('start_date');
        $filterDate = $startDateInput ? Carbon::parse($startDateInput) : Carbon::now()->subYears(5);

        $this->info('TÜRKAK Taraması Başlıyor...');

        $baseUrl = 'https://www.turkak.org.tr/medya/duyurular.html';
        $currentUrl = $baseUrl;
        
        $totalAdded = 0;
        $stopScraping = false;
        $page = 1;

        do {
            $this->comment("Sayfa {$page} taranıyor...");

            try {
                $response = Http::timeout(30)->get($currentUrl);

                if ($response->failed()) break;

                $crawler = new Crawler($response->body());
                $cards = $crawler->filter('article .default-blog-news');

                if ($cards->count() === 0) break;

                $cards->each(function (Crawler $node) use (&$totalAdded, &$stopScraping, $filterDate) {
                    if ($stopScraping) return;

                    try {
                        // Tarih
                        $dateText = $node->filter('.date-u')->count() ? trim($node->filter('.date-u')->text()) : now()->format('d.m.Y');

                        // Published At Oluşturma
                        try {
                            $publishedAt = Carbon::createFromFormat('d.m.Y', $dateText)->startOfDay();
                        } catch (\Exception $e) {
                            $publishedAt = now();
                        }

                        // Filtre
                        if ($publishedAt->lt($filterDate)) {
                            $stopScraping = true;
                            return;
                        }

                        // Link & Başlık
                        $linkNode = $node->filter('.img-holder a');
                        $link = $linkNode->count() ? $linkNode->attr('href') : '#';
                        if (!str_starts_with($link, 'http')) $link = 'https://www.turkak.org.tr' . $link;

                        $titleNode = $node->filter('.lower-content .date');
                        $title = $titleNode->count() ? trim($titleNode->text()) : 'Başlık Yok';

                        $exists = Announcement::where('link', $link)->exists();

                        if (!$exists) {
                            Announcement::create([
                                'title'        => $title,
                                'link'         => $link,
                                'date_text'    => $dateText,
                                'source'       => 'TÜRKAK',
                                'is_read'      => false,
                                'published_at' => $publishedAt, // <--- BURASI ARTIK DOLU
                                'created_at'   => $publishedAt,
                                'updated_at'   => $publishedAt
                            ]);
                            $totalAdded++;
                            $this->line("✅ Eklendi: $title");
                        }

                    } catch (\Exception $e) {}
                });

                if ($stopScraping) {
                    $this->info("Tarih sınırına ulaşıldı.");
                    break;
                }

                // Sayfalama mantığı (Basitçe URL tahmini veya next link)
                // TÜRKAK sayfalama yapısı biraz karışık olabilir, basitçe next linki arayalım
                $nextLink = $crawler->filter('.pagination .next'); // Veya uygun selektör
                // Eğer sayfalama karmaşıksa ve sadece ilk sayfayı çekiyorsa, şimdilik bu döngü 1 kere çalışıp çıkar.
                // HTML yapısından sayfalama linkini bulup $currentUrl'i güncellemek gerekebilir.
                // Şimdilik break atıyoruz sonsuz döngü olmasın diye.
                break; 

            } catch (\Exception $e) {
                break;
            }

        } while (true);

        $this->info("Bitti. Toplam $totalAdded.");
    }
}