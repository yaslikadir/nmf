<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\TurkakAsistService;
use App\Models\TurkakDocument;
use Carbon\Carbon;

class SyncAsistDocs extends Command
{
    protected $signature = 'sync:asist-docs';
    protected $description = 'TÜRKAK Asist Sistemindeki Tüm Dokümanları Çeker';

    // Kategori Sözlüğü (HTML yapısına ve API'lere göre eşleştirme)
    protected $categoryMap = [
        'T17' => 'Genel Dokümanlar',
        'T18' => 'UDK Dokümanları',
        'T19' => 'Yeterlilik Deneyleri Listesi',
        'ManualPersonnelList' => 'Personel Listesi',
        'ManualDeviceList' => 'Cihaz Listesi',
        'ManualSEAR' => 'Öz Değerlendirme Raporu',
        'AppForm' => 'Başvuru Formu',
        'AgreementForm' => 'Sözleşmeler',
        // Diğer T'ler için genel isim (T1-T23 arası döngüde kullanacağız)
        'GNL' => 'Diğer'
    ];

    public function handle(TurkakAsistService $api)
    {
        $this->info('🔄 Genişletilmiş Asist Senkronizasyonu Başlıyor...');

        try {
            $user = $api->getUserInfo();
            $this->info("   🔑 Giriş: " . ($user['Name'] ?? 'Kullanıcı'));

            // Taranacak Parametreler Listesi
            $paramsToScan = [
                'ManualPersonnelList', 'ManualDeviceList', 'ManualSEAR', 'AppForm', 'AgreementForm'
            ];
            // T1'den T25'e kadar ekle
            for ($i = 1; $i <= 25; $i++) {
                $paramsToScan[] = "T$i";
            }

            $count = 0;

            foreach ($paramsToScan as $prm) {
                // Ekranda okunabilir isim yazsın
                $catName = $this->categoryMap[$prm] ?? $prm . ' Kategorisi';
                $this->comment("📂 Taranıyor: $catName ($prm)");
                
                try {
                    // API İsteği (Servisteki metodunu prm parametresi alacak şekilde kullandığını varsayıyoruz)
                    // Eğer servisindeki metod sadece belirli kodları alıyorsa, oraya $prm parametresi ekle.
                    // $api->getDocumentsByCategory($prm) metodunun dinamik olduğunu varsayıyorum.
                    $response = $api->getDocumentsByCategory($prm);
                    $docList = $response['value'] ?? $response ?? [];

                    if (empty($docList)) {
                        continue;
                    }

                    foreach ($docList as $doc) {
                        TurkakDocument::updateOrCreate(
                            ['turkak_id' => $doc['ID']],
                            [
                                'file_id'      => '848bf5cb-6404-4249-ef29-08dd39ef4fb1', // Senin sabit ID
                                'category_code'=> $prm,
                                // Eğer sözlükte varsa o ismi kullan, yoksa kod kalsın
                                'category_name'=> $this->categoryMap[$prm] ?? $prm, 
                                'file_name'    => $doc['FileName'],
                                'title'        => $doc['Title'] ?? null,
                                'description'  => $doc['Description'] ?? null,
                                'file_type'    => pathinfo($doc['FileName'], PATHINFO_EXTENSION),
                                'download_url' => 'https://api.turkak.org.tr/Resources/api/v1/Document/download/' . $doc['ID'],
                                'uploaded_at'  => isset($doc['UploadDate']) ? Carbon::parse($doc['UploadDate']) : now(),
                                'raw_data'     => $doc
                            ]
                        );
                        $count++;
                        $this->line("   ✅ $catName: " . $doc['FileName']);
                    }

                } catch (\Exception $e) {
                    // Boş kategorilerde hata vermemesi için sessiz geçebiliriz veya loglayabiliriz
                }
            }

            $this->info("🏁 İşlem Tamamlandı. Toplam $count dosya.");

        } catch (\Exception $e) {
            $this->error('GENEL HATA: ' . $e->getMessage());
        }
    }
}