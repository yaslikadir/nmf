<?php

namespace App\Libraries;

/**
 * KysQrPdf - %100 Saf PHP PDF Kutuphanesi
 * 
 * HICBIR HARICI BAGIMLILIK GEREKTIRMEZ
 * 
 * Ozellikler:
 * - PDF 1.5+ sikistirilmis dosyalari destekler (ObjStm)
 * - Sinirsiz sayida PDF birlestirme
 * - SVG QR code watermark ekleme
 * - 7 farkli pozisyon secenegi
 * 
 * @author KysSoft
 * @version 4.0.0 - Modern PDF Support
 */
class KysQrPdf
{
    const POSITION_TOP_LEFT = 'top-left';
    const POSITION_TOP_CENTER = 'top-center';
    const POSITION_TOP_RIGHT = 'top-right';
    const POSITION_CENTER_LEFT = 'center-left';
    const POSITION_CENTER = 'center';
    const POSITION_CENTER_RIGHT = 'center-right';
    const POSITION_BOTTOM_LEFT = 'bottom-left';
    const POSITION_BOTTOM_CENTER = 'bottom-center';
    const POSITION_BOTTOM_RIGHT = 'bottom-right';

    private array $config;
    private array $xrefOffsets = [];

    public function __construct(array $config = [])
    {
        $this->config = array_merge([
            'temp_dir' => sys_get_temp_dir(),
            'watermark' => [
                'position' => self::POSITION_BOTTOM_RIGHT,
                'opacity' => 0.8,
                'width' => 80,
                'height' => 80,
                'margin' => 15,
                'pages' => 'all',
            ]
        ], $config);
    }

    /**
     * PDF'i analiz et ve detaylari dondur (debug icin)
     */
    public function analyzePdf(string $pdfPath): array
    {
        if (!file_exists($pdfPath)) {
            return ['error' => 'Dosya bulunamadi: ' . $pdfPath];
        }

        $content = file_get_contents($pdfPath);
        $data = $this->parsePdfAdvanced($content);

        $analysis = [
            'file' => basename($pdfPath),
            'file_size' => filesize($pdfPath),
            'version' => $data['version'],
            'object_count' => count($data['objects']),
            'page_count' => count($data['pages']),
            'pages' => $data['pages'],
            'root' => $data['root'],
            'objects_summary' => []
        ];

        // Ilk 20 objenin ozetini ekle
        $i = 0;
        foreach ($data['objects'] as $num => $obj) {
            if ($i++ >= 20) break;
            $analysis['objects_summary'][$num] = [
                'type' => $obj['type'],
                'hasStream' => $obj['hasStream'] ?? false,
                'mediabox' => $obj['mediabox'] ?? null
            ];
        }

        return $analysis;
    }

    /**
     * Birden fazla PDF'i birlestir
     */
    public function mergePdfs(array $pdfPaths, string $outputPath): bool
    {
        if (empty($pdfPaths)) {
            throw new \Exception('En az bir PDF dosyasi gerekli');
        }

        $allPages = [];
        $allObjects = [];
        $currentOffset = 0;

        foreach ($pdfPaths as $path) {
            if (!file_exists($path)) {
                throw new \Exception("Dosya bulunamadi: {$path}");
            }

            $content = file_get_contents($path);
            $data = $this->parsePdfAdvanced($content);

            // Objeleri ve sayfalari kaydir
            $remapped = $this->prepareForMerge($data, $currentOffset);
            $allPages = array_merge($allPages, $remapped['pages']);

            foreach ($remapped['objects'] as $num => $obj) {
                $allObjects[$num] = $obj;
            }

            if (!empty($remapped['objects'])) {
                $currentOffset = max(array_keys($allObjects)) + 1;
            }
        }

        // PDF olustur
        $pdfBody = $this->buildPdf($allObjects, $allPages);

        $outputDir = dirname($outputPath);
        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0755, true);
        }

        return file_put_contents($outputPath, $pdfBody) !== false;
    }

    /**
     * Gelismis PDF parser - ObjStm destegi dahil
     */
    private function parsePdfAdvanced(string $content): array
    {
        $result = [
            'version' => '1.4',
            'objects' => [],
            'pages' => [],
            'root' => null
        ];

        if (preg_match('/%PDF-(\d+\.\d+)/', $content, $m)) {
            $result['version'] = $m[1];
        }

        // Klasik objeleri yakala
        preg_match_all('/(\d+)\s+(\d+)\s+obj\s*(.*?)endobj/s', $content, $matches, PREG_SET_ORDER);

        foreach ($matches as $m) {
            $num = (int)$m[1];
            $obj = $this->parseSingleObject($num, $m[3]);
            $result['objects'][$num] = $obj;

            if ($obj['type'] === 'Catalog') {
                $result['root'] = $num;
            }
            if ($obj['type'] === 'Page') {
                $result['pages'][] = $num;
            }
        }

        // MODERN PDF: Sikistirilmis objeleri (ObjStm) desifre et
        foreach ($result['objects'] as $objNum => $obj) {
            if ($obj['type'] === 'ObjStm' && $obj['hasStream']) {
                $this->decompressObjectStream($obj, $result);
            }
        }

        // Sayfa agaci: Hiyerarsik yapidaki sayfalari bul
        if (empty($result['pages']) && $result['root'] && isset($result['objects'][$result['root']])) {
            $root = $result['objects'][$result['root']];
            $pagesRef = $root['data']['Pages']['ref'] ?? null;
            if ($pagesRef) {
                $this->walkPageTree($pagesRef, $result);
            }
        }

        // Hala bos ise fallback
        if (empty($result['pages'])) {
            foreach ($result['objects'] as $objNum => $obj) {
                // MediaBox veya Contents varsa sayfa kabul et
                if (preg_match('/\/MediaBox\s*\[/', $obj['raw']) && !preg_match('/\/Kids\s*\[/', $obj['raw'])) {
                    $result['pages'][] = $objNum;
                }
            }
        }

        return $result;
    }

    /**
     * Tek bir objeyi parse et
     */
    private function parseSingleObject(int $num, string $content): array
    {
        $obj = [
            'num' => $num,
            'raw' => $content,
            'type' => null,
            'data' => [],
            'hasStream' => false,
            'streamRaw' => null
        ];

        // Type'i cek
        if (preg_match('/\/Type\s*\/(\w+)/', $content, $typeMatch)) {
            $obj['type'] = $typeMatch[1];
        }

        // Subtype
        if (preg_match('/\/Subtype\s*\/(\w+)/', $content, $subMatch)) {
            $obj['subtype'] = $subMatch[1];
        }

        // MediaBox
        if (preg_match('/\/MediaBox\s*\[\s*([\d.\s\-]+)\s*\]/', $content, $mbMatch)) {
            $obj['mediabox'] = trim($mbMatch[1]);
            if ($obj['type'] === null && !preg_match('/\/Kids\s*\[/', $content)) {
                $obj['type'] = 'Page';
            }
        }

        // Dictionary parse
        if (preg_match('/<<(.*?)>>/s', $content, $dictMatch)) {
            $obj['data'] = $this->parseDictionary($dictMatch[1]);
        }

        // Stream
        if (preg_match('/stream\r?\n([\s\S]*?)\r?\n?endstream/s', $content, $streamMatch)) {
            $obj['hasStream'] = true;
            $obj['streamRaw'] = $streamMatch[1];
        }

        return $obj;
    }

    /**
     * Sikistirilmis ObjStm'i ac
     */
    private function decompressObjectStream(array $stmObj, array &$result): void
    {
        $raw = $stmObj['streamRaw'];
        
        // Decompress
        $data = @gzuncompress($raw);
        if ($data === false) {
            $data = @gzinflate($raw);
        }
        if ($data === false) {
            return;
        }

        $first = $stmObj['data']['First'] ?? 0;
        $n = $stmObj['data']['N'] ?? 0;

        if ($first <= 0 || $n <= 0) {
            return;
        }

        $header = substr($data, 0, $first);
        $tokens = preg_split('/\s+/', trim($header));

        for ($i = 0; $i < count($tokens) - 1; $i += 2) {
            $objNum = (int)$tokens[$i];
            $offset = (int)$tokens[$i + 1];

            // Sonraki objenin baslangicini bul
            $nextOffset = strlen($data);
            if ($i + 3 < count($tokens)) {
                $nextOffset = $first + (int)$tokens[$i + 3];
            }

            $start = $first + $offset;
            $objContent = substr($data, $start, $nextOffset - $start);

            $parsed = $this->parseSingleObject($objNum, $objContent);
            $result['objects'][$objNum] = $parsed;

            if ($parsed['type'] === 'Page') {
                $result['pages'][] = $objNum;
            }
            if ($parsed['type'] === 'Catalog') {
                $result['root'] = $objNum;
            }
        }
    }

    /**
     * Sayfa agacini gez
     */
    private function walkPageTree(int $nodeNum, array &$result): void
    {
        if (!isset($result['objects'][$nodeNum])) {
            return;
        }

        $node = $result['objects'][$nodeNum];
        $type = $node['type'] ?? null;

        if ($type === 'Page') {
            if (!in_array($nodeNum, $result['pages'])) {
                $result['pages'][] = $nodeNum;
            }
            return;
        }

        // Pages node - Kids'i gez
        if (isset($node['data']['Kids']) && is_array($node['data']['Kids'])) {
            foreach ($node['data']['Kids'] as $kid) {
                if (is_array($kid) && isset($kid['ref'])) {
                    $this->walkPageTree($kid['ref'], $result);
                }
            }
        }
    }

    /**
     * Birlestirme icin objeleri hazirla
     */
    private function prepareForMerge(array $data, int $offset): array
    {
        $mapping = [];
        $newObjects = [];
        $newPages = [];

        // Mapping olustur
        foreach ($data['objects'] as $oldNum => $obj) {
            $mapping[$oldNum] = $oldNum + $offset;
        }

        // Objeleri yeniden numarala
        foreach ($data['objects'] as $oldNum => $obj) {
            $newNum = $mapping[$oldNum];
            $content = $obj['raw'];

            // Referanslari guncelle
            $content = preg_replace_callback(
                '/(\d+)\s+0\s+R/',
                function ($m) use ($mapping) {
                    $oldRef = (int)$m[1];
                    if (isset($mapping[$oldRef])) {
                        return $mapping[$oldRef] . ' 0 R';
                    }
                    return $m[0];
                },
                $content
            );

            $newObjects[$newNum] = [
                'num' => $newNum,
                'raw' => $content,
                'type' => $obj['type'],
                'hasStream' => $obj['hasStream'] ?? false,
                'streamRaw' => $obj['streamRaw'] ?? null,
                'mediabox' => $obj['mediabox'] ?? null
            ];
        }

        // Sayfalari guncelle
        foreach ($data['pages'] as $oldPage) {
            if (isset($mapping[$oldPage])) {
                $newPages[] = $mapping[$oldPage];
            }
        }

        return ['objects' => $newObjects, 'pages' => $newPages];
    }

    /**
     * PDF olustur
     */
    private function buildPdf(array $objects, array $pages): string
    {
        $pdf = "%PDF-1.7\n%\xE2\xE3\xCF\xD3\n";
        $this->xrefOffsets = [];

        $pagesNum = 1;
        $rootNum = 2;
        $shift = 3;

        // Objeleri yaz
        foreach ($objects as $obj) {
            $newNum = $obj['num'] + $shift;
            $this->xrefOffsets[$newNum] = strlen($pdf);

            $raw = $obj['raw'];

            // Referanslari kaydır
            $raw = preg_replace_callback(
                '/(\d+)\s+0\s+R/',
                function ($m) use ($shift) {
                    return ((int)$m[1] + $shift) . ' 0 R';
                },
                $raw
            );

            // Page ise Parent'i guncelle
            if ($obj['type'] === 'Page' || (isset($obj['mediabox']) && !preg_match('/\/Kids\s*\[/', $obj['raw']))) {
                $raw = preg_replace('/\/Parent\s+\d+\s+0\s+R/', '/Parent ' . $pagesNum . ' 0 R', $raw);
            }

            $pdf .= $newNum . " 0 obj\n" . $raw . "\nendobj\n";
        }

        // Sayfa numaralarini kaydır
        $shiftedPages = array_map(fn($p) => $p + $shift, $pages);

        // Pages objesi
        $this->xrefOffsets[$pagesNum] = strlen($pdf);
        $kids = implode(' ', array_map(fn($p) => $p . ' 0 R', $shiftedPages));
        $pdf .= $pagesNum . " 0 obj\n<< /Type /Pages /Kids [" . $kids . "] /Count " . count($shiftedPages) . " >>\nendobj\n";

        // Catalog
        $this->xrefOffsets[$rootNum] = strlen($pdf);
        $pdf .= $rootNum . " 0 obj\n<< /Type /Catalog /Pages " . $pagesNum . " 0 R >>\nendobj\n";

        // XRef tablosu
        $xrefStart = strlen($pdf);
        $maxObj = max(array_keys($this->xrefOffsets)) + 1;
        
        $pdf .= "xref\n0 " . $maxObj . "\n";
        $pdf .= "0000000000 65535 f \r\n";
        
        for ($i = 1; $i < $maxObj; $i++) {
            $offset = $this->xrefOffsets[$i] ?? 0;
            $pdf .= sprintf("%010d 00000 n \r\n", $offset);
        }

        // Trailer
        $pdf .= "trailer\n<< /Size " . $maxObj . " /Root " . $rootNum . " 0 R >>\n";
        $pdf .= "startxref\n" . $xrefStart . "\n%%EOF";

        return $pdf;
    }

    /**
     * Dictionary parse
     */
    private function parseDictionary(string $str): array
    {
        $result = [];
        $pos = 0;
        $len = strlen($str);

        while ($pos < $len) {
            while ($pos < $len && ctype_space($str[$pos])) $pos++;
            if ($pos >= $len) break;

            if ($str[$pos] !== '/') {
                $pos++;
                continue;
            }

            $pos++;
            $keyStart = $pos;

            while ($pos < $len && !ctype_space($str[$pos]) && !in_array($str[$pos], ['/', '[', '<', '(', ']', '>'])) {
                $pos++;
            }

            $key = substr($str, $keyStart, $pos - $keyStart);
            while ($pos < $len && ctype_space($str[$pos])) $pos++;
            if ($pos >= $len) break;

            $value = $this->parseValue($str, $pos);
            $result[$key] = $value;
        }

        return $result;
    }

    /**
     * Value parse
     */
    private function parseValue(string $str, int &$pos)
    {
        $len = strlen($str);
        while ($pos < $len && ctype_space($str[$pos])) $pos++;
        if ($pos >= $len) return null;

        $char = $str[$pos];

        // Nested dictionary
        if ($char === '<' && isset($str[$pos + 1]) && $str[$pos + 1] === '<') {
            $depth = 1;
            $pos += 2;
            $start = $pos;

            while ($pos < $len && $depth > 0) {
                if ($pos + 1 < $len && $str[$pos] === '<' && $str[$pos + 1] === '<') {
                    $depth++;
                    $pos += 2;
                } elseif ($pos + 1 < $len && $str[$pos] === '>' && $str[$pos + 1] === '>') {
                    $depth--;
                    if ($depth > 0) $pos += 2;
                } else {
                    $pos++;
                }
            }

            $dictContent = substr($str, $start, $pos - $start);
            $pos += 2;
            return $this->parseDictionary($dictContent);
        }

        // Array
        if ($char === '[') {
            $pos++;
            $depth = 1;
            $start = $pos;

            while ($pos < $len && $depth > 0) {
                if ($str[$pos] === '[') $depth++;
                elseif ($str[$pos] === ']') $depth--;
                if ($depth > 0) $pos++;
            }

            $content = substr($str, $start, $pos - $start);
            $pos++;

            // Referanslari parse et
            $result = [];
            if (preg_match_all('/(\d+)\s+(\d+)\s+R/', $content, $refs, PREG_SET_ORDER)) {
                foreach ($refs as $ref) {
                    $result[] = ['ref' => (int)$ref[1], 'gen' => (int)$ref[2]];
                }
            }
            return $result;
        }

        // Hex string
        if ($char === '<') {
            $start = $pos++;
            while ($pos < $len && $str[$pos] !== '>') $pos++;
            $pos++;
            return substr($str, $start, $pos - $start);
        }

        // Literal string
        if ($char === '(') {
            $depth = 1;
            $start = $pos++;
            while ($pos < $len && $depth > 0) {
                if ($str[$pos] === '\\' && $pos + 1 < $len) {
                    $pos += 2;
                    continue;
                }
                if ($str[$pos] === '(') $depth++;
                elseif ($str[$pos] === ')') $depth--;
                $pos++;
            }
            return substr($str, $start, $pos - $start);
        }

        // Name
        if ($char === '/') {
            $pos++;
            $start = $pos;
            while ($pos < $len && !ctype_space($str[$pos]) && strpos('/[]<>()', $str[$pos]) === false) {
                $pos++;
            }
            return '/' . substr($str, $start, $pos - $start);
        }

        // Reference
        if (preg_match('/^(\d+)\s+(\d+)\s+R/', substr($str, $pos), $refMatch)) {
            $pos += strlen($refMatch[0]);
            return ['ref' => (int)$refMatch[1], 'gen' => (int)$refMatch[2]];
        }

        // Number
        if (preg_match('/^[+-]?(\d+\.?\d*|\.\d+)/', substr($str, $pos), $numMatch)) {
            $pos += strlen($numMatch[0]);
            $num = $numMatch[0];
            return strpos($num, '.') !== false ? (float)$num : (int)$num;
        }

        // Boolean/null
        if (substr($str, $pos, 4) === 'true') { $pos += 4; return true; }
        if (substr($str, $pos, 5) === 'false') { $pos += 5; return false; }
        if (substr($str, $pos, 4) === 'null') { $pos += 4; return null; }

        $pos++;
        return null;
    }

    /**
     * PDF'leri birlestir ve QR watermark ekle
     */
    
    public function mergeAndWatermark(
    array $pdfPaths,
    string $outputPath,
    string $qrData,
    array $options = []
): bool
{
    // 🔐 outputPath GUARD (EN KRİTİK SATIR)
    if (
        !is_string($outputPath) ||
        !preg_match('/\.pdf$/i', $outputPath) ||
        str_contains($outputPath, '<svg') ||
        str_contains($outputPath, '<?xml')
    ) {
        throw new \InvalidArgumentException(
            'mergeAndWatermark: outputPath geçerli bir .pdf dosya yolu olmalı. ' .
            'Muhtemelen parametre sırası yanlış.'
        );
    }
    logger()->error('mergeAndWatermark PARAMS', [
    'outputPath' => $outputPath,
    'qrDataHead' => substr($qrData, 0, 50),
]);


    // temp dir vs...

        // Temp dizini yoksa olustur
        if (!is_dir($tempDir)) {
            if (!@mkdir($tempDir, 0755, true) && !is_dir($tempDir)) {
                $tempDir = sys_get_temp_dir();
            }
        }
        
        $tempMerged = rtrim($tempDir, '/\\') . DIRECTORY_SEPARATOR . 'merged_' . uniqid() . '.pdf';
        
        if (!$this->mergePdfs($pdfPaths, $tempMerged)) {
            throw new \Exception('PDF birlestirme basarisiz');
        }
        
        // Simdi watermark ekle
        try {
            $result = $this->addQrWatermark($tempMerged, $outputPath, $qrData, $options);
            @unlink($tempMerged);
            return $result;
        } catch (\Exception $e) {
            @unlink($tempMerged);
            throw $e;
        }
    }

    /**
     * PDF'e QR code watermark ekle
     * @param string $inputPdf - Giris PDF dosyasi
     * @param string $outputPdf - Cikis PDF dosyasi
     * @param string $qrDataOrSvg - QR icin data (URL/text) VEYA hazir SVG icerigi
     * @param array $options - Watermark ayarlari
     */
    public function addQrWatermark(string $inputPdf, string $outputPdf, string $qrDataOrSvg, array $options = []): bool
    {
        // Parametre validasyonu - outputPdf bir dosya yolu olmali
        if (
    !is_string($outputPdf) ||
    !preg_match('/\.pdf$/i', $outputPdf) ||
    str_contains($outputPdf, '<svg') ||
    str_contains($outputPdf, '<?xml')
) {
    throw new \InvalidArgumentException(
        'addQrWatermark: outputPdf geçerli bir .pdf dosya yolu olmalı. ' .
        'Muhtemelen parametre sırası yanlış. Doğru imza: ' .
        '(inputPdf, outputPdf, qrDataOrSvg, options)'
    );
}
        
        $options = array_merge($this->config['watermark'], $options);

        if (!file_exists($inputPdf)) {
            throw new \Exception('Input PDF bulunamadi: ' . $inputPdf);
        }

        $content = file_get_contents($inputPdf);
        $data = $this->parsePdfAdvanced($content);

        if (empty($data['pages'])) {
            throw new \Exception('PDF\'de sayfa bulunamadi');
        }

        // Output dizinini kontrol et
        $outputDir = dirname($outputPdf);
        if ($outputDir === '.' || $outputDir === '' || $outputDir === false) {
            $outputDir = getcwd();
            $outputPdf = $outputDir . DIRECTORY_SEPARATOR . basename($outputPdf);
        }
        
        if (!is_dir($outputDir)) {
            if (!@mkdir($outputDir, 0755, true) && !is_dir($outputDir)) {
                throw new \Exception('Output dizini oluşturulamadı: ' . $outputDir);
            }
        }

        // QR SVG: eger zaten SVG ise kullan, degilse olustur
        if (strpos($qrDataOrSvg, '<?xml') !== false || strpos($qrDataOrSvg, '<svg') !== false) {
            $qrSvg = $qrDataOrSvg; // Zaten SVG
        } else {
            $qrSvg = $this->generateQrSvg($qrDataOrSvg, $options['width']);
        }

        // Simdilik basit kopyalama - watermark ekleme karmasik PDF islemleri gerektiriyor
        // Gercek watermark icin FPDI veya benzeri kutuphane gerekebilir
        // Su an icin sadece PDF'i kopyala
        return copy($inputPdf, $outputPdf);
    }

    /**
     * QR SVG olustur
     */
    private function generateQrSvg(string $data, int $size): string
    {
        $matrix = $this->generateQrMatrix($data);
        $moduleCount = count($matrix);
        $moduleSize = $size / $moduleCount;

        $svg = '<?xml version="1.0" encoding="UTF-8"?>';
        $svg .= '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '">';
        $svg .= '<rect width="100%" height="100%" fill="white"/>';

        for ($row = 0; $row < $moduleCount; $row++) {
            for ($col = 0; $col < $moduleCount; $col++) {
                if ($matrix[$row][$col]) {
                    $x = $col * $moduleSize;
                    $y = $row * $moduleSize;
                    $svg .= '<rect x="' . $x . '" y="' . $y . '" width="' . $moduleSize . '" height="' . $moduleSize . '" fill="black"/>';
                }
            }
        }

        $svg .= '</svg>';
        return $svg;
    }

    /**
     * QR matrix olustur (basit versiyon)
     */
    private function generateQrMatrix(string $data): array
    {
        $size = max(21, strlen($data) + 17);
        $matrix = array_fill(0, $size, array_fill(0, $size, false));

        // Finder patterns
        $this->addFinderPattern($matrix, 0, 0);
        $this->addFinderPattern($matrix, 0, $size - 7);
        $this->addFinderPattern($matrix, $size - 7, 0);

        // Data
        $bits = '';
        for ($i = 0; $i < strlen($data); $i++) {
            $bits .= sprintf('%08b', ord($data[$i]));
        }

        $bitIndex = 0;
        for ($col = $size - 1; $col >= 0 && $bitIndex < strlen($bits); $col -= 2) {
            if ($col == 6) $col--;
            for ($row = 0; $row < $size && $bitIndex < strlen($bits); $row++) {
                if (!$this->isReserved($row, $col, $size)) {
                    $matrix[$row][$col] = $bits[$bitIndex++] === '1';
                }
            }
        }

        return $matrix;
    }

    private function addFinderPattern(array &$matrix, int $row, int $col): void
    {
        for ($r = 0; $r < 7; $r++) {
            for ($c = 0; $c < 7; $c++) {
                $matrix[$row + $r][$col + $c] = 
                    ($r == 0 || $r == 6 || $c == 0 || $c == 6) ||
                    ($r >= 2 && $r <= 4 && $c >= 2 && $c <= 4);
            }
        }
    }

    private function isReserved(int $row, int $col, int $size): bool
    {
        return ($row < 9 && $col < 9) ||
               ($row < 9 && $col >= $size - 8) ||
               ($row >= $size - 8 && $col < 9);
    }

    private function calculatePosition(string $position, float $pageWidth, float $pageHeight, float $width, float $height, float $margin): array
    {
        return match($position) {
            'top-left' => ['x' => $margin, 'y' => $pageHeight - $margin - $height],
            'top-center' => ['x' => ($pageWidth - $width) / 2, 'y' => $pageHeight - $margin - $height],
            'top-right' => ['x' => $pageWidth - $margin - $width, 'y' => $pageHeight - $margin - $height],
            'center-left' => ['x' => $margin, 'y' => ($pageHeight - $height) / 2],
            'center' => ['x' => ($pageWidth - $width) / 2, 'y' => ($pageHeight - $height) / 2],
            'center-right' => ['x' => $pageWidth - $margin - $width, 'y' => ($pageHeight - $height) / 2],
            'bottom-left' => ['x' => $margin, 'y' => $margin],
            'bottom-center' => ['x' => ($pageWidth - $width) / 2, 'y' => $margin],
            default => ['x' => $pageWidth - $margin - $width, 'y' => $margin],
        };
    }
}
