<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Offer;
use App\Models\OfferItem;
use App\Models\Sample;
use App\Models\User;
use App\Models\Device;
use App\Models\MeasurementPlan;
use App\Models\ScopeParameter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class SampleController extends Controller
{
    // Mevcut index methodu
    public function index($id)
    {
        $offer = Offer::findOrFail($id);
        
        // Tüm barkodlar
        $samples = Sample::where('offer_id', $id)->get();
        
        // Beklemede olan barkodlar
        $pendingSamples = Sample::where('offer_id', $id)
                                 ->where('status', 'Pending')
                                 ->get();
        
        // Kabul edilenler
        $acceptedSamples = Sample::where('offer_id', $id)
                                  ->where('status', 'Kabul Edildi')
                                  ->get();
        
        return view('sample.items-html', compact('offer', 'samples', 'pendingSamples', 'acceptedSamples'));
    }

    // Status güncelleme methodu
    public function updateSampleStatus(Request $request)
    {
        $sample = Sample::findOrFail($request->sample_id);
        $sample->update([
            'status' => 'Kabul Edildi',
            'accepted_at' => now()
        ]);
        
        return response()->json(['success' => true, 'message' => 'Numune kabul edildi']);
    }

    
    /**
     * Numune Oluşturma Sayfası
     */
    public function create()
    {
        // 1. Yeni Barkod Oluşturma Tablosu için (Barkodu hiç olmayanlar)
        $offers = Offer::where('status', 'Onaylandı')
                        // ->where('has_samples', false) 
                        ->orderBy('created_at', 'desc')
                        ->get();

        $users = User::where('is_active', true)->orderBy('name')->get();
        $devices = Device::where('status', 'Aktif')->orderBy('name')->get();
        
        $deliveryPlans = MeasurementPlan::with(['offer.customer', 'users'])
                                        ->orderBy('created_at', 'desc')
                                        ->get();

        // ------------------------------------------------------------------
        // YENİ NESİL GRUPLAMA MANTIĞI (Teklif Bazlı Tablolar İçin)
        // ------------------------------------------------------------------
        // Sistemdeki barkodu basılmış tüm teklifleri ve içindeki barkodları tek sorguda çekiyoruz
        $allSampledOffers = Offer::with(['customer', 'samples'])
            ->whereHas('samples')
            ->orderBy('created_at', 'desc')
            ->get();

        // Koleksiyon (Collection) üzerinden filtreleme yaparak veritabanını ekstra yormuyoruz
        $pendingOffers = $allSampledOffers->filter(function($offer) {
            return $offer->samples->contains('status', 'Pending');
        });

        $acceptedOffers = $allSampledOffers->filter(function($offer) {
            return $offer->samples->contains('status', 'Kabul Edildi');
        });

        // YENİ SEKME MANTIĞI: Analizcinin laboratuvarda teslim aldığı numuneleri barındıran teklifler
        // (lab_accepted_at alanı boş olmayan en az 1 numunesi olan teklifler)
        $labAcceptedOffers = $allSampledOffers->filter(function($offer) {
            return $offer->samples->whereNotNull('lab_accepted_at')->count() > 0;
        });

        // 5. TAB: Analiz işlemi tamamlanmış barkodu barındıran teklifler
        $completedOffers = $allSampledOffers->filter(function($offer) {
            return $offer->samples->contains('status', 'Tamamlandı');
        });

        return view('admin.samples.create', compact(
            'offers', 'users', 'devices', 'deliveryPlans', 
            'allSampledOffers', 'pendingOffers', 'acceptedOffers', 'completedOffers',
            'labAcceptedOffers' // Yeni sekme verisi blade dosyasına gönderildi
        ));
    }

   /**
     * Teslim Formu ve Plan Kaydetme (Kriptolu Kayıt Sistemi)
     */
    public function storeDeliveryPlan(Request $request)
    {
        try {
            DB::beginTransaction();

            $year = date('Y');
            $count = MeasurementPlan::whereYear('created_at', $year)->count() + 1;
            $planCode = 'PLN-' . $year . '-' . str_pad($count, 4, '0', STR_PAD_LEFT);

            // Dış laboratuvar / Müşteri kontrolü (Plansız form Bypass'ı)
            $isExternal = $request->has('is_external_lab') && $request->is_external_lab == 1;

            $startDate = $isExternal ? now()->format('Y-m-d') : $request->start_date;
            $endDate   = $isExternal ? now()->format('Y-m-d') : $request->end_date;

            $teslimEden = $isExternal ? 'Dış Laboratuvar / Müşteri' : $request->teslim_eden;
            $teslimAlan = $isExternal ? (auth()->user()->name ?? 'Sistem') : $request->teslim_alan;

            $not = $request->description ?? '-';
            $kriptoluAciklama = "||Teslim Eden: {$teslimEden}|| ||Teslim Alan: {$teslimAlan}|| ||Koşul: {$request->tasima_kosulu}|| ||Not: {$not}||";

            // Planı Oluştur
            $plan = MeasurementPlan::create([
                'plan_code'   => $planCode,
                'offer_id'    => $request->offer_id ?: null,
                'start_date'  => $startDate,
                'end_date'    => $endDate,
                // İŞTE ÇÖZÜM BURADA: Plansız ise anında "Tamamlandı" oluyor!
                'status'      => $isExternal ? 'Tamamlandı' : 'Planlandı', 
                'description' => $kriptoluAciklama
            ]);

            // EĞER NORMAL SAHA PLANIYSA Personel Atamasını ve Maili Tetikle
            if(!$isExternal) {
                if($request->user_ids) {
                    $plan->users()->sync($request->user_ids);
                    
                    $assignedUsers = \App\Models\User::whereIn('id', $request->user_ids)->get();
                    if($assignedUsers->count() > 0 && class_exists('\App\Notifications\NewMeasurementPlanAssignedNotification')) {
                        \Illuminate\Support\Facades\Notification::send($assignedUsers, new \App\Notifications\NewMeasurementPlanAssignedNotification($plan));
                    }
                }
                
                if($request->devices) {
                    $plan->devices()->sync($request->devices);
                }
            } 
            // Eğer plansız ise sadece teslim alan kişiyi yetkili olarak atayalım (sistem patlamaması için)
            else {
                 $teslimAlanUser = \App\Models\User::where('name', $teslimAlan)->first();
                 if($teslimAlanUser) {
                     $plan->users()->sync([$teslimAlanUser->id]);
                 }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'plan_id' => $plan->id,
                'is_planless' => $isExternal, // Frontend'in yönlendirme yapabilmesi için geri dönüyoruz
                'message' => $isExternal ? 'Direkt teslim alındı. Numune Kabul ekranına yönlendiriliyorsunuz.' : 'Ölçüm Planı oluşturuldu ve tutanak kaydedildi.'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Sistem Hatası: ' . $e->getMessage()], 500);
        }
    }
    /**
     * Teslim Tutanağını PDF/HTML Olarak Basma (Kriptoyu Çözme Sistemi)
     */
    public function printDelivery($planId)
    {
        $plan = MeasurementPlan::with(['offer.customer', 'offer.samples', 'users'])->findOrFail($planId);
        
        // Veritabanındaki açıklamayı deşifre edip değişkenlere atıyoruz
        $desc = $plan->description;
        preg_match('/\|\|Teslim Eden: (.*?)\|\|/', $desc, $m1);
        preg_match('/\|\|Teslim Alan: (.*?)\|\|/', $desc, $m2);
        preg_match('/\|\|Koşul: (.*?)\|\|/', $desc, $m3);
        preg_match('/\|\|Not: (.*?)\|\|/', $desc, $m4);
        
        $formData = [
            'teslim_eden'   => $m1[1] ?? '-',
            'teslim_alan'   => $m2[1] ?? '-',
            'tasima_kosulu' => $m3[1] ?? 'Uygun',
            'not'           => $m4[1] ?? '-'
        ];

        return view('admin.samples.print_delivery', compact('plan', 'formData'));
    }

    /**
     * YENİ METOD: Analizci (Laboratuvar) Teslim Formunu Yazdırma (F-16/01)
     */
    public function printLabReceipt($offerId)
    {
        $offer = Offer::with('customer')->findOrFail($offerId);
        
        // Sadece laboratuvarın kabul ettiği barkodları çekiyoruz
        $samples = Sample::with(['acceptor', 'labAcceptor'])
            ->where('offer_id', $offerId)
            ->whereNotNull('lab_accepted_at')
            ->get();

        if($samples->isEmpty()) {
            return back()->with('error', 'Bu teklife ait laboratuvara teslim alınmış numune bulunamadı.');
        }

        // Sizin mevcut F-16/01 formunuzu (print_delivery.blade.php) çağırıyoruz
        // "plan" ve "formData" değişkenlerini bu rotada kullanmadığımız için null olarak gönderebiliriz, 
        // blade tarafında zaten "isset($samples)" kontrolünüz var.
        return view('admin.samples.print_delivery', compact('offer', 'samples')); 
    }

    /**
     * AJAX: Teklif Kalemlerini Getir (Sol Taraf)
     */
    public function getOfferItems($offerId)
    {
        try {
            $offer = Offer::findOrFail($offerId);
            
            // OfferItem ve ilişkili Parameter verisini çekiyoruz
            $items = OfferItem::with('parameter')
                              ->where('offer_id', $offerId)
                              ->get()
                              ->map(function($item) {
                                  return [
                                      'id' => $item->id,
                                      'name' => $item->parameter->name ?? 'Tanımsız Parametre',
                                      'quantity' => $item->quantity ?? 1
                                  ];
                              });

            $samples = Sample::where('offer_id', $offerId)->latest()->get();

            return response()->json([
                'success' => true,
                'items' => $items,
                'samples' => $samples,
                'offer' => [
                    'id' => $offer->id,
                    'offer_no' => $offer->offer_no
                ]
            ]);
            
        } catch (\Exception $e) {
            Log::error('getOfferItems Error: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Teklif kalemleri yüklenirken bir hata oluştu.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

   /**
     * AJAX: Numune/Barkod Kaydet
     */
    public function store(Request $request)
    {
        try {
            $offer = null;
            $prefix = '1000'; // Teklif seçilmediyse kullanılacak varsayılan kod öneki

            // Eğer teklif seçilmişse, onu bul ve öneki teklif no yap
            if (!empty($request->offer_id)) {
                $offer = Offer::find($request->offer_id);
                if ($offer) {
                    $prefix = $offer->offer_no;
                }
            }

            $createdCount = 0;
            // Kullanıcının girdiği şişe/kopya sayısı
            $copyCount = (int) ($request->copy_count ?? 1);
            if ($copyCount < 1) $copyCount = 1;

            if (empty($request->items) || !is_array($request->items)) {
                return response()->json(['success' => false, 'message' => 'Lütfen barkod oluşturulacak parametre seçiniz.'], 400);
            }

            foreach ($request->items as $item) {
                // YENİ: 0000 ile 9999 arasında tam 4 haneli rastgele bir sayı üretir
                $baseRandomCode = sprintf('%04d', random_int(0, 9999));
                $baseBarcode = $prefix . '-' . $baseRandomCode;

                // Ana barkodun çakışmadığından emin ol
                while(Sample::where('barcode', 'like', $baseBarcode . '%')->exists()) {
                    // YENİ: Çakışma varsa yeni bir 4 haneli sayı üret
                    $baseRandomCode = sprintf('%04d', random_int(0, 9999));
                    $baseBarcode = $prefix . '-' . $baseRandomCode;
                }

                // İstenen şişe sayısı kadar veritabanına kayıt at
                for ($i = 1; $i <= $copyCount; $i++) {
                    $sample = new Sample();
                    // DİKKAT: Veritabanında offer_id alanının nullable olması gerekir
                    $sample->offer_id = $offer ? $offer->id : null; 
                    $sample->barcode = ($copyCount > 1) ? $baseBarcode . '-' . $i : $baseBarcode;
                    $sample->analysis_summary = $item['name']; 
                    $sample->item_count = 1; 
                    $sample->status = 'Pending';
                    $sample->save();
                    
                    $createdCount++;
                }
            }

            // Teklif Durumunu Güncelle (Yalnızca teklife bağlı bir işlemse)
            if ($offer && $createdCount > 0) {
                $offer->has_samples = true;
                $offer->save();
            }

            return response()->json([
                'success' => true, 
                'message' => $createdCount . ' adet numune barkodu başarıyla oluşturuldu.',
                'count' => $createdCount
            ]);

        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Veritabanı Hatası: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Barkod Yazdırma Ekranı (50x30mm)
     */
    public function printLabel($id)
    {
        $sample = Sample::with('offer.customer')->findOrFail($id);
        return view('admin.samples.print', compact('sample'));
    }

    /**
     * Numune Silme
     */
    public function destroy($id)
    {
        try {
            $sample = Sample::findOrFail($id);
            $sample->delete();
            return response()->json(['success' => true, 'message' => 'Kayıt silindi.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Hata.'], 500);
        }
    }

    // TOPLU YAZDIRMA EKRANI
    public function printBulk(Request $request)
    {
        if (!$request->has('ids')) {
            abort(404);
        }

        $ids = explode(',', $request->ids);
        $samples = Sample::with('offer.customer')
                         ->whereIn('id', $ids)
                         ->get();

        return view('admin.samples.print_bulk', compact('samples'));
    }

    /**
     * AJAX: İlave Parametre Arama (Select2 İçin)
     */
    public function searchParameters(Request $request)
    {
        $search = $request->q;
        
        $query = \App\Models\ScopeParameter::where('is_active', true);

        if (!empty($search)) {
            $query->where('name', 'like', '%' . $search . '%');
        }

        // Performans için sadece id ve name alıp 50 adetle sınırlandırıyoruz
        $parameters = $query->select('id', 'name')->limit(50)->get();

        // Select2'nin okuyabileceği formata çeviriyoruz
        $formatted = [];
        foreach ($parameters as $param) {
            $formatted[] = ['id' => $param->id, 'text' => $param->name];
        }

        return response()->json(['results' => $formatted]);
    }

    // YENİ CİHAZ (GoDEX 4'lü Etiket) İÇİN TOPLU YAZDIRMA
    public function printBulkV2(Request $request)
    {
        if (!$request->has('ids')) {
            abort(404);
        }

        $ids = explode(',', $request->ids);
        $samples = \App\Models\Sample::with('offer.customer')
                         ->whereIn('id', $ids)
                         ->get();

        // 4'lü etiket olduğu için verileri 4'erli paketlere bölüyoruz
        $chunks = $samples->chunk(4);

        return view('admin.samples.print_bulk_v2', compact('chunks'));
    }

    /**
     * AJAX: Numune Statüsünü Dinamik Olarak Güncelle (Raporlama Sayfası İçin)
     */
    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|string'
        ]);

        $sample = \App\Models\Sample::findOrFail($id);
        $sample->status = $request->status;
        $sample->save();

        return response()->json([
            'status' => 'success', 
            'message' => 'Numune durumu güncellendi.'
        ]);
    }
    
}