<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sample;
use App\Models\SampleDisposal;
use App\Models\SampleTransaction;
use App\Models\User; // <--- EKLENDİ
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SampleDisposalController extends Controller
{
    public function index()
    {
        // Onay Bekleyenler
        $pending = SampleDisposal::with(['sample', 'requester'])
            ->where('status', 'Pending')
            ->latest()
            ->get();

        // İmha Edilmeyi Bekleyenler
        $approved = SampleDisposal::with(['sample', 'approver'])
            ->where('status', 'Approved')
            ->latest()
            ->get();

        // Geçmiş
        $completed = SampleDisposal::with(['sample', 'executor'])
            ->where('status', 'Completed')
            ->latest('disposal_date')
            ->paginate(20);

        // Personel Listesi (Aktif Kullanıcılar)
        $users = User::where('is_active', true)->orderBy('name')->get(); // <--- EKLENDİ

        return view('admin.sample_disposals.index', compact('pending', 'approved', 'completed', 'users'));
    }

    /**
     * İmha Talebi Oluştur
     */
    public function store(Request $request)
    {
        $request->validate([
            'barcode' => 'required|exists:samples,barcode',
            'disposal_reason' => 'required'
        ]);

        $sample = Sample::where('barcode', $request->barcode)->first();

        // --- [GÜVENLİK DUVARI 1] ---
        // Numune zaten imha edilmişse işlem yapma!
        if ($sample->global_status == 'İmha Edildi') {
            return back()->with('error', 'HATA: Bu numune zaten İMHA EDİLMİŞTİR! Tekrar imha talebi açılamaz.');
        }

        // --- [GÜVENLİK DUVARI 2] ---
        // Açıkta bekleyen (henüz tamamlanmamış) bir talep var mı?
        if(SampleDisposal::where('sample_id', $sample->id)->where('status', '!=', 'Completed')->exists()){
            return back()->with('error', 'Bu numune için zaten açık (onay bekleyen) bir imha talebi var.');
        }

        SampleDisposal::create([
            'sample_id' => $sample->id,
            'requested_by' => Auth::id(),
            'disposal_reason' => $request->disposal_reason,
            'notes' => $request->notes,
            'status' => 'Pending'
        ]);

        return back()->with('success', 'İmha talebi oluşturuldu, yönetici onayı bekleniyor.');
    }

    /**
     * Talebi Onayla (GÜNCELLENDİ: Personel Seçimi)
     */
    public function approve(Request $request, $id) // Request eklendi
    {
        $request->validate([
            'approved_by' => 'required|exists:users,id' // Seçilen yönetici
        ]);

        $disposal = SampleDisposal::findOrFail($id);
        
        $disposal->update([
            'status' => 'Approved',
            'approved_by' => $request->approved_by, // Formdan gelen kişi
            'approval_date' => now()
        ]);

        return back()->with('success', 'İmha talebi onaylandı. Atık yönetimine sevk edildi.');
    }

    /**
     * İmhayı Gerçekleştir (GÜNCELLENDİ: Personel Seçimi)
     */
    public function complete(Request $request, $id)
    {
        $request->validate([
            'disposed_by' => 'required|exists:users,id' // Seçilen personel
        ]);

        try {
            DB::beginTransaction();
            $disposal = SampleDisposal::findOrFail($id);

            $disposal->update([
                'status' => 'Completed',
                'disposed_by' => $request->disposed_by, // Formdan gelen kişi
                'disposal_date' => now(),
                'disposal_method' => $request->disposal_method,
                'waste_code' => $request->waste_code
            ]);

            $disposal->sample->update([
                'global_status' => 'İmha Edildi',
                'storage_location_id' => null 
            ]);

            // Log işlemi (Burada işlemi 'sisteme giren' kişi Auth::id olarak kalabilir veya seçilen kişi yapılabilir.
            // Genelde logu "sisteme giren" tutar, işlemi "seçilen" yapar. O yüzden Auth::id() bırakıyorum.)
            SampleTransaction::create([
                'sample_id' => $disposal->sample_id,
                'user_id' => Auth::id(), 
                'action_type' => 'DISPOSAL',
                'from_location' => 'Depo',
                'to_location' => 'Atık/İmha',
                'description' => "Numune imha edildi. Yöntem: {$request->disposal_method}"
            ]);

            DB::commit();
            return back()->with('success', 'Numune başarıyla imha edildi ve kayıtlardan düşüldü.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    public function printForm($id)
    {
        $disposal = SampleDisposal::with(['sample.offer.customer', 'requester', 'approver', 'executor'])->findOrFail($id);
        return view('admin.sample_disposals.print', compact('disposal'));
    }
}