<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\Module;
use App\Models\RolePermission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class PermissionController extends Controller
{
    /**
     * Sidebar yapısındaki tüm modüllerin veritabanında (modules tablosunda)
     * eksiksiz bulunmasını garanti altına alan tam liste.
     */
    protected array $sidebarModuleDefinitions = [
        // 1. Müşteri İlişkileri & Satış
        'customers'           => 'Müşteriler',
        'contacts'            => 'Kontaklar',
        'activities'          => 'Görüşme Kayıtları (Aktiviteler)',
        'meetings'            => 'Toplantı & Ajanda Yönetimi',
        'requests'            => 'Müşteri Talepleri',
        'offers'              => 'Teklifler',
        'offer_templates'     => 'Teklif Şablonları',

        // 2. Laboratuvar (LIMS)
        'sample_management'   => 'Numune Kabul, Barkod & BKM',
        'sample_transfers'    => 'Numune Transfer & Lojistik',
        'sample_disposals'    => 'Numune İmha',
        'storage_locations'   => 'Depo Tanımları',
        'sample_preparations' => 'Ön İşlem & Hazırlık',
        'test_management'     => 'Analiz İş Emirleri / Görevlerim',
        'reporting'           => 'Raporlama & Onay',
        'methods'             => 'Metot Yönetimi',
        'parameters'          => 'Kapsam & Parametreler',

        // 3. Planlama & Saha Operasyon
        'planning'            => 'Ölçüm Planlama',
        'planning_calendar'   => 'Ölçüm Takvimi',
        'tasks'               => 'Görev Yönetimi',

        // 4. Kaynak Yönetimi (Stok & Cihaz)
        'materials'           => 'RM / CRM / Kimyasal & Stok Hareketleri',
        'devices'             => 'Cihazlar & Kalibrasyon',

        // 5. Satın Alma & Lojistik
        'suppliers'           => 'Tedarikçiler',
        'purchase'            => 'Satın Alma (Talepler / Teklifler / Siparişler)',

        // 6. Kalite Yönetimi (QMS)
        'qms_documents'       => 'Doküman Yönetimi',
        'qms_changes'         => 'Değişiklik Yönetimi',
        'qms_trainings'       => 'Eğitim Yönetimi',
        'qms_audits'          => 'Denetimler (Audit)',
        'qms_capas'           => 'DÖF / CAPA',
        'qms_feedbacks'       => 'Geri Bildirimler',
        'qms_risks'           => 'Risk & Acil Durum Planları',

        // 7. Proje Yönetimi
        'project_management'  => 'Proje Yönetimi (PM Paneli & Projeler)',

        // 8. Sistem Yönetimi
        'users'               => 'Kullanıcılar',
        'settings'            => 'Genel Ayarlar',
    ];

    public function index(Request $request)
    {
        // Eksik modül anahtarlarını veritabanına otomatik tamamla
        foreach ($this->sidebarModuleDefinitions as $key => $title) {
            Module::firstOrCreate(
                ['module_key' => $key],
                ['name' => $title]
            );
        }

        $roles = Role::orderBy('id', 'asc')->get();
        $modules = Module::orderBy('name', 'asc')->get()->keyBy('module_key');
        
        $selectedRoleId = $request->get('role_id');
        $permissions = [];

        // Seçilen Role ait yetkileri çek
        if ($selectedRoleId) {
            $permissions = RolePermission::where('role_id', $selectedRoleId)
                ->get()
                ->keyBy('module_id');
        }

        return view('admin.permissions.index', compact('roles', 'modules', 'selectedRoleId', 'permissions'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'role_id' => 'required|exists:roles,id',
        ]);

        try {
            DB::beginTransaction();

            // 1. MODÜL YETKİLERİNİ ROLE KAYDET
            if ($request->has('perms')) {
                foreach ($request->perms as $moduleId => $values) {
                    $viewLevel = (int) ($values['view_level'] ?? 0);

                    // Görünürlük kapalıysa (0), alt aksiyonları da güvenlik için sıfırla
                    $updateLevel = $viewLevel > 0 ? (int) ($values['update_level'] ?? 0) : 0;
                    $deleteLevel = $viewLevel > 0 ? (int) ($values['delete_level'] ?? 0) : 0;
                    $canCreate   = ($viewLevel > 0 && isset($values['can_create'])) ? 1 : 0;
                    $canExport   = ($viewLevel > 0 && isset($values['can_export'])) ? 1 : 0;

                    RolePermission::updateOrCreate(
                        [
                            'role_id'   => $request->role_id,
                            'module_id' => $moduleId
                        ],
                        [
                            'view_level'   => $viewLevel,
                            'update_level' => $updateLevel,
                            'delete_level' => $deleteLevel,
                            'can_create'   => $canCreate,
                            'can_export'   => $canExport,
                        ]
                    );
                }
            }

            // 2. SABİT MENÜ YETKİLERİNİ ROLE KAYDET
            $role = Role::findOrFail($request->role_id);
            $menuPerms = $request->has('menu_perms') ? $request->menu_perms : [];
            
            $role->update([
                'menu_permissions' => $menuPerms
            ]);

            DB::commit(); 
            return back()->with('success', 'Rol yetkileri ve Sidebar menü görünürlükleri başarıyla güncellendi!');

        } catch (\Exception $e) {
            DB::rollBack(); 
            Log::error('Rol Yetki Kayıt Hatası: ' . $e->getMessage());
            return back()->with('error', 'Kayıt sırasında teknik bir hata oluştu: ' . $e->getMessage());
        }
    }
}