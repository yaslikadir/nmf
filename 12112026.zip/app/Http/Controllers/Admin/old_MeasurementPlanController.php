<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MeasurementPlan;
use App\Models\Offer;
use App\Models\Device;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class MeasurementPlanController extends Controller
{
    /**
     * Plan Listesi
     * KURAL: Status'ü 'Silindi' olanları listelemez.
     */
    public function index()
    {
        // withPermission('planning') scope'unu ekledik. 
        // 'planning' kelimesi senin veritabanındaki (modules tablosundaki) modül anahtarıdır.
        $plans = MeasurementPlan::withPermission('planning') 
            ->with(['offer.customer', 'users'])
            ->where('status', '!=', 'Silindi')
            ->latest()
            ->get();

        return view('admin.planning.index', compact('plans'));
    }

    /**
     * Yeni Plan Oluşturma Sayfası
     * ESNEK FİLTRELEME: show_all parametresine göre numunesizleri de getirir.
     */
    public function create(Request $request)
    {
        // 1. Otomatik Plan Kodu Üretimi (Yıla göre 4 haneli sıralı)
        $year = date('Y');
        $count = MeasurementPlan::whereYear('created_at', $year)->count() + 1;
        $planCode = 'PLN-' . $year . '-' . str_pad($count, 4, '0', STR_PAD_LEFT);

        // 2. Teklif Sorgusu Başlatma
        $query = Offer::with('customer')
            ->where('status', 'Onaylandı'); // Sadece Onaylı teklifler planlanabilir

        // Filtre Kontrolü: Eğer show_all gelmemişse sadece numunesi (barkodu) basılmışları getir
        if (!$request->has('show_all')) {
            $query->where('has_samples', true);
        }

        $offers = $query->orderBy('created_at', 'desc')->get();
        
        // 3. Diğer Form Verileri
        $users = User::where('is_active', true)->orderBy('name')->get(); 
        // $devices = Device::where('status', 'Aktif')->orderBy('name')->get(); // Cihazlar artık AJAX ile yüklenecek

        return view('admin.planning.create', compact('planCode', 'offers', 'users')); // 'devices' kaldırıldı
    }

    /**
     * Yeni Plan Kaydetme
     */
    public function store(Request $request)
    {
        $request->validate([
            'plan_code'  => 'required|unique:measurement_plans,plan_code',
            'offer_id'   => 'required|exists:offers,id',
            'user_ids'   => 'required|array|min:1',
            'user_ids.*' => 'exists:users,id',
            'start_date' => 'required|date',
            'end_date'   => 'required|date|after_or_equal:start_date',
            'status'     => 'required'
        ]);

        try {
            DB::beginTransaction();

            // YENİ HALİ: Formdan gelen verilere planı oluşturan kişinin (giriş yapan kullanıcı) ID'sini ekliyoruz.
$data = $request->except(['devices', 'user_ids']);
$data['created_by'] = auth()->id();

$plan = MeasurementPlan::create($data);
            
            // Pivot Tablo Eşleştirmeleri
            $plan->users()->sync($request->user_ids);

            if ($request->has('devices')) {
                $plan->devices()->sync($request->devices);
            }

            DB::commit();
            return redirect()->route('admin.planning.index')->with('success', 'Ölçüm planı başarıyla oluşturuldu.');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Plan Kayıt Hatası: ' . $e->getMessage());
            return back()->withInput()->with('error', 'Hata oluştu: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Teklif Detaylarını Getir
     * Numunesi olmayan tekliflerde boş array döner, hata vermez.
     */
    public function getOfferDetails($id)
    {
        // YENİ: 'scopeType' ilişkisini eager load (with) içine ekledik ki veritabanını yormadan tek seferde çeksin
        $offer = Offer::with(['customer', 'samples', 'items.parameter', 'scopeType'])->find($id);

        if (!$offer) {
            return response()->json(['error' => 'Teklif bulunamadı'], 404);
        }

        return response()->json([
            'customer_name'  => $offer->customer->name ?? 'Bilinmiyor',
            'customer_phone' => $offer->customer->phone1 ?? $offer->customer->phone2 ?? '-',
            'customer_city'  => $offer->customer->city ?? '-',
            
            // YENİ: Teklif Kapsamını JSON olarak ön yüze gönderiyoruz
            'scope_name'     => $offer->scopeType->name ?? 'Belirtilmemiş', 
            
            'has_samples'    => (bool) $offer->has_samples,
            'samples' => $offer->samples->map(fn($s) => [
                'barcode' => $s->barcode,
                'name'    => $s->analysis_summary ?? $s->description ?? 'Numune'
            ]),
            'parameters' => $offer->items->map(fn($item) => [
                'name'   => $item->parameter->name ?? 'Tanımsız Parametre',
                'method' => $item->parameter->method ?? '-'
            ])
        ]);
    }

    /**
     * Detay Görüntüleme
     */
    public function show($id)
    {
        $plan = MeasurementPlan::with([
            'offer.customer', 
            'offer.samples', 
            'offer.items.parameter', 
            'users', 
            'devices'
        ])->findOrFail($id);

        return view('admin.planning.show', compact('plan'));
    }

    /**
     * Düzenleme Sayfası
     */
    public function edit($id)
    {
        $plan = MeasurementPlan::with(['users', 'devices'])->findOrFail($id);
        
        // Düzenleme sayfasında kısıtlama olmaksızın mevcut teklifleri getiriyoruz
        $offers = Offer::where('status', '!=', 'Silindi')
            ->orderBy('created_at', 'desc')
            ->get(); 

        $users = User::where('is_active', true)->orderBy('name')->get();
        // $devices = Device::where('status', 'Aktif')->orderBy('name')->get(); // Cihazlar artık AJAX ile yüklenecek

        return view('admin.planning.edit', compact('plan', 'offers', 'users')); // 'devices' kaldırıldı
    }

    /**
     * Güncelleme İşlemi
     */
    public function update(Request $request, $id)
    {
        $plan = MeasurementPlan::findOrFail($id);

        $request->validate([
            'offer_id'   => 'required|exists:offers,id',
            'user_ids'   => 'required|array|min:1',
            'user_ids.*' => 'exists:users,id',
            'start_date' => 'required|date',
            'end_date'   => 'required|date|after_or_equal:start_date',
            'status'     => 'required|in:Planlandı,Devam Ediyor,Tamamlandı,İptal',
        ]);

        try {
            DB::beginTransaction();

            // plan_code ve created_at korunur
            $plan->update($request->except(['devices', 'plan_code', 'user_ids']));

            $plan->users()->sync($request->user_ids);
            $plan->devices()->sync($request->get('devices', []));

            DB::commit();
            return redirect()->route('admin.planning.index')->with('success', 'Ölçüm planı güncellendi.');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Plan Güncelleme Hatası: ' . $e->getMessage());
            return back()->with('error', 'Güncelleme hatası oluştu.');
        }
    }

    /**
     * Plan Silme (Soft-delete benzeri statü değişikliği)
     */
    public function destroy($id)
    {
        try {
            $plan = MeasurementPlan::findOrFail($id);
            $plan->update(['status' => 'Silindi']);

            return response()->json(['success' => true, 'message' => 'Plan silinenlere taşındı.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Hata oluştu.'], 500);
        }
    }
}