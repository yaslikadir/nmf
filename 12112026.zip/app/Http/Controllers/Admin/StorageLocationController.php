<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\StorageLocation;
use Illuminate\Http\Request;

class StorageLocationController extends Controller
{
    /**
     * Depolama Alanları Listesi
     */
    public function index()
    {
        $locations = StorageLocation::latest()->get();
        return view('admin.storage_locations.index', compact('locations'));
    }

    /**
     * Yeni Lokasyon Kaydetme (Otomatik Kodlu)
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            // 'code' validasyonunu kaldırdık çünkü otomatik üreteceğiz
            'type' => 'required', 
        ]);

        // --- OTOMATİK KOD ÜRETİMİ ---
        // Mevcut en büyük ID'yi bul, 1 ekle ve formatla (LOC-001 gibi)
        $lastId = StorageLocation::max('id') ?? 0;
        $nextId = $lastId + 1;
        $autoCode = 'LOC-' . str_pad($nextId, 3, '0', STR_PAD_LEFT); 
        // Eğer 4 haneli istersen '3'ü '4' yap: LOC-0001 olur.

        StorageLocation::create([
            'name' => $request->name,
            'code' => $autoCode, // Otomatik kod buraya atandı
            'type' => $request->type,
            'conditions' => $request->conditions,
            'is_active' => true
        ]);

        return back()->with('success', 'Depolama alanı başarıyla oluşturuldu. Atanan Kod: ' . $autoCode);
    }

    /**
     * Lokasyon Silme
     */
    public function destroy($id)
    {
        $location = StorageLocation::findOrFail($id);
        
        if($location->samples()->exists()) {
            return back()->with('error', 'Bu lokasyonda kayıtlı numuneler var, silinemez!');
        }

        $location->delete();
        return back()->with('success', 'Lokasyon silindi.');
    }
}