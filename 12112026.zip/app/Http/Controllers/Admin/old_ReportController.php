<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Offer;
use App\Models\Sample;
use App\Models\SampleTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

// YENİ: Emisyon Hesaplama Servisimizi dahil ediyoruz
use App\Services\EmissionReportService;

class ReportController extends Controller
{
    protected $emissionService;

    // YENİ: Servisi Controller ayağa kalkarken içeri alıyoruz (Dependency Injection)
    public function __construct(EmissionReportService $emissionService)
    {
        $this->emissionService = $emissionService;
    }

    public function index()
    {
        $offers = Offer::with([
                'customer',
                'samples' => function($q) {
                    $q->whereNotNull('accepted_at');
                },
                'samples.offer.offerItems.parameter',
                'samples.workOrders.analyst',
                'samples.workOrders.result',
                'samples.workOrders.method',
                'samples.workOrders.parameter.scopeType' 
            ])
            ->whereHas('samples', function($q) {
                $q->whereNotNull('accepted_at');
            })
            ->orderBy('id', 'desc') 
            ->get();

        return view('admin.reporting.index', compact('offers'));
    }

    public function show($id)
    {
        $offer = Offer::with([
            'customer', 
            'samples.workOrders.result', 
            'samples.workOrders.parameter.scopeType', 
            'samples.workOrders.method',
            'samples.workOrders.analyst'
        ])->findOrFail($id);

        // YENİ EKLENEN BLOK: Blade'e gitmeden önce arka planda hesaplamaları yapıyoruz
        foreach ($offer->samples as $sample) {
            foreach ($sample->workOrders as $wo) {
                $scopeName = $wo->parameter->scopeType->name ?? '';
                $paramName = $wo->parameter->name ?? '';

                // Kapsam Emisyon ve Parametre VOC ise motoru tetikle
if ($scopeName === 'Emisyon' && str_contains(strtolower($paramName), 'voc')) {
    
    // Şimdilik test için 5000 debi veriyoruz.
    $dryFlowRate = 5000.0; 
    
    // YENİ: Artık voc_table_data değil, senin alt parametre json verini gönderiyoruz!
    $sample->emission_voc_data = $this->emissionService->calculateVocMetrics(
        $wo->result->result_value ?? '[]', 
        $dryFlowRate
    );
}
            }
        }
            
        return view('admin.reporting.show', compact('offer'));
    }

    /**
     * YENİ 1: TEKLİ TASLAK RAPOR ÖNİZLEME (HTML / Yazdır Formatı)
     */
    public function previewDraft($sampleId)
    {
        $sample = Sample::with([
            'offer.customer', 
            'workOrders.result', 
            'workOrders.parameter', 
            'workOrders.method'
        ])->findOrFail($sampleId);

        // YOLU admin.reporting.pdf.report_template OLARAK GÜNCELLEDİK
        return view('admin.reporting.pdf.report_template', compact('sample'));
    }

    /**
     * YENİ 2: TOPLU TASLAK RAPOR ÖNİZLEME (Seçilen Barkodları Arka Arkaya Render Eder)
     */
    public function bulkPreviewDraft(Request $request)
    {
        $sampleIds = $request->input('sample_ids', []);
        
        if (empty($sampleIds)) {
            return back()->with('error', 'Lütfen en az bir numune seçin.');
        }

        $samples = Sample::with([
            'offer.customer', 
            'workOrders.result', 
            'workOrders.parameter', 
            'workOrders.method'
        ])->whereIn('id', $sampleIds)->get();

        return view('admin.reporting.bulk_pdf_report_template', compact('samples'));
    }

    /**
     * YENİ 3: RAPORLAMAYI TAMAMLA VE KAPAT (Tüm Teklif İçin)
     */
    public function completeReporting($offerId)
    {
        try {
            DB::beginTransaction();

            $offer = Offer::with('samples')->findOrFail($offerId);
            $updatedCount = 0;

            foreach($offer->samples as $sample) {
                $sample->update([
                    'global_status' => 'Raporlandı',
                    'status'        => 'Tamamlandı'
                ]);
                $updatedCount++;
            }

            DB::commit();
            return response()->json([
                'status' => 'success', 
                'message' => "Tüm numuneler ({$updatedCount} adet) başarıyla 'Tamamlandı' statüsüne çekildi ve süreç kapatıldı!"
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()]);
        }
    }

    /**
     * Raporlama Aşamasındaki Teklifi Analize Geri Gönderir (Koşulsuz)
     */
    public function returnToAnalysis($offerId)
    {
        try {
            DB::beginTransaction();

            $offer = Offer::with('samples')->findOrFail($offerId);
            $updatedCount = 0;

            foreach($offer->samples as $sample) {
                // Şartları tamamen kaldırdık! Raporlamadaki teklifin tüm numuneleri koşulsuz analize döner.
                $sample->update([
                    'global_status' => 'Analiz Aşamasında',
                    'status' => 'Analiz Aşamasında' 
                ]);

                // Log Kaydı
                SampleTransaction::create([
                    'sample_id' => $sample->id,
                    'user_id' => Auth::id(),
                    'action_type' => 'RETURN_TO_ANALYSIS',
                    'from_location' => 'Raporlama',
                    'to_location' => 'Analiz',
                    'description' => 'Raportör tarafından sonuçlar revize edilmek üzere Analize geri gönderildi.'
                ]);

                $updatedCount++;
            }

            DB::commit();
            return response()->json(['status' => 'success', 'message' => "{$updatedCount} adet numune başarıyla Analiz departmanına geri gönderildi!"]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()]);
        }
    }

    public function download($id)
    {
        $sample = Sample::findOrFail($id);
        
        if (!$sample->report_file) {
            return back()->with('error', 'Bu numune için rapor dosyası tanımlanmamış.');
        }

        $fullPath = storage_path('app/public/' . $sample->report_file);
        
        if (!File::exists($fullPath)) {
            return back()->with('error', 'Fiziksel dosya sunucuda bulunamadı.');
        }

        return response()->download($fullPath);
    }

    /**
     * VOC Tablosu verilerini veritabanına kaydeder/sıfırlar
     */
    public function saveVocData(Request $request, $sampleId)
    {
        try {
            $sample = Sample::findOrFail($sampleId);
            
            $sample->update([
                'voc_table_data' => $request->input('voc_data') // null gelirse sıfırlar, dolu gelirse kaydeder
            ]);

            return response()->json([
                'status' => 'success', 
                'message' => 'VOC Tablo verileri başarıyla veritabanına işlendi.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error', 
                'message' => 'Hata: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Saha Verilerini (SV) JSON olarak kaydeder
     */
    public function saveFieldData(Request $request, $sampleId)
    {
        try {
            $sample = Sample::findOrFail($sampleId);
            
            // DÜZELTME: Laravel $fillable (Mass Assignment) korumasına takılmamak için 
            // update() yerine doğrudan özelliği atayıp save() komutunu kullanıyoruz.
            $sample->field_data = $request->input('field_data');
            $sample->save();

            return response()->json([
                'status' => 'success', 
                'message' => 'Saha verileri başarıyla veritabanına işlendi.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error', 
                'message' => 'Hata: ' . $e->getMessage()
            ]);
        }
    }
}