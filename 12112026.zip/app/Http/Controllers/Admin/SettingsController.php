<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File; // Dosya işlemleri için gerekli
use Illuminate\Support\Facades\Artisan; // Önbellek temizleme komutları için eklendi

class SettingsController extends Controller
{
    public function index()
    {
        return view('admin.settings.index');
    }

    public function update(Request $request)
    {
        // ====================================================================
        // 1. .ENV DOSYASINI GÜNCELLEME (LİSANS İÇİN)
        // ====================================================================
        if ($request->has('env_license_key') && $request->filled('env_license_key')) {
            // Güvenlik: Boşlukları sil ve büyük harfe çevir
            $cleanLicenseKey = trim(strtoupper($request->env_license_key));
            
            // Özel fonksiyonumuzu çağırarak .env dosyasına yazıyoruz
            $this->updateEnvFile('LICENSE_KEY', $cleanLicenseKey);
        }

        // ====================================================================
        // 2. VERİTABANI AYARLARI (Lisans, Logo ve Favicon hariç tutuluyor)
        // ====================================================================
        foreach ($request->except(['_token', 'site_logo', 'site_favicon', 'env_license_key']) as $key => $value) {
            Setting::updateOrCreate(['key' => $key], ['value' => $value]);
        }

        // ====================================================================
        // 3. DOSYA YÜKLEME İŞLEMLERİ (Logo & Favicon)
        // ====================================================================
        $destinationPath = public_path('set');

        // Klasör yoksa oluştur
        if (!File::exists($destinationPath)) {
            File::makeDirectory($destinationPath, 0755, true);
        }

        // Logo Yükleme İşlemi
        if ($request->hasFile('site_logo')) {
            $file = $request->file('site_logo');
            $filename = 'logo_' . time() . '.' . $file->getClientOriginalExtension();
            $file->move($destinationPath, $filename);
            Setting::updateOrCreate(['key' => 'site_logo'], ['value' => 'set/' . $filename]);
        }

        // Favicon Yükleme İşlemi
        if ($request->hasFile('site_favicon')) {
            $file = $request->file('site_favicon');
            $filename = 'favicon_' . time() . '.' . $file->getClientOriginalExtension();
            $file->move($destinationPath, $filename);
            Setting::updateOrCreate(['key' => 'site_favicon'], ['value' => 'set/' . $filename]);
        }

        // .env değişikliklerinin sisteme anında yansıması için önbelleği temizle
        Artisan::call('config:clear');

        return back()->with('success', 'Sistem ayarları ve lisans bilgisi başarıyla güncellendi.');
    }

    /**
     * .env dosyasındaki belirli bir anahtarı güvenli bir şekilde günceller.
     */
    private function updateEnvFile($key, $value)
    {
        $path = base_path('.env');

        if (file_exists($path)) {
            // Dosya içeriğini tamamen oku
            $oldEnvFile = file_get_contents($path);

            // Eğer değer boşluk içeriyorsa çift tırnak içine al (Güvenlik önlemi)
            $value = preg_match('/\s/', $value) ? '"' . $value . '"' : $value;

            // Dosyanın içinde bu key (Örn: LICENSE_KEY=) var mı diye kontrol et
            if (str_contains($oldEnvFile, $key . '=')) {
                // Varsa o satırı tamamen yenisiyle değiştir
                $newEnvFile = preg_replace('/^' . $key . '=.*/m', $key . '=' . $value, $oldEnvFile);
            } else {
                // Yoksa dosyanın en altına yeni satır olarak ekle
                $newEnvFile = $oldEnvFile . "\n" . $key . '=' . $value;
            }

            // Değişiklikleri kaydet
            file_put_contents($path, $newEnvFile);
        }
    }
}