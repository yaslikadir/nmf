<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Supplier;
use App\Models\SupplierEvaluation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\SupplierClass;

class SupplierController extends Controller
{
    public function index()
{
    // Tedarikçileri Sınıfı ile birlikte çekiyoruz
    $suppliers = Supplier::with('supplierClass')->latest()->get();
    
    // Filtreleme için Sınıfları çekiyoruz
    $supplierClasses = SupplierClass::all();

    return view('admin.suppliers.index', compact('suppliers', 'supplierClasses'));
}

    public function create()
{
    // Veritabanındaki tüm sınıfları çekiyoruz (A, B, C vb.)
    $supplierClasses = SupplierClass::all();
    
    // View'a gönderiyoruz
    return view('admin.suppliers.create', compact('supplierClasses'));
}

    public function store(Request $request)
    {
        // Validasyon Kuralları ve TÜRKÇE MESAJLAR
        $request->validate([
            'company_name' => 'required',
            'category' => 'required|array', // Çoklu seçim olduğu için array bekliyoruz
            'tax_plate_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096', 
            'iso_9001_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096',
            'iso_17025_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096',
        ], [
            'company_name.required' => 'Firma ünvanı zorunludur.',
            'category.required' => 'Lütfen en az bir kategori seçiniz.',
            
            'tax_plate_file.file' => 'Vergi levhası geçerli bir dosya olmalıdır. (Form etiketinde enctype var mı?)',
            'tax_plate_file.mimes' => 'Vergi levhası sadece PDF, JPG veya PNG formatında olabilir.',
            'tax_plate_file.max' => 'Dosya boyutu 4MB\'dan küçük olmalıdır.',

            'iso_9001_file.file' => 'ISO 9001 geçerli bir dosya olmalıdır.',
            'iso_9001_file.mimes' => 'ISO 9001 sadece PDF, JPG veya PNG formatında olabilir.',
            
            'iso_17025_file.file' => 'Akreditasyon belgesi geçerli bir dosya olmalıdır.',
            'iso_17025_file.mimes' => 'Akreditasyon belgesi sadece PDF, JPG veya PNG formatında olabilir.',
        ]);

        // Verileri alırken category'yi hariç tutuyoruz, çünkü formatlayıp ekleyeceğiz
        $data = $request->except(['tax_plate_file', 'iso_9001_file', 'iso_17025_file', 'category']);

        // ÇOKLU KATEGORİ MANTIĞI: Array olarak gelen veriyi virgülle ayırıp string yapıyoruz
        if ($request->has('category') && is_array($request->category)) {
            $data['category'] = implode(', ', $request->category); // Örn: "Kalibrasyon, Kimyasal"
        }

        if ($request->hasFile('tax_plate_file')) {
            $data['tax_plate_file'] = $request->file('tax_plate_file')->store('suppliers/docs', 'public');
            $data['has_tax_plate'] = true;
        }

        if ($request->hasFile('iso_9001_file')) {
            $data['iso_9001_file'] = $request->file('iso_9001_file')->store('suppliers/docs', 'public');
        }

        if ($request->hasFile('iso_17025_file')) {
            $data['iso_17025_file'] = $request->file('iso_17025_file')->store('suppliers/docs', 'public');
        }

        Supplier::create($data);

        return redirect()->route('admin.suppliers.index')->with('success', 'Tedarikçi kartı başarıyla açıldı.');
    }

    public function show($id)
{
    // Tedarikçiyi, sınıfını, sınıfın sorularını ve kriterlerini ilişkileriyle birlikte çekiyoruz.
    $supplier = Supplier::with([
        'supplierClass.questions', 
        'supplierClass.criteria'
    ])->findOrFail($id);

    return view('admin.suppliers.show', compact('supplier'));
}

    // Puanlama ve Değerlendirme Kaydetme
    // Puanlama ve Değerlendirme Kaydetme
    public function storeEvaluation(Request $request, $id)
    {
        $supplier = Supplier::with('supplierClass.criteria')->findOrFail($id);
        
        // 1. DİNAMİK PUANLARI HESAPLA (Yeni Formdan Gelen Dizi)
        $total = 0;
        if ($request->has('scores') && is_array($request->scores)) {
            foreach ($request->scores as $score) {
                $total += intval($score);
            }
        }

        // 2. DURUMU (STATUS) BELİRLE - Senin eklediğin dinamik kriterlere göre!
        $status = 'Rejected'; // Varsayılan Red
        
        if ($supplier->supplierClass && $supplier->supplierClass->criteria->count() > 0) {
            // Puanın düştüğü kriter aralığını veritabanından bul
            $matchedCriterion = $supplier->supplierClass->criteria()
                ->where('min_score', '<=', $total)
                ->where('max_score', '>=', $total)
                ->first();

            if ($matchedCriterion) {
                // Sınıf kriterinde belirlediğimiz renklere göre sistem statüsünü atayalım
                // Yeşiller Onaylı, Sarılar Şartlı, Kırmızılar Red!
                if (in_array($matchedCriterion->color_code, ['success', 'primary'])) {
                    $status = 'Approved';
                } elseif ($matchedCriterion->color_code == 'warning') {
                    $status = 'Conditional';
                } else {
                    $status = 'Rejected';
                }
            }
        } else {
            // Kriter bulamazsa veya yoksa sistemin çökmemesi için eski mantık (Fallback)
            if ($total >= 85) $status = 'Approved';
            elseif ($total >= 70) $status = 'Conditional';
        }

        // 3. VERİTABANINA KAYDET
        SupplierEvaluation::create([
            'supplier_id' => $supplier->id,
            'evaluator_id' => Auth::id(),
            'evaluation_date' => now(),
            
            // ESKİ STATİK SÜTUNLAR (Veritabanı hata vermesin diye 0 gönderiyoruz)
            'score_technical' => 0,
            'score_cert' => 0,
            'score_quality' => 0,
            'score_delivery' => 0,
            'score_docs' => 0,
            'score_complaint' => 0,
            
            // ASIL YENİ DEĞERLER
            'total_score' => $total,
            'result' => $status,
            'comments' => $request->comments,
        ]);

        // 4. TEDARİKÇİ KARTINI GÜNCELLE
        $supplier->update([
            // DİKKAT: Resimdeki veritabanı yapına göre isimleri güncelledik!
            'score' => $total, 
            'performance_note' => $request->comments,
            
            // Eğer aşağıdaki sütunlar tablonun devamında yoksa, veritabanına eklemelisin:
            'status' => $status,
            'last_evaluation_date' => now(),
            'approved_by' => ($status == 'Approved' ? Auth::id() : null)
        ]);

        return back()->with('success', 'Değerlendirme kaydedildi ve tedarikçi durumu güncellendi.');
    }

    // DÜZENLEME SAYFASI AÇ
    public function edit($id)
{
    $supplier = Supplier::findOrFail($id);
    
    // Veritabanındaki tüm sınıfları çekiyoruz (Düzenleme ekranında listeleyebilmek için)
    $supplierClasses = SupplierClass::all();
    
    // View'a gönderiyoruz
    return view('admin.suppliers.edit', compact('supplier', 'supplierClasses'));
}
    // GÜNCELLEME İŞLEMİ
    public function update(Request $request, $id)
    {
        $supplier = Supplier::findOrFail($id);

        $request->validate([
            'company_name' => 'required',
            'category' => 'required|array', // Çoklu seçim için validation
            // Dosyalar zorunlu DEĞİL (nullable), yüklenirse formatı kontrol et
            'tax_plate_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096', 
            'iso_9001_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096',
            'iso_17025_file' => 'nullable|file|mimes:pdf,jpg,png,jpeg|max:4096',
        ]);

        // Formdan gelen verileri al, category'yi formatlamak üzere ayır
        $data = $request->except(['tax_plate_file', 'iso_9001_file', 'iso_17025_file', '_token', '_method', 'category']);

        // ÇOKLU KATEGORİ MANTIĞI: Dizi olarak geleni string yap
        if ($request->has('category') && is_array($request->category)) {
            $data['category'] = implode(', ', $request->category);
        }

        // CHECKBOX MANTIĞI: Formdan gelmezse (unchecked) 0 olarak set etmeliyiz
        $data['has_tax_plate'] = $request->has('has_tax_plate');
        $data['has_iso_9001'] = $request->has('has_iso_9001');
        $data['has_iso_17025'] = $request->has('has_iso_17025');
        $data['affects_analysis'] = $request->has('affects_analysis');

        // DOSYA GÜNCELLEME MANTIĞI
        
        // 1. Vergi Levhası Değişti mi?
        if ($request->hasFile('tax_plate_file')) {
            $data['tax_plate_file'] = $request->file('tax_plate_file')->store('suppliers/docs', 'public');
            $data['has_tax_plate'] = true; 
        }

        // 2. ISO 9001 Değişti mi?
        if ($request->hasFile('iso_9001_file')) {
            $data['iso_9001_file'] = $request->file('iso_9001_file')->store('suppliers/docs', 'public');
        }

        // 3. ISO 17025 Değişti mi?
        if ($request->hasFile('iso_17025_file')) {
            $data['iso_17025_file'] = $request->file('iso_17025_file')->store('suppliers/docs', 'public');
        }

        $supplier->update($data);

        return redirect()->route('admin.suppliers.show', $supplier->id)
                         ->with('success', 'Tedarikçi bilgileri güncellendi.');
    }
}