<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AnalysisParameter;
use App\Models\AnalysisUnit;
use Illuminate\Http\Request;

class AnalysisParameterController extends Controller
{
    public function index()
    {
        $parameters = AnalysisParameter::with('unit')->orderBy('name')->get();
        $units = AnalysisUnit::all(); // Modalda seçim için

        return view('admin.analysis_parameters.index', compact('parameters', 'units'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'tat' => 'required|integer|min:1', // Süre en az 1 gün olmalı
        ]);

        // Akreditasyon checkbox'ı için kontrol
        $data = $request->all();
        $data['is_accredited'] = $request->has('is_accredited');

        AnalysisParameter::create($data);

        return back()->with('success', 'Analiz parametresi başarıyla tanımlandı.');
    }

    public function update(Request $request)
    {
        $request->validate([
            'id' => 'required|exists:analysis_parameters,id',
            'name' => 'required|string|max:255',
        ]);

        $parameter = AnalysisParameter::findOrFail($request->id);
        
        $data = $request->all();
        $data['is_accredited'] = $request->has('is_accredited'); // Checkbox kontrolü

        $parameter->update($data);

        return response()->json(['status' => 'success', 'message' => 'Analiz güncellendi.']);
    }

    public function destroy($id)
    {
        AnalysisParameter::findOrFail($id)->delete();
        return back()->with('success', 'Analiz parametresi silindi (Arşivlendi).');
    }
    
    // Birim Ekleme (Hızlı Tanımlama İçin)
    public function storeUnit(Request $request)
    {
        $request->validate(['name' => 'required', 'symbol' => 'required']);
        AnalysisUnit::create($request->all());
        return back()->with('success', 'Yeni birim eklendi.');
    }
}