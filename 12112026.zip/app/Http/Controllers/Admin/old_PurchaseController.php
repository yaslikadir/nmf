<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PurchaseRequest;
use App\Models\PurchaseRequestItem; // Modelimizi kullanıyoruz
use App\Models\Material;
use App\Models\Department;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PurchaseController extends Controller
{
    /**
     * Talep Havuzu (Liste) - Yetki ve Öncelik Bazlı
     */
    public function index()
    {
        // YETKİLENDİRME: Eski manuel rol kontrolleri yerine akıllı kalkanımızı devreye soktuk.
        // 'purchase_requests' modül anahtarını kullanarak Seviye 1, 2 veya 3 yetkilerini otomatik uygular.
        $requests = PurchaseRequest::withPermission('purchase_requests')
            ->with(['requester', 'department', 'approver'])
            ->withCount('items')
            ->orderByRaw("FIELD(priority, 'High', 'Normal', 'Low')")
            ->latest()
            ->paginate(15);

        return view('admin.purchase.requests.index', compact('requests'));
    }

    /**
     * Yeni Talep Formu
     */
    public function create(Request $request)
    {
        $preSelectedMaterialId = $request->query('material_id'); 

        $materials = Material::select('id', 'name', 'sku', 'unit', 'cas_no')->get();
        $managers = User::where('id', '!=', Auth::id())->get();
        
        // Tüm departmanları çekiyoruz
        $departments = Department::all(); 
        
        $userDepartment = Auth::user()->department; 

        return view('admin.purchase.requests.create', compact('materials', 'userDepartment', 'managers', 'preSelectedMaterialId', 'departments'));
    }

    /**
     * Talebi Kaydet (Transaction ile)
     */
    public function store(Request $request)
    {
        // 1. Validasyon Kuralları ve ÖZEL MESAJLAR
        $request->validate([
            'department_id' => 'required|exists:departments,id',
            'approver_id' => 'required|exists:users,id',
            'requested_by_date' => 'required|date|after:today',
            'priority' => 'required',
            'items' => 'required|array|min:1', 
            'items.*.material_id' => 'required|exists:materials,id',
            'items.*.quantity' => 'required|numeric|min:0.0001',
        ], [
            // Özel Türkçe Hata Mesajları
            'approver_id.required' => 'Lütfen onaylayacak yöneticiyi seçiniz.',
            'requested_by_date.required' => 'Lütfen termin tarihini (ne zamana lazım) belirtiniz.',
            'requested_by_date.after' => 'Termin tarihi bugünden ileri bir tarih olmalıdır.',
            'items.required' => 'Lütfen listeye en az bir malzeme ekleyiniz.',
            'items.min' => 'Lütfen listeye en az bir malzeme ekleyiniz.',
            'department_id.required' => 'Departman bilgisi alınamadı, lütfen sayfayı yenileyip tekrar deneyin.',
            'items.*.material_id.required' => 'Seçilen malzemelerden biri hatalı.',
            'items.*.quantity.required' => 'Lütfen tüm malzemeler için miktar giriniz.',
            'items.*.quantity.min' => 'Miktar 0 dan büyük olmalıdır.',
        ]);

        try {
            DB::beginTransaction();

            $dateStr = date('Ymd');
            $count = PurchaseRequest::whereDate('created_at', today())->count() + 1;
            $reqNo = 'REQ-' . $dateStr . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

            $purchaseRequest = PurchaseRequest::create([
                'request_no' => $reqNo,
                'requester_id' => Auth::id(), // Kaydı oluşturan kişi otomatik atanıyor (ownerColumn)
                'department_id' => $request->department_id,
                'approver_id' => $request->approver_id,
                'requested_by_date' => $request->requested_by_date,
                'priority' => $request->priority,
                'reason' => $request->reason,
                'status' => 'Pending',
            ]);

            foreach ($request->items as $item) {
                PurchaseRequestItem::create([
                    'purchase_request_id' => $purchaseRequest->id,
                    'material_id' => $item['material_id'],
                    'quantity' => $item['quantity'],
                    'unit' => $item['unit'] ?? 'Adet',
                    'technical_specifications' => $item['specs'] ?? null,
                ]);
            }

            DB::commit();
            return redirect()->route('admin.purchase.requests.index')
                ->with('success', 'Satın alma talebi başarıyla oluşturuldu. No: ' . $reqNo);

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Kayıt sırasında hata oluştu: ' . $e->getMessage())->withInput();
        }
    }

    /**
     * Talep Detay ve Onay Sayfası
     */
    public function show($id)
    {
        // İlişkileri yükleyerek çekiyoruz
        $req = PurchaseRequest::with(['requester', 'department', 'items.material', 'approver'])->findOrFail($id);
        return view('admin.purchase.requests.show', compact('req'));
    }

    /**
     * Onaylama veya Reddetme İşlemi
     */
    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'action' => 'required|in:Approved,Rejected',
            'approval_note' => 'required|string|min:5', // Yorum zorunlu
        ]);

        $purchaseRequest = PurchaseRequest::findOrFail($id);

        // Güvenlik Kontrolü: Sadece atanan onaycı veya Admin işlem yapabilir
        if (Auth::id() != $purchaseRequest->approver_id && !Auth::user()->isAdmin()) {
            abort(403, 'Bu işlem için yetkiniz yok.');
        }

        $purchaseRequest->update([
            'status' => $request->action,
            'approval_note' => $request->approval_note,
            'responded_at' => now(),
        ]);

        $msg = $request->action == 'Approved' ? 'Talep onaylandı, teklif sürecine aktarılacak.' : 'Talep reddedildi.';
        return back()->with('success', $msg);
    }

    /**
     * Satın Alma Talep Formu Yazdır (ISO 17025 - FR-06-01)
     */
    public function printForm($id)
    {
        $req = PurchaseRequest::with(['requester', 'department', 'items.material', 'approver'])->findOrFail($id);
        $logoUrl = asset('assets/img/logo.png');
        return view('admin.purchase.requests.print-form', compact('req'));
    }
}