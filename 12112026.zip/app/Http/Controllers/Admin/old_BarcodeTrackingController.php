<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Sample;
use App\Models\SamplePreparation;
use App\Models\SampleTransfer;
use App\Models\SampleDisposal;
use App\Models\SampleTransaction;
use App\Models\SampleAnalysis;

class BarcodeTrackingController extends Controller
{
    public function index()
    {
        return view('admin.barcode_tracker.index');
    }

    public function search(Request $request)
    {
        $barcode = $request->input('barcode');

        if (!$barcode) {
            return redirect()->route('admin.barcode-tracker.index')->with('warning', 'Lütfen aramak için bir barkod giriniz.');
        }

        // 1. ANA NUMUNE VERİSİNİ ÇEK (Kısmi Arama Desteği İle)
        $sample = Sample::with([
            'offer.customer', 
            'acceptor', 
            'labAcceptor', 
            'storageLocation',
            'workOrders'
        ])
        ->where(function($query) use ($barcode) {
            $query->where('barcode', $barcode)
                  ->orWhere('barcode', 'LIKE', '%' . $barcode);
        })
        ->latest()
        ->first();

        if (!$sample) {
            return redirect()->route('admin.barcode-tracker.index')->with('error', "{$barcode} numarası ile eşleşen bir barkod sistemde bulunamadı!");
        }

        // --- YENİ EKLENEN: AYNI TEKLİFE AİT KARDEŞ BARKODLARI ÇEK ---
        $relatedSamples = collect();
        if ($sample->offer_id) {
            $relatedSamples = Sample::where('offer_id', $sample->offer_id)
                                    ->orderBy('barcode', 'asc')
                                    ->get(['id', 'barcode', 'analysis_summary', 'status']);
        } else {
            // Eğer teklifsiz bir numuneyse sadece kendisini listeye ekle
            $relatedSamples->push($sample);
        }

        $timeline = collect();

        // ---------------------------------------------------------
        // 1. TEMEL EVRELER (Oluşturma, Kabul, Tamamlanma)
        // ---------------------------------------------------------
        if ($sample->created_at) {
            $timeline->push([
                'date' => $sample->created_at,
                'icon' => 'fas fa-qrcode',
                'color' => 'secondary',
                'title' => 'Barkod Oluşturuldu',
                'description' => "Sisteme tanımlandı. (Parametre: {$sample->analysis_summary})",
                'user' => 'Sistem'
            ]);
        }

        if ($sample->accepted_at) {
            $timeline->push([
                'date' => $sample->accepted_at,
                'icon' => 'fas fa-check-circle',
                'color' => 'success',
                'title' => 'Merkez / Depo Kabulü',
                'description' => "Numune depoya alındı. (Lokasyon: " . ($sample->storageLocation->name ?? 'Belirtilmedi') . ")",
                'user' => $sample->acceptor->name ?? 'Bilinmiyor'
            ]);
        }

        if ($sample->lab_accepted_at) {
            $timeline->push([
                'date' => $sample->lab_accepted_at,
                'icon' => 'fas fa-flask',
                'color' => 'primary',
                'title' => 'Laboratuvar Teslimi',
                'description' => 'Numune analiz için laboratuvara kabul edildi.',
                'user' => $sample->labAcceptor->name ?? 'Bilinmiyor'
            ]);
        }

        // ---------------------------------------------------------
        // 2. ÖN İŞLEMLER (SamplePreparation)
        // ---------------------------------------------------------
        $preparations = SamplePreparation::with(['technician', 'device'])->where('sample_id', $sample->id)->get();
        foreach ($preparations as $prep) {
            if ($prep->started_at) {
                $timeline->push([
                    'date' => $prep->started_at,
                    'icon' => 'fas fa-vial',
                    'color' => 'info',
                    'title' => 'Ön İşlem Başladı',
                    'description' => "İşlem: " . ($prep->process_name ?? 'Tanımsız') . ($prep->device ? " (Cihaz: {$prep->device->name})" : ""),
                    'user' => $prep->technician->name ?? 'Bilinmiyor'
                ]);
            }
            if ($prep->completed_at) {
                $timeline->push([
                    'date' => $prep->completed_at,
                    'icon' => 'fas fa-check-double',
                    'color' => 'info',
                    'title' => 'Ön İşlem Tamamlandı',
                    'description' => "Ön hazırlık süreci bitirildi.",
                    'user' => $prep->technician->name ?? 'Bilinmiyor'
                ]);
            }
        }

        // ---------------------------------------------------------
        // 3. TRANSFERLER (SampleTransfer)
        // ---------------------------------------------------------
        $transfers = SampleTransfer::with(['fromLocation', 'toLocation', 'requester', 'receiver', 'transporter'])
                                   ->where('sample_id', $sample->id)->get();
        foreach ($transfers as $transfer) {
            if ($transfer->created_at) {
                $timeline->push([
                    'date' => $transfer->created_at,
                    'icon' => 'fas fa-truck-loading',
                    'color' => 'warning',
                    'title' => 'Transfer Talep Edildi',
                    'description' => ($transfer->fromLocation->name ?? '?') . " konumundan " . ($transfer->toLocation->name ?? '?') . " konumuna transfer istendi.",
                    'user' => $transfer->requester->name ?? 'Bilinmiyor'
                ]);
            }
            if ($transfer->transfer_date) {
                $timeline->push([
                    'date' => $transfer->transfer_date,
                    'icon' => 'fas fa-truck',
                    'color' => 'warning',
                    'title' => 'Transfer Başladı (Yolda)',
                    'description' => "Numune taşıma işlemi başlatıldı.",
                    'user' => $transfer->transporter->name ?? 'Bilinmiyor'
                ]);
            }
            if ($transfer->received_date) {
                $timeline->push([
                    'date' => $transfer->received_date,
                    'icon' => 'fas fa-box-open',
                    'color' => 'success',
                    'title' => 'Transfer Tamamlandı / Teslim Alındı',
                    'description' => "Numune yeni lokasyonuna ulaştı ve teslim alındı.",
                    'user' => $transfer->receiver->name ?? 'Bilinmiyor'
                ]);
            }
        }

        // ---------------------------------------------------------
        // 4. İMHA SÜREÇLERİ (SampleDisposal)
        // ---------------------------------------------------------
        $disposals = SampleDisposal::with(['requester', 'approver', 'executor'])->where('sample_id', $sample->id)->get();
        foreach ($disposals as $disposal) {
            if ($disposal->request_date) {
                $timeline->push([
                    'date' => $disposal->request_date,
                    'icon' => 'fas fa-trash-alt',
                    'color' => 'danger',
                    'title' => 'İmha Talep Edildi',
                    'description' => "Numunenin kullanım ömrü dolduğu/gerek kalmadığı için imhası istendi.",
                    'user' => $disposal->requester->name ?? 'Bilinmiyor'
                ]);
            }
            if ($disposal->approval_date) {
                $timeline->push([
                    'date' => $disposal->approval_date,
                    'icon' => 'fas fa-stamp',
                    'color' => 'danger',
                    'title' => 'İmha Onaylandı',
                    'description' => "İmha talebi yetkili tarafından onaylandı.",
                    'user' => $disposal->approver->name ?? 'Bilinmiyor'
                ]);
            }
            if ($disposal->disposal_date) {
                $timeline->push([
                    'date' => $disposal->disposal_date,
                    'icon' => 'fas fa-biohazard',
                    'color' => 'dark',
                    'title' => 'Numune İmha Edildi',
                    'description' => "Numune fiziksel olarak sistemden ve depodan imha edildi.",
                    'user' => $disposal->executor->name ?? 'Bilinmiyor'
                ]);
            }
        }

        // ---------------------------------------------------------
        // 5. DİĞER HAREKETLER (SampleTransaction)
        // ---------------------------------------------------------
        $transactions = SampleTransaction::with('user')->where('sample_id', $sample->id)->get();
        foreach ($transactions as $transaction) {
            $timeline->push([
                'date' => $transaction->created_at,
                'icon' => 'fas fa-exchange-alt',
                'color' => 'secondary',
                'title' => 'Sistem Hareketi: ' . ($transaction->action ?? 'İşlem'),
                'description' => $transaction->details ?? 'Detay yok.',
                'user' => $transaction->user->name ?? 'Sistem'
            ]);
        }

        // ---------------------------------------------------------
        // 6. ANALİZ VE RAPORLAMA
        // ---------------------------------------------------------
        if ($sample->relationLoaded('workOrders')) {
            foreach ($sample->workOrders as $workOrder) {
                if ($workOrder->status === 'Tamamlandı' || $workOrder->result) {
                    $timeline->push([
                        'date' => $workOrder->updated_at,
                        'icon' => 'fas fa-microscope',
                        'color' => 'success',
                        'title' => 'Analiz Sonucu Girildi',
                        'description' => "Analiz tamamlandı ve veriler işlendi.",
                        'user' => 'Analist'
                    ]);
                }
            }
        }

        if ($sample->status === 'Tamamlandı' && $sample->completed_at) {
            $timeline->push([
                'date' => $sample->completed_at,
                'icon' => 'fas fa-file-pdf',
                'color' => 'dark',
                'title' => 'Raporlandı',
                'description' => "Numune analiz raporu oluşturuldu ve süreç kapatıldı.",
                'user' => 'Sistem / Onaylayıcı'
            ]);
        }

        $timeline = $timeline->sortByDesc('date')->values();

        // relatedSamples değişkenini de compact içine ekledik
        return view('admin.barcode_tracker.index', compact('sample', 'timeline', 'relatedSamples'));
    }
}