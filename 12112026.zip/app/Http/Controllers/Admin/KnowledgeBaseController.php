<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class KnowledgeBaseController extends Controller
{
    /**
     * Kategori klasörleri ve kullanıcıya görünen adları.
     * Dosyalar mevcut projede public/storage/kk altında tutuluyor.
     */
    private const CATEGORIES = [
        'moduller' => 'Modül Kılavuzları',
        'satis' => 'Satış ve Sözleşme Belgeleri',
        'politikalar' => 'Politikalar',
    ];

    /**
     * Admin veya role_id=2 olan Kalite Yöneticisi erişebilir.
     */
    private function authorizeAccess(): void
    {
        $user = auth()->user();

        abort_unless(
            $user && (
                $user->hasRole('admin') ||
                $user->roles()->whereKey(2)->exists()
            ),
            403,
            'Bu belge merkezine erişim yetkiniz bulunmuyor.'
        );
    }

    public function index(Request $request)
    {
        $this->authorizeAccess();

        $basePath = public_path('storage/kk');
        $selectedCategory = $request->string('category')->toString();
        $search = trim($request->string('q')->toString());

        $documents = collect();

        foreach (self::CATEGORIES as $folder => $label) {
            if ($selectedCategory && $selectedCategory !== $folder) {
                continue;
            }

            $folderPath = $basePath . DIRECTORY_SEPARATOR . $folder;
            if (!is_dir($folderPath)) {
                continue;
            }

            foreach (glob($folderPath . DIRECTORY_SEPARATOR . '*.{pdf,PDF}', GLOB_BRACE) ?: [] as $absolutePath) {
                $filename = basename($absolutePath);
                $title = $this->displayTitle($filename);

                if ($search !== '' && !str_contains(mb_strtolower($title), mb_strtolower($search))) {
                    continue;
                }

                $documents->push([
                    'category' => $folder,
                    'category_label' => $label,
                    'filename' => $filename,
                    'title' => $title,
                    'size' => $this->formatBytes(filesize($absolutePath)),
                    'modified_at' => date('d.m.Y H:i', filemtime($absolutePath)),
                    'view_url' => route('admin.knowledge-base.view', [$folder, $filename]),
                    'download_url' => route('admin.knowledge-base.download', [$folder, $filename]),
                ]);
            }
        }

        $documents = $documents->sortBy([
            ['category_label', 'asc'],
            ['title', 'asc'],
        ])->values();

        return view('admin.knowledge_base.index', [
            'documents' => $documents,
            'categories' => self::CATEGORIES,
            'selectedCategory' => $selectedCategory,
            'search' => $search,
            'totalDocuments' => $documents->count(),
        ]);
    }

    public function view(string $category, string $filename): BinaryFileResponse
    {
        $this->authorizeAccess();
        $path = $this->safePath($category, $filename);

        abort_unless(is_file($path), 404);

        return response()->file($path, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="' . basename($path) . '"',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function download(string $category, string $filename): BinaryFileResponse
    {
        $this->authorizeAccess();
        $path = $this->safePath($category, $filename);

        abort_unless(is_file($path), 404);

        return response()->download($path, basename($path), [
            'Content-Type' => 'application/pdf',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    private function safePath(string $category, string $filename): string
    {
        abort_unless(array_key_exists($category, self::CATEGORIES), 404);

        $safeFilename = basename($filename);
        abort_if($safeFilename !== $filename || !preg_match('/\.pdf$/i', $safeFilename), 404);

        $basePath = realpath(public_path('storage/kk'));
        $path = realpath(public_path('storage/kk/' . $category . '/' . $safeFilename));

        abort_unless($basePath && $path && str_starts_with($path, $basePath . DIRECTORY_SEPARATOR), 404);

        return $path;
    }

    private function displayTitle(string $filename): string
    {
        $name = pathinfo($filename, PATHINFO_FILENAME);
        $name = preg_replace('/\.pdf$/i', '', $name);
        $name = preg_replace('/[_-]+/', ' ', $name);
        return trim($name);
    }

    private function formatBytes(int|false $bytes): string
    {
        if ($bytes === false) {
            return '-';
        }

        return number_format($bytes / 1024, 0, ',', '.') . ' KB';
    }
}
