<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MasterAuthController extends Controller
{
    /**
     * Master şifre ekranını gösterir.
     */
    public function show()
    {
        return view('admin.master_login');
    }

    /**
     * Master şifreyi doğrular ve güvenli alan oturumunu açar.
     */
    public function verify(Request $request)
    {
        $request->validate([
            'password' => ['required', 'string'],
        ]);

        // Şifre config üzerinden okunmalıdır; Controller içinde env() kullanılmamalıdır.
        $configuredPassword = (string) config('admin.master_page_password');
        $submittedPassword = (string) $request->input('password');

        if (
            $configuredPassword !== '' &&
            hash_equals($configuredPassword, $submittedPassword)
        ) {
            // Başarılı doğrulamadan sonra session fixation riskini azaltır.
            $request->session()->regenerate();
            $request->session()->put('master_unlocked', true);

            return redirect()->to(
                $request->session()->pull(
                    'url.intended',
                    route('admin.backups.index')
                )
            );
        }

        return back()
            ->withInput()
            ->with('error', 'Hatalı şifre! Bu alana giriş yetkiniz yok.');
    }
}
