<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Customer;
use App\Models\Contact;
use App\Models\Definition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ActivityController extends Controller
{
    /**
     * Tüm aktiviteleri listeler.
     * Global Scope (Trait) sayesinde her kullanıcı sadece yetkisi olanı görür.
     */
   public function index()
    {
        // 1. DİKKAT: Global Scope'u eziyoruz ve N+1 için with ekliyoruz!
        $query = Activity::withoutGlobalScopes()->with(['customer', 'contact', 'creator.department']);

        // --- YETKİ VE GÖRÜNÜRLÜK (VIEW LEVEL) KONTROLÜ BAŞLANGICI ---
        $user = auth()->user();
        $isAdmin = $user->hasRole('admin');

        if (!$isAdmin) {
            // Modülü bul ve aktif rolün bu modüldeki yetkisini çek ('activities' anahtarı ile)
            $module = \App\Models\Module::where('module_key', 'activities')->first();
            $perm = null;

            if ($module && $user->activeRole) {
                $perm = $user->activeRole->rolePermissions()->where('module_id', $module->id)->first();
            }

            // Görünürlük (view_level) Filtrelemesi:
            if (!$perm || $perm->view_level == 0) {
                // Yetki hiç yoksa tabloyu boş döndür
                $query->whereRaw('1 = 0'); 
            } elseif ($perm->view_level == 1) {
                // 1 ise: SADECE KENDİ eklediği aktiviteleri görsün
                $query->where('created_by', $user->id); 
            }
            // view_level == 3 (Tümü) ise $query'e müdahale etmiyoruz.
        }
        // --- YETKİ KONTROLÜ BİTİŞİ ---

        // withoutGlobalScopes() ile Model'deki 'latest_first' filtresini de ezdiğimiz için, 
        // en yeni tarihli olanı en üste getirme sıralamasını burada tekrar ekliyoruz:
        $activities = $query->orderBy('date', 'desc')->get(); 

        return view('admin.activities.index', compact('activities'));
    }

    /**
     * Yeni aktivite oluşturma formu.
     */
    public function create(Request $request)
    {
        $customers = Customer::where('is_active', true)->orderBy('name')->get();
        
        $activityTypes = Definition::byGroup('activity_type')->get();
        $activityStatuses = Definition::byGroup('activity_status')->get();

        $selected_customer_id = $request->get('customer_id');
        $contacts = [];
        
        if ($selected_customer_id) {
            $contacts = Contact::where('customer_id', $selected_customer_id)->get();
        }

        return view('admin.activities.create', compact(
            'customers', 
            'contacts', 
            'activityTypes', 
            'activityStatuses', 
            'selected_customer_id'
        ));
    }

    /**
     * Yeni aktivite kaydı.
     */
    public function store(Request $request)
    {
        $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'type'        => 'required|string',
            'subject'     => 'required|string|max:255',
            'date'        => 'required',
            'status'      => 'required|string',
        ]);

        // Model içindeki static::creating metodumuz created_by'ı otomatik atayacak.
        // Burada sadece formu valide edip basıyoruz.
        Activity::create($request->all());

        return redirect()->route('admin.activities.index')
            ->with('success', 'Görüşme (Aktivite) başarıyla kaydedildi.');
    }

    /**
     * Aktivite düzenleme formu.
     */
    public function edit(Activity $activity)
    {
        $customers = Customer::all();
        $contacts = Contact::where('customer_id', $activity->customer_id)->get();
        
        $activityTypes = Definition::byGroup('activity_type')->get();
        $activityStatuses = Definition::byGroup('activity_status')->get();

        return view('admin.activities.edit', compact(
            'activity', 
            'customers', 
            'contacts', 
            'activityTypes',
            'activityStatuses'
        ));
    }

    /**
     * Aktivite güncelleme.
     */
    public function update(Request $request, Activity $activity)
    {
        $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'type'        => 'required|string',
            'subject'     => 'required|string|max:255',
            'date'        => 'required',
            'status'      => 'required|string',
        ]);

        $activity->update($request->except('created_by'));

        return redirect()->route('admin.activities.index')
            ->with('success', 'Görüşme bilgileri güncellendi.');
    }

    /**
     * Aktiviteyi siler (Soft Delete).
     */
    public function destroy(Activity $activity)
    {
        $activity->delete();

        return redirect()->route('admin.activities.index')
            ->with('success', 'Aktivite silindi (Arşive taşındı).');
    }
}