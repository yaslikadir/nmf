<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sample;
use App\Models\Offer;
use App\Models\SamplePreparation;
use App\Models\Device;
use App\Models\User;
use App\Models\SampleTransaction;
use App\Models\Material; 
use App\Models\StockMovement; 
use App\Models\Inventory;
use App\Models\AnalysisMethod; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SamplePreparationController extends Controller
{
    public function index()
    {
        $activeOffers = Offer::with('customer')
            ->whereHas('samples', function($q) {
                $q->where('status', 'Kabul Edildi')
                  ->whereNull('lab_accepted_at') 
                  ->where(function($subQ) {
                      $subQ->whereNull('global_status')->orWhere('global_status', '!=', 'İmha Edildi');
                  });
            })->orderBy('created_at', 'desc')->get();

        $labReceivedSamples = Sample::with(['offer.customer', 'acceptor', 'labAcceptor'])
            ->whereNotNull('lab_accepted_at')
            ->orderBy('lab_accepted_at', 'desc')
            ->take(300)
            ->get()
            ->groupBy('offer_id');

        // Sadece lokasyonu "Laboratuvar" (ID: 53) olan aktif cihazları getir
        $devices = Device::where('is_active', true)
            ->where('device_location_id', 53)
            ->get();
        $users = User::where('is_active', true)->get(); 

        // 1. Ön işlem bekleyen teklifler
        $offersForPrep = Offer::with(['customer'])
            ->whereHas('samples', function($q) {
                $q->whereIn('global_status', ['Laboratuvara Alındı', 'Ön İşlem Bekliyor', 'Ön İşlemde']);
            })->orderBy('created_at', 'desc')->get();

        // 2. YENİ: Tamamlanan işlemleri olan teklifler (Güvenli ilişki ile)
        $completedOfferIds = SamplePreparation::where('sample_preparations.status', 'Tamamlandı') // BURAYA DİKKAT: Tablo adı eklendi
            ->join('samples', 'sample_preparations.sample_id', '=', 'samples.id')
            ->select('samples.offer_id')
            ->distinct()
            ->pluck('offer_id');
            
        $completedOffersForPrep = Offer::with(['customer'])
            ->whereIn('id', $completedOfferIds)
            ->orderBy('created_at', 'desc')
            ->get();

        // 3. Kimyasallar (Stoktan düşmek için)
        $chemicals = Material::whereHas('category', function($q) {
                $q->whereIn('slug', ['kimyasal', 'referans-malzeme']);
            })
            ->where(function($q) {
                $q->where('is_active', true)->orWhereNull('is_active');
            })
            ->orderBy('name', 'asc')->get();

        // 4. Dinamik Metotları Çek
        $methods = AnalysisMethod::whereIn('status', ['Published', 'Pending'])->orderBy('code')->get();

        return view('admin.sample_preparations.index', compact(
            'activeOffers', 'labReceivedSamples', 'devices', 'users', 
            'offersForPrep', 'completedOffersForPrep', 'chemicals', 'methods'
        ));
    }

    public function getPendingReceiptSamples(Request $request)
    {
        $offerId = $request->offer_id;
        if (!$offerId) return response()->json(['status' => 'error', 'message' => 'Geçersiz Teklif']);

        $samples = Sample::with(['offer.customer', 'acceptor', 'storageLocation'])
                         ->where('offer_id', $offerId)
                         ->where('status', 'Kabul Edildi')
                         ->whereNull('lab_accepted_at')
                         ->get();

        if ($samples->isEmpty()) return response()->json(['status' => 'empty', 'message' => 'Bu teklife ait laboratuvara teslim alınacak yeni numune yok.']);
        return response()->json(['status' => 'success', 'data' => $samples]);
    }

    public function receiveSamples(Request $request)
    {
        $request->validate(['sample_ids' => 'required|array|min:1']);

        try {
            DB::beginTransaction();
            $userId = Auth::id();
            $count = 0;

            foreach($request->sample_ids as $id) {
                $sample = Sample::find($id);
                if (!$sample || $sample->lab_accepted_at != null) continue;

                $sample->update([
                    'lab_accepted_by' => $userId,
                    'lab_accepted_at' => now(),
                    'lab_acceptance_note' => $request->note,
                    'global_status' => 'Laboratuvara Alındı'
                ]);

                SampleTransaction::create([
                    'sample_id' => $sample->id,
                    'user_id' => $userId,
                    'action_type' => 'LAB_HANDOVER',
                    'from_location' => $sample->storageLocation->name ?? 'Numune Kabul',
                    'to_location' => 'Laboratuvar İşlem Alanı',
                    'description' => "Numune analizci tarafından teslim alındı. Not: " . ($request->note ?? '-')
                ]);
                $count++;
            }

            DB::commit();
            return response()->json(['status' => 'success', 'message' => $count . ' adet numune laboratuvara teslim alındı.']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }

    public function getAcceptedSamples(Request $request)
    {
        $offerId = $request->offer_id;
        if (!$offerId) return response()->json(['status' => 'error', 'message' => 'Geçersiz Teklif']);

        $samples = Sample::with(['offer.customer'])
                         ->where('offer_id', $offerId)
                         ->where('status', 'Kabul Edildi')
                         ->whereNotNull('lab_accepted_at')
                         ->where(function($q) {
                             $q->where('global_status', 'Laboratuvara Alındı')
                               ->orWhereNull('global_status');
                         })->get();

        if ($samples->isEmpty()) return response()->json(['status' => 'empty', 'message' => 'Önce numuneleri teslim almalısınız. İşlem atanacak numune bulunamadı.']);
        return response()->json(['status' => 'success', 'data' => $samples]);
    }

    public function getOfferSamplesForPrep($offerId)
    {
        $samples = Sample::where('offer_id', $offerId)
            ->whereIn('global_status', ['Laboratuvara Alındı', 'Ön İşlem Bekliyor', 'Ön İşlemde'])
            ->get();

        if ($samples->isEmpty()) {
            return response()->json(['status' => 'empty', 'message' => 'Bu teklife ait işlem bekleyen numune bulunamadı.']);
        }

        // YENİ EKLENEN KISIM: Alt parametre ID'lerini İsimlere çevirip numuneye ekliyoruz
        foreach($samples as $sample) {
            $sample->sub_parameter_names = '-';
            if (!empty($sample->selected_sub_parameters)) {
                // Seçili ID'leri veritabanından bul ve isimlerini aralarına virgül koyarak birleştir
                $names = \App\Models\SubParameter::whereIn('id', $sample->selected_sub_parameters)->pluck('name')->toArray();
                if(count($names) > 0) {
                    $sample->sub_parameter_names = implode(', ', $names);
                }
            }
        }

        return response()->json(['status' => 'success', 'data' => $samples]);
    }

    public function bulkComplete(Request $request)
    {
        $request->validate([
            'sample_ids' => 'required|array|min:1',
            'process_name' => 'required|string',
            'materials' => 'nullable|array',
            'material_quantities' => 'nullable|array',
            'material_usage_units' => 'nullable|array'
        ]);

        try {
            DB::beginTransaction();
            $userId = Auth::id();
            $count = 0;

            $materialsArr = $request->input('materials', []);
            $quantitiesArr = $request->input('material_quantities', []);
            $usageUnitsArr = $request->input('material_usage_units', []);

            foreach ($request->sample_ids as $sampleId) {
                // Numuneyi teklif ilişkisi ile birlikte çekiyoruz ki teklif no'yu bilelim
                $sample = Sample::with('offer')->find($sampleId);
                if (!$sample) continue;

                $prep = SamplePreparation::firstOrNew([
                    'sample_id' => $sample->id,
                    'status' => 'Bekliyor'
                ]);

                $prep->process_name = $request->process_name;
                $prep->technician_id = $request->technician_id ?? $userId;
                $prep->device_id = $request->device_id;
                $prep->method_used = $request->method_used;
                $prep->observations = $request->observations;
                $prep->secret_note = $request->secret_note; 
                $prep->status = 'Tamamlandı';
                $prep->started_at = $prep->started_at ?? now();
                $prep->completed_at = now();
                $prep->save();

                $sample->update(['global_status' => 'Analize Hazır']);

                SampleTransaction::create([
                    'sample_id' => $sample->id,
                    'user_id' => $userId,
                    'action_type' => 'PREP_COMPLETE',
                    'from_location' => 'Ön Hazırlık',
                    'to_location' => 'Analiz Sırası',
                    'description' => "{$prep->process_name} toplu olarak tamamlandı. Numune analize hazır."
                ]);

                if (!empty($materialsArr) && is_array($materialsArr)) {
                    foreach ($materialsArr as $index => $matId) {
                        if (empty($matId)) continue; 
                        
                        $rawQty = isset($quantitiesArr[$index]) ? str_replace(',', '.', $quantitiesArr[$index]) : '0';
                        $inputQty = floatval($rawQty);
                        $usageUnit = isset($usageUnitsArr[$index]) ? strtolower(trim($usageUnitsArr[$index])) : '';
                        
                        if ($inputQty > 0) {
                            $material = Material::find($matId);
                            if ($material) {
                                $baseUnit = strtolower(trim($material->unit));
                                $finalQtyToDeduct = $inputQty;

                                if (in_array($baseUnit, ['litre', 'l', 'lt']) && $usageUnit === 'ml') {
                                    $finalQtyToDeduct = $inputQty / 1000;
                                } elseif (in_array($baseUnit, ['kg', 'kilogram']) && $usageUnit === 'gr') {
                                    $finalQtyToDeduct = $inputQty / 1000;
                                } elseif (in_array($baseUnit, ['kg', 'kilogram']) && $usageUnit === 'mg') {
                                    $finalQtyToDeduct = $inputQty / 1000000;
                                } elseif (in_array($baseUnit, ['gr', 'gram']) && $usageUnit === 'mg') {
                                    $finalQtyToDeduct = $inputQty / 1000;
                                }

                                // YENİ: LOG İÇERİĞİNE TEKLİF NUMARASI EKLENDİ VE İPTAL İÇİN STANDARTLAŞTIRILDI
                                $offerNo = $sample->offer ? $sample->offer->offer_no : 'Belirtilmemiş';
                                $logDescPrefix = "Teklif: {$offerNo} | Barkod: {$sample->barcode} numunesi {$prep->process_name} işlemi için";
                                $logDesc = "{$logDescPrefix} kullanıldı. (Girdi: {$inputQty} {$usageUnit})";

                                // Hareket Kaydı (Log)
                                StockMovement::create([
                                    'material_id' => $material->id,
                                    'type' => 'out',
                                    'quantity' => -abs($finalQtyToDeduct), 
                                    'user_id' => $userId,
                                    'description' => $logDesc
                                ]);

                                // YENİ: FİZİKSEL ENVANTERDEN (LOTLARDAN) FIFO YÖNTEMİYLE DÜŞ
                                $remainingToDeduct = $finalQtyToDeduct;
                                $inventories = Inventory::where('material_id', $material->id)
                                    ->where('quantity', '>', 0)
                                    ->orderBy('expiration_date', 'asc') // SKT'si en yakın olandan başla
                                    ->get();

                                foreach ($inventories as $inv) {
                                    if ($remainingToDeduct <= 0) break;
                                    if ($inv->quantity >= $remainingToDeduct) {
                                        $inv->quantity -= $remainingToDeduct;
                                        $inv->save();
                                        $remainingToDeduct = 0;
                                    } else {
                                        $remainingToDeduct -= $inv->quantity;
                                        $inv->quantity = 0;
                                        $inv->save();
                                    }
                                }

                                // Stokta yetersizlik varsa bile işlem engellenmesin diye eksi lot açılır
                                if ($remainingToDeduct > 0) {
                                    Inventory::create([
                                        'material_id' => $material->id,
                                        'quantity' => -$remainingToDeduct,
                                        'lot_number' => 'OTO-EKSİ-STOK',
                                        'storage_location' => 'Sistem Zorunlu Çıkış'
                                    ]);
                                }
                            }
                        }
                    }
                }
                $count++;
            }

            DB::commit();
            return response()->json(['status' => 'success', 'message' => "{$count} adet numunenin ön işlemi başarıyla tamamlandı ve kimyasallar fiziksel stoktan düşüldü."]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }

    /**
     * YENİ: Tamamlanan işlemleri Modal'a çekmek için
     */
    public function getCompletedOfferPreps($offerId)
    {
        $preps = SamplePreparation::with(['sample', 'technician'])
            ->where('status', 'Tamamlandı')
            ->whereHas('sample', function($q) use ($offerId) {
                $q->where('offer_id', $offerId);
            })
            ->orderBy('completed_at', 'desc')
            ->get();

        if ($preps->isEmpty()) {
            return response()->json(['status' => 'empty', 'message' => 'Kayıt bulunamadı.']);
        }
        return response()->json(['status' => 'success', 'data' => $preps]);
    }

    /**
     * YENİ: Tamamlanan Ön İşlemi İptal Et ve Stokları İade Et (TEKİL)
     */
    public function revertPreparation($id)
    {
        try {
            DB::beginTransaction();

            $prep = SamplePreparation::with(['sample.offer'])->findOrFail($id);
            $sample = $prep->sample;
            $processName = $prep->process_name;
            $offerNo = $sample->offer ? $sample->offer->offer_no : 'Belirtilmemiş';

            // Teklif no ve barkod içerikli standart log prefixini bul
            $logDescPrefix = "Teklif: {$offerNo} | Barkod: {$sample->barcode} numunesi {$processName} işlemi için";
            $movements = StockMovement::where('description', 'like', $logDescPrefix . '%')->get();

            foreach ($movements as $movement) {
                $qtyToRestore = abs($movement->quantity);
                
                // İade edilen miktarı en son oluşturulan LOT'a ekle veya iade LOT'u aç
                $inv = Inventory::where('material_id', $movement->material_id)->orderBy('id', 'desc')->first();
                if ($inv) {
                    $inv->quantity += $qtyToRestore;
                    $inv->save();
                } else {
                    Inventory::create([
                        'material_id' => $movement->material_id,
                        'quantity' => $qtyToRestore,
                        'lot_number' => 'İADE-STOK',
                        'storage_location' => 'İptal İade Deposu'
                    ]);
                }
                
                $movement->delete(); // Logu sistemden sil
            }

            $prep->delete();

            $otherPreps = SamplePreparation::where('sample_id', $sample->id)->where('status', 'Tamamlandı')->count();
            if ($otherPreps == 0) {
                $sample->update(['global_status' => 'Laboratuvara Alındı']);
            }

            SampleTransaction::create([
                'sample_id' => $sample->id,
                'user_id' => Auth::id(),
                'action_type' => 'PREP_REVERT',
                'from_location' => 'Analiz Sırası',
                'to_location' => 'Ön Hazırlık',
                'description' => "{$processName} işlemi İPTAL EDİLDİ. Stoklar (Lotlara) geri yüklendi."
            ]);

            DB::commit();
            return response()->json(['status' => 'success', 'message' => 'Ön işlem iptal edildi ve stoklar fiziksel olarak iade edildi.']);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }

    /**
     * YENİ: Teklife Ait TÜM Tamamlanan Ön İşlemleri Geri Al (TOPLU)
     */
    public function revertAllPreparations($offerId)
    {
        try {
            DB::beginTransaction();

            $preps = SamplePreparation::with(['sample.offer'])
                ->where('status', 'Tamamlandı')
                ->whereHas('sample', function($q) use ($offerId) {
                    $q->where('offer_id', $offerId);
                })->get();

            if ($preps->isEmpty()) return response()->json(['status' => 'info', 'message' => 'Geri alınacak bir işlem bulunamadı.']);

            $count = 0;
            foreach ($preps as $prep) {
                $sample = $prep->sample;
                $processName = $prep->process_name;
                $offerNo = $sample->offer ? $sample->offer->offer_no : 'Belirtilmemiş';

                $logDescPrefix = "Teklif: {$offerNo} | Barkod: {$sample->barcode} numunesi {$processName} işlemi için";
                $movements = StockMovement::where('description', 'like', $logDescPrefix . '%')->get();
                
                foreach ($movements as $movement) {
                    $qtyToRestore = abs($movement->quantity);
                    
                    $inv = Inventory::where('material_id', $movement->material_id)->orderBy('id', 'desc')->first();
                    if ($inv) {
                        $inv->quantity += $qtyToRestore;
                        $inv->save();
                    } else {
                        Inventory::create([
                            'material_id' => $movement->material_id,
                            'quantity' => $qtyToRestore,
                            'lot_number' => 'İADE-STOK'
                        ]);
                    }
                    $movement->delete();
                }

                $prep->delete();

                $otherPreps = SamplePreparation::where('sample_id', $sample->id)->where('status', 'Tamamlandı')->count();
                if ($otherPreps == 0) {
                    $sample->update(['global_status' => 'Laboratuvara Alındı']);
                }

                SampleTransaction::create([
                    'sample_id' => $sample->id,
                    'user_id' => Auth::id(),
                    'action_type' => 'PREP_REVERT_ALL',
                    'from_location' => 'Analiz Sırası',
                    'to_location' => 'Ön Hazırlık',
                    'description' => "{$processName} işlemi TOPLU İPTAL EDİLDİ. Stoklar geri yüklendi."
                ]);
                $count++;
            }

            DB::commit();
            return response()->json(['status' => 'success', 'message' => "{$count} adet işlem topluca iptal edildi ve düşülen fiziksel kimyasallar iade edildi."]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }
}