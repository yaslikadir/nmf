<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Definition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    /**
     * Tüm AKTİF müşterileri listeler.
     */
    public function index(Request $request)
    {
        // 1. Eğer istek DataTables'tan (AJAX) geliyorsa sadece o sayfaya ait verileri gönder
        if ($request->ajax()) {
            
            // --- DİKKAT: Global Scope'u ezerek başlıyoruz! ---
            $query = Customer::withoutGlobalScopes(); 

            // --- YETKİ VE GÖRÜNÜRLÜK (VIEW LEVEL) KONTROLÜ BAŞLANGICI ---
            $user = auth()->user();
            $isAdmin = $user->hasRole('admin');
            $perm = null;

            if (!$isAdmin) {
                // Modülü bul ve aktif rolün bu modüldeki yetkisini çek
                $module = \App\Models\Module::where('module_key', 'customers')->first();
                if ($module && $user->activeRole) {
                    $perm = $user->activeRole->rolePermissions()->where('module_id', $module->id)->first();
                }

                // Görünürlük (view_level) Filtrelemesi:
                if (!$perm || $perm->view_level == 0) {
                    // Yetki hiç yoksa tabloyu boş döndür (Güvenlik önlemi)
                    $query->whereRaw('1 = 0'); 
                } elseif ($perm->view_level == 1) {
                    // 1 ise: SADECE KENDİ eklediği müşterileri görsün
                    $query->where('created_by', $user->id); 
                }
                // view_level == 3 (Tümü) ise $query'e hiç dokunmuyoruz, tablodaki herkesi çekiyor!
            }
            // --- YETKİ KONTROLÜ BİTİŞİ ---

            // Durum Filtresi (Aktif/Pasif)
            if ($request->has('status') && $request->status !== 'all') {
                $isActive = $request->status === 'Aktif' ? true : false;
                $query->where('is_active', $isActive);
            }

            return DataTables::of($query)
                ->addIndexColumn()
                ->editColumn('name', fn($row) => '<span class="fw-bold text-primary">'.$row->name.'</span>')
                ->editColumn('customer_code', fn($row) => '<code class="text-dark fw-bold">'.$row->customer_code.'</code>')
                ->addColumn('type', fn($row) => '<span class="badge bg-light text-dark border">'.($row->customer_type ?? $row->type).'</span>')
                ->addColumn('tax', fn($row) => $row->tax_office . ' / ' . $row->tax_number)
                ->editColumn('is_active', function($row) {
                    return $row->is_active 
                        ? '<span class="badge bg-success">Aktif</span>' 
                        : '<span class="badge bg-danger">Pasif</span>';
                })
                ->editColumn('created_at', fn($row) => $row->created_at->format('d.m.Y'))
                
                // $isAdmin ve $perm değişkenlerini butonlarda kullanabilmek için 'use' ile içeri alıyoruz
                ->addColumn('actions', function($row) use ($isAdmin, $perm) {
                    $buttons = '<div class="d-flex justify-content-center gap-1">';
                    
                    // Eğer adminse VEYA update_level 0'dan büyükse Düzenle butonunu göster
                    if ($isAdmin || ($perm && $perm->update_level > 0)) {
                        $buttons .= '<a href="'.route('admin.customers.edit', $row->id).'" class="btn btn-xs btn-outline-primary" title="Düzenle"><i class="fas fa-edit"></i></a>';
                    }
                    
                    // Eğer adminse VEYA delete_level 0'dan büyükse Sil butonunu göster
                    if ($isAdmin || ($perm && $perm->delete_level > 0)) {
                        $buttons .= '<form action="'.route('admin.customers.destroy', $row->id).'" method="POST" class="d-inline" onsubmit="return confirm(\'Emin misiniz?\')">
                                        '.csrf_field().method_field('DELETE').'
                                        <button type="submit" class="btn btn-xs btn-outline-danger" title="Sil"><i class="fas fa-trash-alt"></i></button>
                                     </form>';
                    }
                    $buttons .= '</div>';
                    return $buttons;
                })
                ->rawColumns(['name', 'customer_code', 'type', 'is_active', 'actions'])
                ->make(true);
        }

        // --- SAYFA İLK AÇILIŞI İÇİN İSTATİSTİKLER ---
        // İstatistik kartlarını da Model'in gizli filtresinden kurtarıyoruz!
        $stats = [
            'total'   => \App\Models\Customer::withoutGlobalScopes()->count(),
            'active'  => \App\Models\Customer::withoutGlobalScopes()->where('is_active', true)->count(),
            'passive' => \App\Models\Customer::withoutGlobalScopes()->where('is_active', false)->count(),
        ];

        return view('admin.customers.index', compact('stats'));
    }

    /**
     * Yeni müşteri oluşturma formu.
     */
    public function create()
    {
        // 1. En son eklenen müşteri kaydını alıyoruz
        $lastCustomer = Customer::orderBy('id', 'desc')->withoutGlobalScopes()->first();
        
        $nextNumber = 1;
        if ($lastCustomer && preg_match('/(\d+)/', $lastCustomer->customer_code, $matches)) {
            $nextNumber = intval($matches[0]) + 1;
        }

        $customerCode = 'MST-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        // 2. ÇAKIŞMA ÖNLEYİCİ: Kod veritabanında varsa boş olanı bulana kadar artır
        while (Customer::withoutGlobalScopes()->where('customer_code', $customerCode)->exists()) {
            $nextNumber++;
            $customerCode = 'MST-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
        }

        $defs = $this->getDefinitions();

        return view('admin.customers.create', array_merge([
            'customerCode' => $customerCode
        ], $defs));
    }

    /**
     * Yeni müşteri kaydı.
     */
    public function store(Request $request)
    {
        // 1. VALIDASYON (Kontak eklenecekse onun adı da zorunlu olsun)
        $rules = [
            'name'          => 'required|string|max:255',
            'customer_code' => 'required|unique:customers,customer_code',
            'phone1'        => 'required',
            'email'         => 'nullable|email'
        ];

        // Eğer Hızlı Kontak Ekle switch'i açıksa kontak adını da zorunlu kıl
        if ($request->has('add_contact') && $request->add_contact == '1') {
            $rules['contact_full_name'] = 'required|string|max:255';
        }

        $request->validate($rules);

        // 2. İŞLEM (Hata olursa yarım kalmasın diye Transaction kullanıyoruz)
        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            // A. MÜŞTERİYİ KAYDET
            $data = $request->except(['add_contact', 'contact_full_name', 'contact_title', 'contact_mobile', 'contact_email']);
            $data['created_by'] = Auth::id(); 
            $data['is_active']  = $request->has('is_active') ? $request->is_active : true;
            $data['discount_rate'] = !empty($request->discount_rate) ? floatval($request->discount_rate) : 0;
            $data['balance']       = !empty($request->balance) ? floatval($request->balance) : 0;

            $customer = Customer::create($data);

            // B. EĞER İSTENMİŞSE KONTAĞI KAYDET (İşte ID burada $customer->id olarak elimizde)
            if ($request->has('add_contact') && $request->add_contact == '1') {
                \App\Models\Contact::create([
                    'customer_id'  => $customer->id,
                    'full_name'    => $request->contact_full_name,
                    'title'        => $request->contact_title,
                    'mobile_phone' => $request->contact_mobile,
                    'email'        => $request->contact_email,
                    'is_active'    => 1,
                    'created_by'   => Auth::id()
                ]);
            }

            \Illuminate\Support\Facades\DB::commit();

            // 3. YÖNLENDİRME (Listeye değil, yeni oluşturulan müşterinin içine yönlendiriyoruz)
            return redirect()->route('admin.customers.edit', $customer->id)
                ->with('success', 'Müşteri (ve varsa yetkili kişi) başarıyla kaydedildi.');

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            return back()->withInput()->withErrors(['error' => 'Kayıt sırasında hata oluştu: ' . $e->getMessage()]);
        }
    }

    /**
     * Müşteri Detay Görüntüleme
     */
    public function show(Customer $customer)
    {
        return redirect()->route('admin.customers.edit', $customer->id);
    }

    /**
     * Müşteri düzenleme formu.
     */
    public function edit(Customer $customer)
    {
        $customer->load([
            'contacts', 
            'activities.creator'
        ]);

        $defs = $this->getDefinitions();

        return view('admin.customers.edit', array_merge([
            'customer' => $customer
        ], $defs));
    }

    /**
     * Müşteri güncelleme.
     */
    public function update(Request $request, Customer $customer)
    {
        $request->validate([
            'name'          => 'required|string|max:255',
            'customer_code' => 'required|unique:customers,customer_code,' . $customer->id,
        ]);

        // created_by alanının değişmesini engelliyoruz
        $customer->update($request->except('created_by'));

        return back()->with('success', 'Müşteri bilgileri başarıyla güncellendi.');
    }

    /**
     * [YENİ EKLENDİ] Müşteriyi sistemden silmek yerine pasife alır.
     * Arayüzdeki "Sil" butonları bu metodu tetikler.
     */
    public function destroy(Customer $customer)
    {
        $customer->is_active = false;
        $customer->save();

        return redirect()->route('admin.customers.index')
            ->with('success', 'Müşteri başarıyla pasife alındı ve listeden çıkartıldı.');
    }

    /**
     * Müşteri durumunu Aktif/Pasif yapar.
     * (Manuel durum değiştirme butonları için)
     */
    public function toggleStatus(Customer $customer)
    {
        $customer->is_active = !$customer->is_active;
        $customer->save();

        $durum = $customer->is_active ? 'Aktif' : 'Pasif';
        return redirect()->back()
            ->with('success', "Müşteri durumu başarıyla {$durum} yapıldı.");
    }
    
    /**
     * Select2 için AJAX Müşteri Arama
     */
    public function search(Request $request)
    {
        $search = $request->q; // Select2 arama terimini 'q' parametresiyle gönderir

        $query = Customer::where('is_active', true);

        if ($search) {
            $query->where('name', 'like', '%' . $search . '%')
                  ->orWhere('customer_code', 'like', '%' . $search . '%'); // Koda göre de aranabilsin
        }

        // İlk 30 kaydı getir, tarayıcıyı yorma
        $customers = $query->orderBy('name', 'asc')
                           ->select('id', 'name as text') 
                           ->limit(30)
                           ->get();

        return response()->json($customers);
    }
    
    /**
     * Ortak Sabitleri Getir (Kategori, Sektör vb.)
     */
    private function getDefinitions()
    {
        return [
            'categories' => Definition::byGroup('customer_category')->get(),
            'sectors'    => Definition::byGroup('sector')->get(),
            'types'      => Definition::byGroup('customer_type')->get(),
            'cities'     => Definition::byGroup('city')->get(),
            'sources'    => Definition::byGroup('customer_source')->get(),
        ];
    }
}