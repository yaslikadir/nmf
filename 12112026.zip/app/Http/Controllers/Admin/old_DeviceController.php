<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Device;
use App\Models\DeviceMaintenance;
use App\Models\DeviceCalibration;
use App\Models\Definition;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class DeviceController extends Controller
{
    /**
     * Cihaz Listesi ve Dashboard
     */
    public function index(Request $request)
    {
        // 1. İSTATİSTİKLER
        $stats = [
            'total' => Device::count(),
            'maintenance_due' => Device::where('next_maintenance_date', '<=', Carbon::now()->addDays(7))
                                       ->where('status', '!=', 'Pasif')->count(),
            'calibration_due' => Device::where('next_calibration_date', '<=', Carbon::now()->addDays(15))
                                       ->where('status', '!=', 'Pasif')->count(),
            'verification_due' => Device::where('next_verification_date', '<=', Carbon::now()->addDays(7))
                                        ->where('status', '!=', 'Pasif')->count(),
            'malfunction' => Device::where('status', 'Arızalı')->count(),
        ];

        // 2. FİLTRELEME MANTIĞI
        $query = Device::with(['responsibles', 'location']);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('inventory_no', 'like', "%{$search}%")
                  ->orWhere('serial_no', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('filter')) {
            switch ($request->filter) {
                case 'maintenance_due':
                    $query->where('next_maintenance_date', '<=', Carbon::now()->addDays(7))->where('status', '!=', 'Pasif');
                    break;
                case 'calibration_due':
                    $query->where('next_calibration_date', '<=', Carbon::now()->addDays(15))->where('status', '!=', 'Pasif');
                    break;
                case 'verification_due':
                    $query->where('next_verification_date', '<=', Carbon::now()->addDays(7))->where('status', '!=', 'Pasif');
                    break;
                case 'malfunction':
                    $query->where('status', 'Arızalı');
                    break;
            }
        }

        $devices = $query->latest()->paginate(10);

        return view('admin.devices.index', compact('devices', 'stats'));
    }

    /**
     * Yeni Cihaz Formu
     */
    public function create()
    {
        $users = User::all(); 
        $locations = Definition::where('group_key', 'device_locations')
                               ->where('is_active', true)
                               ->orderBy('sort_order')
                               ->get();
        
        $year = date('Y');
        $count = Device::whereYear('created_at', $year)->count() + 1;
        $suggestedInventoryNo = 'ENV-' . $year . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

        return view('admin.devices.create', compact('users', 'locations', 'suggestedInventoryNo'));
    }

    /**
     * Cihaz Kaydetme
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'device_location_id' => 'required',
            'status' => 'required',
            'inventory_no' => 'required|unique:devices,inventory_no',
            'image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        try {
            DB::beginTransaction();

            $data = $request->all();

            if ($request->hasFile('image')) {
                $data['image'] = $request->file('image')->store('devices', 'public');
            }

            // Tarih Hesaplamaları
            if ($request->maintenance_period_days && $request->last_maintenance_date) {
                $data['next_maintenance_date'] = Carbon::parse($request->last_maintenance_date)->addDays((int) $request->maintenance_period_days);
            }
            if ($request->calibration_period_days && $request->last_calibration_date) {
                $data['next_calibration_date'] = Carbon::parse($request->last_calibration_date)->addDays((int) $request->calibration_period_days);
            }
            if ($request->verification_period_days && $request->last_verification_date) {
                $data['next_verification_date'] = Carbon::parse($request->last_verification_date)->addDays((int) $request->verification_period_days);
            }

            $device = Device::create($data);

            if ($request->filled('responsible_ids')) {
                $device->responsibles()->sync($request->responsible_ids);
            }

            DB::commit();
            return redirect()->route('admin.devices.index')->with('success', 'Cihaz başarıyla eklendi.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    /**
     * Cihaz Detay Sayfası
     */
    public function show(Device $device)
    {
        $device->load(['maintenances', 'calibrations', 'responsibles', 'location']);
        return view('admin.devices.show', compact('device'));
    }

    /**
     * Cihaz Düzenleme Formu
     */
    public function edit(Device $device)
    {
        $users = User::all();
        $locations = Definition::where('group_key', 'device_locations')
                               ->where('is_active', true)
                               ->orderBy('sort_order')
                               ->get();

        return view('admin.devices.edit', compact('device', 'users', 'locations'));
    }

    /**
     * Cihaz Güncelleme
     */
    public function update(Request $request, Device $device)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'inventory_no' => 'required|unique:devices,inventory_no,' . $device->id,
        ]);

        try {
            DB::beginTransaction();

            $data = $request->all();

            if ($request->hasFile('image')) {
                if ($device->image) Storage::disk('public')->delete($device->image);
                $data['image'] = $request->file('image')->store('devices', 'public');
            }

            // Tarih Güncellemeleri
            if ($request->filled('maintenance_period_days') && $request->filled('last_maintenance_date')) {
                $data['next_maintenance_date'] = Carbon::parse($request->last_maintenance_date)->addDays((int)$request->maintenance_period_days);
            }
            if ($request->filled('calibration_period_days') && $request->filled('last_calibration_date')) {
                $data['next_calibration_date'] = Carbon::parse($request->last_calibration_date)->addDays((int)$request->calibration_period_days);
            }
            if ($request->filled('verification_period_days') && $request->filled('last_verification_date')) {
                $data['next_verification_date'] = Carbon::parse($request->last_verification_date)->addDays((int)$request->verification_period_days);
            }

            $device->update($data);

            if ($request->has('responsible_ids')) {
                $device->responsibles()->sync($request->responsible_ids);
            }

            DB::commit();
            return redirect()->route('admin.devices.index')->with('success', 'Cihaz güncellendi.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

   public function destroy(Device $device)
    {
        // 1. Arka planda cihazın durumunu Pasif'e çekiyoruz
        $device->update(['status' => 'Pasif']);
        
        // 2. SoftDeletes aktif olduğu için veritabanından kalıcı olarak SİLİNMEZ, sadece deleted_at sütunu dolar ve listelerde görünmez.
        $device->delete(); 

        return redirect()->route('admin.devices.index')->with('success', 'Cihaz başarıyla silindi (arşive kaldırıldı).');
    }

    // --- BAKIM VE DOĞRULAMA İŞLEMLERİ (VALUE DESTEKLİ) ---

    public function addMaintenance(Request $request, Device $device)
    {
        $request->validate([
            'maintenance_date' => 'required|date',
            'type' => 'required',
            'result' => 'required',
            'value' => 'nullable|string|max:255' // Yeni değer alanı
        ]);

        $data = $request->all();
        $data['cost'] = $request->filled('cost') ? $request->cost : 0;
        $data['device_id'] = $device->id;

        // Sadece Doğrulama işleminde değer kaydet, diğerlerinde null yap
        if ($request->type !== 'Doğrulama') {
            $data['value'] = null;
        }

        if($request->hasFile('document')) {
            $data['document'] = $request->file('document')->store('device_docs/maintenance', 'public');
        }

        DeviceMaintenance::create($data);

        // Tarih güncelleme mantığı
        if ($request->type == 'Doğrulama') {
            $device->last_verification_date = $request->maintenance_date;
            if ($device->verification_period_days) {
                $device->next_verification_date = Carbon::parse($request->maintenance_date)->addDays((int) $device->verification_period_days);
            }
        } else {
            // Periyodik Bakım veya Temizlik
            if ($request->type == 'Periyodik Bakım' || $request->type == 'Temizlik') {
                $device->last_maintenance_date = $request->maintenance_date;
                if ($device->maintenance_period_days) {
                    $device->next_maintenance_date = Carbon::parse($request->maintenance_date)->addDays((int) $device->maintenance_period_days);
                }
            }
        }

        if($request->result == 'Sorunlu') $device->status = 'Arızalı';
        $device->save();

        return back()->with('success', 'İşlem kaydı eklendi.');
    }

    public function updateMaintenance(Request $request, $id)
    {
        $m = DeviceMaintenance::findOrFail($id);
        
        $request->validate([
            'maintenance_date' => 'required|date',
            'type' => 'required',
            'result' => 'required',
            'value' => 'nullable|string|max:255'
        ]);

        $data = $request->all();

        // Tip değişirse değeri kontrol et
        if ($request->type !== 'Doğrulama') {
            $data['value'] = null;
        }

        if ($request->hasFile('document')) {
            if ($m->document) Storage::disk('public')->delete($m->document);
            $data['document'] = $request->file('document')->store('device_docs/maintenance', 'public');
        }

        $m->update($data);
        return back()->with('success', 'Bakım kaydı güncellendi.');
    }

    public function deleteMaintenance($id)
    {
        $m = DeviceMaintenance::findOrFail($id);
        if ($m->document) Storage::disk('public')->delete($m->document);
        $m->delete();
        return back()->with('success', 'Bakım kaydı silindi.');
    }

    // --- KALİBRASYON İŞLEMLERİ ---

    public function addCalibration(Request $request, Device $device)
    {
        $request->validate(['calibration_date' => 'required|date', 'valid_until' => 'required|date', 'result' => 'required']);

        $data = $request->all();
        $data['device_id'] = $device->id;

        if($request->hasFile('document')) {
            $data['document'] = $request->file('document')->store('device_docs/calibration', 'public');
        }

        DeviceCalibration::create($data);

        $device->last_calibration_date = $request->calibration_date;
        $device->next_calibration_date = $request->valid_until;
        $device->save();

        return back()->with('success', 'Kalibrasyon kaydı eklendi.');
    }

    public function updateCalibration(Request $request, $id)
    {
        $c = DeviceCalibration::findOrFail($id);
        $data = $request->all();
        if ($request->hasFile('document')) {
            if ($c->document) Storage::disk('public')->delete($c->document);
            $data['document'] = $request->file('document')->store('device_docs/calibration', 'public');
        }
        $c->update($data);
        return back()->with('success', 'Kalibrasyon güncellendi.');
    }

    public function deleteCalibration($id)
    {
        $c = DeviceCalibration::findOrFail($id);
        if ($c->document) Storage::disk('public')->delete($c->document);
        $c->delete();
        return back()->with('success', 'Kalibrasyon silindi.');
    }

    public function qcReport($id)
    {
        $device = Device::findOrFail($id);

        // Sadece 'Doğrulama' tipindeki ve değeri boş olmayan kayıtları çek
        // Tarihe göre sırala (Eskiden yeniye)
        $maintenances = DeviceMaintenance::where('device_id', $id)
            ->where('type', 'Doğrulama')
            ->whereNotNull('value')
            ->orderBy('maintenance_date', 'asc')
            ->take(21) // Rapora sığması için son 21 kayıt (veya tümü)
            ->get();

        // Hesaplamalar için değerleri diziye al
        // Veritabanındaki string değeri float'a çeviriyoruz (virgül varsa noktaya çevir)
        $values = $maintenances->map(function ($item) {
            return (float) str_replace(',', '.', $item->value);
        })->toArray();

        $count = count($values);
        
        // İstatistiksel Hesaplamalar
        $mean = 0;
        $stdDev = 0;
        $stats = [
            'mean' => 0, 'std' => 0, 
            'aul' => 0, 'ahl' => 0, 
            'uul' => 0, 'uhl' => 0
        ];

        if ($count > 0) {
            // 1. Ortalama
            $mean = array_sum($values) / $count;

            // 2. Standart Sapma (Örneklem)
            $variance = 0;
            foreach ($values as $val) {
                $variance += pow(($val - $mean), 2);
            }
            // $count - 1 (Bessel düzeltmesi - örneklem için)
            // Eğer popülasyon ise $count kullanılır. Genelde QC'de n-1 kullanılır.
            $stdDev = $count > 1 ? sqrt($variance / ($count - 1)) : 0;

            // 3. Limitler (Mean +/- 2*STD ve Mean +/- 3*STD)
            $stats['mean'] = $mean;
            $stats['std'] = $stdDev;
            
            $stats['aul'] = $mean - (2 * $stdDev); // Alt Uyarı Limiti
            $stats['ahl'] = $mean - (3 * $stdDev); // Alt Hareket Limiti
            $stats['uul'] = $mean + (2 * $stdDev); // Üst Uyarı Limiti
            $stats['uhl'] = $mean + (3 * $stdDev); // Üst Hareket Limiti
        }

        return view('admin.devices.qc_report', compact('device', 'maintenances', 'stats'));
    }

    /**
     * AJAX: Cihaz Arama (Select2 için)
     */
    public function search(Request $request)
    {
        $search = $request->get('term');
        $page = $request->get('page', 1);
        $startDate = $request->get('start_date');
        $endDate = $request->get('end_date');
        $scope = $request->get('scope'); // YENİ: Kapsam filtresini yakalıyoruz
        $perPage = 15; 

        $devices = \App\Models\Device::query()
            ->when($search, function ($query, $search) {
                $query->where(function($q) use ($search) {
                    $q->where('name', 'like', '%' . $search . '%')
                      ->orWhere('brand', 'like', '%' . $search . '%')
                      ->orWhere('model', 'like', '%' . $search . '%')
                      ->orWhere('serial_no', 'like', '%' . $search . '%')
                      ->orWhere('inventory_no', 'like', '%' . $search . '%'); 
                });
            })
            ->when($scope, function ($query, $scope) {
                // YENİ: Dropdown'dan bir filtre seçilmişse sadece o ölçüm kapsamındakileri getirir
                $query->where('measurement_scope', $scope);
            })
            ->paginate($perPage, ['*'], 'page', $page);

        $formattedDevices = $devices->map(function ($dev) use ($startDate, $endDate) {
            $isExp = $dev->next_calibration_date && \Carbon\Carbon::parse($dev->next_calibration_date)->isPast();
            
            // Cihazın planda olup olmadığını kontrol et
            $inUseCount = \Illuminate\Support\Facades\DB::table('measurement_plan_device')
                ->join('measurement_plans', 'measurement_plan_device.measurement_plan_id', '=', 'measurement_plans.id')
                ->where('measurement_plan_device.device_id', $dev->id)
                ->whereIn('measurement_plans.status', ['Planlandı', 'Devam Ediyor'])
                ->whereNull('measurement_plans.deleted_at') 
                ->where(function($q) use ($startDate, $endDate) {
                    if ($startDate && $endDate) {
                        $q->where('measurement_plans.start_date', '<=', $endDate)
                          ->where('measurement_plans.end_date', '>=', $startDate);
                    } else {
                        $q->where('measurement_plans.end_date', '>=', \Carbon\Carbon::today());
                    }
                })
                ->count();

            return [
                'id' => $dev->id,
                'text' => $dev->name . ' ' . $dev->brand . ' ' . $dev->model . ' ' . $dev->serial_no . ' ' . $dev->inventory_no,
                'name' => $dev->name,
                'brand' => $dev->brand . ' / ' . $dev->model,
                'serial' => $dev->serial_no,
                'inventory' => $dev->inventory_no,
                'cal' => $isExp ? 'Süresi Dolmuş' : 'Geçerli',
                'in_use_count' => $inUseCount 
            ];
        });

        return response()->json([
            'results' => $formattedDevices,
            'pagination' => [
                'more' => $devices->hasMorePages()
            ]
        ]);
    }
}