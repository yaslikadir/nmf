<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use App\Models\Customer;
use App\Models\Definition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth; // <-- Auth facade eklendi
use Yajra\DataTables\Facades\DataTables;

class ContactController extends Controller
{
    public function index(Request $request)
    {
        // 1. AJAX isteği gelirse DataTables'a verileri JSON olarak gönder
        if ($request->ajax()) {
            
            // --- DİKKAT: Global Scope'u ezerek başlıyoruz ve N+1 için with ekliyoruz! ---
            $query = Contact::withoutGlobalScopes()->with('customer');

            // --- YETKİ VE GÖRÜNÜRLÜK (VIEW LEVEL) KONTROLÜ BAŞLANGICI ---
            $user = auth()->user();
            $isAdmin = $user->hasRole('admin');
            $perm = null;

            if (!$isAdmin) {
                // Modülü bul ve aktif rolün bu modüldeki yetkisini çek ('contacts' anahtarı ile arıyoruz)
                $module = \App\Models\Module::where('module_key', 'contacts')->first();
                if ($module && $user->activeRole) {
                    $perm = $user->activeRole->rolePermissions()->where('module_id', $module->id)->first();
                }

                // Görünürlük (view_level) Filtrelemesi:
                if (!$perm || $perm->view_level == 0) {
                    // Yetki hiç yoksa tabloyu boş döndür
                    $query->whereRaw('1 = 0'); 
                } elseif ($perm->view_level == 1) {
                    // 1 ise: SADECE KENDİ eklediği kontakları görsün
                    $query->where('created_by', $user->id); 
                }
                // view_level == 3 (Tümü) ise $query'e hiç dokunmuyoruz, tablodaki herkesi çekiyor!
            }
            // --- YETKİ KONTROLÜ BİTİŞİ ---

            // Durum Filtresi (Aktif/Pasif)
            if ($request->has('status') && $request->status !== 'all') {
                $isActive = $request->status === 'Aktif' ? true : false;
                $query->where('is_active', $isActive);
            }

            return DataTables::of($query)
                ->addIndexColumn()
                ->addColumn('customer_name', function($row) {
                    return $row->customer 
                        ? '<a href="'.route('admin.customers.edit', $row->customer->id).'" class="fw-bold text-dark text-decoration-none"><i class="fas fa-building text-muted me-1 small"></i>'.$row->customer->name.'</a>' 
                        : '<span class="text-muted">Müşteri Yok</span>';
                })
                ->editColumn('full_name', fn($row) => '<span class="fw-bold text-primary">'.$row->full_name.'</span>')
                ->editColumn('title', fn($row) => $row->title ?? '-')
                ->editColumn('mobile_phone', fn($row) => $row->mobile_phone ?? $row->work_phone ?? '-')
                ->editColumn('email', fn($row) => $row->email ?? '-')
                ->editColumn('is_active', function($row) {
                    return $row->is_active 
                        ? '<span class="badge bg-success">Aktif</span>' 
                        : '<span class="badge bg-danger">Pasif</span>';
                })
                // Butonları da yetkiye (update_level) bağladık!
                ->addColumn('actions', function($row) use ($isAdmin, $perm) {
                    $buttons = '<div class="d-flex justify-content-center gap-1">';
                    
                    if ($isAdmin || ($perm && $perm->update_level > 0)) {
                        $buttons .= '<a href="'.route('admin.contacts.edit', $row->id).'" class="btn btn-xs btn-outline-primary" title="Düzenle"><i class="fas fa-edit"></i></a>';
                    }
                    
                    $buttons .= '</div>';
                    return $buttons;
                })
                ->rawColumns(['customer_name', 'full_name', 'is_active', 'actions'])
                ->make(true);
        }

        // 2. Normal sayfa yüklemesinde sadece üst istatistikleri gönder
        // İstatistik kartlarını da Model'in gizli filtresinden kurtarıyoruz!
        $stats = [
            'total'   => Contact::withoutGlobalScopes()->count(),
            'active'  => Contact::withoutGlobalScopes()->where('is_active', true)->count(),
            'passive' => Contact::withoutGlobalScopes()->where('is_active', false)->count(),
        ];

        return view('admin.contacts.index', compact('stats'));
    }
    public function create(Request $request)
    {
        $selected_customer_id = $request->get('customer_id');
        $customers = Customer::where('is_active', true)->orderBy('name')->get();
        
        $addressTypes = Definition::byGroup('contact_address_type')->get();
        $decisionStatuses = Definition::byGroup('decision_status')->get();
        $relationships = Definition::byGroup('company_relationship')->get();
        $genders = Definition::byGroup('gender')->get();
        $maritalStatuses = Definition::byGroup('marital_status')->get();

        return view('admin.contacts.create', compact(
            'customers', 'addressTypes', 'decisionStatuses', 
            'relationships', 'genders', 'maritalStatuses', 'selected_customer_id'
        ));
    }

    public function store(Request $request)
    {
        // 1. VALIDASYON (GÜVENLİK)
        // Formdan gelen verilerin doğruluğunu kontrol ediyoruz.
        $request->validate([
            'customer_id'   => 'required|exists:customers,id',
            'full_name'     => 'required|string|max:255',
            'email'         => 'nullable|email|max:255',
            'mobile_phone'  => 'nullable|string|max:30',
            'business_card' => 'nullable|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        // 2. VERİ HAZIRLIĞI
        // Formdaki tüm verileri alıyoruz (Modelde $fillable tanımlıysa hepsi geçer)
        $data = $request->all();

        // Checkbox'lar bazen formda işaretlenmeyince gelmez, varsayılan atayabiliriz
        $data['is_active'] = $request->has('is_active') ? 1 : 0;
        
        // Kayıt Sahibini Ekleme
        $data['created_by'] = Auth::id(); 

        // 3. DOSYA YÜKLEME İŞLEMİ
        if ($request->hasFile('business_card')) {
            $file = $request->file('business_card');
            
            // Dosya ismini benzersiz yap (Zaman damgası + Temizlenmiş isim)
            $filename = time() . '_' . \Illuminate\Support\Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)) . '.' . $file->getClientOriginalExtension();
            
            // Klasör yoksa oluştur (Hata almamak için)
            $path = public_path('uploads/contacts');
            if (!File::exists($path)) {
                File::makeDirectory($path, 0755, true);
            }

            $file->move($path, $filename);
            $data['business_card_path'] = 'uploads/contacts/' . $filename;
        }

        // 4. KAYIT (MASS ASSIGNMENT)
        // DİKKAT: Contact modelindeki $fillable dizisinde 'email', 'mobile_phone' vb. alanlar olmalı!
        Contact::create($data);

        return redirect()->route('admin.contacts.index')
            ->with('success', 'Kontak başarıyla oluşturuldu.');
    }

    public function edit(Contact $contact)
    {
        $customers = Customer::where('is_active', true)->orderBy('name')->get();
        $addressTypes = Definition::byGroup('contact_address_type')->get();
        $decisionStatuses = Definition::byGroup('decision_status')->get();
        $relationships = Definition::byGroup('company_relationship')->get();
        $genders = Definition::byGroup('gender')->get();
        $maritalStatuses = Definition::byGroup('marital_status')->get();

        return view('admin.contacts.edit', compact(
            'contact', 'customers', 'addressTypes', 'decisionStatuses', 
            'relationships', 'genders', 'maritalStatuses'
        ));
    }

    public function update(Request $request, Contact $contact)
    {
        $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'full_name'   => 'required|string|max:255',
        ]);

        $data = $request->all();

        // Kartvizit Güncelleme
        if ($request->hasFile('business_card')) {
            // Eski dosyayı fiziksel olarak sil
            if ($contact->business_card_path && File::exists(public_path($contact->business_card_path))) {
                File::delete(public_path($contact->business_card_path));
            }
            $file = $request->file('business_card');
            $filename = 'card_' . time() . '.' . $file->extension();
            $file->move(public_path('uploads/contacts'), $filename);
            $data['business_card_path'] = 'uploads/contacts/' . $filename;
        }

        // --- GÜVENLİK: Kayıt sahibinin değiştirilmesini engelle ---
        $contact->update($request->except('created_by'));

        return redirect()->route('admin.contacts.index')->with('success', 'Kontak güncellendi.');
    }
}