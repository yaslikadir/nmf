<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Material;
use App\Models\Inventory;
use App\Models\StockMovement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InventoryController extends Controller
{
    /**
     * Stok Giriş Formu
     */
    public function create($material_id)
    {
        $material = Material::findOrFail($material_id);
        return view('admin.inventory.create', compact('material'));
    }

    /**
     * Stok Girişini Kaydet
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'material_id' => 'required|exists:materials,id',
            'quantity' => 'required|numeric|min:0.01',
            'lot_number' => 'nullable|string|max:50',
            'expiration_date' => 'nullable|date',
            'storage_location' => 'nullable|string|max:100',
            'reason' => 'nullable|string', 
        ]);

        DB::transaction(function () use ($validated) {
            $inventory = Inventory::create([
                'material_id' => $validated['material_id'],
                'lot_number' => $validated['lot_number'],
                'quantity' => $validated['quantity'],
                'expiration_date' => $validated['expiration_date'],
                'storage_location' => $validated['storage_location'],
            ]);

            StockMovement::create([
                'material_id' => $validated['material_id'],
                'inventory_id' => $inventory->id,
                'type' => 'in',
                'quantity' => $validated['quantity'],
                'user_id' => auth()->id(),
                // DÜZELTİLDİ: Artık doğru sütun adı olan 'reason' kullanılıyor
                'reason' => $validated['reason'] ?? 'Yeni stok girişi', 
            ]);
        });

        return redirect()->route('admin.materials.show', $validated['material_id'])
            ->with('success', 'Stok başarıyla eklendi.');
    }

    /**
     * Manuel Stok Düşme Formu (Çıkış)
     */
    public function createDecrement($material_id)
    {
        $material = Material::findOrFail($material_id);
        return view('admin.inventory.decrement', compact('material'));
    }

    /**
     * Stok Düşme İşlemi (FEFO Mantığı ile)
     */
    public function storeDecrement(Request $request)
    {
        $validated = $request->validate([
            'material_id' => 'required|exists:materials,id',
            'quantity' => 'required|numeric|min:0.01',
            'reason' => 'required|string|max:255',
        ]);

        $material = Material::findOrFail($validated['material_id']);
        $totalRequested = (float) $validated['quantity'];

        if ($material->total_stock < $totalRequested) {
            return back()->with('error', 'Yetersiz stok! Mevcut: ' . $material->total_stock);
        }

        DB::transaction(function () use ($material, $totalRequested, $validated) {
            // FEFO Mantığı: Son kullanma tarihi en yakın olan (asc) ve stokta olanlar
            $stocks = Inventory::where('material_id', $material->id)
                ->where('quantity', '>', 0)
                ->orderBy('expiration_date', 'asc')
                ->get();

            $remainingToDrop = $totalRequested;

            foreach ($stocks as $stock) {
                if ($remainingToDrop <= 0) break;

                $take = min($stock->quantity, $remainingToDrop);
                $stock->decrement('quantity', $take);
                $remainingToDrop -= $take;

                StockMovement::create([
                    'material_id' => $material->id,
                    'inventory_id' => $stock->id,
                    'type' => 'out',
                    'quantity' => $take,
                    'user_id' => auth()->id(),
                    // DÜZELTİLDİ: Artık doğru sütun adı olan 'reason' kullanılıyor
                    'reason' => $validated['reason'],
                ]);
            }
        });

        return redirect()->route('admin.materials.show', $material->id)
            ->with('success', 'Stok düşüşü başarıyla yapıldı.');
    }
}