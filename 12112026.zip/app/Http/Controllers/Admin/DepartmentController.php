<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class DepartmentController extends Controller
{
    /**
     * Departman Listesi
     */
    public function index()
    {
        $departments = Department::withCount('users')->orderBy('name', 'asc')->get();
        return view('admin.departments.index', compact('departments'));
    }

    /**
     * AJAX: Departmana Bağlı Personelleri Getir
     */
    public function getUsers(Department $department): JsonResponse
    {
        $users = $department->users()
            ->select(['id', 'name', 'title', 'profile_photo', 'user_code', 'is_active'])
            ->orderBy('name', 'asc')
            ->get();

        return response()->json($users);
    }

    /**
     * Yeni Departman Kaydı
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'code' => 'required|string|max:20|unique:departments,code',
        ]);

        Department::create([
            'name'      => $request->name,
            'code'      => mb_strtoupper($request->code, 'UTF-8'),
            'is_active' => 1,
        ]);

        return back()->with('success', 'Yeni departman başarıyla tanımlandı.');
    }

    /**
     * Departman Güncelleme
     */
    public function update(Request $request, Department $department)
    {
        // 'is_active' validation'ı 'sometimes' yapıyoruz çünkü switch kapalıyken veri gelmez
        $request->validate([
            'name'      => 'required|string|max:255',
            'code'      => 'required|string|max:20|unique:departments,code,' . $department->id,
            'is_active' => 'sometimes', 
        ]);

        // Hata buradaydı: Dizi içinde direkt atama yaptık. 
        // Şimdi doğru şekilde güncelliyoruz:
        $department->update([
            'name'      => $request->name,
            'code'      => mb_strtoupper($request->code, 'UTF-8'),
            'is_active' => $request->has('is_active') ? 1 : 0,
        ]);

        return back()->with('success', 'Departman bilgileri güncellendi.');
    }

    /**
     * Departman Silme (Soft Delete)
     */
    public function destroy(Department $department)
    {
        if ($department->users()->exists()) {
            return back()->with('error', 'Bu departmana bağlı personeller olduğu için silme işlemi gerçekleştirilemez.');
        }

        $department->delete();
        
        return back()->with('success', 'Departman sistemden kaldırıldı.');
    }
}