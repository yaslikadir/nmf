<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Announcement;
use Illuminate\Support\Facades\Artisan;

class AnnouncementController extends Controller
{
   public function index(Request $request)
{
    $sourceKey = $request->get('source', 'CSB');
    $dbSource = ($sourceKey == 'TURKAK') ? 'TÜRKAK' : 'ÇŞB Laboratuvar';

    $announcements = Announcement::where('source', $dbSource)
                                 ->orderBy('published_at', 'desc') // <--- KRİTİK NOKTA (DESC = En Yeni En Üstte)
                                 ->paginate(12);
    
    return view('admin.announcements.index', compact('announcements', 'sourceKey', 'dbSource'));
}

    // Manuel Tetikleme İçin
    public function fetchNow()
    {
        try {
            Artisan::call('scrape:csb');
            return back()->with('success', 'Bakanlık taraması başarıyla tamamlandı. Yeni duyurular eklendi.');
        } catch (\Exception $e) {
            return back()->with('error', 'Tarama sırasında hata oluştu: ' . $e->getMessage());
        }
    }
}