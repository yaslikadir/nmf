<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TurkakDocument;
use App\Models\Setting; // Don't forget this!
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Http; // For the login attempt

class TurkakDocumentController extends Controller
{
    public function index(Request $request)
    {
        // 1. Tüm dokümanları kategori sırasına göre çekiyoruz (Sayfalama yok)
        $documents = TurkakDocument::orderBy('category_code', 'asc')
            ->orderBy('uploaded_at', 'desc')
            ->get(); // paginate(15) yerine get() kullandık
        
        // 2. Ayarları Çek (Mevcut kodun)
        $settings = new \stdClass();
        $settings->bearer_token = Setting::where('key', 'turkak_bearer_token')->value('value');
        $settings->asist_username = Setting::where('key', 'turkak_asist_username')->value('value');
        
        $tokenUpdatedAt = Setting::where('key', 'turkak_token_updated_at')->value('value');
        if($tokenUpdatedAt) {
            $settings->token_updated_at = \Carbon\Carbon::parse($tokenUpdatedAt);
        }

        // 3. View'e gönder (Category değişkenine artık gerek yok)
        return view('admin.turkak_documents.index', compact('documents', 'settings'));
    }
    public function sync(Request $request)
    {
        // Sadece senkronizasyon komutunu çalıştırır
        try {
            Artisan::call('sync:asist-docs');
            $output = Artisan::output();
            
            // Hata kontrolü (komut çıktısında hata varsa)
            if (str_contains(strtolower($output), 'hata') || str_contains(strtolower($output), 'error')) {
                 return back()->with('error', 'Senkronizasyon sırasında hata oluştu. Token süresi dolmuş olabilir. ' . $output);
            }

            return back()->with('success', 'Senkronizasyon tamamlandı. ' . $output);
        } catch (\Exception $e) {
            return back()->with('error', 'Senkronizasyon hatası: ' . $e->getMessage());
        }
    }

    // *** NEW METHOD: Handle Settings Update (Manual Token or Auto Login) ***
    public function updateSettings(Request $request)
    {
        $action = $request->input('action');

        // 1. Manuel Token Kaydetme
        if ($action === 'save_token') {
            $request->validate(['bearer_token' => 'required|string']);
            
            $this->saveSettings([
                'bearer_token' => $request->input('bearer_token'),
                'token_updated_at' => now(),
            ]);
            
            return back()->with('success', 'Token başarıyla kaydedildi.');
        }

        // 2. Kullanıcı Adı/Şifre ile Login (Otomatik Token)
        if ($action === 'login_and_get_token') {
            try {
                $response = Http::post('https://api.turkak.org.tr/api/Auth/Login', [
                    'email' => $request->input('asist_username'),
                    'password' => $request->input('asist_password'),
                ]);

                if ($response->successful()) {
                    $data = $response->json();
                    // API yanıtına göre token alanını bul (tahmini: 'token' veya 'accessToken')
                    $token = $data['token'] ?? $data['accessToken'] ?? null;

                    if ($token) {
                        $this->saveSettings([
                            'asist_username' => $request->input('asist_username'),
                            'bearer_token' => $token,
                            'token_updated_at' => now(),
                        ]);
                        return back()->with('success', 'Giriş başarılı! Yeni token alındı ve kaydedildi.');
                    }
                }
                
                return back()->with('error', 'Giriş başarısız. Lütfen bilgileri kontrol edin. (API Yanıtı: ' . $response->status() . ')');
                
            } catch (\Exception $e) {
                return back()->with('error', 'API bağlantı hatası: ' . $e->getMessage());
            }
        }

        // 3. Token Testi
        if ($action === 'test_token') {
             // Basit bir istek atıp 200 dönüyor mu bakalım
             try {
                 // Basit bir endpoint (Örn: Kullanıcı bilgisi)
                 $token = Setting::where('key', 'turkak_bearer_token')->value('value');
                 $response = Http::withToken($token)->get('https://api.turkak.org.tr/Account/GetUserInfo');
                 
                 if ($response->successful()) {
                     return back()->with('success', 'Token GEÇERLİ! Bağlantı başarılı.');
                 } else {
                     return back()->with('error', 'Token GEÇERSİZ veya süresi dolmuş. (HTTP ' . $response->status() . ')');
                 }
             } catch (\Exception $e) {
                 return back()->with('error', 'Test hatası: ' . $e->getMessage());
             }
        }

        return back();
    }

    // Helper method to save settings to DB
    private function saveSettings(array $data)
    {
        foreach ($data as $key => $value) {
            Setting::updateOrCreate(
                ['key' => 'turkak_' . $key],
                ['value' => $value]
            );
        }
    }

    public function download($id)
    {
        // 1. Veri ve Token Hazırlığı
        $document = TurkakDocument::findOrFail($id);
        
        $tokenRaw = \App\Models\Setting::where('key', 'turkak_asist_token')->value('value') 
                    ?: env('TURKAK_ASIST_TOKEN');

        if (!$tokenRaw) {
            return back()->with('error', 'Token bulunamadı! Ayarlardan giriniz.');
        }

        // Token temizliği (Bearer kelimesini kaldır, boşlukları sil)
        $token = trim(str_replace('Bearer ', '', $tokenRaw));
        $cleanId = trim($document->turkak_id);

        // URL (Senin gönderdiğin listeye göre)
        $downloadUrl = 'https://api.turkak.org.tr/Resources/api/v1/Document/download/' . $cleanId;

        try {
            // 2. İSTEK AT (Daha Gelişmiş Header Ayarı)
            $response = Http::withToken($token)
                ->withHeaders([
                    'Accept'          => 'application/json, text/plain, */*',
                    'Accept-Language' => 'tr-TR,tr;q=0.9',
                    'Origin'          => 'https://asist.turkak.org.tr', // <-- API bunu kontrol ediyor
                    'Referer'         => 'https://asist.turkak.org.tr/', // <-- Bunu da kontrol ediyor olabilir
                    'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'sec-ch-ua'       => '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
                    'sec-ch-ua-mobile'=> '?0',
                    'sec-ch-ua-platform' => '"Windows"'
                ])
                ->timeout(120)
                ->get($downloadUrl);

            // 3. HATA YÖNETİMİ (Detaylı Analiz)
            if ($response->failed()) {
                
                // Sunucudan dönen hata mesajını yakala (Genelde JSON döner)
                $serverError = $response->json()['Message'] ?? $response->body();
                
                if ($response->status() == 404) {
                    // Link hatalıysa veya dosya silinmişse
                    return back()->with('error', "Dosya Sunucuda Bulunamadı (404). \nAPI Mesajı: $serverError \nURL: $downloadUrl");
                }
                
                if ($response->status() == 401) {
                    return back()->with('error', 'Token Süresi Dolmuş! Lütfen Ayarlar kısmından yeni token giriniz.');
                }

                return back()->with('error', 'İndirme Başarısız: ' . $response->status() . ' - ' . Str::limit($serverError, 100));
            }

            // 4. İNDİRME BAŞARILI İSE KULLANICIYA VER
            $fileName = $document->file_name;
            // İçerik tipini API yanıtından al
            $contentType = $response->header('Content-Type') ?: 'application/octet-stream';

            return response()->streamDownload(function () use ($response) {
                echo $response->body();
            }, $fileName, [
                'Content-Type' => $contentType,
            ]);

        } catch (\Exception $e) {
            return back()->with('error', 'Sistem Hatası: ' . $e->getMessage());
        }
    }
}