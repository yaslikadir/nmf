<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PurchaseRequest;
use App\Models\PurchaseOffer;
use App\Models\PurchaseOfferItem;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PurchaseOfferController extends Controller
{
    public function index(Request $request)
    {
        // URL'den 'status' parametresini al. Yoksa varsayılan 'Pending' olsun.
        $status = $request->query('status', 'Pending');

        // İSTATİSTİKLERİ KESİN OLARAK DB'DEN ÇEKİYORUZ (Filtreden etkilenmez)
        $counts = [
            'total'   => PurchaseOffer::count(),
            'pending' => PurchaseOffer::where('status', 'Pending')->count(),
            'won'     => PurchaseOffer::where('status', 'Won')->count(),
            'lost'    => PurchaseOffer::where('status', 'Lost')->count(),
        ];

        $query = PurchaseOffer::with(['request.requester', 'supplier'])->latest();

        // Eğer 'tum' seçilmediyse veritabanından filtrele
        if ($status !== 'tum') {
            $query->where('status', $status);
        }

        // Filtrelenmiş veriyi çek
        $offers = $query->paginate(15);
        
        return view('admin.purchase.offers.index', compact('offers', 'status', 'counts'));
    }

    public function create(Request $request)
    {
        $requestId = $request->query('request_id');
        
        if(!$requestId) {
            return redirect()->back()->with('error', 'Talep seçilmedi.');
        }

        $req = PurchaseRequest::with('items.material')->findOrFail($requestId);
        
        // KİLİT AÇILDI: Tüm tedarikçiler geliyor
        $suppliers = Supplier::orderBy('company_name', 'asc')->get(); 

        $count = PurchaseOffer::where('purchase_request_id', $requestId)->count();
        $nextSuffix = str_pad($count + 1, 2, '0', STR_PAD_LEFT);
        $newOfferCode = $req->request_no . '-' . $nextSuffix;

        return view('admin.purchase.offers.create', compact('req', 'suppliers', 'newOfferCode'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'purchase_request_id' => 'required|exists:purchase_requests,id',
            'supplier_id' => 'required|exists:suppliers,id',
            'offer_date' => 'required|date',
            'currency' => 'required',
            'items' => 'required|array',
            'items.*.unit_price' => 'required|numeric|min:0',
            'offer_no' => 'required|string', 
        ]);

        try {
            DB::beginTransaction();

            $offer = PurchaseOffer::create([
                'purchase_request_id' => $request->purchase_request_id,
                'supplier_id' => $request->supplier_id,
                'offer_no' => $request->offer_no,
                'supplier_offer_ref' => $request->supplier_offer_ref,
                'offer_date' => $request->offer_date,
                'valid_until' => $request->valid_until,
                'currency' => $request->currency,
                'notes' => $request->notes,
                'status' => 'Pending' // İLK EKLENDİĞİNDE BEKLİYOR OLARAK KAYDET
            ]);

            $grandTotal = 0;
            $taxTotal = 0;
            $subTotal = 0;

            foreach ($request->items as $reqItemId => $data) {
                $qty = $data['quantity'];
                $price = $data['unit_price'];
                $taxRate = $data['tax_rate'];
                
                $netTotal = $qty * $price; 
                $taxAmount = $netTotal * ($taxRate / 100);

                PurchaseOfferItem::create([
                    'purchase_offer_id' => $offer->id,
                    'purchase_request_item_id' => $reqItemId,
                    'quantity' => $qty,
                    'unit_price' => $price,
                    'tax_rate' => $taxRate,
                    'net_total' => $netTotal,
                    'description' => $data['description'] ?? null,
                ]);

                $subTotal += $netTotal;
                $taxTotal += $taxAmount;
            }

            $offer->update([
                'sub_total' => $subTotal,
                'tax_total' => $taxTotal,
                'grand_total' => $subTotal + $taxTotal
            ]);

            DB::commit();

            return redirect()->route('admin.purchase.requests.show', $request->purchase_request_id)
                ->with('success', 'Fiyat teklifi başarıyla kaydedildi.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage())->withInput();
        }
    }

    public function selectWinner($id)
    {
        $selectedOffer = PurchaseOffer::findOrFail($id);
        $req = $selectedOffer->request; 

        try {
            DB::beginTransaction();

            // 1. Kazanan teklifi güncelle
            $selectedOffer->update(['status' => 'Won']);
            
            // 2. Diğer teklifleri 'Lost' (Kaybetti) yap
            PurchaseOffer::where('purchase_request_id', $req->id)
                ->where('id', '!=', $id)
                ->update(['status' => 'Lost']);

            // 3. Talebin durumunu güncelle
            $req->update([
                'status' => 'Ordered',
                'converted_offer_id' => $selectedOffer->id
            ]);

            // 4. SİPARİŞ EMRİ OLUŞTUR
            $orderNo = 'PO-' . date('Y') . '-' . str_pad($req->id, 4, '0', STR_PAD_LEFT);

            \App\Models\PurchaseOrder::create([
                'purchase_request_id' => $req->id,
                'purchase_offer_id' => $selectedOffer->id,
                'supplier_id' => $selectedOffer->supplier_id,
                'order_no' => $orderNo,
                'status' => 'Ordered',
                'ordered_at' => now(),
            ]);

            DB::commit();
            
            return back()->with('success', 'Tedarikçi seçildi ve SİPARİŞ EMRİ (PO) oluşturuldu.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }
}