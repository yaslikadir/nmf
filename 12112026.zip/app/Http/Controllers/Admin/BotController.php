<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use App\Models\Announcement;
use Carbon\Carbon;

class BotController extends Controller
{
    public function index()
    {
        $bots = [
            [
                'key' => 'csb',
                'name' => 'ÇŞB Duyuru Robotu',
                'description' => 'Çevre, Şehircilik ve İklim Değişikliği Bakanlığı Lab Duyuruları',
                'url' => 'https://lab.csb.gov.tr/duyurular',
                'last_run' => class_exists(Announcement::class) ? (Announcement::where('source', 'ÇŞB Laboratuvar')->latest()->first()->created_at ?? null) : null,
                'total_data' => class_exists(Announcement::class) ? Announcement::where('source', 'ÇŞB Laboratuvar')->count() : 0,
                'status' => 'Aktif',
                'color' => 'danger',
                'has_date_filter' => true // ARTIK TRUE (ÇŞB Tarih Seçimi Aktif)
            ],
            [
                'key' => 'turkak',
                'name' => 'TÜRKAK Duyuru Robotu',
                'description' => 'Türk Akreditasyon Kurumu Duyuruları',
                'url' => 'https://www.turkak.org.tr/medya/duyurular.html',
                'last_run' => class_exists(Announcement::class) ? (Announcement::where('source', 'TÜRKAK')->latest()->first()->created_at ?? null) : null,
                'total_data' => class_exists(Announcement::class) ? Announcement::where('source', 'TÜRKAK')->count() : 0,
                'status' => 'Aktif',
                'color' => 'info',
                'has_date_filter' => true 
            ]
        ];

        return view('admin.bots.index', compact('bots'));
    }

    public function run(Request $request, $botKey)
    {
        try {
            // Ortak Parametre Hazırlığı
            $params = [];
            if ($request->filled('start_date')) {
                $params['start_date'] = $request->input('start_date');
            }

            if ($botKey == 'csb') {
                // ÇŞB komutuna parametreyi gönder
                Artisan::call('scrape:csb', $params);
            } 
            elseif ($botKey == 'turkak') {
                // TÜRKAK komutuna parametreyi gönder
                Artisan::call('scrape:turkak', $params);
            } 
            else {
                return back()->with('error', 'Geçersiz robot anahtarı.');
            }

            return back()->with('success', strtoupper($botKey) . ' robotu başarıyla çalıştırıldı ve veritabanı güncellendi.');
            
        } catch (\Exception $e) {
            return back()->with('error', 'Robot çalışırken hata oluştu: ' . $e->getMessage());
        }
    }
}