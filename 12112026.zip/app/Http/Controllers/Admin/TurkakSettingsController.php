<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TurkakSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class TurkakSettingsController extends Controller
{
    public function update(Request $request)
    {
        $settings = TurkakSetting::firstOrCreate(['id' => 1]);
        $action = $request->input('action');

        if ($action === 'save_token') {
            $settings->update([
                'bearer_token' => $request->input('bearer_token'),
                'token_updated_at' => now(),
            ]);
            return back()->with('success', 'Token basariyla kaydedildi.');
        }

        if ($action === 'login_and_get_token') {
            try {
                $response = Http::post('https://api.turkak.org.tr/api/Auth/Login', [
                    'email' => $request->input('asist_username'),
                    'password' => $request->input('asist_password'),
                ]);

                if ($response->successful()) {
                    $token = $response->json('token') ?? $response->json('accessToken');
                    
                    $settings->update([
                        'asist_username' => $request->input('asist_username'),
                        'asist_password' => encrypt($request->input('asist_password')),
                        'bearer_token' => $token,
                        'token_updated_at' => now(),
                    ]);
                    
                    return back()->with('success', 'Giris basarili! Token alindi ve kaydedildi.');
                }
                
                return back()->with('error', 'Giris basarisiz: ' . $response->body());
            } catch (\Exception $e) {
                return back()->with('error', 'API hatasi: ' . $e->getMessage());
            }
        }

        if ($action === 'test_token') {
            try {
                $response = Http::withToken($settings->bearer_token)
                    ->get('https://api.turkak.org.tr/api/Documents');
                
                if ($response->successful()) {
                    return back()->with('success', 'Token gecerli ve calisiyor!');
                }
                return back()->with('error', 'Token gecersiz veya suresi dolmus.');
            } catch (\Exception $e) {
                return back()->with('error', 'Test hatasi: ' . $e->getMessage());
            }
        }

        return back();
    }
}