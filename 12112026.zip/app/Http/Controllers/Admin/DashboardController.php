<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

// Model importları
use Modules\Customers\Models\Customer;
use Modules\Customers\Models\Contact;
use Modules\ProjectManagement\Models\Task;
use Modules\Sales\Models\Offer;
use Modules\Sales\Models\OfferItem;

use App\Models\Sample;
use App\Models\SampleAnalysis;
use App\Models\Material;
use App\Models\Inventory;
use App\Models\StockMovement;
use App\Models\Equipment;
use App\Models\Personnel;
use App\Models\Department;
use App\Models\PurchaseRequest;
use App\Models\AnalysisMethod;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $branchId = $this->branchId();
        $taskTable = Schema::hasTable('project_management_tasks') ? 'project_management_tasks' : 'tasks';

        // ═══════════════════════════════════════════════════════════════════════════
        // ANA İSTATİSTİKLER (Tüm Modellere withoutGlobalScopes() eklendi!)
        // ═══════════════════════════════════════════════════════════════════════════
        
        $criticalStockCount = $this->branchTable(DB::table('materials'), 'materials')
            ->where('materials.min_stock', '>', 0)
            ->whereRaw('(SELECT COALESCE(SUM(quantity), 0) FROM inventories i WHERE i.material_id = materials.id AND i.branch_id = ?) <= materials.min_stock', [$branchId])
            ->count();

        $stats = [
            'active_tasks' => $this->branchModel(Task::withoutGlobalScopes(), $taskTable)
                ->whereIn('status', ['pending', 'in_progress', 'Beklemede', 'Devam Ediyor'])
                ->count(),

            'pending_methods' => $this->branchModel(AnalysisMethod::withoutGlobalScopes(), 'analysis_methods')
                ->whereIn('status', ['pending_approval', 'Onay Bekliyor'])
                ->count(),

            'critical_stock' => $criticalStockCount,

            'expired_soon' => $this->branchTable(DB::table('inventories'), 'inventories')
                ->where('inventories.expiration_date', '<=', Carbon::now()->addDays(30))
                ->where('inventories.expiration_date', '>', Carbon::now())
                ->where('quantity', '>', 0)
                ->count(),
            
            'total_customers' => $this->branchModel(Customer::withoutGlobalScopes(), 'customers')
                ->whereIn('status', ['active', 'Aktif'])
                ->count(),

            'new_customers_this_month' => $this->branchModel(Customer::withoutGlobalScopes(), 'customers')
                ->whereMonth('created_at', Carbon::now()->month)
                ->whereYear('created_at', Carbon::now()->year)
                ->count(),

            'pending_offers' => $this->branchModel(Offer::withoutGlobalScopes(), 'offers')
                ->whereIn('status', ['pending', 'Beklemede', 'Onay Bekliyor'])
                ->count(),

            'pending_offers_total' => $this->branchModel(Offer::withoutGlobalScopes(), 'offers')
                ->whereIn('status', ['pending', 'Beklemede', 'Onay Bekliyor'])
                ->sum('total_amount'),

            'total_offers' => $this->branchModel(Offer::withoutGlobalScopes(), 'offers')->count(),

            'active_samples' => $this->branchModel(Sample::withoutGlobalScopes(), 'samples')
                ->whereIn('status', ['pending', 'Pending', 'in_progress', 'in_analysis', 'Analiz Aşamasında'])
                ->count(),

            'samples_in_analysis' => $this->branchModel(Sample::withoutGlobalScopes(), 'samples')
                ->whereIn('status', ['in_analysis', 'Analiz Aşamasında'])
                ->count(),

            'calibration_due' => $this->branchModel(Equipment::withoutGlobalScopes(), 'equipment')
                ->where('next_calibration_date', '<=', Carbon::now()->addDays(30))
                ->count(),

            'calibration_overdue' => $this->branchModel(Equipment::withoutGlobalScopes(), 'equipment')
                ->where('next_calibration_date', '<', Carbon::now())
                ->count(),
            
            'total_materials' => $this->branchModel(Material::withoutGlobalScopes(), 'materials')->count(),
            'total_personnel' => Personnel::withoutGlobalScopes()->whereIn('status', ['active', 'Aktif'])->count(),
            'total_equipment' => $this->branchModel(Equipment::withoutGlobalScopes(), 'equipment')->whereIn('status', ['active', 'Aktif'])->count(),
            'total_templates' => $this->branchTable(DB::table('document_templates'), 'document_templates')->count(),
            
            'chemical_usage_percent' => $this->calculateUsagePercent('kimyasallar'),
            'critical_stock_percent' => $this->calculateCriticalStockPercent(),
            'consumable_usage_percent' => $this->calculateUsagePercent('sarf-malzemeler'),
            'reference_usage_percent' => $this->calculateUsagePercent('cihaz-parcalari'),
        ];

        // ═══════════════════════════════════════════════════════════════════════════
        // SON TEKLİFLER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $latestOffers = $this->branchModel(Offer::withoutGlobalScopes(), 'offers')
            ->with(['customer', 'contact', 'consultant'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // AKTİF NUMUNELER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $activeSamples = $this->branchModel(Sample::withoutGlobalScopes(), 'samples')
            ->with(['offer.customer', 'storageLocation'])
            ->whereIn('status', ['pending', 'Pending', 'in_progress', 'in_analysis', 'Analiz Aşamasında'])
            ->orderBy('received_at', 'desc')
            ->limit(6)
            ->get()
            ->map(function ($sample) {
                $totalAnalyses = $sample->workOrders()->withoutGlobalScopes()->count();
                $completedAnalyses = $sample->workOrders()->withoutGlobalScopes()->whereIn('status', ['completed', 'Tamamlandı'])->count();
                $sample->analysis_progress = $totalAnalyses > 0 
                    ? round(($completedAnalyses / $totalAnalyses) * 100) 
                    : 0;
                return $sample;
            });

        // ═══════════════════════════════════════════════════════════════════════════
        // SON STOK HAREKETLERİ
        // ═══════════════════════════════════════════════════════════════════════════
        
        $latestMovements = DB::table('stock_movements')
            ->join('materials', 'stock_movements.material_id', '=', 'materials.id')
            ->leftJoin('users', 'stock_movements.user_id', '=', 'users.id')
            ->when(Schema::hasColumn('stock_movements', 'branch_id'), fn($q) => $q->where('stock_movements.branch_id', $branchId))
            ->when(Schema::hasColumn('materials', 'branch_id'), fn($q) => $q->where('materials.branch_id', $branchId))
            ->select(
                'stock_movements.*',
                'materials.name as material_name',
                'materials.code as material_code',
                'users.name as user_name'
            )
            ->orderBy('stock_movements.created_at', 'desc')
            ->limit(8)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // KRİTİK STOK LİSTESİ
        // ═══════════════════════════════════════════════════════════════════════════
        
        $criticalStockItems = $this->branchModel(Material::withoutGlobalScopes(), 'materials')
            ->select('materials.*')
            ->selectSub(function ($query) use ($branchId) {
                $query->from('inventories')
                    ->selectRaw('COALESCE(SUM(quantity), 0)')
                    ->whereColumn('inventories.material_id', 'materials.id')
                    ->when(Schema::hasColumn('inventories', 'branch_id'), fn($q) => $q->where('inventories.branch_id', $branchId));
            }, 'current_stock')
            ->whereRaw('(
                SELECT COALESCE(SUM(quantity), 0)
                FROM inventories
                WHERE inventories.material_id = materials.id
                  AND inventories.branch_id = ?
            ) <= materials.min_stock', [$branchId])
            ->orderByRaw('current_stock / NULLIF(min_stock, 0) ASC')
            ->limit(10)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // YAKLAŞAN SKT
        // ═══════════════════════════════════════════════════════════════════════════
        
        $expiringMaterials = DB::table('inventories')
            ->join('materials', 'inventories.material_id', '=', 'materials.id')
            ->when(Schema::hasColumn('inventories', 'branch_id'), fn($q) => $q->where('inventories.branch_id', $branchId))
            ->when(Schema::hasColumn('materials', 'branch_id'), fn($q) => $q->where('materials.branch_id', $branchId))
            ->select(
                'inventories.*',
                'materials.name as material_name',
                'materials.code as material_code',
                'materials.unit as material_unit'
            )
            ->where('inventories.expiration_date', '<=', Carbon::now()->addDays(30))
            ->where('inventories.expiration_date', '>', Carbon::now())
            ->where('inventories.quantity', '>', 0)
            ->orderBy('inventories.expiration_date', 'asc')
            ->limit(8)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // BEKLEYEN GÖREVLER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $pendingTasks = $this->branchModel(Task::withoutGlobalScopes(), $taskTable)
            ->with(['assignedTo', 'department'])
            ->whereIn('status', ['pending', 'in_progress', 'Beklemede', 'Devam Ediyor'])
            ->orderByRaw("FIELD(priority, 'urgent', 'high', 'medium', 'low')")
            ->orderBy('due_date', 'asc')
            ->limit(5)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // SATIN ALMA TALEPLERİ
        // ═══════════════════════════════════════════════════════════════════════════
        
        $purchaseRequests = $this->branchModel(PurchaseRequest::withoutGlobalScopes(), 'purchase_requests')
            ->with('requester')
            ->whereIn('status', ['pending', 'approved', 'ordered', 'Beklemede', 'Onaylandı', 'Sipariş Verildi'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // KALİBRASYON TAKVİMİ
        // ═══════════════════════════════════════════════════════════════════════════
        
        $upcomingCalibrations = $this->branchModel(Equipment::withoutGlobalScopes(), 'equipment')
            ->whereIn('status', ['active', 'Aktif'])
            ->whereNotNull('next_calibration_date')
            ->where('next_calibration_date', '<=', Carbon::now()->addDays(60))
            ->orderBy('next_calibration_date', 'asc')
            ->limit(5)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // DEPARTMAN BAZLI İSTATİSTİKLER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $departmentStats = Department::withoutGlobalScopes()->get()->map(function ($department) use ($taskTable, $branchId) {
            $department->active_count = 0;
            $department->completed_count = 0;
            if (Schema::hasTable($taskTable) && Schema::hasColumn($taskTable, 'department_id')) {
                $base = DB::table($taskTable)->where('department_id', $department->id);
                if (Schema::hasColumn($taskTable, 'branch_id')) {
                    $base->where('branch_id', $branchId);
                }
                $department->active_count = (clone $base)->whereIn('status', ['pending', 'in_progress', 'Beklemede', 'Devam Ediyor'])->count();
                $department->completed_count = (clone $base)->whereIn('status', ['completed', 'Tamamlandı'])
                    ->whereMonth('completed_at', Carbon::now()->month)->count();
            }
            return $department;
        });

        // ═══════════════════════════════════════════════════════════════════════════
        // AKTİF KULLANICILAR
        // ═══════════════════════════════════════════════════════════════════════════
        
        $activeUsers = User::withoutGlobalScopes()
            ->with('department')
            ->where('last_activity_at', '>=', Carbon::now()->subMinutes(15))
            ->orderBy('last_activity_at', 'desc')
            ->limit(6)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // GRAFİK VERİLERİ VE YETKİLER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $chartData = $this->getChartData();
        $activeBranchName = session('active_branch_name', 'Merkez Şube');
        $isKnowledgeBaseAuthorized = auth()->check() && auth()->user()->can('knowledge_base_access');

        return view('admin.dashboard', compact(
            'stats',
            'latestOffers',
            'activeSamples',
            'latestMovements',
            'criticalStockItems',
            'expiringMaterials',
            'pendingTasks',
            'purchaseRequests',
            'upcomingCalibrations',
            'departmentStats',
            'activeUsers',
            'chartData',
            'activeBranchName',
            'isKnowledgeBaseAuthorized'
        ));
    }

    private function branchId(): int
    {
        $id = (int) session('active_branch_id', 0);
        return $id > 0 ? $id : 1;
    }

    private function branchTable($query, string $table)
    {
        if (!Schema::hasTable($table)) {
            return $query;
        }

        if (Schema::hasColumn($table, 'branch_id')) {
            return $query->where($table . '.branch_id', $this->branchId());
        }

        return $query;
    }

    private function branchModel($query, string $table)
    {
        return $this->branchTable($query, $table);
    }

    private function calculateUsagePercent(string $categorySlug): int
    {
        $branchId = $this->branchId();
        $categoryId = DB::table('inventory_categories')
            ->when(Schema::hasColumn('inventory_categories', 'branch_id'), fn($q) => $q->where('branch_id', $branchId))
            ->where('slug', $categorySlug)
            ->value('id');

        if (!$categoryId) return 0;
        
        $totalCapacity = DB::table('materials')
            ->when(Schema::hasColumn('materials', 'branch_id'), fn($q) => $q->where('branch_id', $branchId))
            ->where('category_id', $categoryId)
            ->sum('min_stock') * 5;
        
        $currentStock = DB::table('inventories')
            ->join('materials', 'inventories.material_id', '=', 'materials.id')
            ->when(Schema::hasColumn('materials', 'branch_id'), fn($q) => $q->where('materials.branch_id', $branchId))
            ->when(Schema::hasColumn('inventories', 'branch_id'), fn($q) => $q->where('inventories.branch_id', $branchId))
            ->where('materials.category_id', $categoryId)
            ->sum('inventories.quantity');
        
        if ($totalCapacity <= 0) return 0;
        
        $usagePercent = (($totalCapacity - $currentStock) / $totalCapacity) * 100;
        return (int) max(0, min(100, round($usagePercent)));
    }

    private function calculateCriticalStockPercent(): int
    {
        $branchId = $this->branchId();
        $total = $this->branchModel(Material::withoutGlobalScopes(), 'materials')->where('min_stock', '>', 0)->count();
        if ($total <= 0) return 0;
        
        $criticalCount = $this->branchTable(DB::table('materials'), 'materials')
            ->where('materials.min_stock', '>', 0)
            ->whereRaw('(SELECT COALESCE(SUM(quantity), 0) FROM inventories i WHERE i.material_id = materials.id AND i.branch_id = ?) <= materials.min_stock', [$branchId])
            ->count();
        
        return (int) round(($criticalCount / $total) * 100);
    }

    private function getChartData(): array
    {
        $months = [];
        $monthlyCompleted = [];
        $monthlyStarted = [];
        $offersSent = [];
        $offersApproved = [];

        for ($i = 11; $i >= 0; $i--) {
            $date = Carbon::now()->subMonths($i);
            $months[] = $date->translatedFormat('M');
            
            $monthlyCompleted[] = SampleAnalysis::withoutGlobalScopes()
                ->whereMonth('completed_at', $date->month)
                ->whereYear('completed_at', $date->year)
                ->whereIn('status', ['completed', 'Tamamlandı'])
                ->count();
            
            $monthlyStarted[] = SampleAnalysis::withoutGlobalScopes()
                ->whereMonth('created_at', $date->month)
                ->whereYear('created_at', $date->year)
                ->count();
            
            $offersSent[] = $this->branchModel(Offer::withoutGlobalScopes(), 'offers')
                ->whereMonth('created_at', $date->month)
                ->whereYear('created_at', $date->year)
                ->whereIn('status', ['sent', 'approved', 'rejected', 'Gönderildi', 'Onaylandı', 'Reddedildi'])
                ->count();
            
            $offersApproved[] = $this->branchModel(Offer::withoutGlobalScopes(), 'offers')
                ->whereMonth('approved_at', $date->month)
                ->whereYear('approved_at', $date->year)
                ->whereIn('status', ['approved', 'Onaylandı'])
                ->count();
        }

        $topCustomers = $this->branchModel(Offer::withoutGlobalScopes(), 'offers')
            ->select('customer_id', DB::raw('SUM(total_amount) as total'))
            ->whereIn('status', ['approved', 'Onaylandı'])
            ->whereYear('created_at', Carbon::now()->year)
            ->groupBy('customer_id')
            ->orderBy('total', 'desc')
            ->limit(4)
            ->with('customer')
            ->get();

        $customerNames = $topCustomers->pluck('customer.company_name')->toArray();
        $customerRevenue = $topCustomers->pluck('total')->toArray();
        
        $otherRevenue = $this->branchModel(Offer::withoutGlobalScopes(), 'offers')
            ->whereIn('status', ['approved', 'Onaylandı'])
            ->whereYear('created_at', Carbon::now()->year)
            ->whereNotIn('customer_id', $topCustomers->pluck('customer_id'))
            ->sum('total_amount');
        
        if ($otherRevenue > 0) {
            $customerNames[] = 'Diğer';
            $customerRevenue[] = $otherRevenue;
        }

        $analysisTypes = SampleAnalysis::withoutGlobalScopes()
            ->select('analysis_type', DB::raw('COUNT(*) as count'))
            ->whereYear('created_at', Carbon::now()->year)
            ->groupBy('analysis_type')
            ->orderBy('count', 'desc')
            ->get();

        $stockDays = [];
        $stockIn = [];
        $stockOut = [];
        
        for ($i = 6; $i >= 0; $i--) {
            $date = Carbon::now()->subDays($i);
            $stockDays[] = $date->translatedFormat('D');
            
            $stockIn[] = $this->branchModel(StockMovement::withoutGlobalScopes(), 'stock_movements')
                ->whereDate('created_at', $date)
                ->where('type', 'in')
                ->count();
            
            $stockOut[] = $this->branchModel(StockMovement::withoutGlobalScopes(), 'stock_movements')
                ->whereDate('created_at', $date)
                ->where('type', 'out')
                ->count();
        }

        return [
            'monthly_labels' => $months,
            'monthly_completed' => $monthlyCompleted,
            'monthly_started' => $monthlyStarted,
            'offers_sent' => $offersSent,
            'offers_approved' => $offersApproved,
            'top_customers' => $customerNames,
            'customer_revenue' => $customerRevenue,
            'analysis_types' => $analysisTypes->pluck('analysis_type')->toArray(),
            'analysis_counts' => $analysisTypes->pluck('count')->toArray(),
            'stock_days' => $stockDays,
            'stock_in' => $stockIn,
            'stock_out' => $stockOut,
        ];
    }
}