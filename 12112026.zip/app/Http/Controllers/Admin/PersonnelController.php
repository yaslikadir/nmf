<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Definition;
use App\Models\PersonnelAuthorization;
use App\Models\PersonnelAuthorizationMatrix;
use App\Models\PersonnelCompetencyAssessment;
use App\Models\PersonnelCompetencyRenewalLog;
use App\Models\PersonnelDocument;
use App\Models\PersonnelOrientationRecord;
use App\Models\PersonnelOrientationDocument;
use App\Models\PersonnelScopeAuthorization;
use App\Models\TrainingRecord;
use App\Models\ScopeParameter;
use App\Models\ScopeType;
use App\Models\User;
use App\Models\UserLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Spatie\Permission\Models\Role;

class PersonnelController extends Controller
{
    /**
     * Personel Listesi (Çift kayıt ve eksik personel sorunu giderildi)
     */
    public function index()
    {
        $personnel = User::withoutGlobalScopes()
            ->whereNull('users.deleted_at')
            ->with([
                'department' => function ($query) {
                    $query->withTrashed();
                },
                'roles',
                'branches'
            ])
            ->select('users.*')
            ->distinct()
            ->orderBy('users.name', 'asc')
            ->get()
            ->unique('id')
            ->values();

        return view('admin.personnel.index', compact('personnel'));
    }

    /**
     * Personel Ekleme Sayfası
     */
    public function create()
    {
        return view('admin.personnel.create', $this->formData());
    }

    /**
     * Yeni personel kaydı
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:100', 'unique:users,username'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'confirmed', 'min:8'],
            'role' => ['required', 'exists:roles,name'],
            'department_id' => ['nullable', 'exists:departments,id'],
            'title' => ['nullable', 'string', 'max:255'],
            'user_code' => ['nullable', 'string', 'max:100'],
            'gender' => ['nullable', 'string', 'max:50'],
            'tc_no' => ['nullable', 'string', 'max:20'],
            'mobile_phone' => ['nullable', 'string', 'max:40'],
            'address' => ['nullable', 'string'],
            'hire_date' => ['nullable', 'date'],
            'profile_photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
            'signature_stamp' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        $role = $data['role'];
        unset($data['role'], $data['profile_photo'], $data['signature_stamp']);

        $data['password'] = Hash::make($data['password']);
        $data['is_active'] = $request->boolean('is_active', true);

        $user = DB::transaction(function () use ($request, $data, $role) {
            $user = User::create($data);
            $user->assignRole($role);
            $this->storeUserImages($request, $user);
            return $user;
        });

        $this->writeLog('Personel Oluşturma', "{$user->name} personel kaydı oluşturuldu.");

        return redirect()
            ->route('admin.personnel.show', $user->id)
            ->with('success', 'Personel kaydı başarıyla oluşturuldu.');
    }

    /**
     * Personel Detay Sayfası - 360 derece personel dosyası
     */
    public function show($id)
    {
        $personnel = User::withoutGlobalScopes()->with([
            'department' => fn ($q) => $q->withTrashed(),
            'roles',
            'branches',
            'trainingRecords.plan.training',
            'scopes',
            'personnelDocuments' => fn ($query) => $query->latest(),
            'orientationRecords' => fn ($query) => $query->latest(),
            'competencyAssessments' => fn ($query) => $query->with(['matrix', 'assessor'])->orderByDesc('id'),
            'personnelAuthorizations' => fn ($query) => $query->with('documents')->latest(),
            'scopeAuthorizations.scopeType',
        ])->findOrFail($id);

        // Aynı yetki matrisi için birden fazla yenileme kaydı varsa, ana listede sadece en güncel olanı göster:
        $latestCompetencyAssessments = $personnel->competencyAssessments
            ->groupBy(fn ($item) => $item->matrix_id ? 'matrix_' . $item->matrix_id : 'title_' . $item->activity_title)
            ->map(fn ($group) => $group->first())
            ->values();

        $profileTrainingRecords = $personnel->trainingRecords
            ->filter(fn ($record) => $record->plan && $record->plan->training)
            ->sortByDesc(fn ($record) => optional($record->plan->start_date)->timestamp ?? optional($record->created_at)->timestamp ?? 0)
            ->values();

        $orientationTrainingRecords = $profileTrainingRecords
            ->filter(fn ($record) => ($record->plan->training->profile_category ?? 'general') === 'orientation')
            ->values();

        $authorizationTrainingRecords = $profileTrainingRecords
            ->filter(fn ($record) => ($record->plan->training->profile_category ?? 'general') === 'authorization_training')
            ->values();

        $authorizationMatrices = PersonnelAuthorizationMatrix::with('authorization')->where('user_id', $id)->latest()->get();

        $scopeTypes = ScopeType::with(['parameters' => fn ($query) => $query
                ->where('is_active', true)
                ->orderBy('name')])
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        $assessors = User::withoutGlobalScopes()->whereNull('deleted_at')->where('is_active', true)
            ->orderBy('name')
            ->get(['id', 'name']);

        $today = Carbon::today();
        $reviewWindow = $today->copy()->addDays(30);
        $approvedAuthorizations = $personnel->personnelAuthorizations->where('status', 'approved');
        $approvedScopes = $personnel->scopeAuthorizations->where('status', 'approved');
        $competentAssessments = $latestCompetencyAssessments->where('result', 'competent');
        $pendingAuthorizations = $personnel->personnelAuthorizations->whereIn('status', ['pending', 'draft']);
        $pendingScopes = $personnel->scopeAuthorizations->whereIn('status', ['pending', 'draft']);
        $upcomingReviews = $latestCompetencyAssessments
            ->filter(function ($assessment) use ($today, $reviewWindow) {
                $reviewDate = $assessment->assessment_date ? $assessment->next_review_date : $assessment->planned_assessment_date;
                return $reviewDate && $reviewDate->betweenIncluded($today, $reviewWindow);
            })
            ->sortBy(fn ($assessment) => ($assessment->assessment_date ? $assessment->next_review_date : $assessment->planned_assessment_date)?->timestamp ?? PHP_INT_MAX)
            ->values();

        $dashboard = [
            'document_count' => $personnel->personnelDocuments->count(),
            'orientation_count' => $personnel->orientationRecords->count() + $orientationTrainingRecords->count(),
            'approved_authorization_count' => $approvedAuthorizations->count(),
            'approved_scope_count' => $approvedScopes->count(),
            'competent_assessment_count' => $competentAssessments->count(),
            'upcoming_review_count' => $upcomingReviews->count(),
            'pending_authorization_count' => $pendingAuthorizations->count(),
            'pending_scope_count' => $pendingScopes->count(),
        ];

        $scopeCatalogJson = $scopeTypes->map(fn ($type) => [
            'id' => $type->id,
            'name' => $type->name,
            'code' => $type->code,
            'parameters' => $type->parameters->map(fn ($parameter) => [
                'id' => $parameter->id,
                'name' => $parameter->name,
                'category' => $parameter->scope_category,
                'standard_ref' => $parameter->standard_ref,
                'unit' => $parameter->unit,
                'limit_min' => $parameter->limit_min,
                'limit_max' => $parameter->limit_max,
                'analysis_duration' => $parameter->analysis_duration,
                'duration_unit' => $parameter->duration_unit,
                'analysis_methods' => $parameter->analysis_methods,
                'analysis_techniques' => $parameter->analysis_techniques,
                'storage_conditions' => $parameter->storage_conditions,
                'needs_sample' => (bool) $parameter->needs_sample,
                'is_accredited' => (bool) $parameter->is_accredited,
            ])->values(),
        ])->values()->toJson();

        // Tabloda sadece son revizyonların listelenmesi için ilişkiyi güncelliyoruz
        $personnel->setRelation('competencyAssessments', $latestCompetencyAssessments);

        return view('admin.personnel.show', compact('personnel', 'scopeTypes', 'assessors', 'scopeCatalogJson', 'authorizationMatrices', 'dashboard', 'upcomingReviews', 'orientationTrainingRecords', 'authorizationTrainingRecords'));
    }

    /**
     * Excel'deki PL-03-02 düzenine göre yazdırılabilir HTML yetkilendirme formu.
     */
    public function printAuthorizationForm($id)
    {
        $personnel = User::withoutGlobalScopes()->with([
            'department',
            'personnelAuthorizations' => fn ($query) => $query->latest(),
            'scopeAuthorizations.scopeType',
        ])->findOrFail($id);
        $authorizationMatrices = PersonnelAuthorizationMatrix::with(['authorization', 'competencyAssessments.assessor'])
            ->where('user_id', $id)->latest()->get();

        $siteLogo = null;
        if (class_exists(\App\Models\Setting::class)) {
            $logoValue = \App\Models\Setting::where('key', 'site_logo')->value('value');
            $siteLogo = $logoValue ? asset($logoValue) : null;
        }

        return view('admin.personnel.authorization-print', compact('personnel', 'authorizationMatrices', 'siteLogo'));
    }

    /** Tüm aktif personelleri Excel benzeri tek yetkilendirme planında gösterir. */
    public function printAllAuthorizationForm()
    {
        $personnel = User::withoutGlobalScopes()->whereNull('deleted_at')->with([
            'department',
            'personnelAuthorizations' => fn ($query) => $query->latest(),
        ])->where('is_active', true)->orderBy('name')->get();
        $personnel->each(function ($person) {
            $person->setRelation('authorizationMatrices', PersonnelAuthorizationMatrix::with(['authorization', 'competencyAssessments.assessor'])
                ->where('user_id', $person->id)->latest()->get());
        });

        $siteLogo = null;
        if (class_exists(\App\Models\Setting::class)) {
            $logoValue = \App\Models\Setting::where('key', 'site_logo')->value('value');
            $siteLogo = $logoValue ? asset($logoValue) : null;
        }

        return view('admin.personnel.authorization-print-all', compact('personnel', 'siteLogo'));
    }

    /** Yönetim ekranından PL-03-02 form logosunu günceller. */
    public function uploadSiteLogo(Request $request)
    {
        $request->validate([
            'site_logo' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        $destinationPath = public_path('set');
        if (! is_dir($destinationPath)) {
            mkdir($destinationPath, 0755, true);
        }

        $file = $request->file('site_logo');
        $filename = 'logo_' . time() . '.' . $file->getClientOriginalExtension();
        $file->move($destinationPath, $filename);

        if (class_exists(\App\Models\Setting::class)) {
            \App\Models\Setting::updateOrCreate(
                ['key' => 'site_logo'],
                ['value' => 'set/' . $filename]
            );
        }

        return back()->with('success', 'Form logosu güncellendi.');
    }

    /**
     * Personel Düzenleme Sayfası
     */
    public function edit($id)
    {
        $user = User::withoutGlobalScopes()->findOrFail($id);

        return view('admin.personnel.edit', array_merge(
            ['user' => $user],
            $this->formData()
        ));
    }

    /**
     * Personel güncelleme
     */
    public function update(Request $request, $id)
    {
        $user = User::withoutGlobalScopes()->findOrFail($id);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:100', 'unique:users,username,' . $user->id],
            'email' => ['required', 'email', 'max:255', 'unique:users,email,' . $user->id],
            'role' => ['required', 'exists:roles,name'],
            'department_id' => ['nullable', 'exists:departments,id'],
            'title' => ['nullable', 'string', 'max:255'],
            'user_code' => ['nullable', 'string', 'max:100'],
            'gender' => ['nullable', 'string', 'max:50'],
            'tc_no' => ['nullable', 'string', 'max:20'],
            'mobile_phone' => ['nullable', 'string', 'max:40'],
            'address' => ['nullable', 'string'],
            'hire_date' => ['nullable', 'date'],
            'education_status' => ['nullable', 'string', 'max:100'],
            'graduated_school' => ['nullable', 'string', 'max:255'],
            'graduation_date' => ['nullable', 'date'],
            'password' => ['nullable', 'confirmed', 'min:8'],
            'profile_photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
            'signature_stamp' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        $role = $data['role'];
        unset($data['role'], $data['profile_photo'], $data['signature_stamp']);

        if (blank($data['password'] ?? null)) {
            unset($data['password']);
        } else {
            $data['password'] = Hash::make($data['password']);
        }

        DB::transaction(function () use ($request, $user, $data, $role) {
            $user->update($data);
            $user->syncRoles($role);
            if ($request->has('branches')) {
                $user->branches()->sync($request->input('branches', []));
            }
            $this->storeUserImages($request, $user);
        });

        $this->writeLog('Personel Güncelleme', "{$user->name} personel kaydı güncellendi.");

        return redirect()
            ->route('admin.personnel.show', $user->id)
            ->with('success', 'Personel bilgileri güncellendi.');
    }

    /**
     * Personel silme - SoftDelete kullanır
     */
    public function destroy($id)
    {
        $user = User::withoutGlobalScopes()->findOrFail($id);
        $name = $user->name;
        $user->delete();

        $this->writeLog('Personel Silme', "{$name} personel kaydı silindi.");

        return redirect()
            ->route('admin.personnel.index')
            ->with('success', 'Personel başarıyla silindi.');
    }

    /**
     * Özlük belgesi yükleme
     */
    public function storeDocument(Request $request, $id)
    {
        $user = User::withoutGlobalScopes()->findOrFail($id);

        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'notes' => ['nullable', 'string'],
            'document_date' => ['nullable', 'date'],
            'file' => ['required', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
        ]);

        $file = $request->file('file');
        $path = $file->store('personnel/' . $user->id . '/documents', 'local');

        $data['user_id'] = $user->id;
        $data['document_type'] = 'ozluk';
        $data['file_path'] = $path;
        $data['original_name'] = $file->getClientOriginalName();
        $data['mime_type'] = $file->getMimeType();
        $data['file_size'] = $file->getSize();
        $data['file_hash'] = hash_file('sha256', $file->getRealPath());
        $data['uploaded_by'] = Auth::id();
        $data['status'] = 'approved';

        PersonnelDocument::create($data);

        $this->writeLog('Özlük Belgesi Yükleme', "{$user->name} personeline belge yüklendi.");

        return back()->with('success', 'Özlük belgesi doğrudan yüklendi.');
    }

    public function viewDocument($id)
    {
        $document = PersonnelDocument::findOrFail($id);
        abort_unless(Storage::disk('local')->exists($document->file_path), 404);

        return response()->file(Storage::disk('local')->path($document->file_path), [
            'Content-Type' => $document->mime_type ?: 'application/octet-stream',
            'Content-Disposition' => 'inline; filename="' . addslashes($document->original_name ?: $document->title) . '"',
        ]);
    }

    public function editDocument($id)
    {
        $document = PersonnelDocument::findOrFail($id);
        return view('admin.personnel.document-edit', compact('document'));
    }

    public function updateDocument(Request $request, $id)
    {
        $document = PersonnelDocument::findOrFail($id);
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'notes' => ['nullable', 'string'],
            'document_date' => ['nullable', 'date'],
            'file' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
        ]);

        if ($request->hasFile('file')) {
            Storage::disk('local')->delete($document->file_path);
            $file = $request->file('file');
            $data['file_path'] = $file->store('personnel/' . $document->user_id . '/documents', 'local');
            $data['original_name'] = $file->getClientOriginalName();
            $data['mime_type'] = $file->getMimeType();
            $data['file_size'] = $file->getSize();
            $data['file_hash'] = hash_file('sha256', $file->getRealPath());
            $data['uploaded_by'] = Auth::id();
        }

        $document->update($data);
        return redirect()->route('admin.personnel.show', $document->user_id)->with('success', 'Özlük belgesi güncellendi.');
    }

    public function destroyDocument($id)
    {
        $document = PersonnelDocument::findOrFail($id);
        Storage::disk('local')->delete($document->file_path);
        $document->delete();

        return back()->with('success', 'Özlük belgesi silindi.');
    }

    /**
     * Oryantasyon kaydı ekleme
     */
    public function storeOrientation(Request $request, $id)
    {
        User::withoutGlobalScopes()->findOrFail($id);
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'category' => ['required', 'in:general,quality,technical,safety,other'],
            'content' => ['nullable', 'string'],
            'planned_date' => ['nullable', 'date'],
            'completed_date' => ['nullable', 'date'],
            'end_date' => ['nullable', 'date', 'after_or_equal:completed_date'],
            'duration_minutes' => ['nullable', 'integer', 'min:1'],
            'status' => ['required', 'in:planned,in_progress,completed,failed,rework'],
            'score' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'passed' => ['nullable', 'boolean'],
            'evidence_notes' => ['nullable', 'string'],
            'video_url' => ['nullable', 'url', 'max:1000'],
            'video_file' => ['nullable', 'file', 'mimes:mp4,webm,ogg,mov', 'max:51200'],
            'evidence_file' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
            'orientation_documents' => ['nullable', 'array'],
            'orientation_documents.*.name' => ['required_with:orientation_documents.*.file', 'nullable', 'string', 'max:255'],
            'orientation_documents.*.file' => ['required_with:orientation_documents.*.name', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
        ]);

        if ($request->hasFile('evidence_file')) {
            $data['evidence_path'] = $request->file('evidence_file')->store('personnel/' . $id . '/orientation', 'local');
        }
        if ($request->hasFile('video_file') && $request->file('video_file')->isValid()) {
            $data['video_path'] = $request->file('video_file')->store('personnel/' . $id . '/orientation/videos', 'local');
        }
        unset($data['evidence_file'], $data['video_file']);
        $data['user_id'] = $id;
        $record = PersonnelOrientationRecord::create($data);

        foreach ($request->file('orientation_documents', []) as $index => $files) {
            if (! is_array($files) || empty($files['file'])) continue;
            $file = $files['file'];
            PersonnelOrientationDocument::create([
                'personnel_orientation_record_id' => $record->id,
                'document_name' => $request->input("orientation_documents.$index.name") ?: $file->getClientOriginalName(),
                'file_path' => $file->store('personnel/' . $id . '/orientation', 'local'),
                'original_name' => $file->getClientOriginalName(),
                'mime_type' => $file->getMimeType(),
                'file_size' => $file->getSize(),
                'uploaded_by' => Auth::id(),
            ]);
        }

        return back()->with('success', 'Oryantasyon kaydı eklendi.');
    }

    public function showOrientation($userId, $recordId)
    {
        $personnel = User::withoutGlobalScopes()->with('department')->findOrFail($userId);
        $record = PersonnelOrientationRecord::where('user_id', $userId)->findOrFail($recordId);

        return view('admin.personnel.orientation-show', compact('personnel', 'record'));
    }

    public function viewOrientationEvidence($userId, $recordId)
    {
        $record = PersonnelOrientationRecord::where('user_id', $userId)->findOrFail($recordId);
        abort_unless($record->evidence_path && Storage::disk('local')->exists($record->evidence_path), 404);

        return response()->file(Storage::disk('local')->path($record->evidence_path), [
            'Content-Type' => Storage::disk('local')->mimeType($record->evidence_path) ?: 'application/octet-stream',
            'Content-Disposition' => 'inline; filename="oryantasyon-kaniti-' . $record->id . '"',
        ]);
    }

    public function viewOrientationVideo($userId, $recordId)
    {
        $record = PersonnelOrientationRecord::where('user_id', $userId)->findOrFail($recordId);
        abort_unless($record->video_path && Storage::disk('local')->exists($record->video_path), 404);
        return response()->file(Storage::disk('local')->path($record->video_path), [
            'Content-Type' => Storage::disk('local')->mimeType($record->video_path) ?: 'video/mp4',
            'Content-Disposition' => 'inline; filename="oryantasyon-videosu-' . $record->id . '"',
        ]);
    }

    public function viewOrientationDocument($userId, $recordId, $documentId)
    {
        $document = PersonnelOrientationDocument::where('id', $documentId)
            ->whereHas('orientationRecord', fn ($query) => $query->where('user_id', $userId)->whereKey($recordId))
            ->firstOrFail();
        abort_unless(Storage::disk('local')->exists($document->file_path), 404);
        return response()->file(Storage::disk('local')->path($document->file_path), [
            'Content-Type' => Storage::disk('local')->mimeType($document->file_path) ?: 'application/octet-stream',
            'Content-Disposition' => 'inline; filename="' . addslashes($document->original_name ?: $document->document_name) . '"',
        ]);
    }

    public function editOrientation($userId, $recordId)
    {
        $personnel = User::withoutGlobalScopes()->findOrFail($userId);
        $record = PersonnelOrientationRecord::where('user_id', $userId)->findOrFail($recordId);
        return view('admin.personnel.orientation-edit', compact('personnel', 'record'));
    }

    public function updateOrientation(Request $request, $userId, $recordId)
    {
        $record = PersonnelOrientationRecord::where('user_id', $userId)->findOrFail($recordId);
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'category' => ['required', 'in:general,quality,technical,safety,other'],
            'content' => ['nullable', 'string'],
            'planned_date' => ['nullable', 'date'],
            'completed_date' => ['nullable', 'date'],
            'end_date' => ['nullable', 'date', 'after_or_equal:completed_date'],
            'duration_minutes' => ['nullable', 'integer', 'min:1'],
            'status' => ['required', 'in:planned,in_progress,completed,failed,rework'],
            'score' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'passed' => ['nullable', 'boolean'],
            'evidence_notes' => ['nullable', 'string'],
            'video_url' => ['nullable', 'url', 'max:1000'],
            'video_file' => ['nullable', 'file', 'mimes:mp4,webm,ogg,mov', 'max:51200'],
            'evidence_file' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
        ]);

        if ($request->hasFile('evidence_file')) {
            if ($record->evidence_path) Storage::disk('local')->delete($record->evidence_path);
            $data['evidence_path'] = $request->file('evidence_file')->store('personnel/' . $userId . '/orientation', 'local');
        }
        if ($request->hasFile('video_file') && $request->file('video_file')->isValid()) {
            if ($record->video_path) Storage::disk('local')->delete($record->video_path);
            $data['video_path'] = $request->file('video_file')->store('personnel/' . $userId . '/orientation/videos', 'local');
        }
        unset($data['evidence_file'], $data['video_file']);
        $record->update($data);

        return redirect()->route('admin.personnel.show', $userId)->with('success', 'Oryantasyon kaydı güncellendi.');
    }

    public function destroyOrientation($userId, $recordId)
    {
        $record = PersonnelOrientationRecord::where('user_id', $userId)->findOrFail($recordId);
        if ($record->evidence_path) Storage::disk('local')->delete($record->evidence_path);
        foreach ($record->documents as $document) {
            Storage::disk('local')->delete($document->file_path);
        }
        $record->delete();

        return back()->with('success', 'Oryantasyon kaydı silindi.');
    }

    public function storeAuthorizationMatrix(Request $request, $userId)
    {
        User::withoutGlobalScopes()->findOrFail($userId);
        $data = $request->validate([
            'authorization_id' => ['required', 'integer'],
            'experiment_name' => ['required', 'string', 'max:255'],
            'product_material' => ['nullable', 'string', 'max:255'],
            'test_method' => ['nullable', 'string', 'max:255'],
            'authorization_date' => ['required', 'date'],
        ]);

        $data['tested_product'] = $data['product_material'] ?? null;
        $data['material'] = null;
        unset($data['product_material']);
        $authorization = PersonnelAuthorization::where('user_id', $userId)
            ->findOrFail($data['authorization_id']);
        if ($authorization->authorized_from) {
            $data['authorization_date'] = $authorization->authorized_from->toDateString();
        }
        $data['user_id'] = $userId;
        $data['status'] = $authorization->evaluation_result === 'competent' ? 'active' : 'pending';

        $columns = Schema::getColumnListing('personnel_authorization_matrices');
        $data = array_intersect_key($data, array_flip($columns));
        PersonnelAuthorizationMatrix::create($data);

        return back()->with('success', 'Yetki matrisi kaydı eklendi.');
    }

    public function editAuthorizationMatrix($userId, $matrixId)
    {
        $personnel = User::withoutGlobalScopes()->findOrFail($userId);
        $matrix = PersonnelAuthorizationMatrix::where('user_id', $userId)->findOrFail($matrixId);
        $authorizations = PersonnelAuthorization::where('user_id', $userId)->latest()->get();
        return view('admin.personnel.authorization-matrix-edit', compact('personnel', 'matrix', 'authorizations'));
    }

    public function updateAuthorizationMatrix(Request $request, $userId, $matrixId)
    {
        $matrix = PersonnelAuthorizationMatrix::where('user_id', $userId)->findOrFail($matrixId);
        $data = $request->validate([
            'authorization_id' => ['required', 'integer'],
            'experiment_name' => ['required', 'string', 'max:255'],
            'product_material' => ['nullable', 'string', 'max:255'],
            'test_method' => ['nullable', 'string', 'max:255'],
            'authorization_date' => ['required', 'date'],
        ]);
        $data['tested_product'] = $data['product_material'] ?? null;
        $data['material'] = null;
        unset($data['product_material']);
        PersonnelAuthorization::where('user_id', $userId)->findOrFail($data['authorization_id']);
        $matrix->update($data);
        return redirect()->route('admin.personnel.show', $userId)->with('success', 'Yetki matrisi güncellendi.');
    }

    public function destroyAuthorizationMatrix($userId, $matrixId)
    {
        PersonnelAuthorizationMatrix::where('user_id', $userId)->findOrFail($matrixId)->delete();
        return back()->with('success', 'Yetki matrisi kaydı silindi.');
    }

    public function storeAuthorization(Request $request, $id)
    {
        User::withoutGlobalScopes()->findOrFail($id);
        $data = $this->validateSimpleAuthorization($request);
        $data['user_id'] = $id;
        $data['status'] = 'pending';

        if ($request->hasFile('authorization_document')) {
            $file = $request->file('authorization_document');
            if ($file->isValid()) {
                try {
                    $path = $file->store('personnel/' . $id . '/authorizations', 'local');
                    if ($path) {
                        $data['document_path'] = $path;
                        $data['document_name'] = $data['document_name'] ?? $file->getClientOriginalName();
                        $data['document_uploaded_at'] = $data['document_uploaded_at'] ?? now()->toDateString();
                    }
                } catch (\Throwable $exception) {
                    report($exception);
                    unset($data['document_path']);
                }
            }
        }
        unset($data['authorization_document']);

        $data['authorization_type'] = $data['authorization_type'] ?? $data['authorization_scope'];
        $data['title'] = $data['title'] ?? ($data['experiment_name'] ?: $data['authorization_scope']);

        $columns = Schema::getColumnListing('personnel_authorizations');
        $data = array_intersect_key($data, array_flip($columns));
        $authorization = PersonnelAuthorization::create($data);
        foreach ($request->file('authorization_documents', []) as $index => $row) {
            $file = is_array($row) ? ($row['file'] ?? null) : null;
            if (! $file || ! $file->isValid()) continue;
            $path = $file->store('personnel/' . $id . '/authorizations', 'local');
            if (! $path) continue;
            $authorization->documents()->create([
                'document_name' => trim((string) $request->input("authorization_documents.$index.name")) ?: $file->getClientOriginalName(),
                'file_path' => $path,
                'original_name' => $file->getClientOriginalName(),
                'mime_type' => $file->getMimeType(),
                'file_size' => $file->getSize(),
                'uploaded_by' => Auth::id(),
            ]);
        }

        return back()->with('success', 'Personel yetkilendirmesi ve belgeleri kaydedildi.');
    }

    public function showAuthorization($userId, $authorizationId)
    {
        $personnel = User::withoutGlobalScopes()->with('department')->findOrFail($userId);
        $authorization = PersonnelAuthorization::with('documents')->where('user_id', $userId)->findOrFail($authorizationId);
        return view('admin.personnel.authorization-show', compact('personnel', 'authorization'));
    }

    public function viewAuthorizationDocument($userId, $authorizationId)
    {
        $authorization = PersonnelAuthorization::where('user_id', $userId)->findOrFail($authorizationId);
        abort_unless($authorization->document_path && Storage::disk('local')->exists($authorization->document_path), 404);
        return response()->file(Storage::disk('local')->path($authorization->document_path), [
            'Content-Type' => Storage::disk('local')->mimeType($authorization->document_path) ?: 'application/octet-stream',
            'Content-Disposition' => 'inline; filename="yetkilendirme-dokumani-' . $authorization->id . '"',
        ]);
    }

    public function viewAuthorizationAttachment($userId, $authorizationId, $documentId)
    {
        $document = \App\Models\PersonnelAuthorizationDocument::where('authorization_id', $authorizationId)
            ->whereHas('authorization', fn ($query) => $query->where('user_id', $userId))
            ->findOrFail($documentId);
        abort_unless(Storage::disk('local')->exists($document->file_path), 404);
        return response()->file(Storage::disk('local')->path($document->file_path), [
            'Content-Type' => Storage::disk('local')->mimeType($document->file_path) ?: 'application/octet-stream',
            'Content-Disposition' => 'inline; filename="yetkilendirme-belgesi-' . $document->id . '"',
        ]);
    }

    public function editAuthorization($userId, $authorizationId)
    {
        $personnel = User::withoutGlobalScopes()->findOrFail($userId);
        $authorization = PersonnelAuthorization::where('user_id', $userId)->findOrFail($authorizationId);
        return view('admin.personnel.authorization-edit', compact('personnel', 'authorization'));
    }

    public function updateAuthorization(Request $request, $userId, $authorizationId)
    {
        $authorization = PersonnelAuthorization::where('user_id', $userId)->findOrFail($authorizationId);
        $data = $this->validateSimpleAuthorization($request, $authorization->id);
        if ($request->hasFile('authorization_document')) {
            Storage::disk('local')->delete($authorization->document_path);
            $file = $request->file('authorization_document');
            $data['document_path'] = $file->store('personnel/' . $userId . '/authorizations', 'local');
            $data['document_name'] = $data['document_name'] ?? $file->getClientOriginalName();
            $data['document_uploaded_at'] = $data['document_uploaded_at'] ?? now()->toDateString();
        }
        unset($data['authorization_document']);
        $authorization->update($data);
        return redirect()->route('admin.personnel.show', $userId)->with('success', 'Yetkilendirme kaydı güncellendi.');
    }

    private function validateSimpleAuthorization(Request $request, $authorizationId = null): array
    {
        return $request->validate([
            'authorization_scope' => ['required', 'in:customer_representative,sample_acceptance,reporting,experiment,qms,purchasing,analysis'],
            'experiment_name' => ['nullable', 'required_if:authorization_scope,experiment', 'string', 'max:255'],
            'objective_evidence' => ['required', 'string'],
            'document_name' => ['nullable', 'string', 'max:255'],
            'document_uploaded_at' => ['nullable', 'date'],
            'authorization_document' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
            'authorization_documents' => ['nullable', 'array', 'max:10'],
            'authorization_documents.*.name' => ['nullable', 'string', 'max:255'],
            'authorization_documents.*.file' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
            'evaluation_result' => ['required', 'in:competent,not_competent'],
            'authorized_from' => ['required', 'date'],
        ]);
    }

    public function destroyAuthorization($userId, $authorizationId)
    {
        $authorization = PersonnelAuthorization::where('user_id', $userId)->findOrFail($authorizationId);
        if ($authorization->document_path) {
            Storage::disk('local')->delete($authorization->document_path);
        }
        foreach ($authorization->documents as $document) {
            Storage::disk('local')->delete($document->file_path);
        }
        $authorization->delete();
        return back()->with('success', 'Yetkilendirme kaydı silindi.');
    }

    public function approveAuthorization($userId, $authorizationId)
    {
        $this->ensureApprover();
        $authorization = PersonnelAuthorization::where('user_id', $userId)->findOrFail($authorizationId);
        $authorization->update(['status' => 'approved', 'authorized_by' => Auth::id()]);
        return back()->with('success', 'Yetkilendirme kaydı onaylandı.');
    }

    public function rejectAuthorization(Request $request, $userId, $authorizationId)
    {
        $this->ensureApprover();
        $request->validate(['decision_reason' => ['required', 'string', 'max:2000']]);
        $authorization = PersonnelAuthorization::where('user_id', $userId)->findOrFail($authorizationId);
        $authorization->update(['status' => 'rejected', 'authorized_by' => Auth::id(), 'decision_reason' => $request->decision_reason]);
        return back()->with('success', 'Yetkilendirme kaydı reddedildi.');
    }

    /**
     * Yeni kapsam yetkilendirme kaydı
     */
    public function storeScopeAuthorization(Request $request, $id)
    {
        User::withoutGlobalScopes()->findOrFail($id);

        $data = $request->validate([
            'scope_type_id' => ['required', 'exists:scope_types,id'],
            'scope_parameter_id' => ['required', 'exists:scope_parameters,id'],
            'scope_code' => ['nullable', 'string', 'max:100'],
            'scope_title' => ['required', 'string', 'max:255'],
            'discipline' => ['nullable', 'string', 'max:255'],
            'matrix_material' => ['nullable', 'string', 'max:255'],
            'parameter' => ['nullable', 'string', 'max:255'],
            'method_reference' => ['nullable', 'string', 'max:255'],
            'method_version' => ['nullable', 'string', 'max:100'],
            'equipment_reference' => ['nullable', 'string', 'max:255'],
            'location' => ['nullable', 'string', 'max:255'],
            'authorization_level' => ['required', 'in:awareness,training,supervised,authorized,assessor'],
            'authorized_from' => ['nullable', 'date'],
            'review_date' => ['nullable', 'date', 'after_or_equal:authorized_from'],
            'expires_at' => ['nullable', 'date', 'after_or_equal:review_date'],
            'conditions' => ['nullable', 'string'],
            'evidence_notes' => ['nullable', 'string'],
        ]);

        $scopeType = ScopeType::where('is_active', true)->findOrFail($data['scope_type_id']);
        $parameter = ScopeParameter::where('id', $data['scope_parameter_id'])
            ->where('scope_type_id', $scopeType->id)
            ->where('is_active', true)
            ->firstOrFail();
        $data['scope_code'] = $scopeType->code;
        $data['scope_title'] = $scopeType->name . ' - ' . $parameter->name;
        $data['parameter'] = $parameter->name;
        $data['discipline'] = $parameter->scope_category;
        $data['method_reference'] = $parameter->standard_ref ?: $data['method_reference'];
        unset($data['scope_parameter_id']);

        $data['user_id'] = $id;
        $data['status'] = 'pending';
        PersonnelScopeAuthorization::create($data);

        return back()->with('success', 'Yeni kapsam yetkilendirme incelemesine gönderildi.');
    }

    public function editScopeAuthorization($userId, $scopeId)
    {
        $personnel = User::withoutGlobalScopes()->findOrFail($userId);
        $scope = PersonnelScopeAuthorization::where('user_id', $userId)->findOrFail($scopeId);
        $scopeTypes = ScopeType::where('is_active', true)->orderBy('name')->get();
        return view('admin.personnel.scope-edit', compact('personnel', 'scope', 'scopeTypes'));
    }

    public function updateScopeAuthorization(Request $request, $userId, $scopeId)
    {
        $scope = PersonnelScopeAuthorization::where('user_id', $userId)->findOrFail($scopeId);
        $scope->update($this->validateScope($request));
        return redirect()->route('admin.personnel.show', $userId)->with('success', 'Kapsam kaydı güncellendi.');
    }

    public function destroyScopeAuthorization($userId, $scopeId)
    {
        PersonnelScopeAuthorization::where('user_id', $userId)->findOrFail($scopeId)->delete();
        return back()->with('success', 'Kapsam kaydı silindi.');
    }

    public function approveScopeAuthorization($userId, $scopeId)
    {
        $this->ensureApprover();
        $scope = PersonnelScopeAuthorization::where('user_id', $userId)->findOrFail($scopeId);
        $scope->update(['status' => 'approved', 'approved_by' => Auth::id()]);
        return back()->with('success', 'Kapsam kaydı onaylandı.');
    }

    public function rejectScopeAuthorization(Request $request, $userId, $scopeId)
    {
        $this->ensureApprover();
        $request->validate(['decision_reason' => ['required', 'string', 'max:2000']]);
        $scope = PersonnelScopeAuthorization::where('user_id', $userId)->findOrFail($scopeId);
        $scope->update(['status' => 'rejected', 'decision_reason' => $request->decision_reason, 'approved_by' => Auth::id()]);
        return back()->with('success', 'Kapsam kaydı reddedildi.');
    }

    public function storeCompetencyAssessment(Request $request, $userId)
    {
        User::withoutGlobalScopes()->findOrFail($userId);
        $data = $this->validateCompetency($request);

        if (! empty($data['matrix_id'])) {
            PersonnelAuthorizationMatrix::where('user_id', $userId)->findOrFail($data['matrix_id']);
        }

        if (! empty($data['monitoring_period_years']) && ! empty($data['assessment_date'])) {
            $data['next_review_date'] = Carbon::parse($data['assessment_date'])
                ->addYears((int) $data['monitoring_period_years'])
                ->toDateString();
        } elseif (empty($data['assessment_date'])) {
            $data['result'] = 'pending';
            $data['next_review_date'] = null;
        }

        if ($request->hasFile('evidence_file') && $request->file('evidence_file')->isValid()) {
            try {
                $data['evidence_path'] = $request->file('evidence_file')
                    ->store('personnel/' . $userId . '/competency', 'local');
            } catch (\Throwable $exception) {
                report($exception);
                unset($data['evidence_path']);
            }
        }
        unset($data['evidence_file']);
        $data['user_id'] = $userId;
        $data['result'] = $data['result'] ?? 'pending';

        $columns = Schema::getColumnListing('personnel_competency_assessments');
        $data = array_intersect_key($data, array_flip($columns));
        PersonnelCompetencyAssessment::create($data);

        return back()->with('success', 'Yetkinlik izleme kaydı oluşturuldu.');
    }

    /**
     * YENİ: Yetkinlik Yenileme (Mevcut kaydı ezmez, yeni tarihli yeni kayıt açar ve geçmişte saklar)
     */
    public function renewCompetencyAssessment(Request $request, $userId, $assessmentId)
    {
        $oldAssessment = PersonnelCompetencyAssessment::where('user_id', $userId)->findOrFail($assessmentId);

        $data = $request->validate([
            'planned_assessment_date' => ['required', 'date'],
            'assessment_date' => ['nullable', 'date'],
            'monitoring_period_years' => ['required', 'integer', 'min:1', 'max:20'],
            'next_review_date' => ['nullable', 'date', 'after_or_equal:assessment_date'],
            'result' => ['required', 'in:pending,competent,not_competent,assistant'],
            'assessor_id' => ['nullable', 'string', 'max:30'],
            'assessor_other_name' => ['nullable', 'required_if:assessor_id,other', 'string', 'max:255'],
            'evidence' => ['nullable', 'string'],
            'evidence_file' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
        ]);

        if (! empty($data['assessment_date']) && empty($data['next_review_date'])) {
            $data['next_review_date'] = Carbon::parse($data['assessment_date'])
                ->addYears((int) $data['monitoring_period_years'])->toDateString();
        }
        if (empty($data['assessment_date'])) {
            $data['result'] = 'pending';
            $data['next_review_date'] = null;
        }

        $assessorId = null;
        $assessorName = null;
        if (($data['assessor_id'] ?? null) === 'other') {
            $assessorName = trim($data['assessor_other_name'] ?? '');
        } elseif (! empty($data['assessor_id'])) {
            $assessorId = $data['assessor_id'];
        } else {
            $assessorId = $oldAssessment->assessor_id;
            $assessorName = $oldAssessment->assessor_name;
        }

        // Eski kaydın matris ve kapsam bilgilerini kopyala, yeni değerlendirme verilerini üzerine yaz
        $newAttributes = $oldAssessment->replicate([
            'id', 'created_at', 'updated_at', 'deleted_at', 'evidence_path', 'approved_by', 'approved_at'
        ])->toArray();

        $newAttributes['user_id'] = $userId;
        $newAttributes['planned_assessment_date'] = $data['planned_assessment_date'];
        $newAttributes['assessment_date'] = $data['assessment_date'] ?? null;
        $newAttributes['monitoring_period_years'] = $data['monitoring_period_years'];
        $newAttributes['next_review_date'] = $data['next_review_date'];
        $newAttributes['result'] = $data['result'];
        $newAttributes['evidence'] = $data['evidence'] ?? null;
        $newAttributes['assessor_id'] = $assessorId;
        $newAttributes['assessor_name'] = $assessorName;

        if ($request->hasFile('evidence_file') && $request->file('evidence_file')->isValid()) {
            try {
                $newAttributes['evidence_path'] = $request->file('evidence_file')
                    ->store('personnel/' . $userId . '/competency', 'local');
            } catch (\Throwable $exception) {
                report($exception);
            }
        }

        $columns = Schema::getColumnListing('personnel_competency_assessments');
        $insertData = array_intersect_key($newAttributes, array_flip($columns));

        $newAssessment = PersonnelCompetencyAssessment::create($insertData);

        // Yenileme log tablosuna da kaydet
        PersonnelCompetencyRenewalLog::create([
            'user_id' => $userId,
            'assessment_id' => $newAssessment->id,
            'previous_review_date' => $oldAssessment->next_review_date?->toDateString() ?: $oldAssessment->assessment_date?->toDateString(),
            'new_review_date' => $newAssessment->next_review_date?->toDateString(),
            'monitoring_period_years' => $newAssessment->monitoring_period_years,
            'result' => $newAssessment->result,
            'notes' => $data['evidence'] ?: 'Yeni tarihli yetkinlik yenilemesi yapıldı (Önceki Kayıt #' . $oldAssessment->id . ').',
            'changed_by' => Auth::id(),
        ]);

        return redirect()
            ->route('admin.personnel.show', $userId)
            ->with('success', 'Yetkinlik yenilemesi yeni tarihli kayıt olarak eklendi ve önceki kayıt geçmişe aktarıldı.');
    }

    public function viewCompetencyEvidence($userId, $assessmentId)
    {
        $assessment = PersonnelCompetencyAssessment::where('user_id', $userId)->findOrFail($assessmentId);
        abort_unless($assessment->evidence_path && Storage::disk('local')->exists($assessment->evidence_path), 404);
        return response()->file(Storage::disk('local')->path($assessment->evidence_path), [
            'Content-Type' => Storage::disk('local')->mimeType($assessment->evidence_path) ?: 'application/octet-stream',
            'Content-Disposition' => 'inline; filename="yetkinlik-izleme-' . $assessment->id . '"',
        ]);
    }

    public function editCompetencyAssessment($userId, $assessmentId)
    {
        $personnel = User::withoutGlobalScopes()->findOrFail($userId);
        $assessment = PersonnelCompetencyAssessment::where('user_id', $userId)->findOrFail($assessmentId);
        $assessors = User::withoutGlobalScopes()->whereNull('deleted_at')->where('is_active', true)->orderBy('name')->get(['id', 'name']);
        $authorizationMatrices = PersonnelAuthorizationMatrix::where('user_id', $userId)->latest()->get();
        return view('admin.personnel.competency-edit', compact('personnel', 'assessment', 'assessors', 'authorizationMatrices'));
    }

    public function updateCompetencyAssessment(Request $request, $userId, $assessmentId)
    {
        $assessment = PersonnelCompetencyAssessment::where('user_id', $userId)->findOrFail($assessmentId);
        $previousReviewDate = $assessment->next_review_date?->toDateString();
        $data = $this->validateCompetency($request);
        if (! empty($data['matrix_id'])) {
            PersonnelAuthorizationMatrix::where('user_id', $userId)->findOrFail($data['matrix_id']);
        }
        if (! empty($data['monitoring_period_years']) && ! empty($data['assessment_date'])) {
            $data['next_review_date'] = Carbon::parse($data['assessment_date'])->addYears((int) $data['monitoring_period_years'])->toDateString();
        } elseif (empty($data['assessment_date'])) {
            $data['result'] = 'pending';
            $data['next_review_date'] = null;
        }
        if ($request->hasFile('evidence_file') && $request->file('evidence_file')->isValid()) {
            try {
                if ($assessment->evidence_path) Storage::disk('local')->delete($assessment->evidence_path);
                $data['evidence_path'] = $request->file('evidence_file')->store('personnel/' . $userId . '/competency', 'local');
            } catch (\Throwable $exception) {
                report($exception);
            }
        }
        unset($data['evidence_file']);
        $columns = Schema::getColumnListing('personnel_competency_assessments');
        $updateData = array_intersect_key($data, array_flip($columns));
        $assessment->update($updateData);
        if ($previousReviewDate !== ($assessment->next_review_date?->toDateString())) {
            PersonnelCompetencyRenewalLog::create([
                'user_id' => $userId,
                'assessment_id' => $assessment->id,
                'previous_review_date' => $previousReviewDate,
                'new_review_date' => $assessment->next_review_date?->toDateString(),
                'monitoring_period_years' => $assessment->monitoring_period_years,
                'result' => $assessment->result,
                'notes' => 'Yetkinlik izleme kaydı düzenlendi.',
                'changed_by' => Auth::id(),
            ]);
        }
        return redirect()->route('admin.personnel.show', $userId)->with('success', 'Yetkinlik izleme kaydı güncellendi.');
    }

    public function destroyCompetencyAssessment($userId, $assessmentId)
    {
        $assessment = PersonnelCompetencyAssessment::where('user_id', $userId)->findOrFail($assessmentId);
        if ($assessment->evidence_path) Storage::disk('local')->delete($assessment->evidence_path);
        $assessment->delete();
        return back()->with('success', 'Yetkinlik izleme kaydı silindi.');
    }

    public function approveCompetencyAssessment($userId, $assessmentId)
    {
        $this->ensureApprover();
        $assessment = PersonnelCompetencyAssessment::where('user_id', $userId)->findOrFail($assessmentId);
        $assessment->update(['result' => 'competent', 'approved_by' => Auth::id(), 'approved_at' => now()]);
        return back()->with('success', 'Yetkinlik izleme kaydı onaylandı.');
    }

    public function rejectCompetencyAssessment(Request $request, $userId, $assessmentId)
    {
        $this->ensureApprover();
        $request->validate(['decision_reason' => ['required', 'string', 'max:2000']]);
        $assessment = PersonnelCompetencyAssessment::where('user_id', $userId)->findOrFail($assessmentId);
        $assessment->update(['result' => 'not_competent', 'decision_reason' => $request->decision_reason, 'approved_by' => Auth::id(), 'approved_at' => now()]);
        return back()->with('success', 'Yetkinlik izleme kaydı reddedildi.');
    }

    /**
     * Yetkinlik Geçmişi Sayfası (Aynı matrise ait tüm eski ve yeni yetkinlik kayıtlarını ve logları getirir)
     */
    public function showCompetencyHistory($userId, $assessmentId)
    {
        $personnel = User::withoutGlobalScopes()->findOrFail($userId);
        $assessment = PersonnelCompetencyAssessment::with(['matrix', 'assessor'])->where('user_id', $userId)->findOrFail($assessmentId);

        // Bu yetkinliğin (matrisin veya faaliyet başlığının) tüm geçmiş ve güncel kayıtları
        $assessmentHistory = PersonnelCompetencyAssessment::with(['matrix', 'assessor'])
            ->where('user_id', $userId)
            ->when($assessment->matrix_id, function ($q) use ($assessment) {
                $q->where('matrix_id', $assessment->matrix_id);
            }, function ($q) use ($assessment) {
                $q->where('activity_title', $assessment->activity_title);
            })
            ->orderByDesc('id')
            ->get();

        $historyIds = $assessmentHistory->pluck('id')->toArray();

        $renewalLogs = PersonnelCompetencyRenewalLog::with('changedBy')
            ->where('user_id', $userId)
            ->whereIn('assessment_id', $historyIds)
            ->latest()
            ->get();

        return view('admin.personnel.competency-history', compact('personnel', 'assessment', 'assessmentHistory', 'renewalLogs'));
    }

    private function validateCompetency(Request $request): array
    {
        $data = $request->validate([
            'matrix_id' => ['nullable', 'exists:personnel_authorization_matrices,id'],
            'activity_title' => ['required', 'string', 'max:255'],
            'scope_type_id' => ['nullable', 'exists:scope_types,id'],
            'scope_parameter_id' => ['nullable', 'exists:scope_parameters,id'],
            'method_reference' => ['nullable', 'string', 'max:255'],
            'analysis_methods' => ['nullable', 'string'],
            'analysis_techniques' => ['nullable', 'string'],
            'parameter_unit' => ['nullable', 'string', 'max:100'],
            'limit_min' => ['nullable', 'string', 'max:100'],
            'limit_max' => ['nullable', 'string', 'max:100'],
            'analysis_duration' => ['nullable', 'numeric', 'min:0'],
            'duration_unit' => ['nullable', 'string', 'max:30'],
            'storage_conditions' => ['nullable', 'string'],
            'is_accredited' => ['nullable', 'boolean'],
            'assessment_type' => ['required', 'in:observation,exam,field_practice,report_review,interview'],
            'level' => ['required', 'integer', 'min:0', 'max:5'],
            'planned_assessment_date' => ['required', 'date'],
            'assessment_date' => ['nullable', 'date'],
            'next_review_date' => ['nullable', 'date', 'after_or_equal:assessment_date'],
            'monitoring_period_years' => ['nullable', 'integer', 'min:1', 'max:20'],
            'assessor_id' => ['nullable', 'string', 'max:30'],
            'assessor_other_name' => ['nullable', 'required_if:assessor_id,other', 'string', 'max:255'],
            'result' => ['nullable', 'in:pending,competent,not_competent,assistant'],
            'criteria' => ['nullable', 'string'],
            'evidence' => ['nullable', 'string'],
            'evidence_file' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx', 'max:10240'],
            'limitations' => ['nullable', 'string'],
        ]);
        if (! empty($data['assessor_id']) && $data['assessor_id'] !== 'other' && ! User::withoutGlobalScopes()->whereKey($data['assessor_id'])->exists()) {
            throw \Illuminate\Validation\ValidationException::withMessages(['assessor_id' => 'Geçerli bir değerlendirici seçiniz.']);
        }
        if (($data['assessor_id'] ?? null) === 'other') {
            $data['assessor_name'] = trim($data['assessor_other_name'] ?? '');
            $data['assessor_id'] = null;
        } else {
            $data['assessor_name'] = null;
        }
        unset($data['assessor_other_name']);
        return $data;
    }

    private function enrichCompetencyFromParameter(array $data): array
    {
        if (empty($data['scope_parameter_id'])) {
            return $data;
        }

        $parameter = ScopeParameter::whereKey($data['scope_parameter_id'])
            ->where('is_active', true)
            ->when($data['scope_type_id'] ?? null, fn ($query, $typeId) => $query->where('scope_type_id', $typeId))
            ->firstOrFail();

        $data['scope_type_id'] = $parameter->scope_type_id;
        $data['activity_title'] = $parameter->name;
        $data['method_reference'] = $parameter->standard_ref;
        $data['analysis_methods'] = $parameter->analysis_methods;
        $data['analysis_techniques'] = $parameter->analysis_techniques;
        $data['parameter_unit'] = $parameter->unit;
        $data['limit_min'] = $parameter->limit_min;
        $data['limit_max'] = $parameter->limit_max;
        $data['analysis_duration'] = $parameter->analysis_duration;
        $data['duration_unit'] = $parameter->duration_unit;
        $data['storage_conditions'] = $parameter->storage_conditions;
        $data['is_accredited'] = (bool) $parameter->is_accredited;

        return $data;
    }

    private function validateScope(Request $request): array
    {
        return $request->validate([
            'scope_type_id' => ['nullable', 'exists:scope_types,id'], 'scope_code' => ['nullable', 'string', 'max:100'],
            'scope_title' => ['required', 'string', 'max:255'], 'discipline' => ['nullable', 'string', 'max:255'],
            'matrix_material' => ['nullable', 'string', 'max:255'], 'parameter' => ['nullable', 'string', 'max:255'],
            'method_reference' => ['nullable', 'string', 'max:255'], 'method_version' => ['nullable', 'string', 'max:100'],
            'equipment_reference' => ['nullable', 'string', 'max:255'], 'location' => ['nullable', 'string', 'max:255'],
            'authorization_level' => ['required', 'in:awareness,training,supervised,authorized,assessor'],
            'authorized_from' => ['nullable', 'date'], 'review_date' => ['nullable', 'date'],
            'expires_at' => ['nullable', 'date'], 'conditions' => ['nullable', 'string'], 'evidence_notes' => ['nullable', 'string'],
        ]);
    }

    private function formData(): array
    {
        return [
            'roles' => Role::orderBy('name')->get(),
            'departments' => Department::withTrashed()->orderBy('name')->get(),
            'branches' => \Modules\Branches\Models\Branch::where('is_active', true)->orderBy('name')->get(),
            'genders' => Definition::byGroup('gender')->get(),
            'bloodGroups' => Definition::byGroup('blood_group')->get(),
            'educationList' => Definition::byGroup('education_status')->get(),
            'maritalStatusList' => Definition::byGroup('marital_status')->get(),
        ];
    }

    private function storeUserImages(Request $request, User $user): void
    {
        foreach (['profile_photo', 'signature_stamp'] as $field) {
            if (!$request->hasFile($field)) {
                continue;
            }

            $path = $request->file($field)->store('personnel/' . $user->id, 'public');
            $user->update([$field => $path]);
        }
    }

    private function writeLog(string $action, string $description): void
    {
        if (!class_exists(UserLog::class)) {
            return;
        }

        UserLog::create([
            'user_id' => Auth::id(),
            'action' => $action,
            'description' => $description,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
    }

    private function ensureApprover(): void
    {
        abort_unless(
            Auth::user() && (Auth::user()->hasRole('admin') || Auth::user()->hasRole('quality_manager')),
            403,
            'Bu kayıt için yönetici onayı gereklidir.'
        );
    }
}
