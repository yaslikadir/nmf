<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AnalysisMethod;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Models\User;

class MethodManagementController extends Controller
{
    public function index()
    {
        $methods = AnalysisMethod::orderBy('code')->orderBy('version', 'desc')->get();
        return view('admin.methods.index', compact('methods'));
    }

    public function create()
    {
        // Personel listesini çekiyoruz
        $users = User::orderBy('name')->get(); 
        
        return view('admin.methods.create', compact('users'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'code' => 'required|string|max:50',
            'name' => 'required|string|max:255',
            'procedure_pdf' => 'nullable|file|mimes:pdf|max:51200', // Maks 5MB PDF
        ]);

        try {
            DB::beginTransaction();

            $pdfPath = null;
            if ($request->hasFile('procedure_pdf')) {
                $pdfPath = $request->file('procedure_pdf')->store('methods/procedures', 'public');
            }

            $method = AnalysisMethod::create([
                'code' => strtoupper($request->code),
                'name' => $request->name,
                'technique' => $request->technique,
                'description' => $request->description,
                'procedure' => $request->procedure,
                'procedure_pdf' => $pdfPath, // YENİ EKLENEN PDF ALANI
                'document_date' => $request->document_date,
                'last_revision_date' => $request->last_revision_date,
                'experiment_area' => $request->experiment_area,
                'tracking_method' => $request->tracking_method,
                'control_date' => $request->control_date,
                'controlled_by' => $request->controlled_by,
                'status' => 'Draft',
                'version' => 1,
                'created_by' => Auth::id()
            ]);

            // DİNAMİK CİHAZ VE KİMYASALLARI KAYDET (Varsa)
            if ($request->has('devices')) {
                $method->devices()->sync($request->devices);
            }
            if ($request->has('chemicals')) {
                $method->materials()->sync($request->chemicals);
            }

            DB::commit();
            return redirect()->route('admin.methods.index')->with('success', 'Metot taslağı oluşturuldu.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    public function show($id)
    {
        // İlişkileri view tarafında kullanmak için eager load (with) ile çekiyoruz
        $method = AnalysisMethod::with(['creator', 'approver', 'devices', 'materials'])->findOrFail($id);
        
        // Bu metodun diğer versiyonlarını da bulalım (Geçmiş takibi için)
        $history = AnalysisMethod::where('code', $method->code)
                                 ->where('id', '!=', $method->id)
                                 ->orderBy('version', 'desc')
                                 ->get();

        return view('admin.methods.show', compact('method', 'history'));
    }

    public function edit($id)
    {
        $method = AnalysisMethod::with(['devices', 'materials'])->findOrFail($id);
        
        // Personel listesini çekiyoruz
        $users = User::orderBy('name')->get(); 

        if ($method->status == 'Published' || $method->status == 'Archived') {
            return back()->with('error', 'Yayınlanmış veya arşivlenmiş metotlar düzenlenemez. Lütfen "Yeni Revizyon" oluşturun.');
        }

        return view('admin.methods.edit', compact('method', 'users'));
    }

    public function update(Request $request, $id)
    {
        $method = AnalysisMethod::findOrFail($id);
        
        if ($method->status != 'Draft' && $method->status != 'Pending') {
            return back()->with('error', 'Sadece taslaklar güncellenebilir.');
        }

        try {
            DB::beginTransaction();

            $data = [
                'name' => $request->name,
                'technique' => $request->technique,
                'description' => $request->description,
                'procedure' => $request->procedure,
                'document_date' => $request->document_date,
                'last_revision_date' => $request->last_revision_date,
                'experiment_area' => $request->experiment_area,
                'tracking_method' => $request->tracking_method,
                'control_date' => $request->control_date,
                'controlled_by' => $request->controlled_by,
            ];

            // PDF GÜNCELLEMESİ
            if ($request->hasFile('procedure_pdf')) {
                // Eski dosya varsa sil
                if ($method->procedure_pdf) {
                    Storage::disk('public')->delete($method->procedure_pdf);
                }
                $data['procedure_pdf'] = $request->file('procedure_pdf')->store('methods/procedures', 'public');
            }

            $method->update($data);

            // DİNAMİK İLİŞKİLERİ GÜNCELLE (Eğer boş geldiyse tümünü silmek için boş dizi '[]' atıyoruz)
            $method->devices()->sync($request->devices ?? []);
            $method->materials()->sync($request->chemicals ?? []);

            if ($request->has('submit_for_approval')) {
                $method->update(['status' => 'Pending']);
                DB::commit();
                return redirect()->route('admin.methods.index')->with('success', 'Metot güncellendi ve onaya gönderildi.');
            }

            DB::commit();
            return back()->with('success', 'Taslak güncellendi.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    /**
     * SİLME (SOFT DELETE)
     */
    public function destroy($id)
    {
        $method = AnalysisMethod::findOrFail($id);
        
        // Modelde SoftDeletes aktif olduğu için veritabanından kalkmaz, deleted_at dolar.
        $method->delete();

        return redirect()->route('admin.methods.index')->with('success', 'Metot başarıyla silindi (Arşive taşındı).');
    }

    /**
     * REVİZYON OLUŞTURMA (CRITICAL PROCESS)
     */
    public function revise($id)
    {
        $oldMethod = AnalysisMethod::with(['devices', 'materials'])->findOrFail($id);

        // Yeni Sürüm Oluştur
        $newMethod = $oldMethod->replicate(); // Verileri kopyala
        $newMethod->version = $oldMethod->version + 1; // Sürümü artır
        $newMethod->status = 'Draft'; // Durumu başa sar
        $newMethod->created_by = Auth::id();
        $newMethod->approved_by = null;
        $newMethod->approved_at = null;
        $newMethod->save();

        // YENİ: Eski sürüme bağlı cihaz ve kimyasalları yeni sürüme kopyala
        if($oldMethod->devices->count() > 0) {
            $newMethod->devices()->sync($oldMethod->devices->pluck('id'));
        }
        if($oldMethod->materials->count() > 0) {
            $newMethod->materials()->sync($oldMethod->materials->pluck('id'));
        }

        return redirect()->route('admin.methods.edit', $newMethod->id)
                         ->with('success', 'Yeni revizyon (v' . $newMethod->version . ') oluşturuldu. Cihaz ve kimyasallar aktarıldı, düzenlemeye başlayabilirsiniz.');
    }

    /**
     * ONAYLAMA (Admin Only)
     */
    public function approve($id)
    {
        // 1. Spatie Role Kontrolü (Daha güvenli)
        if (!Auth::user()->hasRole('admin')) { 
            return back()->with('error', 'Bu işlem için yetkiniz bulunmamaktadır.');
        }

        try {
            DB::beginTransaction();
            
            $method = AnalysisMethod::findOrFail($id);

            // Sadece 'Pending' olanlar onaylanabilir
            if ($method->status !== 'Pending') {
                return back()->with('error', 'Sadece onaya sunulmuş (Pending) metotlar onaylanabilir.');
            }

            // 1. Aynı koda sahip diğer tüm "Published" metotları "Archived" yap.
            AnalysisMethod::where('code', $method->code)
                          ->where('status', 'Published')
                          ->update(['status' => 'Archived']);

            // 2. Bu metodu yayınla
            $method->update([
                'status' => 'Published',
                'approved_by' => Auth::id(),
                'approved_at' => now()
            ]);

            DB::commit();
            return back()->with('success', 'Metot protokolü onaylandı ve yayına alındı. Eski sürüm arşivlendi.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    public function report()
    {
        $methods = AnalysisMethod::orderBy('code')->get();
        return view('admin.methods.reportmetot', compact('methods'));
    }
}