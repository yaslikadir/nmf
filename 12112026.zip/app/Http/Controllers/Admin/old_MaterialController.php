<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Material;
use App\Models\InventoryCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class MaterialController extends Controller
{
    public function index(Request $request)
    {
        // 1. GÜNCELLEME: withSum ile stokların toplamını doğrudan SQL'de hesaplatıyoruz (Hız ve performans için)
        $query = \App\Models\Material::with('category')->withSum('stocks', 'quantity');

        // --- 1. KATEGORİ FİLTRESİ (Malzeme / Hizmet Geçişi) ---
        $filterType = $request->input('filter_type', 'material'); 

        if ($filterType === 'service') {
            // Sadece Hizmet kategorisini getir (name yerine slug kullanmak daha garantidir)
            $query->whereHas('category', function($q) {
                $q->where('slug', 'hizmet');
            });
        } else {
            // Hizmet HARİÇ diğer tüm malzemeleri ve kategorisi BOŞ olanları getir
            $query->where(function($q) {
                $q->whereDoesntHave('category', function($sq) {
                    $sq->where('slug', 'hizmet');
                })->orWhereNull('category_id');
            });
        }

        // --- 2. DROPDOWN KATEGORİ FİLTRESİ ---
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        // --- 3. ARAMA FİLTRESİ ---
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', '%' . $search . '%')
                  ->orWhere('sku', 'like', '%' . $search . '%')
                  ->orWhere('cas_no', 'like', '%' . $search . '%');
            });
        }

        // --- 4. AKTİF / PASİF FİLTRESİ ---
        $statusFilter = $request->input('status_filter', 'active'); 

        if ($statusFilter === 'active') {
            $query->where(function($q) {
                $q->where('is_active', true)->orWhereNull('is_active');
            });
        } elseif ($statusFilter === 'passive') {
            $query->where('is_active', false);
        }

        // Veriyi çekiyoruz
        $materials = $query->latest()->paginate(15);

        // 2. GÜNCELLEME: İstatistikleri RAM'i çökertmeden hızlıca hesaplıyoruz
        $criticalCount = \App\Models\Material::withSum('stocks', 'quantity')
            ->get()
            ->filter(function($m) {
                return $m->min_stock > 0 && ($m->stocks_sum_quantity ?? 0) <= $m->min_stock;
            })->count();

        $stats = [
            'total' => \App\Models\Material::count(),
            'critical' => $criticalCount,
            'with_msds' => \App\Models\Material::whereNotNull('msds_file')->count(),
            'categories' => \App\Models\InventoryCategory::count(),
        ];

        // YENİ EKLENEN: Kullanıcının bulunduğu sayfayı ve filtreleri hafızaya al
        session(['material_list_url' => request()->fullUrl()]);

        return view('admin.inventory.materials.index', compact('materials', 'stats'));
    }

    public function create()
    {
        $categories = InventoryCategory::all();
        return view('admin.inventory.materials.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'              => 'required|string|max:255',
            'category_id'       => 'required|exists:inventory_categories,id', 
            'cas_no'            => 'nullable|string',    
            'formula'           => 'nullable|string',    
            'unit'              => 'nullable|string',      
            'min_stock'         => 'nullable|numeric|min:0', 
            'msds_file'         => 'nullable|file|mimes:pdf|max:2048',
            'manufacturer'      => 'nullable|string|max:255',
            'lot_no'            => 'nullable|string|max:255',
            'storage_condition' => 'nullable|string|max:255',
            'shelf_no'          => 'nullable|string|max:255',
            'expiry_date'       => 'nullable|date',
        ]);

        $category = InventoryCategory::find($request->category_id);
        $isService = ($category && $category->slug === 'hizmet');

        $year = date('Y');
        $prefix = $isService ? 'HZMT-' : 'STK-';

        $lastMaterial = Material::whereYear('created_at', $year)
                                ->where('sku', 'like', $prefix . '%')
                                ->latest('id')
                                ->first();
                                
        $sequence = $lastMaterial ? (int) substr($lastMaterial->sku, -4) + 1 : 1;
        $sku = $prefix . $year . '-' . str_pad($sequence, 4, '0', STR_PAD_LEFT);

        // YENİ EKLENEN: Stok Kodunun benzersiz olduğundan %100 emin olana kadar döngüye sok
        while (\App\Models\Material::where('sku', $sku)->exists()) {
            $sequence++;
            $sku = $prefix . $year . '-' . str_pad($sequence, 4, '0', STR_PAD_LEFT);
        }
        $validated['sku'] = $sku;

        if ($request->hasFile('msds_file')) {
            $path = $request->file('msds_file')->store('inventory/msds', 'public');
            $validated['msds_file'] = $path;
        }

        Material::create($validated);

        // YENİ EKLENEN: Hafızadaki son listeleme sayfasına dön (Örn: sayfa 3)
        return redirect(session('material_list_url', route('admin.materials.index')))
            ->with('success', 'Kayıt başarıyla tanımlandı. Kod: ' . $validated['sku']);
    }

    public function show(Material $material)
    {
        $material->load(['category', 'stocks']);
        return view('admin.inventory.materials.show', compact('material'));
    }

    public function edit(Material $material)
    {
        $categories = InventoryCategory::all();
        return view('admin.inventory.materials.edit', compact('material', 'categories'));
    }

    public function update(Request $request, Material $material)
    {
        $validated = $request->validate([
            'name'              => 'required|string|max:255',
            'category_id'       => 'required|exists:inventory_categories,id',
            'cas_no'            => 'nullable|string',
            'formula'           => 'nullable|string',
            'unit'              => 'nullable|string',
            'min_stock'         => 'nullable|numeric|min:0',
            'manufacturer'      => 'nullable|string|max:255',
            'lot_no'            => 'nullable|string|max:255',
            'storage_condition' => 'nullable|string|max:255',
            'shelf_no'          => 'nullable|string|max:255',
            'expiry_date'       => 'nullable|date',
        ]);

        if ($request->hasFile('msds_file')) {
            if ($material->msds_file) {
                Storage::disk('public')->delete($material->msds_file); 
            }
            $validated['msds_file'] = $request->file('msds_file')->store('inventory/msds', 'public');
        }

        $category = InventoryCategory::find($request->category_id);
        $isService = ($category && $category->slug === 'hizmet');
        $prefix = $isService ? 'HZMT-' : 'STK-';

        if (!Str::startsWith($material->sku, $prefix)) {
            $year = date('Y');
            $lastMaterial = Material::whereYear('created_at', $year)
                                    ->where('sku', 'like', $prefix . '%')
                                    ->latest('id')
                                    ->first();
                                    
            $sequence = $lastMaterial ? (int) substr($lastMaterial->sku, -4) + 1 : 1;
            $sku = $prefix . $year . '-' . str_pad($sequence, 4, '0', STR_PAD_LEFT);
            
            // YENİ EKLENEN: Stok kodu çakışma kontrolü
            while (\App\Models\Material::where('sku', $sku)->exists()) {
                $sequence++;
                $sku = $prefix . $year . '-' . str_pad($sequence, 4, '0', STR_PAD_LEFT);
            }
            $validated['sku'] = $sku;
        }

        $material->update($validated);

        // YENİ EKLENEN: Düzenlenen kaydın olduğu o anki sayfaya geri yönlendir
        return redirect(session('material_list_url', route('admin.materials.index')))
            ->with('success', 'Kayıt başarıyla güncellendi.');
    }

    public function destroy($id)
    {
        try {
            $material = \App\Models\Material::findOrFail($id);
            $material->delete();
            return back()->with('success', 'Malzeme sistemden tamamen kaldırıldı.');
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == '23000') {
                $material = \App\Models\Material::find($id);
                $material->update(['is_active' => false]);
                return back()->with('warning', 'Bu malzeme işlem gördüğü için silinemedi, ancak durumu "PASİF" olarak güncellendi.');
            }
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    public function stockMovements(Request $request)
    {
        $query = \App\Models\StockMovement::with(['material.category', 'user', 'inventory']);
        $materialQuery = \App\Models\Material::with('category'); 

        $filterType = $request->input('filter_type', 'material'); 

        if ($filterType === 'service') {
            $query->whereHas('material.category', function($q) {
                $q->where('slug', 'hizmet');
            });
            $materialQuery->whereHas('category', function($q) {
                $q->where('slug', 'hizmet');
            });
        } else {
            $query->whereHas('material.category', function($q) {
                $q->where('slug', '!=', 'hizmet');
            })->orWhereDoesntHave('material.category'); 
            
            $materialQuery->whereHas('category', function($q) {
                $q->where('slug', '!=', 'hizmet');
            })->orWhereDoesntHave('category');
        }

        if ($request->start_date && $request->end_date) {
            $query->whereBetween('created_at', [$request->start_date . ' 00:00:00', $request->end_date . ' 23:59:59']);
        }

        if ($request->type) {
            $query->where('type', $request->type);
        }

        if ($request->material_id) {
            $query->where('material_id', $request->material_id);
        }

        $movements = $query->latest()->paginate(20);
        $materials = $materialQuery->get(['id', 'name', 'sku']);

        return view('admin.inventory.materials.movements', compact('movements', 'materials'));
    }

    public function toggleStatus($id)
    {
        $material = \App\Models\Material::findOrFail($id);
        $material->update(['is_active' => !$material->is_active]);
        
        $durum = $material->is_active ? 'Aktif' : 'Pasif';
        return back()->with('success', "Malzeme başarıyla {$durum} duruma getirildi.");
    }

    public function chemicalReport()
    {
        // Sadece "Kimyasal" ve "Referans Malzeme" olan aktif kayıtları çekiyoruz
        $materials = Material::with('category')
            ->whereHas('category', function($q) {
                $q->whereIn('slug', ['kimyasal', 'referans-malzeme']);
            })
            ->where(function($q) {
                $q->where('is_active', true)->orWhereNull('is_active');
            })
            ->orderBy('name', 'asc')
            ->get();

        // Eğer veritabanında bir "Setting" modelin varsa logoyu oradan çekebilirsin.
        // Şimdilik null atanırsa senin "🌿" ikonlu CSS logon çalışır, ayar varsa resmi basar.
        $siteLogo = \App\Models\Setting::first()->logo ?? null; 

        return view('admin.inventory.materials.krapor', compact('materials', 'siteLogo'));
    }

    /**
     * AJAX: Kimyasal/Malzeme Arama (Select2 için)
     */
    public function search(Request $request)
    {
        $search = $request->get('term');
        $page = $request->get('page', 1);
        $perPage = 15; 

        $materials = \App\Models\Material::query()
            ->where(function ($query) use ($search) {
                $query->where('name', 'like', '%' . $search . '%')
                      ->orWhere('sku', 'like', '%' . $search . '%')
                      ->orWhere('cas_no', 'like', '%' . $search . '%');
            })
            // İstersen sadece aktif olanları getir
            ->where(function($q) {
                $q->where('is_active', true)->orWhereNull('is_active');
            })
            ->paginate($perPage, ['*'], 'page', $page);

        $formattedMaterials = $materials->map(function ($mat) {
            return [
                'id' => $mat->id,
                'text' => $mat->name . ' (' . ($mat->sku ?? $mat->cas_no ?? 'Kod Yok') . ')',
                'name' => $mat->name,
                'sku' => $mat->sku,
                'cas_no' => $mat->cas_no
            ];
        });

        return response()->json([
            'results' => $formattedMaterials,
            'pagination' => [
                'more' => $materials->hasMorePages()
            ]
        ]);
    }
}