<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use Illuminate\Http\Request;

class BackupController extends Controller
{
    /**
     * Google Drive'daki yedekleri listeler
     */
    public function index()
    {
        $disk = Storage::disk('local');
        $files = $disk->allFiles(env('APP_NAME')); // Spatie projeyi APP_NAME klasörü içine atar

        $backups = [];
        foreach ($files as $file) {
            // Sadece .zip dosyalarını listele
            if (substr($file, -4) === '.zip') {
                $backups[] = [
                    'file_path' => $file,
                    'file_name' => str_replace(env('APP_NAME') . '/', '', $file),
                    'file_size' => $this->bytesToHuman($disk->size($file)),
                    'last_modified' => Carbon::createFromTimestamp($disk->lastModified($file))->timezone(config('app.timezone'))->format('d.m.Y H:i'),
                ];
            }
        }

        // Yeniden eskiye sırala
        $backups = array_reverse($backups);

        return view('admin.backups.index', compact('backups'));
    }

     /**

     * Yeni Yedek Alma İşlemini Başlatır

     */

    public function create()

    {

        try {

            // Yedekleme işlemi uzun süreceği için arka planda çalıştırıyoruz (Queue)

            Artisan::queue('backup:run');

           

            return back()->with('success', 'Yedekleme işlemi arka planda başlatıldı. Dosya boyutu ve internet hızına bağlı olarak 5-10 dakika içinde listeye düşecektir.');

        } catch (\Exception $e) {

            return back()->with('error', 'Yedekleme başlatılamadı: ' . $e->getMessage());

        }

    }

    /**
     * Yedeği Bilgisayara İndirir
     */
    public function download($file_name)
    {
        $file = env('APP_NAME') . '/' . $file_name;
        $disk = Storage::disk('local');

        if ($disk->exists($file)) {
            // Google Drive'dan dosyayı stream ederek indir
            return Storage::disk('local')->download($file);
        }

        return back()->with('error', 'Dosya bulunamadı.');
    }

    /**
     * Yedeği Siler
     */
    public function destroy($file_name)
    {
        $file = env('APP_NAME') . '/' . $file_name;
        $disk = Storage::disk('local');

        if ($disk->exists($file)) {
            $disk->delete($file);
            return back()->with('success', 'Yedek başarıyla silindi.');
        }

        return back()->with('error', 'Silinecek dosya bulunamadı.');
    }

    /**
     * Bayt boyutunu okunaklı formata çevirir
     */
    private function bytesToHuman($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        for ($i = 0; $bytes > 1024; $i++) $bytes /= 1024;
        return round($bytes, 2) . ' ' . $units[$i];
    }

    public function getLogs()
    {
        $logPath = storage_path('logs/laravel.log');
        
        if (!file_exists($logPath)) {
            return response()->json(['output' => 'Henüz bir log kaydı oluşmadı.']);
        }

        // 50 satır yetmedi, son 200 satırı çekelim ki hatanın başını görelim
        $file = file($logPath);
        $lastLines = array_slice($file, -200); 
        $output = implode("", $lastLines);

        return response()->json(['output' => $output]);
    }
}