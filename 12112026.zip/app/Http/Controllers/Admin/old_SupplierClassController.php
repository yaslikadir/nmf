<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SupplierClass;
use App\Models\SupplierQuestion;
use App\Models\SupplierCriterion;
use Illuminate\Http\Request;

class SupplierClassController extends Controller
{
    // Sınıfların Listelendiği Sayfa
    public function index()
    {
        $classes = SupplierClass::withCount(['questions', 'suppliers'])->with('questions')->get();
        return view('admin.suppliers.classes.index', compact('classes'));
    }

    // Yeni Sınıf Oluştur
    public function store(Request $request)
    {
        $request->validate(['name' => 'required|string|max:255']);
        SupplierClass::create($request->only('name', 'description'));
        return back()->with('success', 'Sınıf başarıyla oluşturuldu.');
    }

    // Sınıf Detayı (Soruları ve Kriterleri Eklediğimiz Sayfa)
    public function show($id)
    {
        $class = SupplierClass::with(['questions', 'criteria'])->findOrFail($id);
        
        // Toplam puanı hesapla (100'ü geçemez kontrolü için blade'e göndereceğiz)
        $totalScore = $class->questions->sum('max_score');
        
        return view('admin.suppliers.classes.show', compact('class', 'totalScore'));
    }

    // Soru Ekleme (Matematiksel Kontrol Burada!)
    public function storeQuestion(Request $request, $id)
    {
        $request->validate([
            'question' => 'required|string',
            'max_score' => 'required|integer|min:1'
        ]);

        $class = SupplierClass::with('questions')->findOrFail($id);
        $currentTotal = $class->questions->sum('max_score');

        if (($currentTotal + $request->max_score) > 100) {
            return back()->with('error', 'Hata! Eklediğiniz soru ile toplam puan 100\'ü aşıyor. Mevcut Toplam: ' . $currentTotal);
        }

        SupplierQuestion::create([
            'supplier_class_id' => $class->id,
            'question' => $request->question,
            'max_score' => $request->max_score,
        ]);

        return back()->with('success', 'Soru başarıyla eklendi.');
    }

    // Soru Silme
    public function destroyQuestion($id)
    {
        SupplierQuestion::findOrFail($id)->delete();
        return back()->with('success', 'Soru silindi.');
    }

    // Kriter Ekleme (Örn: 0-60 RED)
    public function storeCriterion(Request $request, $id)
    {
        $request->validate([
            'min_score' => 'required|integer|min:0',
            'max_score' => 'required|integer|gte:min_score|max:100',
            'status_label' => 'required|string',
            'color_code' => 'required|string',
        ]);

        SupplierCriterion::create([
            'supplier_class_id' => $id,
            'min_score' => $request->min_score,
            'max_score' => $request->max_score,
            'status_label' => $request->status_label,
            'color_code' => $request->color_code,
        ]);

        return back()->with('success', 'Değerlendirme kriteri eklendi.');
    }

    // Kriter Silme
    public function destroyCriterion($id)
    {
        SupplierCriterion::findOrFail($id)->delete();
        return back()->with('success', 'Kriter silindi.');
    }
}