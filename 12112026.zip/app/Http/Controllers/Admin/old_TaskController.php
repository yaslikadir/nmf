<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\User;
use App\Models\Customer;
use App\Models\Offer;
use App\Models\MeasurementPlan;
use App\Models\Definition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TaskController extends Controller
{
    /**
     * Görev Listesi
     */
    public function index()
    {
        $user = Auth::id();
        
        // Görev Listesi
        $tasks = Task::with(['responsibles', 'customer', 'creator'])
            ->where('status', '!=', 'Silindi')
            ->where(function($query) use ($user) {
                $query->where('created_by', $user)
                      ->orWhereHas('responsibles', function($q) use ($user) { $q->where('user_id', $user); })
                      ->orWhereHas('observers', function($q) use ($user) { $q->where('user_id', $user); });
            })
            ->latest()
            ->paginate(15);

        // --- DİNAMİK FİLTRELER İÇİN VERİLER ---
        $taskStatuses = Definition::where('group_key', 'task_status')->orderBy('sort_order')->get();
        $taskPriorities = Definition::where('group_key', 'task_priority')->orderBy('sort_order')->get();

        return view('admin.tasks.index', compact('tasks', 'taskStatuses', 'taskPriorities'));
    }

    public function create()
    {
        $year = date('Y');
        $count = Task::whereYear('created_at', $year)->count() + 1;
        $code = 'TSK-' . $year . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

        $users = User::where('is_active', true)->get();
        $customers = Customer::select('id', 'name')->orderBy('name')->get();
        $offers = Offer::select('id', 'offer_no', 'customer_id')->latest()->get();
        $plans = MeasurementPlan::select('id', 'plan_code', 'offer_id')->latest()->get();

        $taskTypes = Definition::where('group_key', 'task_type')->orderBy('sort_order')->get();
        $taskStatuses = Definition::where('group_key', 'task_status')->orderBy('sort_order')->get();
        $taskPriorities = Definition::where('group_key', 'task_priority')->orderBy('sort_order')->get();

        return view('admin.tasks.create', compact(
            'code', 'users', 'customers', 'offers', 'plans',
            'taskTypes', 'taskStatuses', 'taskPriorities'
        ));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'status' => 'required',
            'priority' => 'required',
            'start_date' => 'required|date',
            'responsibles' => 'required|array',
        ]);

        $task = Task::create([
            'code' => $request->code,
            'title' => $request->title,
            'description' => $request->description,
            'created_by' => Auth::id(),
            'type' => $request->type,
            'status' => $request->status,
            'priority' => $request->priority,
            'start_date' => $request->start_date,
            'due_date' => $request->due_date,
            'reminder_date' => $request->reminder_date,
            'progress' => $request->progress ?? 0,
            'is_calendar' => $request->has('is_calendar'),
            'customer_id' => $request->customer_id,
            'offer_id' => $request->offer_id,
            'measurement_plan_id' => $request->measurement_plan_id,
        ]);

        if($request->has('responsibles')) {
            $task->responsibles()->sync($request->responsibles);
        }
        if($request->has('observers')) {
            $task->observers()->sync($request->observers);
        }

        return redirect()->route('admin.tasks.index')->with('success', 'Görev başarıyla oluşturuldu.');
    }

    /**
     * GÖREV DETAY SAYFASI (EKSİK OLAN METOT)
     */
    public function show($id)
    {
        // İlişkileriyle birlikte görevi çekiyoruz
        $task = Task::with([
            'responsibles', 
            'observers', 
            'customer', 
            'offer', 
            'plan', 
            'creator'
        ])->findOrFail($id);

        return view('admin.tasks.show', compact('task'));
    }

    public function edit($id)
    {
        $task = Task::with(['responsibles', 'observers'])->findOrFail($id);

        $users = User::where('is_active', true)->get();
        $customers = Customer::select('id', 'name')->orderBy('name')->get();
        $offers = Offer::select('id', 'offer_no', 'customer_id')->latest()->get();
        $plans = MeasurementPlan::select('id', 'plan_code', 'offer_id')->latest()->get();

        $taskTypes = Definition::where('group_key', 'task_type')->orderBy('sort_order')->get();
        $taskStatuses = Definition::where('group_key', 'task_status')->orderBy('sort_order')->get();
        $taskPriorities = Definition::where('group_key', 'task_priority')->orderBy('sort_order')->get();

        return view('admin.tasks.edit', compact(
            'task', 'users', 'customers', 'offers', 'plans',
            'taskTypes', 'taskStatuses', 'taskPriorities'
        ));
    }

    public function update(Request $request, $id)
    {
        $task = Task::findOrFail($id);

        $request->validate([
            'title' => 'required|string|max:255',
            'status' => 'required',
            'priority' => 'required',
            'start_date' => 'required|date',
            'responsibles' => 'required|array',
        ]);

        $task->update([
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'status' => $request->status,
            'priority' => $request->priority,
            'start_date' => $request->start_date,
            'due_date' => $request->due_date,
            'reminder_date' => $request->reminder_date,
            'actual_end_date' => $request->actual_end_date,
            'progress' => $request->progress ?? 0,
            'is_calendar' => $request->has('is_calendar'),
            'customer_id' => $request->customer_id,
            'offer_id' => $request->offer_id,
            'measurement_plan_id' => $request->measurement_plan_id,
        ]);

        if($request->has('responsibles')) {
            $task->responsibles()->sync($request->responsibles);
        } else {
            $task->responsibles()->detach();
        }

        if($request->has('observers')) {
            $task->observers()->sync($request->observers);
        } else {
            $task->observers()->detach();
        }

        return redirect()->route('admin.tasks.index')->with('success', 'Görev başarıyla güncellendi.');
    }

    public function destroy($id)
    {
        try {
            $task = Task::findOrFail($id);
            $task->status = 'Silindi';
            $task->save();
            return response()->json(['success' => true, 'message' => 'Görev başarıyla silinenlere taşındı.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Hata oluştu.'], 500);
        }
    }
}