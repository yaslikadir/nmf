<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    public function index()
    {
        // Rolleri ID'ye göre sıralı çekelim ki liste ekranda zıplamasın
        $roles = Role::orderBy('id', 'asc')->get(); 
        return response()->json($roles);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:roles,name',
        ]);

        Role::create([
            'name' => $request->name,
            'guard_name' => 'web'
        ]);

        return response()->json(['success' => 'Rol başarıyla eklendi.']);
    }

    public function update(Request $request, Role $role)
    {
        // Güvenlik: Admin adı yanlışlıkla değiştirilmesin
        if ($role->name === 'admin') {
            return response()->json(['message' => 'Yönetici rolünün adı değiştirilemez!'], 403);
        }

        $request->validate([
            'name' => 'required|unique:roles,name,' . $role->id,
        ]);

        $role->update(['name' => $request->name]);

        return response()->json(['success' => 'Rol güncellendi.']);
    }

    public function destroy(Role $role)
    {
        // Güvenlik: Admin rolü silinemesin
        if ($role->name === 'admin') {
            return response()->json(['message' => 'Yönetici rolü silinemez!'], 403);
        }

        // KRİTİK DOKUNUŞ: Rol silindiğinde, bizim oluşturduğumuz 
        // "RolePermission" tablosundaki yetkileri de temizlesin ki veritabanı çöplüğe dönmesin.
        if (method_exists($role, 'rolePermissions')) {
            $role->rolePermissions()->delete();
        }

        $role->delete();
        
        return response()->json(['success' => 'Rol başarıyla silindi.']);
    }

    // App\Http\Controllers\Admin\RoleController.php

public function switchRole($roleId) 
{
    $user = auth()->user();
    
    // Kullanıcının gerçekten bu role sahip olduğunu Spatie ile kontrol et
    if ($user->roles->contains($roleId)) {
        // En garantili ve fillable engeline takılmayan doğrudan atama yöntemi:
        $user->active_role_id = $roleId;
        $user->save();
        
        return redirect()->back()->with('success', 'Çalışma modunuz güncellendi.');
    }
    
    return redirect()->back()->with('error', 'Bu role geçiş yetkiniz bulunmuyor!');
}
}