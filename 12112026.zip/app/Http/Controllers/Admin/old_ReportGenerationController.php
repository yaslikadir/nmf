<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sample;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage; // Storage Facade Eklendi

// QR Kod Kütüphanesi
use SimpleSoftwareIO\QrCode\Facades\QrCode;

// FPDI (PDF Birleştirme Motoru)
use setasign\Fpdi\Tcpdf\Fpdi; 

class ReportGenerationController extends Controller
{
    /**
     * Rapor Oluşturma/Birleştirme Ekranı
     */
    public function create($id)
    {
        $sample = Sample::with([
            'offer.customer', 
            'workOrders.result', 
            'workOrders.parameter', 
            'workOrders.method'
        ])->findOrFail($id);

        return view('admin.reporting.generate', compact('sample'));
    }

    /**
     * Dosyaları Birleştir, Dinamik Konumda QR Kod Bas ve Kaydet
     */
    public function store(Request $request, $id)
    {
        set_time_limit(300); // Büyük dosyalar için süre sınırı (5 dakika)
        $sample = Sample::findOrFail($id);

        // --- VALIDASYON ---
        $request->validate([
            'attachments'   => 'required|array',
            'attachments.*' => 'mimes:pdf,jpg,jpeg,png|max:10240', // Max 10MB
            'qr_page'       => 'nullable|integer|min:1',
            'qr_x'          => 'nullable|numeric',
            'qr_y'          => 'nullable|numeric',
        ]);

        // --- KLASÖR TANIMLARI ---
        $tempDir = storage_path('app/temp_processing');
        $reportsDir = storage_path('app/public/reports');
        
        // Klasörler yoksa oluştur
        if (!File::exists($tempDir)) File::makeDirectory($tempDir, 0755, true);
        if (!File::exists($reportsDir)) File::makeDirectory($reportsDir, 0755, true);

        // Birleştirilecek dosyaların listesi (Temizlik için tutuyoruz)
        $filesToMerge = [];
        $qrPath = $tempDir . '/qr_' . uniqid() . '.svg';

        try {
            // ---------------------------------------------------------
            // 1. KULLANICI AYARLARINI AL
            // ---------------------------------------------------------
            $targetPage = (int) $request->input('qr_page', 1);
            $qrX = (float) $request->input('qr_x', 10);
            $qrY = (float) $request->input('qr_y', 260);

            // ---------------------------------------------------------
            // 2. QR KODU HAZIRLA (SVG FORMATINDA)
            // ---------------------------------------------------------
            $qrUrl = route('public.report.show', $sample->barcode);
            
            QrCode::format('svg')
                    ->size(300)
                    ->margin(1)
                    ->generate($qrUrl, $qrPath);

            // ---------------------------------------------------------
            // 3. YÜKLENEN DOSYALARI GEÇİCİ KLASÖRE TAŞI
            // ---------------------------------------------------------
            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $file) {
                    $name = uniqid() . '_' . $file->getClientOriginalName();
                    $file->move($tempDir, $name);
                    $filesToMerge[] = $tempDir . '/' . $name;
                }
            }

            // ---------------------------------------------------------
            // 4. BİRLEŞTİRME VE DİNAMİK QR BASMA İŞLEMİ
            // ---------------------------------------------------------
            $pdf = new Fpdi();
            
            // Otomatik çizgileri kapat (TCPDF ayarı)
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);

            // Global Sayfa Sayacı
            $globalPageCounter = 0; 

            foreach ($filesToMerge as $filePath) {
                $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

                // --- A) PDF DOSYASI İSE ---
                if ($extension === 'pdf') {
                    try {
                        $pageCount = $pdf->setSourceFile($filePath);
                        for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
                            $globalPageCounter++;

                            // Sayfayı şablon olarak al
                            $templateId = $pdf->importPage($pageNo);
                            $size = $pdf->getTemplateSize($templateId);
                            
                            // Sayfa boyutunu koruyarak ekle
                            $pdf->AddPage($size['orientation'], [$size['width'], $size['height']]);
                            $pdf->useTemplate($templateId);

                            // QR Kod Bas (Helper Fonksiyon Kullanımı)
                            $this->addQrToPage($pdf, $globalPageCounter, $targetPage, $qrPath, $qrX, $qrY);
                        }
                    } catch (\Exception $e) { 
                        // Bozuk PDF gelirse atla ama logla
                        \Log::warning("PDF Merge Hatası (Dosya: $filePath): " . $e->getMessage());
                        continue; 
                    }
                } 
                // --- B) RESİM DOSYASI İSE ---
                elseif (in_array($extension, ['jpg', 'jpeg', 'png'])) {
                    $globalPageCounter++;

                    // A4 Sayfa
                    $pdf->AddPage('P', 'A4');
                    // Resmi yerleştir (X:10, Y:10, Genişlik: 190mm)
                    $pdf->Image($filePath, 10, 10, 190, 0, '', '', 'T', false, 300, 'C');

                    // QR Kod Bas
                    $this->addQrToPage($pdf, $globalPageCounter, $targetPage, $qrPath, $qrX, $qrY);
                }
            }

            // ---------------------------------------------------------
            // 5. KAYDETME VE BİTİRME
            // ---------------------------------------------------------
            $finalFileName = 'Rapor_' . $sample->barcode . '_' . time() . '.pdf';
            $finalPath = $reportsDir . '/' . $finalFileName;
            
            // Windows path düzeltmesi
            $finalPath = str_replace('\\', '/', $finalPath);

            // Dosyayı kaydet
            $pdf->Output($finalPath, 'F'); 

            // 6. TEMİZLİK (Geçici dosyaları sil)
            foreach ($filesToMerge as $file) {
                if(File::exists($file)) File::delete($file);
            }
            if(File::exists($qrPath)) File::delete($qrPath);

            // 7. VERİTABANI GÜNCELLEME
            $sample->update([
                'status'       => 'Tamamlandı', // veya 'Raporlandı'
                'completed_at' => now(),
                'report_file'  => 'reports/' . $finalFileName, // Public link yolu
            ]);

            return redirect()->route('admin.reporting.index')
                             ->with('success', 'Rapor başarıyla birleştirildi. QR Kod ' . $targetPage . '. sayfaya eklendi.');

        } catch (\Exception $e) {
            // Hata durumunda da temizlik yap
            if(isset($filesToMerge)) {
                foreach ($filesToMerge as $file) {
                    if(File::exists($file)) File::delete($file);
                }
            }
            if(isset($qrPath) && File::exists($qrPath)) File::delete($qrPath);

            return back()->with('error', 'Rapor oluşturulurken hata: ' . $e->getMessage());
        }
    }

    /**
     * Yardımcı Fonksiyon: QR Kod Basma
     */
    private function addQrToPage($pdf, $currentCounter, $targetPage, $qrPath, $x, $y)
    {
        if ($currentCounter == $targetPage) {
            // QR (SVG)
            $pdf->ImageSVG($qrPath, $x, $y, 25, 25);
            
            // Alt Yazı
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->SetXY($x, $y + 26);
            $pdf->Write(0, 'Doğrulama Kodu');
        }
    }
}