<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sample;
use App\Models\SampleTransfer;
use App\Models\StorageLocation;
use App\Models\SampleTransaction; // Loglama için
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SampleTransferController extends Controller
{
    /**
     * Transfer Paneli
     */
    public function index()
    {
        // 1. Bekleyenler
        $pendingTransfers = SampleTransfer::with(['sample', 'fromLocation', 'toLocation', 'requester'])
            ->where('status', 'Pending')
            ->latest()
            ->get();

        // 2. Yoldakiler (Transporter eklendi)
        $incomingTransfers = SampleTransfer::with(['sample', 'fromLocation', 'toLocation', 'requester', 'transporter'])
            ->where('status', 'InTransit')
            ->latest()
            ->get();

        // 3. Tamamlananlar (Transporter ve Receiver eklendi)
        $completedTransfers = SampleTransfer::with(['sample', 'fromLocation', 'toLocation', 'requester', 'transporter', 'receiver'])
            ->whereIn('status', ['Delivered', 'Rejected'])
            ->latest() // take(20)'yi kaldırdık, DataTables sayfalama yapacak
            ->get();

        $locations = StorageLocation::where('is_active', true)->get();

        return view('admin.sample_transfers.index', compact('pendingTransfers', 'incomingTransfers', 'completedTransfers', 'locations'));
    }

    /**
     * Transfer Talebi Oluştur (Adım 1)
     */
    public function store(Request $request)
    {
        $request->validate([
            'barcode' => 'required|exists:samples,barcode',
            'to_location_id' => 'required|exists:storage_locations,id',
            'notes' => 'nullable|string'
        ]);

        $sample = Sample::where('barcode', $request->barcode)->first();

        // Numune şu an zaten hedefte mi?
        if($sample->storage_location_id == $request->to_location_id) {
            return back()->with('error', 'Numune zaten seçilen lokasyonda bulunuyor.');
        }

        // --- GÜVENLİK KONTROLÜ ---
        if ($sample->global_status == 'İmha Edildi') {
            return back()->with('error', 'HATA: İmha edilmiş bir numune transfer edilemez!');
        }

        SampleTransfer::create([
            'sample_id' => $sample->id,
            'from_location_id' => $sample->storage_location_id,
            'to_location_id' => $request->to_location_id,
            'requested_by' => Auth::id(),
            'status' => 'Pending',
            'notes' => $request->notes,
            'transport_conditions' => $request->transport_conditions // Örn: Soğuk Zincir
        ]);

        return back()->with('success', 'Transfer talebi oluşturuldu. Lojistik onayı bekleniyor.');
    }

    /**
     * Transferi Başlat / Yola Çıkar (Adım 2)
     */
    public function startTransfer($id)
    {
        $transfer = SampleTransfer::findOrFail($id);
        
        $transfer->update([
            'status' => 'InTransit',
            'transferred_by' => Auth::id(),
            'transfer_date' => now()
        ]);

        // Loglama
        SampleTransaction::create([
            'sample_id' => $transfer->sample_id,
            'user_id' => Auth::id(),
            'action_type' => 'TRANSFER_START',
            'from_location' => $transfer->fromLocation->name ?? '?',
            'to_location' => 'Yolda',
            'description' => 'Transfer başladı. Hedef: ' . ($transfer->toLocation->name ?? 'Dış Merkez')
        ]);

        return back()->with('success', 'Numune yola çıkarıldı.');
    }

    /**
     * Numuneyi Teslim Al ve Onayla (Adım 3)
     */
    public function completeTransfer(Request $request, $id)
    {
        $transfer = SampleTransfer::findOrFail($id);
        
        try {
            DB::beginTransaction();

            // 1. Transfer Kaydını Güncelle
            $transfer->update([
                'status' => 'Delivered',
                'received_by' => Auth::id(),
                'received_date' => now(),
                'condition_check_result' => $request->condition_result // "Uygun", "Kırık" vb.
            ]);

            // 2. Numunenin Ana Lokasyonunu Güncelle (Kritik Adım)
            $sample = Sample::find($transfer->sample_id);
            $sample->update([
                'storage_location_id' => $transfer->to_location_id,
                'storage_conditions' => 'Transfer Sonrası: ' . $request->condition_result // Opsiyonel bilgi güncelleme
            ]);

            // 3. Loglama
            SampleTransaction::create([
                'sample_id' => $sample->id,
                'user_id' => Auth::id(),
                'action_type' => 'TRANSFER_COMPLETE',
                'from_location' => 'Transfer',
                'to_location' => $transfer->toLocation->name,
                'description' => 'Numune teslim alındı. Kontrol Sonucu: ' . $request->condition_result
            ]);

            DB::commit();
            return back()->with('success', 'Numune başarıyla teslim alındı ve yeni lokasyonuna atandı.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }
}