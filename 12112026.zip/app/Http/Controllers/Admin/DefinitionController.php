<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Definition;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class DefinitionController extends Controller 
{
    public function index(Request $request) 
    {
        $activeGroup = $request->get('group', 'customer_type');
        $definitions = Definition::where('group_key', $activeGroup)->orderBy('sort_order')->get();

        $menuGroups = [
            'Müşteri Sabitleri' => [
                'customer_type'     => 'Müşteri Türü',
                'sector'            => 'Sektör',
                'city'              => 'Şehir',
                'customer_category' => 'Müşteri Kategorisi',
                'customer_source'   => 'Müşteri Kaynağı',
            ],
            'Kontak (Yetkili) Sabitleri' => [
                'contact_address_type' => 'Adres Tipi',
                'decision_status'      => 'Karar Durumu',
                'company_relationship' => 'İlişki (Sıcak/Soğuk)',
                'gender'               => 'Cinsiyet',
            ],
            'Aktivite Sabitleri' => [
                'activity_type'   => 'Aktivite Türü',
                'activity_status' => 'Aktivite Durumu',
            ],
            'Kullanıcı Sabitleri' => [
                'education_status' => 'Eğitim Durumu',
                'blood_group'      => 'Kan Grubu',
                'marital_status'   => 'Medeni Hal',
            ],
            'Cihaz ve Ekipman Sabitleri' => [
                'device_locations'  => 'Cihaz Lokasyonları',
                'device_brands'     => 'Cihaz Markaları',
                'device_types'      => 'Cihaz Türleri',
                'maintenance_types' => 'Bakım Türleri',
            ],
            'Görev Yönetimi Sabitleri' => [
                'task_type'     => 'Görev Tipleri',
                'task_status'   => 'Görev Durumları',
                'task_priority' => 'Görev Öncelikleri',
            ],
            'Sistem Sabitleri' => [
                'department' => 'Departmanlar',
                'title'      => 'Ünvanlar',
            ]
        ];

        return view('admin.definitions.index', compact('definitions', 'menuGroups', 'activeGroup'));
    }

    public function bulkUpdate(Request $request) 
    {
        $items = $request->input('items', []);
        $deletedIds = $request->input('deleted_ids', []);
        $groupKey = $request->input('group_key');

        if (empty($groupKey)) {
            return response()->json(['success' => false, 'message' => 'Grup anahtarı eksik!'], 400);
        }

        try {
            DB::beginTransaction();

            // Silinen satırlar varsa veritabanından kaldır
            if (!empty($deletedIds) && is_array($deletedIds)) {
                Definition::where('group_key', $groupKey)->whereIn('id', $deletedIds)->delete();
            }

            foreach ($items as $id => $data) {
                if (empty($data['label'])) continue;

                $slugValue = Str::slug($data['label']);

                if (str_starts_with((string) $id, 'new_')) {
                    Definition::create([
                        'group_key'   => $groupKey,
                        'group_label' => $request->group_label ?? $groupKey,
                        'label'       => $data['label'],
                        'value'       => $slugValue,
                        'sort_order'  => $data['sort_order'] ?? 0,
                        'color_code'  => $data['color_code'] ?? '#ffffff',
                        'is_active'   => true,
                        'type'        => 'system_defined'
                    ]);
                } else {
                    $def = Definition::find($id);
                    if ($def) {
                        $def->update([
                            'label'      => $data['label'],
                            'value'      => $slugValue,
                            'sort_order' => $data['sort_order'] ?? 0,
                            'color_code' => $data['color_code'] ?? '#ffffff',
                        ]);
                    }
                }
            }

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Değişiklikler başarıyla uygulandı.']);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Sistem Hatası: ' . $e->getMessage()], 500);
        }
    }

    public function destroy($id)
    {
        $def = Definition::findOrFail($id);
        $def->delete();
        return response()->json(['success' => true, 'message' => 'Sabit silindi.']);
    }
}