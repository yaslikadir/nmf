<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Material;
use App\Models\Inventory;
use App\Models\StockMovement;
use Illuminate\Support\Facades\DB;

class InventoryCountController extends Controller
{
    // Sayım Ekranını Göster
    public function index(Request $request)
    {
        $categories = \App\Models\InventoryCategory::where('slug', '!=', 'hizmet')->get();

        $query = Material::with(['category', 'stocks'])
            ->where(function($q) {
                $q->where('is_active', true)->orWhereNull('is_active');
            });

        // Kategori filtresi
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        } else {
            // Hizmetleri hariç tut
            $query->where(function($q) {
                $q->whereDoesntHave('category', function($cat) {
                    $cat->where('slug', 'hizmet');
                })->orWhereNull('category_id');
            });
        }

        $materials = $query->orderBy('name')->get();

        return view('admin.inventory.count.index', compact('materials', 'categories'));
    }

    // Toplu Sayımı Veritabanına İşle
    public function sync(Request $request)
    {
        $counts = $request->input('counts', []); // Mevcut lotların sayımı
        $newCounts = $request->input('new_counts', []); // Hiç stoğu olmayanların ilk sayımı

        if (empty($counts) && empty($newCounts)) {
            return back()->with('error', 'Sayım yapılacak hiçbir veri bulunamadı.');
        }

        DB::beginTransaction();
        try {
            $islemYapilanSatiSayisi = 0;

            // --- 1. MEVCUT LOTLARIN EŞİTLENMESİ ---
            foreach ($counts as $inventoryId => $countedQuantity) {
                if (is_null($countedQuantity) || $countedQuantity === '') continue; 

                $countedQuantity = (float) $countedQuantity;
                $inventory = Inventory::with('material')->find($inventoryId);
                if (!$inventory) continue;

                $systemQuantity = (float) $inventory->quantity;
                $difference = $countedQuantity - $systemQuantity;

                if ($difference == 0) continue; // Fark yoksa atla

                $inventory->quantity = $countedQuantity;
                $inventory->save();

                StockMovement::create([
                    'material_id' => $inventory->material_id,
                    'inventory_id' => $inventory->id,
                    'user_id' => auth()->id(),
                    'type' => $difference > 0 ? 'in' : 'out', 
                    'quantity' => abs($difference),
                    // DÜZELTME BURADA: description yerine reason kullanıldı
                    'reason' => 'Sistem Sayım Eşitlemesi. Eski: ' . $systemQuantity . ' -> Yeni: ' . $countedQuantity . ' (' . ($difference > 0 ? 'Fazla' : 'Fire') . ')'
                ]);

                $islemYapilanSatiSayisi++;
            }

            // --- 2. HİÇ STOĞU OLMAYANLARIN "İLK SAYIM" GİRİŞİ ---
            foreach ($newCounts as $materialId => $countedQuantity) {
                if (is_null($countedQuantity) || $countedQuantity === '') continue;

                $countedQuantity = (float) $countedQuantity;
                if ($countedQuantity <= 0) continue; 

                $newInventory = Inventory::create([
                    'material_id' => $materialId,
                    'lot_number' => 'DEVIR-' . date('Ymd'), 
                    'quantity' => $countedQuantity,
                    'storage_location' => 'Sayım Alanı'
                ]);

                StockMovement::create([
                    'material_id' => $materialId,
                    'inventory_id' => $newInventory->id,
                    'user_id' => auth()->id(),
                    'type' => 'in', 
                    'quantity' => $countedQuantity,
                    // DÜZELTME BURADA: description yerine reason kullanıldı
                    'reason' => 'İlk Sayım / Devir Girişi. Eşitlenen Miktar: ' . $countedQuantity
                ]);

                $islemYapilanSatiSayisi++;
            }

            DB::commit();

            if ($islemYapilanSatiSayisi > 0) {
                return back()->with('success', $islemYapilanSatiSayisi . ' adet stok kaydı başarıyla eşitlendi ve hareket geçmişine işlendi.');
            } else {
                return back()->with('info', 'Değişiklik tespit edilmedi, işlemler pas geçildi.');
            }

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Eşitleme sırasında bir hata oluştu: ' . $e->getMessage());
        }
    }
}