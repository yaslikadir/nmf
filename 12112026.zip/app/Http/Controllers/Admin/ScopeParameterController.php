<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ScopeType;
use App\Models\ScopeParameter;
use App\Models\ScopeTable;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Gate; // <--- KRİTİK EKLEME
use App\Models\AnalysisMethod;

class ScopeParameterController extends Controller 
{
    /**
     * Sayfa Görüntüleme
     */
    public function index() 
    {
        // 1. GÜVENLİK: Gate Facade kullanımı
        if (!auth()->user()->hasPermissionToAccessModule('parameters')) {
    abort(403, 'Bu modüle erişim yetkiniz yok.');
}

        $scopeTypes = ScopeType::orderBy('name')->get();
        
        // Sadece YAYINDA (Published) olan metotları çekiyoruz.
        $methods = AnalysisMethod::where('status', 'Published')
                                 ->orderBy('code')
                                 ->get(['code', 'name', 'technique']);

        return view('admin.scope_parameters.index', compact('scopeTypes', 'methods'));
    }

    /**
     * Seçilen Kapsam Tipine Göre Verileri Getir (AJAX)
     */
    public function getData($typeId): JsonResponse
    {
        Gate::authorize('view-module', 'parameters');

        try {
            $parameters = ScopeParameter::where('scope_type_id', $typeId)
                ->orderBy('name', 'asc')
                ->get();

            $tables = ScopeTable::where('scope_type_id', $typeId)
                ->with('parameters')
                ->orderBy('name', 'asc')
                ->get();
            
            return response()->json([
                'parameters' => $parameters,
                'tables' => $tables
            ]);
        } catch (\Exception $e) {
            Log::error("Scope GetData Hatası: " . $e->getMessage());
            return response()->json(['success' => false, 'message' => "Veri çekilemedi: " . $e->getMessage()], 500);
        }
    }

    /**
     * Toplu Parametre Kaydı ve Güncelleme (ANALİZ DETAYLARI İLE)
     */
    public function bulkUpdate(Request $request): JsonResponse
    {
        // Yazma yetkisi kontrolü
        Gate::authorize('view-module', 'parameters');

        $request->validate([
            'scope_type_id' => 'required|exists:scope_types,id',
            'items'         => 'nullable|array'
        ]);

        try {
            DB::beginTransaction();
            $typeId = $request->scope_type_id;
            $items = $request->items ?? [];

            foreach ($items as $id => $data) {
                // Veri Hazırlığı
                $preparedData = [
                    'name'                => $data['name'] ?? '',
                    'scope_category'      => $data['scope_category'] ?? null,
                    'unit'                => $data['unit'] ?? null,
                    'standard_ref'        => $data['standard_ref'] ?? null,
                    'limit_min'           => $data['limit_min'] ?? null,
                    'limit_max'           => $data['limit_max'] ?? null,
                    'analysis_duration'   => $data['analysis_duration'] ?? 1,
                    'duration_unit'       => $data['duration_unit'] ?? 'Gün',
                    'can_be_urgent'       => isset($data['can_be_urgent']) ? 1 : 0,
                    'is_accredited'       => isset($data['is_accredited']) ? 1 : 0,
                    // --- Analiz Detayları ---
                    'analysis_methods'    => $data['analysis_methods'] ?? null,
                    'analysis_techniques' => $data['analysis_techniques'] ?? null,
                    'storage_conditions'  => $data['storage_conditions'] ?? null,
                    'needs_sample'        => isset($data['needs_sample']) ? 1 : 0,
                    'is_active'           => isset($data['is_active']) ? 1 : 0,
                ];

                // 3. FİYAT GÜNCELLEME YETKİSİ (Sadece Admin)
                if (auth()->user()->hasRole('admin')) { 
                    $preparedData['gov_price'] = isset($data['gov_price']) ? str_replace(',', '.', $data['gov_price']) : 0;
                    $preparedData['external_price'] = isset($data['external_price']) ? str_replace(',', '.', $data['external_price']) : 0;
                }

                if (str_starts_with($id, 'new_')) {
                    $preparedData['scope_type_id'] = $typeId;
                    ScopeParameter::create($preparedData);
                } else {
                    ScopeParameter::where('id', $id)->update($preparedData);
                }
            }

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Parametreler ve analiz detayları başarıyla güncellendi.']);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Bulk Update Hatası: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Tablo Başlıklarını Toplu Kaydet
     */
    public function bulkUpdateTables(Request $request): JsonResponse
    {
        Gate::authorize('view-module', 'parameters');

        $request->validate([
            'scope_type_id' => 'required|exists:scope_types,id',
            'items'         => 'nullable|array'
        ]);

        try {
            DB::beginTransaction();
            foreach ($request->items ?? [] as $id => $data) {
                $updateData = [
                    'name'      => $data['name'],
                    'is_active' => isset($data['is_active']) ? 1 : 0
                ];

                if (str_starts_with($id, 'new_')) {
                    $updateData['scope_type_id'] = $request->scope_type_id;
                    ScopeTable::create($updateData);
                } else {
                    ScopeTable::where('id', $id)->update($updateData);
                }
            }
            DB::commit();
            return response()->json(['success' => true, 'message' => 'Tablo başlıkları güncellendi.']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Parametreleri Tabloya Bağla
     */
    public function syncParameters(Request $request): JsonResponse
    {
        Gate::authorize('view-module', 'parameters');

        $request->validate([
            'scope_table_id' => 'required|exists:scope_tables,id',
            'parameter_ids'  => 'required|array'
        ]);

        try {
            $table = ScopeTable::findOrFail($request->scope_table_id);
            $table->parameters()->syncWithoutDetaching($request->parameter_ids);
            return response()->json(['success' => true, 'message' => 'Parametreler tabloya eklendi.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Parametreleri Tablodan Çıkart
     */
    public function detachParameters(Request $request): JsonResponse
    {
        Gate::authorize('view-module', 'parameters');

        $request->validate([
            'scope_table_id' => 'required|exists:scope_tables,id',
            'parameter_ids'  => 'required|array'
        ]);

        try {
            $table = ScopeTable::findOrFail($request->scope_table_id);
            $table->parameters()->detach($request->parameter_ids);
            return response()->json(['success' => true, 'message' => 'Seçili parametreler çıkartıldı.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    // Tekli Silme Metotları
    public function destroyParameter($id)
    {
        Gate::authorize('view-module', 'parameters');

        try {
            ScopeParameter::findOrFail($id)->delete();
            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function destroyTable($id)
    {
        Gate::authorize('view-module', 'parameters');

        try {
            ScopeTable::findOrFail($id)->delete();
            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

   /**
 * Tüm Kapsamları Tek Raporda Getir
 */
public function generateFullReport()
{
    \Illuminate\Support\Facades\Gate::authorize('view-module', 'parameters');

    // Tüm aktif kapsam tiplerini, tabloları ve parametreleri hiyerarşik çekiyoruz
    $scopeTypes = \App\Models\ScopeType::with(['tables' => function($q) {
            $q->where('is_active', 1)->with(['parameters' => function($pq) {
                $pq->where('is_active', 1)->orderBy('name', 'asc');
            }]);
        }])
        ->orderBy('name', 'asc')
        ->get();

    return view('admin.scope_parameters.scoperaport', compact('scopeTypes'));
}
}