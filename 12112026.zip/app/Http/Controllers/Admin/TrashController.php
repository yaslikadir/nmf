<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TrashController extends Controller
{
    /**
     * Sistemdeki ana ve modül modellerinin tablo ve başlık tanımları
     */
    protected array $knownModels = [
        'User' => [
            'table' => 'users',
            'label' => 'Kullanıcılar (Personel Hesapları)',
            'icon'  => 'fas fa-user-shield',
        ],
        'Customer' => [
            'table' => 'customers',
            'label' => 'Müşteriler',
            'icon'  => 'fas fa-building',
        ],
        'Contact' => [
            'table' => 'contacts',
            'label' => 'Kontaklar (Yetkili Kişiler)',
            'icon'  => 'fas fa-address-card',
        ],
        'Activity' => [
            'table' => 'activities',
            'label' => 'Görüşme Kayıtları (Aktiviteler)',
            'icon'  => 'fas fa-comments',
        ],
        'CustomerRequest' => [
            'table' => 'customer_requests',
            'label' => 'Müşteri Talepleri',
            'icon'  => 'fas fa-bell',
        ],
        'Offer' => [
            'table' => 'offers',
            'label' => 'Teklifler',
            'icon'  => 'fas fa-file-invoice-dollar',
        ],
        'Sample' => [
            'table' => 'samples',
            'label' => 'Numuneler',
            'icon'  => 'fas fa-vial',
        ],
        'MeasurementPlan' => [
            'table' => 'measurement_plans',
            'label' => 'Ölçüm Planları',
            'icon'  => 'fas fa-calendar-check',
        ],
        'Task' => [
            'table' => 'tasks',
            'label' => 'Görevler (Tasks)',
            'icon'  => 'fas fa-tasks',
        ],
        'Device' => [
            'table' => 'devices',
            'label' => 'Cihazlar',
            'icon'  => 'fas fa-microscope',
        ],
        'Material' => [
            'table' => 'materials',
            'label' => 'Stok / Kimyasal Malzemeler',
            'icon'  => 'fas fa-boxes',
        ],
        'Supplier' => [
            'table' => 'suppliers',
            'label' => 'Tedarikçiler',
            'icon'  => 'fas fa-truck',
        ],
        'PurchaseRequest' => [
            'table' => 'purchase_requests',
            'label' => 'Satın Alma Talepleri',
            'icon'  => 'fas fa-shopping-cart',
        ],
        'Department' => [
            'table' => 'departments',
            'label' => 'Departmanlar',
            'icon'  => 'fas fa-sitemap',
        ],
        'Branch' => [
            'table' => 'branches',
            'label' => 'Şubeler',
            'icon'  => 'fas fa-code-branch',
        ],
    ];

    /**
     * Hem bilinen modelleri hem de modules/ klasörü altına yeni eklenen modelleri güvenle bulur
     * (require_once kullanmadığı için asla Fatal Error / 500 vermez)
     */
    protected function discoverModels(): array
    {
        $discovered = [];

        // 1. Önce tanımlı ana ve modül tablolarını kontrol et
        foreach ($this->knownModels as $key => $info) {
            $table = $info['table'];
            if (!Schema::hasTable($table)) {
                continue;
            }

            $hasSoftDelete = Schema::hasColumn($table, 'deleted_at');
            $hasStatus     = Schema::hasColumn($table, 'status');
            $hasIsActive   = Schema::hasColumn($table, 'is_active');

            if ($hasSoftDelete || $hasStatus || $hasIsActive) {
                $discovered[$key] = [
                    'key'             => $key,
                    'table'           => $table,
                    'label'           => $info['label'],
                    'icon'            => $info['icon'] ?? 'fas fa-folder',
                    'has_soft_delete' => $hasSoftDelete,
                    'has_status_del'  => $hasStatus,
                    'has_is_active'   => $hasIsActive && in_array($key, ['User', 'Customer', 'Contact'], true),
                    'has_branch_id'   => Schema::hasColumn($table, 'branch_id'),
                ];
            }
        }

        // 2. modules/ ve Modules/ klasörlerini tarayıp listede olmayan yeni model dosyalarını bul
        foreach (['modules', 'Modules'] as $modRoot) {
            $baseModPath = base_path($modRoot);
            if (!File::isDirectory($baseModPath)) {
                continue;
            }

            foreach (File::allFiles($baseModPath) as $file) {
                if ($file->getExtension() !== 'php') {
                    continue;
                }

                // Sadece Models klasörü içindeki dosyaları incele
                if (!str_contains($file->getPathname(), 'Models')) {
                    continue;
                }

                $className = $file->getFilenameWithoutExtension();
                if (isset($discovered[$className])) {
                    continue;
                }

                try {
                    $content = File::get($file->getRealPath());

                    // Dosya içinde özel $table tanımı varsa al, yoksa çoğul snake_case tahmin et
                    if (preg_match('/\$table\s*=\s*[\'"]([^\'"]+)[\'"]/', $content, $tMatch)) {
                        $table = trim($tMatch[1]);
                    } else {
                        $table = Str::snake(Str::pluralStudly($className));
                    }

                    if (!Schema::hasTable($table)) {
                        continue;
                    }

                    $hasSoftDelete = Schema::hasColumn($table, 'deleted_at');
                    $hasStatus     = Schema::hasColumn($table, 'status');

                    if ($hasSoftDelete || $hasStatus) {
                        $discovered[$className] = [
                            'key'             => $className,
                            'table'           => $table,
                            'label'           => $className,
                            'icon'            => 'fas fa-cube',
                            'has_soft_delete' => $hasSoftDelete,
                            'has_status_del'  => $hasStatus,
                            'has_is_active'   => false,
                            'has_branch_id'   => Schema::hasColumn($table, 'branch_id'),
                        ];
                    }
                } catch (\Throwable $e) {
                    continue;
                }
            }
        }

        return $discovered;
    }

    /**
     * Geri Dönüşüm Kutusu Listesi
     */
    public function index(Request $request)
    {
        $models = $this->discoverModels();
        $selectedModelKey = $request->get('model', 'all');
        $activeBranchId = session('active_branch_id');

        $trashedItems = collect();
        $modelCounts = [];

        foreach ($models as $key => $meta) {
            try {
                $table = $meta['table'];
                $query = DB::table($table);

                // Şube filtresi (Kullanıcılar, Departmanlar ve Şubeler tüm şubelerde ortaktır)
                if ($meta['has_branch_id'] && $activeBranchId && !in_array($key, ['User', 'Department', 'Branch'], true)) {
                    $query->where($table . '.branch_id', $activeBranchId);
                }

                // Silinmiş (deleted_at IS NOT NULL) VEYA status='Silindi' VEYA Pasife çekilmiş (is_active=0) kayıtları yakala
                $query->where(function ($q) use ($meta, $table) {
                    $addedCondition = false;

                    if ($meta['has_soft_delete']) {
                        $q->whereNotNull($table . '.deleted_at');
                        $addedCondition = true;
                    }

                    if ($meta['has_status_del']) {
                        $method = $addedCondition ? 'orWhereIn' : 'whereIn';
                        $q->{$method}($table . '.status', ['Silindi', 'deleted', 'Deleted']);
                        $addedCondition = true;
                    }

                    if ($meta['has_is_active']) {
                        $method = $addedCondition ? 'orWhere' : 'where';
                        $q->{$method}($table . '.is_active', 0);
                        $addedCondition = true;
                    }

                    if (!$addedCondition) {
                        $q->whereRaw('1 = 0');
                    }
                });

                $count = (clone $query)->count();
                $modelCounts[$key] = $count;

                if ($count > 0 && ($selectedModelKey === 'all' || $selectedModelKey === $key)) {
                    $orderCol = Schema::hasColumn($table, 'updated_at') ? 'updated_at' : 'id';
                    $records = $query->orderByDesc($orderCol)->limit(250)->get();

                    foreach ($records as $rec) {
                        $deleteType = 'Durum: Silindi';
                        if (!empty($rec->deleted_at)) {
                            $deleteType = 'Silindi (Trash)';
                        } elseif (isset($rec->is_active) && $rec->is_active == 0) {
                            $deleteType = 'Pasife Alındı';
                        }

                        $trashedItems->push([
                            'id'          => $rec->id,
                            'model_key'   => $key,
                            'model_label' => $meta['label'],
                            'title'       => $this->resolveRecordTitle($rec, $key),
                            'code'        => $this->resolveRecordCode($rec, $key),
                            'deleted_at'  => $rec->deleted_at ?? ($rec->updated_at ?? ($rec->created_at ?? null)),
                            'delete_type' => $deleteType,
                        ]);
                    }
                }
            } catch (\Throwable $e) {
                $modelCounts[$key] = 0;
            }
        }

        $trashedItems = $trashedItems->sortByDesc('deleted_at')->values();

        return view('admin.trash.index', compact('models', 'modelCounts', 'trashedItems', 'selectedModelKey'));
    }

    /**
     * Silinen Kaydı Geri Yükle (Kullanıcı, Müşteri, Plan, Görev, Numune vb.)
     */
    public function restore(Request $request, string $modelKey, $id)
    {
        $models = $this->discoverModels();

        if (!isset($models[$modelKey])) {
            return back()->with('error', 'Geçersiz modül/model tipi.');
        }

        $meta = $models[$modelKey];
        $table = $meta['table'];

        try {
            $record = DB::table($table)->where('id', $id)->first();
            if (!$record) {
                return back()->with('error', 'Kayıt bulunamadı.');
            }

            $updates = [];

            if ($meta['has_soft_delete']) {
                $updates['deleted_at'] = null;
            }

            if ($meta['has_status_del'] && isset($record->status) && in_array($record->status, ['Silindi', 'deleted', 'Deleted'], true)) {
                $updates['status'] = match ($modelKey) {
                    'MeasurementPlan' => 'Planlandı',
                    'Task'            => 'Bekliyor',
                    'Offer'           => 'Açık',
                    'Customer'        => 'active',
                    default           => 'Aktif',
                };
            }

            if (Schema::hasColumn($table, 'is_active')) {
                $updates['is_active'] = 1;
            }

            if (Schema::hasColumn($table, 'updated_at')) {
                $updates['updated_at'] = now();
            }

            if (!empty($updates)) {
                DB::table($table)->where('id', $id)->update($updates);
            }

            return back()->with('success', "{$meta['label']} kaydı (#{$id}) başarıyla geri yüklendi ve aktif edildi!");
        } catch (\Throwable $e) {
            return back()->with('error', 'Geri yükleme sırasında hata oluştu: ' . $e->getMessage());
        }
    }

    /**
     * Kaydı Veritabanından Kalıcı Olarak Sil (Force Delete)
     */
    public function forceDelete(Request $request, string $modelKey, $id)
    {
        $models = $this->discoverModels();

        if (!isset($models[$modelKey])) {
            return back()->with('error', 'Geçersiz modül/model tipi.');
        }

        if ($modelKey === 'User' && (int) $id === (int) auth()->id()) {
            return back()->with('error', 'Kendi aktif kullanıcı hesabınızı kalıcı olarak silemezsiniz!');
        }

        $meta = $models[$modelKey];
        $table = $meta['table'];

        try {
            DB::table($table)->where('id', $id)->delete();

            return back()->with('success', "{$meta['label']} kaydı (#{$id}) veritabanından kalıcı olarak silindi.");
        } catch (\Throwable $e) {
            return back()->with('error', 'Bu kayıt başka tablolarda (teklif/analiz vb.) kullanıldığı için kalıcı silinemedi. Önce bağlı kayıtları silmelisiniz.');
        }
    }

    protected function resolveRecordTitle($record, string $modelKey): string
    {
        foreach (['name', 'full_name', 'title', 'subject', 'official_title', 'analysis_summary', 'description', 'email'] as $field) {
            if (!empty($record->{$field})) {
                return (string) Str::limit($record->{$field}, 65);
            }
        }
        return $modelKey . ' #' . $record->id;
    }

    protected function resolveRecordCode($record, string $modelKey): string
    {
        foreach (['customer_code', 'plan_code', 'code', 'offer_no', 'request_no', 'barcode', 'inventory_no', 'user_code', 'username', 'email'] as $field) {
            if (!empty($record->{$field})) {
                return (string) $record->{$field};
            }
        }
        return '#' . $record->id;
    }
}