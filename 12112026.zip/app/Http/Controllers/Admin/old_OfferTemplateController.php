<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\OfferTemplate;
use App\Models\Offer;
use App\Services\OdtService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Process\Process; // <-- [YENİ] LİBREOFFICE İÇİN EKLENDİ

class OfferTemplateController extends Controller
{
    // Listeleme
    public function index()
    {
        $templates = OfferTemplate::latest()->paginate(10);
        return view('admin.offer_templates.index', compact('templates'));
    }

    // Oluşturma Sayfası
    public function create()
    {
        return view('admin.offer_templates.create');
    }

    // Kaydetme İşlemi
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'odt_file' => 'required|file|mimes:odt', // Sadece ODT
        ]);

        $path = $request->file('odt_file')->store('templates');

        OfferTemplate::create([
            'name' => $request->name,
            'file_path' => $path,
            'type' => 'odt',
        ]);

        return redirect()->route('admin.offer-templates.index')
                         ->with('success', 'Şablon başarıyla yüklendi.');
    }

    // Silme İşlemi
    public function destroy($id)
    {
        $template = OfferTemplate::findOrFail($id);
        
        if(Storage::exists($template->file_path)) {
            Storage::delete($template->file_path);
        }
        
        $template->delete();

        return redirect()->route('admin.offer-templates.index')
                         ->with('success', 'Şablon silindi.');
    }

    /**
     * [YENİ] ORTAK ODT ÜRETME MERKEZİ
     * Hem ODT indirme hem de PDF dönüştürme işlemleri önce bu fonksiyonu kullanır.
     */
    public function generateOdtDocument($offerId, $templateId)
    {
        // 1. Verileri Çek
        $offer = Offer::with(['customer', 'contact', 'creator', 'items.scopeParameter.scopeType'])->findOrFail($offerId);
        $template = OfferTemplate::findOrFail($templateId);

        $odt = new OdtService($template->file_path);

        // Alt Kısım Hesaplamaları
        $belgeIndirimi = $offer->document_discount ?? 0;
        $indirimliToplam = $offer->subtotal - $offer->discount_total - $belgeIndirimi;
        $kdvSizGenelToplam = $offer->grand_total - $offer->tax_total; 

        // Müşteri Adını Garantile
        $musteriAdi = $offer->customer->company_name ?: ($offer->customer->name ?: '-');

        // --- A) TEKİL DEĞİŞKENLER SÖZLÜĞÜ ---
        $data = [
            // Genel Bilgiler
            'teklif_no'         => $offer->offer_no ?? '-',
            'talep_no'          => $offer->request_no ?? '-',
            'teklif_kapsami'    => $offer->scopeType ? $offer->scopeType->name : '-',
            'konu'              => $offer->subject ?? '',
            'aciklama'          => $offer->description ?? '',
            'teklif_tarihi'     => $offer->offer_date ? Carbon::parse($offer->offer_date)->format('d.m.Y') : '-',
            'gecerlilik_tarihi' => $offer->valid_until ? Carbon::parse($offer->valid_until)->format('d.m.Y') : '-',
            'odeme_sekli'       => $offer->payment_method ?? 'Peşin',
            'para_birimi'       => $offer->currency ?? 'TL',

            // Müşteri Bilgileri
            'musteri_adi'           => $musteriAdi,
            'musteri_vergi_no'      => $offer->customer->tax_number ?? '-',
            'musteri_vergi_dairesi' => $offer->customer->tax_office ?? '-',
            'musteri_adres'         => implode(' ', array_filter([$offer->customer->address1 ?? '', $offer->customer->district ?? '', $offer->customer->city ?? ''])) ?: '-',
            'musteri_telefon'       => $offer->customer->mobile ?? $offer->customer->phone1 ?? $offer->contact->phone ?? '-',
            'musteri_tel'           => $offer->customer->mobile ?? $offer->customer->phone1 ?? $offer->contact->phone ?? '-',
            'musteri_mail'          => $offer->customer->email ?? '-', 
            'teslimat_adresi'       => $offer->address ?? '-',
            'teslimat_adresi'       => $offer->address ?? '-', 
            'ilgili_kisi'           => $offer->contact->full_name ?? '-',
            'ilgili_kisi_unvan'     => $offer->contact->title ?? '-',
            'ilgili_kisi_mail'      => $offer->contact->email ?? '-',

            // Personel / Şirket Bilgileri
            'hazirlayan_personel' => $offer->creator ? $offer->creator->name : 'Sistem',
            'hazirlayan_email'    => $offer->creator ? $offer->creator->email : '-',
            'hazirlayan_unvan'    => $offer->creator ? $offer->creator->title : '-',
            'danisman_adi'        => $offer->consultant_name ?? '-',

            // Finansal Toplamlar
            'ara_toplam'           => number_format($offer->subtotal, 2, ',', '.'),
            'toplam_iskonto'       => number_format($offer->discount_total, 2, ',', '.'),
            'indirimli_toplam'     => number_format($indirimliToplam, 2, ',', '.'), 
            'toplam_kdv'           => number_format($offer->tax_total, 2, ',', '.'),
            'kdv_siz_genel_toplam' => number_format($kdvSizGenelToplam, 2, ',', '.'), 
            'genel_toplam'         => number_format($offer->grand_total, 2, ',', '.'),
            'belge_indirimi'       => number_format($belgeIndirimi, 2, ',', '.'), 
            'toplam_tutar_birimli' => number_format($offer->grand_total, 2, ',', '.') . ' ' . ($offer->currency ?? 'TL'),
            'toplam_indirim'       => number_format($offer->discount_total + $belgeIndirimi, 2, ',', '.'),
        ];

        // 1. Standart Değişkenleri Bas
        foreach ($data as $key => $val) {
            $odt->setVar($key, $val !== null ? (string)$val : '');
        }

        // --- 2. İMZA GÖRSELİ İŞLEME ---
        if ($offer->creator && $offer->creator->signature_stamp) {
            $signaturePath = public_path($offer->creator->signature_stamp);
            if (file_exists($signaturePath)) {
                $odt->setImage('personel_imza', $signaturePath);
            } else {
                $odt->setVar('personel_imza', ''); 
            }
        } else {
            $odt->setVar('personel_imza', ''); 
        }

        // --- B) TABLO DÖNGÜLERİ ---
        if ($offer->items && $offer->items->count() > 0) {
            
            // 1. ÜRÜN / HİZMET TABLOSU
            $priceTableData = $offer->items->map(function($item, $index) {
                $urunAdi = $item->scopeParameter ? $item->scopeParameter->name : ($item->name ?? '-');
                $kapsamTipi = ($item->scopeParameter && $item->scopeParameter->scopeType) ? $item->scopeParameter->scopeType->name : '-';
                $miktar = $item->quantity ?? 1;
                $birimFiyat = $item->unit_price ?? 0;
                $iskontoOrani = $item->discount_rate ?? 0;
                $kdvOrani = $item->tax_rate ?? 0;

                $kdvSizSatirToplam = ($miktar * $birimFiyat) * (1 - ($iskontoOrani / 100));
                $kdvliSatirToplam = $kdvSizSatirToplam + ($kdvSizSatirToplam * ($kdvOrani / 100));

                return [
                    'sira_no'               => $index + 1,
                    'kapsam'                => (string)$kapsamTipi,  
                    't_param'               => (string)$urunAdi, 
                    'kaynak_adi'            => $item->source_name ?? '-',
                    'miktar'                => number_format($miktar, 0, ',', '.'),
                    'birim_fiyat'           => number_format($birimFiyat, 2, ',', '.'),
                    'satir_toplami'         => number_format($item->row_total, 2, ',', '.'), 
                    'iskonto_orani'         => '%' . $iskontoOrani,
                    'kdv_orani'             => '%' . $kdvOrani,
                    'kdv_siz_satir_toplami' => number_format($kdvSizSatirToplam, 2, ',', '.'),
                    'kdvli_satir_toplami'   => number_format($kdvliSatirToplam, 2, ',', '.') 
                ];
            })->toArray();

            $priceMapping = [
                '{sira}'           => 'sira_no',
                '{kapsam_tipi}'    => 'kapsam',  
                '{t_parametre}'    => 't_param', 
                '{kaynak_adi}'     => 'kaynak_adi',
                '{miktar}'         => 'miktar',
                '{birim_fiyat}'    => 'birim_fiyat',
                '{toplam}'         => 'satir_toplami',
                '{iskonto}'        => 'iskonto_orani',
                '{kdv}'            => 'kdv_orani',
                '{kdv_siz_toplam}' => 'kdv_siz_satir_toplami',
                '{kdvli_toplam}'   => 'kdvli_satir_toplami',
            ];
            
            $odt->setRows($priceTableData, $priceMapping);

            // 2. METOT VE STANDART TABLOSU
            $methodTableData = $offer->items->map(function($item, $index) {
                $paramName = $item->scopeParameter ? $item->scopeParameter->name : ($item->name ?? '-');
                $metot    = $item->scopeParameter ? $item->scopeParameter->analysis_methods : '';
                $standart = $item->scopeParameter ? $item->scopeParameter->standard_ref : '';
                $fullMetot = ($metot && $standart) ? $metot . ' (' . $standart . ')' : ($metot . $standart);

                return [
                    'm_sira'  => $index + 1,
                    'm_param' => (string)$paramName, 
                    'm_metot' => empty($fullMetot) ? '-' : (string)$fullMetot
                ];
            })->toArray();

            $methodMapping = [
                '{m_sira}'      => 'm_sira',
                '{m_parametre}' => 'm_param',
                '{m_metot}'     => 'm_metot'
            ];

            $odt->setRows($methodTableData, $methodMapping);
        }

        // Dosyayı kaydet ve tam yolu ile offer objesini döndür
        $file = $odt->save();
        return [
            'file_path' => $file,
            'offer' => $offer
        ];
    }

    /**
     * GERÇEK TEKLİF İNDİRME (ODT FORMATINDA)
     */
    /**
     * GERÇEK TEKLİF İNDİRME (ODT FORMATINDA)
     */
    public function downloadProposal($offerId, $templateId)
    {
        try {
            $data = $this->generateOdtDocument($offerId, $templateId);
            $offer = $data['offer'];
            
            // Müşteri unvanını veya adını alıyoruz
            $customerName = $offer->customer->company_name ?: ($offer->customer->name ?: 'Musteri');
            
            // Firma adını Türkçe karakterleri koruyarak "İlk Harfler Büyük" (Title Case) formata çeviriyoruz
            $formattedCustomerName = mb_convert_case(mb_strtolower($customerName, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
            
            // TEHLİKELİ KARAKTERLERİ TEMİZLE (Dosya isminde hata verdiren / ve \ işaretlerini tireye çeviriyoruz)
            $safeCustomerName = str_replace(['/', '\\'], '-', $formattedCustomerName);
            
            // Eğer TK-2026-0005 formatındaki tireleri kaldırıp TK20260005 yapmak isterseniz alt satırı kullanın:
            $cleanOfferNo = str_replace('-', '', $offer->offer_no);
            
            // Çıktı Örn: TK20260005-Akademi Çevre.odt
            $filename = $cleanOfferNo . '-' . $safeCustomerName . '.odt';
            
            return response()->download($data['file_path'], $filename)->deleteFileAfterSend(true);

        } catch (\Exception $e) {
            Log::error('ODT İndirme Hatası: ' . $e->getMessage());
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    /**
     * [YENİ] GERÇEK TEKLİF İNDİRME (PDF FORMATINDA)
     */
    public function exportPdf($offerId, $templateId)
    {
        try {
            // 1. Önce arka planda ODT dosyasını hazırla
            $data = $this->generateOdtDocument($offerId, $templateId);
            $odtFilePath = $data['file_path'];
            $offer = $data['offer'];
            
            // ODT'nin bulunduğu klasörü PDF çıktısı için hedef klasör olarak belirle
            $outputDir = dirname($odtFilePath);

            // 2. LibreOffice Process'ini Başlat
            $process = new Process([
                'libreoffice',
                '--headless',
                '--convert-to', 'pdf',
                $odtFilePath,
                '--outdir', $outputDir
            ]);

            $process->setEnv(['HOME' => '/tmp']);
            $process->setTimeout(60);
            $process->mustRun();

            // 3. Dosya Yollarını ve İsimlerini Ayarla
            $pdfFilePath = str_replace('.odt', '.pdf', $odtFilePath);
            
            // Müşteri unvanını al ve "İlk Harfler Büyük" formata çevir
            $customerName = $offer->customer->company_name ?: ($offer->customer->name ?: 'Musteri');
            $formattedCustomerName = mb_convert_case(mb_strtolower($customerName, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
            
            // TEHLİKELİ KARAKTERLERİ TEMİZLE (Dosya isminde hata verdiren / ve \ işaretlerini tireye çeviriyoruz)
            $safeCustomerName = str_replace(['/', '\\'], '-', $formattedCustomerName);
            
            // Teklif numarasındaki tireleri temizle (TK-2026-0005 -> TK20260005)
            $cleanOfferNo = str_replace('-', '', $offer->offer_no);
            
            // Çıktı Örn: TK20260005-Akademi Çevre.pdf (Temizlenmiş müşteri adı kullanılıyor)
            $pdfFilename = $cleanOfferNo . '-' . $safeCustomerName . '.pdf';

            // Temizlik: İşimiz biten orijinal ODT'yi sunucudan siliyoruz
            if (file_exists($odtFilePath)) {
                @unlink($odtFilePath);
            }

            // PDF başarıyla oluştuysa kullanıcıya indir ve sunucudan sil
            if (file_exists($pdfFilePath)) {
                return response()->download($pdfFilePath, $pdfFilename)->deleteFileAfterSend(true);
            }

            throw new \Exception("PDF dosyası oluşturulamadı.");

        } catch (\Exception $e) {
            Log::error('PDF Çevirme Hatası: ' . $e->getMessage());
            return back()->with('error', 'PDF Dönüştürme Hatası: ' . $e->getMessage());
        }
    }

    public function downloadExample($id)
    {
        $latestOffer = Offer::latest()->first();
        if (!$latestOffer) {
            return back()->with('error', 'Sistemde henüz hiç teklif kaydı bulunmuyor.');
        }
        return $this->downloadProposal($latestOffer->id, $id);
    }

    public function downloadRaw($id)
    {
        $template = OfferTemplate::findOrFail($id);
        $path = storage_path('app/' . $template->file_path);

        if (!file_exists($path)) {
            return back()->with('error', 'Orijinal şablon dosyası bulunamadı.');
        }

        // basename() fonksiyonu "revisions/teklif.pdf" içinden sadece "teklif.pdf" kısmını alır.
       return response()->download($path, basename($template->file_path));
    }
}