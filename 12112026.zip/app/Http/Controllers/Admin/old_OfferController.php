<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Contact;
use App\Models\ScopeType;
use App\Models\ScopeTable;
use App\Models\ScopeParameter;
use App\Models\Offer;
use App\Models\OfferItem;
use App\Models\OfferTemplate; 
use App\Models\CustomerRequest; // Talep entegrasyonu için
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

class OfferController extends Controller 
{
    /**
     * Teklif Listesi ve Şablon Seçimi
     */
    public function index() 
    {
        $offers = Offer::with(['customer', 'contact', 'creator'])
            ->where('status', '!=', 'Silindi') 
            ->latest()
            ->get();
        
        $templates = OfferTemplate::all(); 

        return view('admin.offers.index', compact('offers', 'templates'));
    }

    /**
     * Yeni Teklif Formu
     */
    public function create() 
    {
        $customers = Customer::where('is_active', 1)->orderBy('name')->get();
        $scopeTypes = ScopeType::orderBy('name')->get();
        
        $year = date('Y');

// O yıla ait, silinmişler dahil sisteme kayıtlı en son teklifi buluyoruz
$lastOffer = \App\Models\Offer::withTrashed()
    ->where('offer_no', 'like', "TK-{$year}-%")
    ->orderBy('id', 'desc')
    ->first();

$nextNumber = 1;
if ($lastOffer) {
    // Örn: 'TK-2026-0005-R1' verisini tirelerden parçalıyoruz
    $parts = explode('-', $lastOffer->offer_no); 
    
    // 3. parça (index 2) her zaman bizim ana sıra numaramızdır ('0005' gibi)
    if (isset($parts[2])) {
        $nextNumber = (int)$parts[2] + 1;
    }
}

$offerNo = "TK-{$year}-" . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        // Onaylanmış ama teklifi yapılmamış talepleri getir
        $pendingRequests = CustomerRequest::where('request_status', 'Onaylandı')
            ->whereNull('converted_offer_id')
            ->with(['customer', 'contact'])
            ->orderBy('created_at', 'desc')
            ->get();

        return view('admin.offers.create', compact('customers', 'scopeTypes', 'offerNo', 'pendingRequests'));
    }

    /**
     * Yeni Teklif Kaydetme (Store)
     */
    public function store(Request $request)
    {
        $request->validate([
            'offer_no'    => 'required|unique:offers,offer_no',
            'customer_id' => 'required|exists:customers,id',
            'offer_date'  => 'required|date',
            'request_no'  => 'nullable|string',
        ]);

        try {
            DB::beginTransaction();

            // 1. Ana Teklif Verisi
            $offer = Offer::create([
                'offer_no'          => $request->offer_no,
                'request_no'        => $request->request_no,
                
                'customer_id'       => $request->customer_id,
                'contact_id'        => $request->contact_id,
                'created_by'        => Auth::id(),
                
                'subject'           => $request->subject,
                'offer_date'        => $request->offer_date,
                'valid_until'       => $request->valid_until,
                'reminder_date'     => $request->reminder_date,
                'payment_method'    => $request->payment_method,
                'status'            => 'Açık',
                'address'           => $request->address,
                'address_type'      => $request->address_type,
                'description'       => $request->description,
                'probability'       => $request->probability ?? 50,
                'probability_date'  => $request->probability_date,
                'consultant_name'     => $request->consultant_name,
                'consultant_1_contact'=> $request->consultant_1_contact,
                'consultant_2'        => $request->consultant_2,
                'consultant_2_contact'=> $request->consultant_2_contact,
                'consultant_notes'    => $request->consultant_notes,
                'scope_type_id'       => $request->scope_type_id,
                'currency'            => $request->currency ?? 'TL',
                
                // FİNANSAL ALANLAR (Belge İndirimi Eklendi)
                'subtotal'          => $this->normalizePrice($request->subtotal),
                'discount_total'    => $this->normalizePrice($request->discount_total),
                'document_discount' => $this->normalizePrice($request->document_discount), // <--- YENİ EKLENEN
                'tax_total'         => $this->normalizePrice($request->tax_total),
                'grand_total'       => $this->normalizePrice($request->grand_total),
            ]);

            // 2. Teklif Kalemleri
            if ($request->has('items') && is_array($request->items)) {
                foreach ($request->items as $index => $item) {
                    OfferItem::create([
                        'offer_id'           => $offer->id,
                        'scope_parameter_id' => $item['scope_parameter_id'],
                        'row_order'          => $index + 1,
                        'source_name'        => $item['source_name'] ?? null,
                        'quantity'           => $item['quantity'] ?? 1,
                        'unit_price'         => $this->normalizePrice($item['unit_price']),
                        'discount_rate'      => $item['discount_rate'] ?? 0,
                        'tax_rate'           => $item['tax_rate'] ?? 20,
                        'row_total'          => $this->normalizePrice($item['row_total'] ?? 0),
                    ]);
                }
            }

            // 3. Bağlı Talep Varsa Güncelle
            if ($request->request_no) {
                $linkedRequest = CustomerRequest::where('request_no', $request->request_no)->first();
                if ($linkedRequest) {
                    $linkedRequest->converted_offer_id = $offer->id;
                    $linkedRequest->save();
                }
            }

            DB::commit();
            
            if($request->ajax()){
                return response()->json(['success' => true, 'message' => 'Teklif başarıyla oluşturuldu!', 'redirect' => route('admin.offers.index')]);
            }

            return redirect()->route('admin.offers.index')->with('success', 'Teklif başarıyla oluşturuldu.');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Teklif Oluşturma Hatası: ' . $e->getMessage());
            
            if($request->ajax()){
                return response()->json(['success' => false, 'message' => 'Hata: ' . $e->getMessage()], 500);
            }
            return back()->withInput()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    /**
     * Teklif Detayı
     */
   public function show(Offer $offer)
{
    $offer->load(['customer', 'contact', 'items.parameter', 'scopeType', 'creator', 'revisions.user']);
    return view('admin.offers.show', compact('offer'));
}

    /**
     * Teklif Düzenleme Formu
     */
    public function edit(Offer $offer)
    {
        $customers = Customer::where('is_active', 1)->orderBy('name')->get();
        $scopeTypes = ScopeType::orderBy('name')->get();
        
        $offer->load('items.parameter');

        return view('admin.offers.edit', compact('offer', 'customers', 'scopeTypes'));
    }

    /**
     * Teklif Güncelleme
     */
    public function update(Request $request, Offer $offer)
    {
        $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'offer_date'  => 'required|date',
        ]);

        try {
            DB::beginTransaction();

            // 1. Varsayılan olarak mevcut teklif numarası ve revizyon sayısını koruyoruz
            $newOfferNo = $offer->offer_no;
            $newRevisionNumber = $offer->revision_number;
            $hasRevision = false;
            
            // YENİ: Eski PDF'in yolunu tutacak değişkeni başlangıçta null olarak tanımlıyoruz
            $archivedPdfPath = null; 

            // 2. ŞARTIMIZ: Eğer 'revision_note' alanı doldurulmuşsa revizyon mantığı devreye girsin
            if ($request->filled('revision_note')) {
                // Eski numaradan (varsa) -R kısmını temizle (Örn: TK-2026-0001-R1 -> TK-2026-0001)
                $baseOfferNo = preg_replace('/-R\d+$/', '', $offer->offer_no);
                
                // Revizyon sayısını 1 artır ve yeni numarayı üret
                $newRevisionNumber = $offer->revision_number + 1;
                $newOfferNo = $baseOfferNo . '-R' . $newRevisionNumber;
                $hasRevision = true;

                // ----- EKLENEN KISIM: ESKİ TEKLİFİN GERÇEK PDF'İNİ OLUŞTUR VE YOLUNU AL -----
                try {
                    // Sistemdeki ilk aktif ODT şablonunu buluyoruz
                    $defaultTemplate = \App\Models\OfferTemplate::where('type', 'odt')->first();

                    if ($defaultTemplate) {
                        // ODT Üretme fonksiyonunu çağır (Teklif henüz DB'de güncellenmediği için ESKİ haliyle üretilir)
                        $templateCtrl = app(\App\Http\Controllers\Admin\OfferTemplateController::class);
                        $odtData = $templateCtrl->generateOdtDocument($offer->id, $defaultTemplate->id);
                        $odtFilePath = $odtData['file_path'];

                        // Arşiv klasörünün yolunu belirle ve yoksa oluştur
                        $revisionsDir = storage_path('app/public/revisions');
                        if (!file_exists($revisionsDir)) {
                            mkdir($revisionsDir, 0755, true);
                        }

                        // LibreOffice ile ODT'yi PDF'e çevir
                        $process = new \Symfony\Component\Process\Process([
                            'libreoffice',
                            '--headless',
                            '--convert-to', 'pdf',
                            $odtFilePath,
                            '--outdir', $revisionsDir
                        ]);
                        $process->setEnv(['HOME' => '/tmp']);
                        $process->setTimeout(60);
                        $process->mustRun();

                        // LibreOffice'in ürettiği PDF'i bul
                        $baseFileName = pathinfo($odtFilePath, PATHINFO_FILENAME);
                        $generatedPdfPath = $revisionsDir . '/' . $baseFileName . '.pdf';

                        // PDF ismini düzenle (Örn: TK-2026-0077-R2_eski_surum_1718462000.pdf)
                        $finalPdfName = $offer->offer_no . '_eski_surum_' . time() . '.pdf';
                        $finalPdfPath = $revisionsDir . '/' . $finalPdfName;

                        // Dosyayı yeniden adlandır ve veritabanı yolunu değişkene ata
                        if (file_exists($generatedPdfPath)) {
                            rename($generatedPdfPath, $finalPdfPath);
                            $archivedPdfPath = 'revisions/' . $finalPdfName; 
                        }

                        // Sunucuyu yormamak için geçici ODT dosyasını sil
                        if (file_exists($odtFilePath)) {
                            @unlink($odtFilePath);
                        }
                    } else {
                        Log::warning("Revizyon arşivlemesi için sistemde kayıtlı bir ODT şablonu bulunamadı.");
                    }
                } catch (\Exception $e) {
                    Log::error("Revizyon öncesi PDF arşivlenemedi: " . $e->getMessage());
                }
                // -----------------------------------------------------------------------------

                // Log kaydı oluştur (ISO 17025 için sistem kanıtı)
                Log::info("Teklif Revize Edildi | Eski No: {$offer->offer_no} | Yeni No: {$newOfferNo} | Revizyon Nedeni: {$request->revision_note} | Yapan Kullanıcı ID: " . Auth::id());
            }

            // 3. Teklif Güncelleme
            $offer->update([
                'offer_no'            => $newOfferNo,
                'revision_number'     => $newRevisionNumber,
                // Revizyon varsa yeni notu yaz, yoksa veritabanındaki eski notu koru
                'revision_note'       => $hasRevision ? $request->revision_note : $offer->revision_note, 
                'customer_id'         => $request->customer_id,
                'contact_id'          => $request->contact_id,
                'subject'             => $request->subject,
                'offer_date'          => $request->offer_date,
                'valid_until'         => $request->valid_until,
                'reminder_date'       => $request->reminder_date,
                'payment_method'      => $request->payment_method,
                'status'              => $request->status,
                'address'             => $request->address,
                'address_type'        => $request->address_type,
                'description'         => $request->description,
                'probability'         => $request->probability ?? 50,
                'probability_date'    => $request->probability_date,
                'consultant_name'     => $request->consultant_name,
                'consultant_1_contact'=> $request->consultant_1_contact,
                'consultant_2'        => $request->consultant_2,
                'consultant_2_contact'=> $request->consultant_2_contact,
                'consultant_notes'    => $request->consultant_notes,
                'scope_type_id'       => $request->scope_type_id,
                'loss_reason'         => $request->loss_reason,
                'currency'            => $request->currency ?? 'TL',
                
                'subtotal'          => $this->normalizePrice($request->subtotal),
                'discount_total'    => $this->normalizePrice($request->discount_total),
                'document_discount' => $this->normalizePrice($request->document_discount),
                'tax_total'         => $this->normalizePrice($request->tax_total),
                'grand_total'       => $this->normalizePrice($request->grand_total),
            ]);

            // Kalemleri Yenile
            $offer->items()->delete();

            if ($request->has('items') && is_array($request->items)) {
                foreach ($request->items as $index => $item) {
                    OfferItem::create([
                        'offer_id'           => $offer->id,
                        'scope_parameter_id' => $item['scope_parameter_id'],
                        'row_order'          => $index + 1,
                        'source_name'        => $item['source_name'] ?? null,  
                        'quantity'           => $item['quantity'] ?? 1,
                        'unit_price'         => $this->normalizePrice($item['unit_price']),
                        'discount_rate'      => $item['discount_rate'] ?? 0,
                        'tax_rate'           => $item['tax_rate'] ?? 20,
                        'row_total'          => $this->normalizePrice($item['row_total'] ?? 0),
                    ]);
                }
            }

            // 4. ŞARTIMIZ: Sadece revizyon gerekçesi girilmişse tarihçe tablosuna satır ekle
            if ($hasRevision) {
                $offer->revisions()->create([
                    'revision_number' => $newRevisionNumber,
                    'revision_note'   => $request->revision_note,
                    'user_id'         => Auth::id(),
                    'pdf_path'        => $archivedPdfPath // YENİ: Üretilen gerçek arşiv PDF yolunu veritabanına ekliyoruz
                ]);
            }

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Teklif başarıyla güncellendi!']);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Teklif Güncelleme Hatası: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Hata: ' . $e->getMessage()], 500);
        }
    }

  /**
     * Teklif Silme (ID üzerinden talebi bulur ve %100 boşa çıkarır)
     */
    public function destroy(Offer $offer)
    {
        try {
            DB::beginTransaction();

            // 1. Teklifin durumunu 'Silindi' yap
            $offer->update(['status' => 'Silindi']);

            // 2. BU TEKLİFİN BAĞLI OLDUĞU TALEBİ BUL (ID ile kesin eşleşme)
            $linkedRequest = CustomerRequest::where('converted_offer_id', $offer->id)->first();
            
            if ($linkedRequest) {
                // Talebi boşa çıkar (NULL yap)
                $linkedRequest->update(['converted_offer_id' => null]);
            }

            DB::commit();

            if (request()->ajax()) {
                return response()->json(['success' => true, 'message' => 'Teklif silindi ve bağlı talep tekrar boşa çıkarıldı.']);
            }

            return redirect()->route('admin.offers.index')->with('success', 'Teklif çöp kutusuna taşındı (Durum: Silindi).');

        } catch (\Exception $e) {
            DB::rollBack();
            if (request()->ajax()) {
                return response()->json(['success' => false, 'message' => 'Hata: ' . $e->getMessage()], 500);
            }
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    /**
     * EXCEL İNDİRME
     */
    public function exportExcel(Offer $offer)
    {
        return back()->with('info', 'Excel indirme modülü hazırlanıyor. Yakında aktif olacak.');
    }

    /**
     * AJAX: Müşteri Kontaklarını Getir
     */
    public function getContacts($customerId) 
    {
        // 1. Önce müşterinin detaylarını buluyoruz (Adres, vergi dairesi vb. için)
        $customer = \App\Models\Customer::find($customerId);

        // 2. Sonra sadece aktif kontaklarını getiriyoruz
        $contacts = \App\Models\Contact::where('customer_id', $customerId)
            ->where('is_active', true)
            ->orderBy('full_name')
            ->get(['id', 'full_name']); // İhtiyaç varsa buraya 'email', 'title' vb. eklenebilir

        // 3. İkisini tek bir paket yapıp ön yüze (JS'e) gönderiyoruz
        return response()->json([
    'contacts' => $contacts,
    'customer' => $customer
]);
    }

    /**
     * AJAX: Teklif için Analiz Parametrelerini Getir
     */
    public function getParamsForOffer(Request $request)
    {
        $scopeTypeId = $request->scope_type_id;
        $scopeTableId = $request->scope_table_id;

        $tables = ScopeTable::where('scope_type_id', $scopeTypeId)->where('is_active', true)->get(['id', 'name']);
        $query = ScopeParameter::where('scope_type_id', $scopeTypeId);

        if ($scopeTableId) {
            $query->whereHas('tables', function($q) use ($scopeTableId) {
                $q->where('scope_tables.id', $scopeTableId);
            });
        }

        return response()->json([
            'params' => $query->orderBy('name')->get(),
            'tables' => $tables
        ]);
    }

    private function normalizePrice($price) {
        if (!$price) return 0;
        if (is_numeric($price)) return $price;
        $clean = str_replace('.', '', $price); 
        return str_replace(',', '.', $clean); 
    }
}