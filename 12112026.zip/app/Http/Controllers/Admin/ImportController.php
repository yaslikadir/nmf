<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Imports\CustomerImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ChemicalImport;

class ImportController extends Controller
{
    /**
     * Import sayfasını gösterir.
     */
    public function index()
    {
        return view('admin.settings.import');
    }

    /**
     * Müşteri Excel dosyasını içe aktarır.
     */
    public function importCustomers(Request $request)
    {
        // Dosyanın yüklenip yüklenmediğini ve formatını kontrol edelim
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv|max:10240', // Maksimum 10MB
        ]);

        try {
            // Excel dosyasını az önce yazdığımız sınıfa gönderiyoruz
            Excel::import(new CustomerImport, $request->file('file'));
            
            return redirect()->back()
                ->with('success', 'Müşteriler başarıyla sisteme aktarıldı ve kodları otomatik oluşturuldu.');

        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            // Excel içindeki veri hatalarını yakalamak için
            $failures = $e->failures();
            return redirect()->back()->with('error', 'Excel dosyasında veri hataları mevcut.');
        } catch (\Exception $e) {
            // Diğer sistemsel hataları yakalamak için
            return redirect()->back()->with('error', 'İçe aktarma sırasında bir hata oluştu: ' . $e->getMessage());
        }
    }

    /**
     * Kimyasal Excel dosyasını içe aktarır.
     */
    public function importChemicals(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv|max:10240',
        ]);

        try {
            Excel::import(new ChemicalImport, $request->file('file'));
            
            return redirect()->back()
                ->with('success', 'Kimyasal listesi başarıyla sisteme aktarıldı ve stok kodları otomatik oluşturuldu.');

        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            return redirect()->back()->with('error', 'Excel dosyasında veri hataları mevcut.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'İçe aktarma sırasında bir hata oluştu: ' . $e->getMessage());
        }
    }
}