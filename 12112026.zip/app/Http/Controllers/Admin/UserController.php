<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserLog;
use App\Models\Definition;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\File;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    /**
     * Kullanıcı Listesi
     */
    public function index()
    {
        $users = User::with(['roles', 'department' => function($query) {
            $query->withTrashed();
        }])
        ->orderBy('name', 'asc')
        ->get();

        return view('admin.users.index', compact('users'));
    }

    /**
     * AJAX: Personel Hızlı Bakış
     */
    public function quickView(User $user)
    {
        $user->load(['department' => function($query) {
            $query->withTrashed();
        }, 'roles']);

        return view('admin.users.partials.quick_view', compact('user'))->render();
    }

    /**
     * Yeni Kullanıcı Formu
     */
    public function create()
    {
        // Rolleri isme göre sıralı getiriyoruz
        $roles = Role::orderBy('name')->get();
        $departments = Department::active()->orderBy('name')->get();
        $branches = \Modules\Branches\Models\Branch::where('is_active', true)->orderBy('name')->get();
        
        $genders = Definition::byGroup('gender')->get();
        $bloodGroups = Definition::byGroup('blood_group')->get();
        $educationList = Definition::byGroup('education_status')->get();
        $maritalStatusList = Definition::byGroup('marital_status')->get();

        return view('admin.users.create', compact(
            'roles', 'departments', 'branches', 'genders', 'bloodGroups', 'educationList', 'maritalStatusList'
        ));
    }

    /**
     * Yeni Kullanıcı Kaydı
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'            => 'required|string|max:255',
            'username'        => 'required|string|unique:users,username',
            'email'           => 'required|email|unique:users,email',
            'password'        => 'required|confirmed|min:6',
            'role'            => 'required|exists:roles,name', // GÜVENLİK: Sadece tanımlı roller seçilebilir
            'department_id'   => 'required|exists:departments,id',
            'profile_photo'   => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'signature_stamp' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $data = $request->all();
        $data['password'] = Hash::make($request->password);
        $data['is_active'] = $request->has('is_active') ? $request->is_active : true;

        // Dosya Yolu Hazırlığı
        $path = public_path('user_image');
        if (!File::isDirectory($path)) {
            File::makeDirectory($path, 0777, true, true);
        }

        // Profil Fotoğrafı
        if ($request->hasFile('profile_photo')) {
            $photoName = 'profile_' . time() . '_' . uniqid() . '.' . $request->profile_photo->extension();
            $request->profile_photo->move($path, $photoName);
            $data['profile_photo'] = 'user_image/' . $photoName;
        }

        // İmza/Kaşe (Metot Onayları İçin Kritik)
        if ($request->hasFile('signature_stamp')) {
            $sigName = 'sig_' . time() . '_' . uniqid() . '.' . $request->signature_stamp->extension();
            $request->signature_stamp->move($path, $sigName);
            $data['signature_stamp'] = 'user_image/' . $sigName;
        }

        $user = User::create($data);

        // --- YENİ EKLENEN: ŞUBE EŞLEŞTİRMELERİNİ KAYDET ---
        if ($request->has('branches')) {
            $user->branches()->sync($request->branches);
        }
        
        // Spatie Role Ataması
        $user->assignRole($request->role);

        // Loglama
        UserLog::create([
            'user_id'     => Auth::id(),
            'action'      => 'Kullanıcı Oluşturma',
            'description' => "{$user->name} personeli, {$request->role} yetkisiyle eklendi.",
            'ip_address'  => $request->ip(),
            'user_agent'  => $request->userAgent(),
        ]);

        return redirect()->route('admin.users.index')->with('success', 'Kullanıcı başarıyla oluşturuldu.');
    }

    /**
     * Kullanıcı Düzenleme
     */
    public function edit(User $user)
    {
        $roles = Role::orderBy('name')->get();
        $departments = Department::withTrashed()->orderBy('name')->get();
        $branches = \Modules\Branches\Models\Branch::where('is_active', true)->orderBy('name')->get();
        
        $genders = Definition::byGroup('gender')->get();
        $bloodGroups = Definition::byGroup('blood_group')->get();
        $educationList = Definition::byGroup('education_status')->get();
        $maritalStatusList = Definition::byGroup('marital_status')->get();

        return view('admin.users.edit', compact(
            'user', 'roles', 'departments', 'branches', 'genders', 'bloodGroups', 'educationList', 'maritalStatusList'
        ));
    }

    /**
     * Kullanıcı Güncelleme
     */
    public function update(Request $request, User $user)
    {
        $request->validate([
            'name'          => 'required|string|max:255',
            'username'      => 'required|string|unique:users,username,' . $user->id,
            'email'         => 'required|email|unique:users,email,' . $user->id,
            'role'          => 'required|exists:roles,name', // GÜVENLİK
            'department_id' => 'required|exists:departments,id',
        ]);

        $data = $request->all();

        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->password);
        } else {
            unset($data['password']);
        }

        $path = public_path('user_image');

        // Profil Fotoğrafı
        if ($request->hasFile('profile_photo')) {
            if ($user->profile_photo && File::exists(public_path($user->profile_photo))) {
                File::delete(public_path($user->profile_photo));
            }
            $photoName = 'profile_' . time() . '.' . $request->profile_photo->extension();
            $request->profile_photo->move($path, $photoName);
            $data['profile_photo'] = 'user_image/' . $photoName;
        }

        // İmza/Kaşe
        if ($request->hasFile('signature_stamp')) {
            if ($user->signature_stamp && File::exists(public_path($user->signature_stamp))) {
                File::delete(public_path($user->signature_stamp));
            }
            $sigName = 'sig_' . time() . '.' . $request->signature_stamp->extension();
            $request->signature_stamp->move($path, $sigName);
            $data['signature_stamp'] = 'user_image/' . $sigName;
        }

        $user->update($data);

        // --- YENİ EKLENEN: ŞUBE EŞLEŞTİRMELERİNİ GÜNCELLE ---
        if ($request->has('branches')) {
            $user->branches()->sync($request->branches);
        } else {
            // Eğer formda hiçbir şube seçilmemişse hepsini temizle
            $user->branches()->detach(); 
        }
        
        // Rol Senkronizasyonu (Eski rolü siler, yenisini ekler)
        $user->syncRoles($request->role);

        UserLog::create([
            'user_id'     => Auth::id(),
            'action'      => 'Kullanıcı Güncelleme',
            'description' => "{$user->name} personelinin bilgileri güncellendi. Yeni Rol: {$request->role}",
            'ip_address'  => $request->ip(),
            'user_agent'  => $request->userAgent(),
        ]);

        return redirect()->route('admin.users.index')->with('success', 'Kullanıcı bilgileri güncellendi.');
    }

    /**
     * Kullanıcı Durumunu Değiştir
     */
    public function toggleStatus(User $user)
    {
        $user->is_active = !$user->is_active;
        $user->save();

        $status = $user->is_active ? 'Aktif' : 'Pasif';

        UserLog::create([
            'user_id'     => Auth::id(),
            'action'      => 'Durum Değişikliği',
            'description' => "{$user->name} kullanıcısı {$status} durumuna getirildi.",
            'ip_address'  => request()->ip(),
            'user_agent'  => request()->userAgent(),
        ]);

        return redirect()->back()->with('success', "Kullanıcı durumu {$status} yapıldı.");
    }

    /**
     * Kullanıcı Silme
     */
    public function destroy(User $user)
    {
        if ($user->profile_photo && File::exists(public_path($user->profile_photo))) {
            File::delete(public_path($user->profile_photo));
        }

        if ($user->signature_stamp && File::exists(public_path($user->signature_stamp))) {
            File::delete(public_path($user->signature_stamp));
        }
        
        $userName = $user->name;
        $user->delete();

        UserLog::create([
            'user_id'     => Auth::id(),
            'action'      => 'Kullanıcı Silme',
            'description' => "{$userName} isimli personel silindi.",
            'ip_address'  => request()->ip(),
            'user_agent'  => request()->userAgent(),
        ]);

        return redirect()->route('admin.users.index')->with('success', 'Kullanıcı başarıyla silindi.');
    }

    public function updateSettings(Request $request)
    {
        $user = auth()->user();
        
        // Mevcut ayarları al, yoksa boş dizi oluştur
        $currentSettings = $user->settings ?? [];

        // Gelen QR ayarlarını 'qr_defaults' anahtarı altına koy
        $currentSettings['qr_defaults'] = [
            'page' => $request->input('page'),
            'x'    => $request->input('x'),
            'y'    => $request->input('y'),
        ];

        // Güncelle ve kaydet
        $user->settings = $currentSettings;
        $user->save();

        return response()->json(['status' => 'success']);
    }

    public function updateRoles(Request $request, $userId)
    {
        $user = \App\Models\User::findOrFail($userId);
        
        // Gelen rollerin array olduğundan emin ol
        $roles = $request->input('roles', []); 
        
        // Spatie'nin syncRoles metodu çoklu rolü otomatik yönetir
        $user->syncRoles($roles); 

        return response()->json(['success' => 'Kullanıcı rolleri başarıyla güncellendi.']);
    }

    public function getUserRoles($userId) {
        return \App\Models\User::findOrFail($userId)->getRoleNames();
    }
}