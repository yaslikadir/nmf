<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sample;
use App\Models\Offer;
use App\Models\MeasurementPlan;
use App\Models\StorageLocation;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

// QR Kod Kütüphanesi (SVG formatı için)
use SimpleSoftwareIO\QrCode\Facades\QrCode;

// FPDI ve TCPDF (PDF Birleştirme ve Manipülasyon)
use setasign\Fpdi\Tcpdf\Fpdi;

class SampleManagementController extends Controller
{
    /**
     * Ana Sayfa - Numune Kabul Ekranı
     * Sadece ölçüm planı "Tamamlandı" olan teklifleri listeler
     */
    /**
     * Ana Sayfa - Numune Kabul Ekranı
     * Sadece ölçüm planı "Tamamlandı" olan teklifleri listeler
     */
    public function index()
    {
        $samples = Sample::orderBy('created_at', 'desc')->paginate(10);
        
        // Son 3 ayda kabul edilen numuneler (Geçmiş Kabuller sekmesi için varsayılan liste)
$recentSamples = Sample::with(['offer.customer', 'storageLocation'])
            ->whereNotNull('accepted_at')
           // ->where('accepted_at', '>=', now()->subMonths(3)) // <--- 3 AYLIK ZAMAN FİLTRESİ
            ->orderBy('accepted_at', 'desc')
            ->get();
        
        // Aktif depo lokasyonları
        $locations = StorageLocation::where('is_active', 1)->get();

        // --- ZIRHLI FİLTRE ---
        // 1. ADIM: Ölçüm Planı "Tamamlandı" olan tekliflerin ID'lerini çek
        $completedPlanOfferIds = DB::table('measurement_plans')
                                    ->where('status', 'LIKE', '%Tamamlandı%')
                                    ->pluck('offer_id');

        // YENİ ADIM: Ölçüm Planı "Planlandı" VEYA "Tamamlandı" olan tekliflerin ID'lerini çek
        $allPlannedOfferIds = DB::table('measurement_plans')
                                    ->whereIn('status', ['Planlandı', 'Tamamlandı'])
                                    ->pluck('offer_id');

        // 2. ADIM (VARSAYILAN): Sadece planı "Tamamlandı" olanları getir
        $activeOffers = Offer::with('customer')
            ->whereIn('id', $completedPlanOfferIds)
            ->whereHas('samples', function($query) {
                $query->where('status', '!=', 'Kabul Edildi')
                      ->orWhereNull('status');
            })
            ->orderBy('offer_no', 'desc')
            ->get();

        // 3. ADIM (DÜZELTİLEN MANTIK): Planı yapılmış ama "Planlandı" statüsünde bekleyenleri de kapsayan TÜM teklifler
        $allPendingOffers = Offer::with('customer')
            ->whereIn('id', $allPlannedOfferIds) // SADECE PLANI OLANLAR GELECEK
            ->whereHas('samples', function($query) {
                $query->where('status', '!=', 'Kabul Edildi')
                      ->orWhereNull('status');
            })
            ->orderBy('offer_no', 'desc')
            ->get();

        // Personel listesi
        $personnels = User::all(); 

        // YENİ EKLENEN: Alt Parametre Modalı için tüm Ana Parametreleri (ScopeParameters) gönderiyoruz
        $allScopeParameters = \App\Models\ScopeParameter::orderBy('name', 'asc')->get();

        // allScopeParameters'i compact içine ekledik
        return view('admin.sample_management.index', compact('samples', 'recentSamples', 'locations', 'activeOffers', 'allPendingOffers', 'personnels', 'allScopeParameters'));
    }

    /**
     * Rapor Oluşturma/Birleştirme Ekranını Gösterir
     * @param int $id Numune ID
     */
    public function create($id)
    {
        // Numune verisini ilişkili tablolarla (müşteri, analiz sonuçları vb.) çekiyoruz
        $sample = Sample::with([
            'offer.customer', 
            'workOrders.result', 
            'workOrders.parameter', 
            'workOrders.method'
        ])->findOrFail($id);

        return view('admin.reporting.generate', compact('sample'));
    }

    /**
     * Dosyaları Birleştirir, QR Kod Basar ve Raporu Kaydeder
     * @param Request $request
     * @param int $id Numune ID
     */
    public function store(Request $request, $id)
    {
        // PDF işlemleri uzun sürebilir, zaman aşımını uzatıyoruz (5 dakika)
        set_time_limit(300); 
        
        $sample = Sample::findOrFail($id);

        // --- 1. VALIDASYON ---
        $request->validate([
            'attachments'   => 'required|array',
            'attachments.*' => 'mimes:pdf,jpg,jpeg,png|max:10240', // Max 10MB dosya
            'qr_page'       => 'nullable|integer|min:1',
            'qr_x'          => 'nullable|numeric',
            'qr_y'          => 'nullable|numeric',
        ]);

        // --- 2. KLASÖR TANIMLARI ---
        // Geçici dosyalar için (işlem bitince silinecek)
        $tempDir = storage_path('app/temp_processing');
        // Raporların saklanacağı kalıcı klasör
        $reportsDir = storage_path('app/public/reports');
        
        // Klasörler yoksa oluştur (0755 izinleriyle)
        if (!File::exists($tempDir)) File::makeDirectory($tempDir, 0755, true);
        if (!File::exists($reportsDir)) File::makeDirectory($reportsDir, 0755, true);

        try {
            // --- 3. KULLANICI AYARLARINI AL ---
            // Formdan gelen QR kod konumu ve sayfa numarası (Varsayılan: Sayfa 1, Sol Alt Köşe)
            $targetPage = (int) $request->input('qr_page', 1);
            $qrX = (float) $request->input('qr_x', 10);  // X ekseni (mm)
            $qrY = (float) $request->input('qr_y', 260); // Y ekseni (mm)

            // --- 4. QR KODU HAZIRLA (SVG) ---
            // Public doğrulama URL'si oluştur
            $qrUrl = route('public.report.show', $sample->barcode);
            $qrFilename = 'qr_' . uniqid() . '.svg';
            $qrPath = $tempDir . '/' . $qrFilename;
            
            // SVG formatında oluştur (Imagick gerekmez, hafiftir ve kalitelidir)
            QrCode::format('svg')
                    ->size(300)     // Piksel boyutu (SVG olduğu için ölçeklenebilir)
                    ->margin(1)     // Kenar boşluğu
                    ->generate($qrUrl, $qrPath);

            // --- 5. YÜKLENEN DOSYALARI GEÇİCİ KLASÖRE TAŞI ---
            $filesToMerge = [];

            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $file) {
                    // Benzersiz bir isimle taşı
                    $name = uniqid() . '_' . $file->getClientOriginalName();
                    $file->move($tempDir, $name);
                    $filesToMerge[] = $tempDir . '/' . $name;
                }
            }

            // --- 6. PDF BİRLEŞTİRME VE QR BASMA (FPDI/TCPDF) ---
            $pdf = new Fpdi();
            
            // TCPDF ayarları: Header ve Footer çizgilerini kapat
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);

            $globalPageCounter = 0; // Toplam sayfa sayacı

            foreach ($filesToMerge as $filePath) {
                $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

                // --- A) PDF DOSYASI İŞLEME ---
                if ($extension === 'pdf') {
                    try {
                        // PDF sayfa sayısını al
                        $pageCount = $pdf->setSourceFile($filePath);
                        
                        for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
                            $globalPageCounter++;

                            // Sayfayı şablon olarak içe aktar
                            $templateId = $pdf->importPage($pageNo);
                            
                            // Mevcut sayfanın boyutunu ve yönünü al (A4, A3, Yatay, Dikey vb.)
                            $size = $pdf->getTemplateSize($templateId);
                            
                            // Orijinal boyutta yeni sayfa ekle
                            $pdf->AddPage($size['orientation'], [$size['width'], $size['height']]);
                            $pdf->useTemplate($templateId);

                            // QR Kod Basma Kontrolü
                            $this->addQrToPage($pdf, $globalPageCounter, $targetPage, $qrPath, $qrX, $qrY);
                        }
                    } catch (\Exception $e) {
                        // Bozuk PDF gelirse işlemi durdurma, logla ve devam et
                        Log::error("PDF Merge Hatası (Dosya: $filePath): " . $e->getMessage());
                        continue; 
                    }
                } 
                // --- B) RESİM DOSYASI İŞLEME (JPG, PNG) ---
                elseif (in_array($extension, ['jpg', 'jpeg', 'png'])) {
                    $globalPageCounter++;

                    // Standart A4 Dikey sayfa ekle
                    $pdf->AddPage('P', 'A4');
                    
                    // Resmi sayfaya yerleştir (X:10, Y:10, Genişlik:190mm)
                    $pdf->Image($filePath, 10, 10, 190, 0, '', '', 'T', false, 300, 'C');

                    // QR Kod Basma Kontrolü
                    $this->addQrToPage($pdf, $globalPageCounter, $targetPage, $qrPath, $qrX, $qrY);
                }
            }

            // --- 7. KAYDETME VE BİTİRME ---
            $finalFileName = 'Rapor_' . $sample->barcode . '_' . time() . '.pdf';
            $finalPath = $reportsDir . '/' . $finalFileName;
            
            // Windows sunucular için yol düzeltmesi
            $finalPath = str_replace('\\', '/', $finalPath);

            // PDF'i diske kaydet ('F' parametresi File System'e kaydeder)
            $pdf->Output($finalPath, 'F'); 

            // --- 8. TEMİZLİK (GEÇİCİ DOSYALARI SİL) ---
            // Yüklenen dosyaları ve QR kodunu sil
            foreach ($filesToMerge as $file) {
                File::delete($file);
            }
            File::delete($qrPath);

            // --- 9. VERİTABANI GÜNCELLEME ---
            $sample->update([
                'status'       => 'Tamamlandı',
                'completed_at' => now(),
                'report_file'  => 'reports/' . $finalFileName,
            ]);

            return redirect()->route('admin.reporting.index')
                             ->with('success', 'Rapor başarıyla oluşturuldu. QR Kod ' . $targetPage . '. sayfaya eklendi.');

        } catch (\Exception $e) {
            // Hata durumunda da temizlik yapmaya çalışabiliriz
            if(isset($filesToMerge)) {
                foreach ($filesToMerge as $file) File::delete($file);
            }
            return back()->with('error', 'Rapor oluşturulurken hata: ' . $e->getMessage());
        }
    }

    /**
     * Sayfaya QR Kod ve Alt Yazı Ekleyen Yardımcı Fonksiyon
     */
    private function addQrToPage($pdf, $currentPage, $targetPage, $qrPath, $qrX, $qrY)
    {
        if ($currentPage == $targetPage) {
            // ImageSVG: Vektörel basım (W:25mm, H:25mm)
            $pdf->ImageSVG($qrPath, $qrX, $qrY, 25, 25);
            
            // Altına yazı ekle
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->SetXY($qrX, $qrY + 26);
            $pdf->Write(0, 'Doğrulama Kodu');
        }
    }

    /**
     * 1. AJAX: Barkod Okutulduğunda Numuneyi Bulur
     */
    public function findByBarcode(Request $request)
    {
        $barcode = trim($request->barcode);
        
        // Numuneyi müşteri ilişkisiyle birlikte bul
        $sample = Sample::with('offer.customer')->where('barcode', $barcode)->first();

        // Eğer barkod yoksa
        if (!$sample) {
            return response()->json([
                'status' => 'error', 
                'message' => 'Bu barkoda ait sistemde herhangi bir numune kaydı bulunamadı!'
            ]);
        }

        // Eğer numune zaten kabul edilmişse uyar
        if ($sample->status === 'Kabul Edildi') {
            return response()->json([
                'status' => 'error', 
                'message' => "Bu numune zaten kabul edilmiş. (Kabul Tarihi: {$sample->accepted_at})"
            ]);
        }

        // Aktif depo lokasyonlarını çek (Selectbox'ı doldurmak için)
        $locations = StorageLocation::where('is_active', 1)->select('id', 'name', 'code')->get();

        // Ekrana basılacak HTML tasarımı
        $customerName = $sample->offer->customer->name ?? 'Bilinmeyen Müşteri';
        $html = '
            <div class="alert alert-success border shadow-sm">
                <h5 class="fw-bold text-success"><i class="fas fa-check-circle me-2"></i>Numune Eşleşti!</h5>
                <hr>
                <div class="mb-2"><strong>Müşteri/Teklif:</strong> ' . $customerName . ' (' . ($sample->offer->offer_no ?? '-') . ')</div>
                <div class="mb-3"><strong>İçerik:</strong> ' . $sample->analysis_summary . '</div>
                
                <form id="acceptForm">
                    <input type="hidden" name="sample_id" value="' . $sample->id . '">
                    <div class="mb-3">
                        <label class="fw-bold mb-1">Depolama Alanı Seçin <span class="text-danger">*</span></label>
                        <select class="form-select" name="storage_location_id" id="storageSelect" required>
                            </select>
                    </div>
                    <button type="button" class="btn btn-success w-100 fw-bold shadow-sm" id="btnAcceptSample">
                        <i class="fas fa-download me-1"></i> NUMUNEYİ KABUL ET VE DEPOYA AL
                    </button>
                </form>
            </div>
        ';

        return response()->json([
            'status' => 'success',
            'html' => $html,
            'locations' => $locations
        ]);
    }

    /**
     * 2. AJAX: Numuneyi Kabul Et ve Kaydet
     */
    public function accept(Request $request)
    {
        $request->validate([
            'sample_id' => 'required|exists:samples,id',
            'storage_location_id' => 'required|exists:storage_locations,id'
        ]);

        try {
            $sample = Sample::findOrFail($request->sample_id);
            
            // Numuneyi güncelle
            $sample->update([
                'status' => 'Kabul Edildi',
                'storage_location_id' => $request->storage_location_id,
                'accepted_at' => now(),
                'acceptor_id' => auth()->id()
            ]);

            return response()->json([
                'status' => 'success', 
                'message' => 'Numune başarıyla kabul edildi ve depoya atandı.'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error', 
                'message' => 'Kabul işlemi sırasında bir hata oluştu: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * 3. AJAX: Numune Deposunu Güncelle (Düzenle Modalı İçin)
     */
    public function update(Request $request)
    {
        $request->validate([
            'sample_id' => 'required|exists:samples,id',
            'storage_location_id' => 'required|exists:storage_locations,id'
        ]);

        try {
            $sample = Sample::findOrFail($request->sample_id);
            $sample->storage_location_id = $request->storage_location_id;
            $sample->save();

            return response()->json([
                'status' => 'success', 
                'message' => 'Numunenin depo konumu başarıyla güncellendi.'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error', 
                'message' => 'Güncelleme sırasında bir hata oluştu.'
            ], 500);
        }
    }

   /**
     * AJAX: Seçilen teklife ait henüz kabul ETMEDİĞİMİZ numuneleri getirir.
     */
    public function getSamplesByOffer(Request $request)
    {
        try {
            $offerId = $request->offer_id;
            
            if (!$offerId) {
                return response()->json([
                    'status' => 'error', 
                    'message' => 'Geçersiz Teklif ID'
                ]);
            }

            // 'samples.status' diyerek tablolar arası karışıklığı (Ambiguous Column) önlüyoruz
            $samples = \App\Models\Sample::with([
                'offer',                      
                'offer.items',                
                'offer.items.parameter.subParameters' // YENİ: Alt parametreleri de getiriyoruz       
            ])
            ->where('samples.offer_id', $offerId)
            ->where(function($query) {
                $query->where('samples.status', '!=', 'Kabul Edildi')
                      ->orWhereNull('samples.status'); 
            })
            ->get();

            if ($samples->isEmpty()) {
                return response()->json([
                    'status' => 'empty', 
                    'message' => 'Bu teklife ait kabul edilecek bekleyen numune kalmamıştır.'
                ]);
            }

            return response()->json([
                'status' => 'success', 
                'data' => $samples
            ]);

        } catch (\Exception $e) {
            // İŞTE DEDEKTİF BURADA! 500 Hatası vermek yerine sebebi sana söyleyecek.
            return response()->json([
                'status' => 'error', 
                'message' => 'Sistem Hatası: ' . $e->getMessage() . ' (Satır: ' . $e->getLine() . ')'
            ]);
        }
    }

    /**
     * AJAX: Çoklu Numune Kabulü (Yazılabilir alanlarla birlikte)
     */
    public function acceptMultiple(Request $request)
    {
        $request->validate([
            'samples' => 'required|array|min:1',
            'samples.*.id' => 'required|exists:samples,id',
            'storage_location_id' => 'required|exists:storage_locations,id'
        ]);

        try {
            DB::beginTransaction();

            $locationId = $request->storage_location_id;
            $userId = auth()->id();
            $adv = $request->advanced_options ?? []; // Master panelden gelen ekstra veriler

            foreach ($request->samples as $sampleData) {
                $acceptedAt = !empty($sampleData['accepted_at']) ? Carbon::parse($sampleData['accepted_at']) : now();

                $updateData = [
                    'status' => 'Kabul Edildi',
                    'storage_location_id' => $locationId,
                    'accepted_at' => $acceptedAt,
                    'acceptor_id' => $userId,
                    'arrival_type' => !empty($sampleData['arrival_type']) ? $sampleData['arrival_type'] : null,
                    'sampler_id' => !empty($sampleData['sampler_id']) ? $sampleData['sampler_id'] : null,
                    'description' => $sampleData['content_note'] ?? null, 
                    'packaging_type' => $sampleData['packaging_type'] ?? null, // TABLODAN (DROPDOWN) GELECEK
                    'selected_sub_parameters' => $sampleData['selected_sub_parameters'] ?? null,
                    
                    // GELİŞMİŞ SEÇENEKLER (Ambalaj Tipi buradan çıkarıldı)
                    'sampling_location' => $adv['sampling_location'] ?? null,
                    'coordinate_x' => $adv['coordinate_x'] ?? null,
                    'coordinate_y' => $adv['coordinate_y'] ?? null,
                    'sampling_start_date' => $adv['sampling_start_date'] ?? null,
                    'sampling_end_date' => $adv['sampling_end_date'] ?? null,
                    'sampling_purpose' => $adv['sampling_purpose'] ?? null,
                    'sampling_standard' => $adv['sampling_standard'] ?? null,
                    'sampling_method' => $adv['sampling_method'] ?? null,
                    'is_protected' => $adv['is_protected'] ?? null,
                    'transport_method' => $adv['transport_method'] ?? null,
                    'seal_number' => $adv['seal_number'] ?? null,
                    'total_volume' => $adv['total_volume'] ?? null,
                    'environment_temp' => $adv['environment_temp'] ?? null,
                    'has_witness_sample' => $adv['has_witness_sample'] ?? null,
                    'witness_seal_number' => $adv['witness_seal_number'] ?? null,
                    'report_number' => $adv['report_number'] ?? null,
                    'pre_treatments' => $adv['pre_treatments'] ?? null,
                ];

                Sample::where('id', $sampleData['id'])->update($updateData);
            }

            DB::commit();
            return response()->json(['status' => 'success', 'message' => count($request->samples) . ' adet numune başarıyla kabul edildi.']);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Sistem Hatası: ' . $e->getMessage()], 500);
        }
    }

    /**
     * AJAX: Barkoddan Teklif ID'sini bulur (Akıllı barkod okuma için)
     * Sadece planı tamamlanmış tekliflerin numunelerini kabul eder
     */
    public function findOfferByBarcode(Request $request)
    {
        $barcode = trim($request->barcode);
        $sample = Sample::where('barcode', $barcode)->first();

        if (!$sample) {
            return response()->json(['status' => 'error', 'message' => 'Sistemde böyle bir barkod bulunamadı.']);
        }

        // Numune zaten kabul edilmiş mi?
        if ($sample->status === 'Kabul Edildi') {
            return response()->json(['status' => 'error', 'message' => "Bu numune zaten kabul edilmiş. (Kabul Tarihi: {$sample->accepted_at})"]);
        }

        // Bu numunenin teklifine ait geçerli bir plan var mı? (Planlandı veya Tamamlandı)
        $validPlan = MeasurementPlan::where('offer_id', $sample->offer_id)
                                        ->whereIn('status', ['Tamamlandı', 'Planlandı'])
                                        ->first();

        if (!$validPlan) {
            return response()->json([
                'status' => 'error', 
                'message' => 'Bu numunenin ölçüm planı henüz oluşturulmamış! Lütfen önce planlama departmanının planı oluşturmasını bekleyin.'
            ]);
        }

        return response()->json([
            'status' => 'success',
            'offer_id' => $sample->offer_id
        ]);
    }
    
    /**
     * AJAX: Geçmiş Kabuller sekmesindeki Modal için detayları getirir
     */
    public function getSampleDetails($id)
    {
        try {
            // İlişkileriyle birlikte numuneyi bul
            $sample = Sample::with(['offer.customer', 'storageLocation'])->find($id);

            if(!$sample) {
                return response()->json(['status' => 'error', 'message' => 'Numune bulunamadı.']);
            }

            // HTML datetime-local inputu için tarihi özel olarak formatlayalım
            if ($sample->accepted_at) {
                $sample->accepted_at_formatted = \Carbon\Carbon::parse($sample->accepted_at)->format('Y-m-d\TH:i');
            }

            return response()->json(['status' => 'success', 'data' => $sample]);

        } catch (\Exception $e) {
            Log::error("Modal Detay Hatası: " . $e->getMessage());
            
            return response()->json([
                'status' => 'error', 
                'message' => 'Sistem Hatası: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Kabul edilmiş numuneler için dinamik Numune İletim Formu (FR-10-02) basar
     */
    public function printDeliveryForm($offer_no)
    {
        // İlgili teklifin SADECE kabul edilmiş numunelerini ilişkileriyle çekiyoruz
        $samples = \App\Models\Sample::with(['offer.customer', 'offer.items.parameter'])
            ->whereHas('offer', function($q) use ($offer_no) {
                $q->where('offer_no', $offer_no);
            })
            ->where('status', 'Kabul Edildi')
            ->orderBy('barcode', 'asc')
            ->get();

        if ($samples->isEmpty()) {
            return abort(404, 'Bu teklife ait kabul edilmiş numune bulunamadı.');
        }

        $offer = $samples->first()->offer;

        // Numunelerden genel/ortak bilgileri çıkartıyoruz
        $commonTemps = $samples->pluck('environment_temp')->filter()->unique()->implode(', ');
        $commonSeals = $samples->pluck('seal_number')->filter()->unique()->implode(', ');
        $commonDates = $samples->pluck('sampling_start_date')->filter()->map(function($d) {
            return \Carbon\Carbon::parse($d)->format('d.m.Y');
        })->unique()->implode(', ');

        return view('admin.sample_management.print_delivery_form', compact('samples', 'offer', 'commonTemps', 'commonSeals', 'commonDates'));
    }

    /**
     * AJAX: Kabul edilmiş numunenin detaylarını günceller (Düzenle Modalı)
     */
    public function updateAcceptedDetails(Request $request, $id)
    {
        try {
            $sample = Sample::findOrFail($id);

            // Sadece kabul edilmiş numuneler düzenlenebilir
            if ($sample->status !== 'Kabul Edildi') {
                return response()->json(['status' => 'error', 'message' => 'Sadece kabul edilmiş numuneler düzenlenebilir.']);
            }

            // Gelen verilerle güncelleme yap
            $sample->update([
                'storage_location_id' => $request->storage_location_id,
                'sampling_location'   => $request->sampling_location,
                'packaging_type'      => $request->packaging_type,
                'seal_number'         => $request->seal_number,
                'environment_temp'    => $request->environment_temp,
                'transport_method'    => $request->transport_method,
                'is_protected'        => $request->is_protected,
                'report_number'       => $request->report_number,
            ]);

            return response()->json(['status' => 'success', 'message' => 'Numune detayları başarıyla güncellendi.']);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Güncelleme hatası: ' . $e->getMessage()], 500);
        }
    }

    /**
     * AJAX: Numune kabulünü iptal eder ve "Pending" durumuna geri çeker
     */
    public function revertAcceptance($id)
    {
        try {
            $sample = Sample::findOrFail($id);

            // Kabul edilmiş durumu geri alınıyor
            $sample->update([
                'status'              => 'Pending', // Bekliyor konumuna al
                'storage_location_id' => null,      // Depodan çıkar
                'accepted_at'         => null,      // Kabul tarihini sil
                'acceptor_id'         => null,      // Kabul eden kişiyi sil
                // İsterseniz gelişmiş seçenekleri (sıcaklık vs.) burada silebilirsiniz, 
                // ancak yanlışlıkla geri alınanlarda verinin kaybolmaması için tutmak daha mantıklıdır.
            ]);

            return response()->json(['status' => 'success', 'message' => 'Kabul işlemi geri alındı. Numune tekrar bekleyenler listesine taşındı.']);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Geri alma hatası: ' . $e->getMessage()], 500);
        }
    }
}
