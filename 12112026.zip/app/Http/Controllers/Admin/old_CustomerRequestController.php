<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CustomerRequest;
use App\Models\Offer;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CustomerRequestController extends Controller
{
    // LİSTELEME
    public function index()
    {
        // İlişkileriyle beraber çekiyoruz (Performans için eager loading)
        $requests = CustomerRequest::with(['customer', 'creator', 'offer'])->latest()->paginate(15);
        return view('admin.requests.index', compact('requests'));
    }

    // YENİ EKLEME SAYFASI
    public function create()
    {
        // Talep No Üret (TLP-YYYY-0001)
        $lastReq = CustomerRequest::latest()->first();
        // Eğer kayıt varsa son numarayı al, yoksa 1'den başla
        // (request_no formatı TLP-2026-0001 varsayılıyor, son 4 haneyi int'e çeviriyoruz)
        if ($lastReq && preg_match('/-(\d{4})$/', $lastReq->request_no, $matches)) {
            $number = intval($matches[1]) + 1;
        } else {
            $number = 1;
        }
        
        $newRequestNo = 'TLP-' . date('Y') . '-' . str_pad($number, 4, '0', STR_PAD_LEFT);

        $customers = Customer::where('is_active', 1)->orderBy('name')->get();
        
        return view('admin.requests.create', compact('customers', 'newRequestNo'));
    }

   // KAYDETME İŞLEMİ
    public function store(Request $request)
    {
        $request->validate([
            'customer_id' => 'required',
            'request_date' => 'required',
            'request_type' => 'required',
            'request_source' => 'required',
        ]);

        $req = new \App\Models\CustomerRequest();
        $req->fill($request->all());
        
        // --- TLP (Talep) KODU OLUŞTURMA MANTIĞI ---
        $year = date('Y');
        $prefix = 'TLP-';

        // ÇÖZÜM BURADA: Model yerine doğrudan DB::table kullanıyoruz!
        // Bu sayede SoftDelete (silinmiş) veya pasif yapılmış kayıtları bile atlamaz, numarayı kaldığı yerden artırır.
        $lastRequest = \Illuminate\Support\Facades\DB::table('customer_requests')
                        ->whereYear('created_at', $year)
                        ->where('request_no', 'like', $prefix . '%')
                        ->orderBy('id', 'desc')
                        ->first();

        if ($lastRequest && $lastRequest->request_no) {
            $parts = explode('-', $lastRequest->request_no);
            $lastSequence = (int) end($parts);
            $sequence = $lastSequence + 1;
        } else {
            $sequence = 1;
        }

        // En güncel ve benzersiz numarayı atıyoruz
        $req->request_no = $prefix . $year . '-' . str_pad($sequence, 4, '0', STR_PAD_LEFT);
        
        $req->created_by = \Illuminate\Support\Facades\Auth::id();
        $req->request_status = 'Beklemede'; // İlk kayıt
        $req->save();

        return redirect()->route('admin.requests.index')
            ->with('success', 'Talep başarıyla oluşturuldu. Kod: ' . $req->request_no);
    }

    // DÜZENLEME SAYFASI (EKSİK OLAN KISIM buydu)
    public function edit($id)
    {
        $request = CustomerRequest::with(['customer.contacts', 'offer'])->findOrFail($id);
        $customers = Customer::where('is_active', 1)->orderBy('name')->get();

        return view('admin.requests.edit', compact('request', 'customers'));
    }

    // GÜNCELLEME İŞLEMİ (EKSİK OLAN KISIM)
    public function update(Request $request, $id)
    {
        $req = CustomerRequest::findOrFail($id);

        // Eğer talep teklife dönüştüyse bazı kritik alanların değişmesini engelleyebiliriz
        // Şimdilik serbest bırakıyoruz.

        $req->fill($request->all());
        // created_by değişmemeli, updated_by olsaydı onu güncellerdik.
        $req->save();

        return redirect()->route('admin.requests.edit', $id)->with('success', 'Talep bilgileri güncellendi.');
    }

    // SİLME İŞLEMİ (EKSİK OLAN KISIM)
    public function destroy($id)
    {
        $req = CustomerRequest::findOrFail($id);
        
        if($req->converted_offer_id) {
            return back()->with('error', 'Teklife dönüşmüş bir talep silinemez. Önce teklifi silmelisiniz.');
        }

        $req->delete();
        return redirect()->route('admin.requests.index')->with('success', 'Talep silindi.');
    }

    // --- KRİTİK NOKTA: TALEBİ TEKLİFE DÖNÜŞTÜR ---
    public function convertToOffer($id)
    {
        $talep = CustomerRequest::findOrFail($id);

        if($talep->converted_offer_id) {
            return back()->with('error', 'Bu talep zaten teklife dönüştürülmüş.');
        }

        // 1. Yeni Teklif No Üret (Silinenler ve Revizyonlar Dahil Kurşun Geçirmez Mantık)
        $year = date('Y');
        
        $lastOffer = Offer::withTrashed()
            ->where('offer_no', 'like', "TK-{$year}-%")
            ->orderBy('id', 'desc')
            ->first();

        $offerNum = 1;
        if ($lastOffer) {
            // Örn: TK-2026-0005-R1 veya TK-2026-0005 formatını tirelerden bölüyoruz
            $parts = explode('-', $lastOffer->offer_no); 
            
            // 3. parça (index 2) her zaman bizim ana sıra numaramızdır (Örn: 0005)
            if (isset($parts[2])) {
                $offerNum = (int)$parts[2] + 1;
            }
        }
        
        $newOfferNo = "TK-{$year}-" . str_pad($offerNum, 4, '0', STR_PAD_LEFT);

        // 2. Teklifi Oluştur (Veri Transferi)
        $offer = new Offer();
        $offer->offer_no = $newOfferNo;
        $offer->request_no = $talep->request_no; // Talep No'yu teklife yazıyoruz
        $offer->customer_id = $talep->customer_id;
        $offer->contact_id = $talep->contact_id;
        $offer->subject = 'Talep Dönüşümü: ' . $talep->request_type;
        $offer->offer_date = now();
        $offer->status = 'Açık'; // Varsayılan durum
        $offer->created_by = Auth::id();
        $offer->description = $talep->description; // Talep notunu teklif açıklamasına taşı
        
        // Diğer varsayılanlar (decimal alanlar null kalmasın diye)
        $offer->subtotal = 0;
        $offer->tax_total = 0;
        $offer->grand_total = 0;
        
        $offer->save();

        // 3. Talebi Güncelle
        $talep->request_status = 'Onaylandı'; // Talep onaylanmış sayılır
        $talep->converted_offer_id = $offer->id;
        $talep->save();

        // 4. Teklif Düzenleme Ekranına Gönder
        return redirect()->route('admin.offers.edit', $offer->id)
                         ->with('success', 'Talep onaylandı ve taslak teklif oluşturuldu. Lütfen fiyatlandırmayı yapın.');
    }
}