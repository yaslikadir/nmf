<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use ZipArchive;
use Exception;

class ModuleController extends Controller
{
    public function index()
    {
        $modules = [];
        $modulesPath = base_path('modules');

        // Klasör yoksa otomatik oluştur
        if (!File::exists($modulesPath)) {
            File::makeDirectory($modulesPath, 0775, true);
        }

        if (File::exists($modulesPath)) {
            $directories = File::directories($modulesPath);
            foreach ($directories as $dir) {
                $manifestPath = $dir . '/manifest.json';
                if (File::exists($manifestPath)) {
                    $manifest = json_decode(File::get($manifestPath), true);
                    if (is_array($manifest)) {
                        $manifest['path'] = $dir;
                        $modules[] = $manifest;
                    }
                }
            }
        }

        return view('admin.modules.index', compact('modules'));
    }

    public function toggle($slug)
    {
        $modulesPath = base_path('modules');

        if (File::exists($modulesPath)) {
            $directories = File::directories($modulesPath);
            foreach ($directories as $dir) {
                $manifestPath = $dir . '/manifest.json';
                if (File::exists($manifestPath)) {
                    $manifest = json_decode(File::get($manifestPath), true);

                    // Küçük/büyük harf uyuşmazlığını önlemek için strtolower kullanıyoruz
                    if (isset($manifest['slug']) && strtolower($manifest['slug']) === strtolower($slug)) {

                        if (!File::isWritable($manifestPath)) {
                            return redirect()->to('/admin/modules')->with('error', 'manifest.json dosyasına yazma izni yok! Lütfen sunucu klasör izinlerini kontrol edin.');
                        }

                        // Durumu tersine çevir (Aktifse Pasif, Pasifse Aktif yap)
                        $manifest['enabled'] = !($manifest['enabled'] ?? false);
                        File::put($manifestPath, json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

                        // SİSTEMİ UYANDIR: Modül açılıp kapandığı için önbelleği temizleyip menüleri güncelliyoruz
                        Artisan::call('optimize:clear');

                        return redirect()->to('/admin/modules')->with('success', 'Modül durumu başarıyla güncellendi.');
                    }
                }
            }
        }

        return redirect()->to('/admin/modules')->with('error', 'Modül bulunamadı veya değiştirilemedi.');
    }

    /**
     * DIŞARI AKTAR (EXPORT)
     * Modül klasörünü ziple ve indir.
     */
    public function export($slug)
    {
        $modulePath = base_path('modules/' . $slug);

        if (!File::exists($modulePath)) {
            return redirect()->to('/admin/modules')->with('error', 'Modül klasörü bulunamadı!');
        }

        $storageAppPath = storage_path('app');
        if (!File::exists($storageAppPath)) {
            File::makeDirectory($storageAppPath, 0775, true);
        }

        // Zip dosyasını geçici klasörde (storage) oluştur
        $zipFileName = $slug . '-v' . time() . '.zip';
        $zipFilePath = $storageAppPath . '/' . $zipFileName;

        $zip = new ZipArchive;
        if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {

            // Klasördeki tüm dosyaları zipe ekle (Recursive)
            $files = File::allFiles($modulePath);
            foreach ($files as $file) {
                // Dosyanın modül klasörü içindeki göreceli yolunu bul (Örn: src/Controllers/Test.php)
                $relativePath = str_replace($modulePath . DIRECTORY_SEPARATOR, '', $file->getRealPath());
                // Windows/Linux dizin ayracı uyumluluğu
                $relativePath = str_replace('\\', '/', $relativePath);
                // ZIP'in içine $slug ana klasörü altına koy ki açıldığında dağınık çıkmasın
                $zip->addFile($file->getRealPath(), $slug . '/' . $relativePath);
            }
            $zip->close();

            // Dosyayı indir ve indirme bitince sunucudan (storage'dan) sil
            return response()->download($zipFilePath)->deleteFileAfterSend(true);
        }

        return redirect()->to('/admin/modules')->with('error', 'ZIP dosyası oluşturulurken bir hata oluştu.');
    }

    /**
     * İÇERİ AKTAR (UPLOAD/IMPORT)
     * Yüklenen ZIP'i aç, manifesti kontrol et, modules klasörüne çıkar.
     */
    public function upload(Request $request)
    {
        $request->validate([
            'module_zip' => 'required|mimes:zip|max:20480' // Maks 20MB
        ], [
            'module_zip.required' => 'Lütfen yüklenecek bir ZIP dosyası seçin.',
            'module_zip.mimes' => 'Lütfen sadece .zip uzantılı dosya yükleyin.'
        ]);

        $zipFile = $request->file('module_zip');
        $zip = new ZipArchive;
        $res = $zip->open($zipFile->getRealPath());

        if ($res === TRUE) {
            // Güvenlik Kontrolü: İçinde manifest.json var mı?
            $hasManifest = false;
            $moduleFolderName = null;

            for ($i = 0; $i < $zip->numFiles; $i++) {
                $filename = str_replace('\\', '/', $zip->getNameIndex($i));
                if (str_ends_with($filename, 'manifest.json')) {
                    $hasManifest = true;
                    // Klasör adını bul (Örn: Customers/manifest.json -> Customers)
                    $parts = explode('/', trim($filename, '/'));
                    if (count($parts) > 1) {
                        $moduleFolderName = $parts[0];
                    }
                    break;
                }
            }

            if (!$hasManifest || !$moduleFolderName) {
                $zip->close();
                return redirect()->to('/admin/modules')->with('error', 'Geçersiz Modül! Yüklenen ZIP dosyası geçerli bir klasör yapısı veya manifest.json barındırmıyor.');
            }

            // ZIP içeriğini doğrudan /modules dizinine çıkar
            $extractPath = base_path('modules');

            // Klasör yoksa otomatik oluşturmayı dene
            if (!File::exists($extractPath)) {
                try {
                    File::makeDirectory($extractPath, 0775, true);
                } catch (Exception $e) {
                    $zip->close();
                    return redirect()->to('/admin/modules')->with('error', 'Ana dizinde "modules" klasörü oluşturulamadı. Lütfen sunucu izinlerini kontrol edin.');
                }
            }

            // Yazma izni kontrolü (500 hatasını önler)
            if (!File::isWritable($extractPath)) {
                $zip->close();
                return redirect()->to('/admin/modules')->with('error', '"modules" klasörüne yazma izni yok! Sunucuda "sudo chown -R www-data:www-data modules && sudo chmod -R 775 modules" komutunu çalıştırın.');
            }

            $targetModulePath = $extractPath . '/' . $moduleFolderName;

            // Eğer aynı isimde modül varsa önce eskisini sil (Üzerine yazma çakışmalarını önlemek için)
            if (File::exists($targetModulePath)) {
                if (!File::isWritable($targetModulePath)) {
                    $zip->close();
                    return redirect()->to('/admin/modules')->with('error', 'Mevcut "' . $moduleFolderName . '" klasörü silinemedi (Yazma izni yok).');
                }
                File::deleteDirectory($targetModulePath);
            }

            // ZIP çıkartma işlemi
            try {
                if (!$zip->extractTo($extractPath)) {
                    $zip->close();
                    return redirect()->to('/admin/modules')->with('error', 'ZIP dosyası çıkartılamadı! Klasör izinlerini kontrol edin.');
                }
            } catch (Exception $e) {
                $zip->close();
                return redirect()->to('/admin/modules')->with('error', 'ZIP çıkartılırken yetki hatası oluştu: ' . $e->getMessage());
            }

            $zip->close();

            // SİSTEMİ KENDİNE GETİR: Yeni kodlar/dosyalar geldiği için artisan'ı tetikle
            Artisan::call('optimize:clear');
            Artisan::call('migrate', ['--force' => true]);

            return redirect()->to('/admin/modules')->with('success', 'Modül başarıyla yüklendi ve sisteme entegre edildi!');
        }

        return redirect()->to('/admin/modules')->with('error', 'ZIP dosyası açılamadı veya bozuk.');
    }

    /**
     * SİL (DESTROY)
     * Modül klasörünü ve Veritabanı tablolarını tamamen sil.
     */
    public function destroy($slug)
    {
        $modulePath = base_path('modules/' . $slug);

        if (!File::exists($modulePath)) {
            return redirect()->to('/admin/modules')->with('error', 'Modül bulunamadı veya zaten silinmiş.');
        }

        if (!File::isWritable($modulePath)) {
            return redirect()->to('/admin/modules')->with('error', 'Modül klasörünü silmek için yazma izni yok!');
        }

        // 1. KRİTİK ADIM: DOSYALARI SİLMEDEN ÖNCE VERİTABANI TABLOLARINI SİL (ROLLBACK)
        $migrationPath = 'modules/' . $slug . '/database/migrations';
        if (File::exists(base_path($migrationPath))) {
            Artisan::call('migrate:rollback', [
                '--path' => $migrationPath,
                '--force' => true
            ]);
        }

        // 2. İhtiyati Tedbir: Modül aktifse önce manifest.json'da pasif yap
        $manifestPath = $modulePath . '/manifest.json';
        if (File::exists($manifestPath) && File::isWritable($manifestPath)) {
            $manifest = json_decode(File::get($manifestPath), true);
            if (is_array($manifest)) {
                $manifest['enabled'] = false;
                File::put($manifestPath, json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
        }

        // 3. Klasörü Tüm İçeriğiyle Birlikte Fiziksel Olarak Sil
        File::deleteDirectory($modulePath);

        // 4. Son Temizlik (Sistemi kendine getir)
        Artisan::call('optimize:clear');

        return redirect()->to('/admin/modules')->with('success', $slug . ' Modülü ve veritabanı tabloları sistemden kalıcı olarak silindi.');
    }
}