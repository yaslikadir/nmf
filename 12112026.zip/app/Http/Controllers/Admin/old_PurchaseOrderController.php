<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\PurchaseOrder;
use Illuminate\Http\Request;

class PurchaseOrderController extends Controller
{
    // AÇIK SİPARİŞLER LİSTESİ (Mal Beklenenler)
    public function index()
    {
        $orders = PurchaseOrder::with(['supplier', 'request.requester'])
                    ->latest()
                    ->paginate(15);
        return view('admin.purchase.orders.index', compact('orders'));
    }

    // SİPARİŞ DETAY VE İŞLEM EKRANI (İrsaliye/Fatura Girişi)
    public function show($id)
    {
        $order = PurchaseOrder::with(['supplier', 'request', 'offer.items.requestItem.material'])
                    ->findOrFail($id);
        return view('admin.purchase.orders.show', compact('order'));
    }

    // İRSALİYE GİRİŞİ (Mal Kabul)
    public function updateDelivery(Request $request, $id)
    {
        $order = PurchaseOrder::findOrFail($id);
        
        $request->validate([
            'delivery_note_no' => 'required',
            'delivery_date' => 'required|date',
        ]);

        $order->update([
            'delivery_note_no' => $request->delivery_note_no,
            'delivery_date' => $request->delivery_date,
            'status' => 'GoodsReceived' // Durum: Mal Kabul Yapıldı
        ]);

        return back()->with('success', 'İrsaliye bilgileri girildi, mal kabul yapıldı.');
    }

    // FATURA GİRİŞİ (Süreci Tamamla)
    public function completeOrder(Request $request, $id)
    {
        $order = PurchaseOrder::findOrFail($id);
        
        $request->validate([
            'invoice_no' => 'required',
            'invoice_date' => 'required|date',
            'invoice_file' => 'nullable|file|mimes:pdf,jpg,png|max:2048'
        ]);

        $data = [
            'invoice_no' => $request->invoice_no,
            'invoice_date' => $request->invoice_date,
            'status' => 'Completed' // Durum: Tamamlandı
        ];

        if($request->hasFile('invoice_file')) {
            $data['invoice_file'] = $request->file('invoice_file')->store('invoices', 'public');
        }

        $order->update($data);

        // Talebi de tamamen kapatabiliriz (Completed)
        $order->request->update(['status' => 'Completed']);

        return back()->with('success', 'Fatura işlendi ve sipariş süreci tamamlandı.');
    }

    public function deliveryForm($id)
    {
        $order = PurchaseOrder::with(['offer.items.requestItem.material', 'deliveries.items'])->findOrFail($id);
        
        // Hesaplama: Hangi üründen ne kadar daha gelmesi lazım?
        foreach($order->offer->items as $item) {
            // Bu ürün için daha önce yapılan tüm teslimatlardaki "Gelen Miktar" toplamı
            $alreadyReceived = \App\Models\PurchaseDeliveryItem::where('purchase_offer_item_id', $item->id)->sum('quantity_received');
            
            $item->remaining_qty = $item->quantity - $alreadyReceived;
            $item->received_so_far = $alreadyReceived;
        }

        return view('admin.purchase.orders.delivery', compact('order'));
    }

    /**
     * ADIM 2: Teslimatı ve Kalite Kontrolü Kaydet
     */
    public function storeDelivery(Request $request, $id)
    {
        $order = PurchaseOrder::findOrFail($id);

        $request->validate([
            'delivery_note_no' => 'required',
            'delivery_date' => 'required|date',
            'items' => 'required|array'
        ]);

        try {
            DB::beginTransaction();

            // 1. Teslimat Başlığını Oluştur
            $delivery = \App\Models\PurchaseDelivery::create([
                'purchase_order_id' => $order->id,
                'delivery_note_no' => $request->delivery_note_no,
                'delivery_date' => $request->delivery_date,
                'notes' => $request->notes,
                'received_by' => auth()->id(), // İşlemi yapan kişi
            ]);

            $totalReceived = 0;

            // 2. Kalemleri İşle
            foreach($request->items as $offerItemId => $data) {
                // Eğer miktar girilmemişse (0) bu satırı atla
                if($data['received_qty'] <= 0) continue;

                $received = $data['received_qty'];
                $rejected = $data['rejected_qty'] ?? 0;
                $accepted = $received - $rejected;

                // Validasyon: Kabul + Red = Gelen olmalı (Matematik hatası olmasın)
                if($accepted < 0) {
                    throw new \Exception("Hata: Reddedilen miktar, gelen miktardan fazla olamaz!");
                }

                \App\Models\PurchaseDeliveryItem::create([
                    'purchase_delivery_id' => $delivery->id,
                    'purchase_offer_item_id' => $offerItemId,
                    'quantity_received' => $received,
                    'quantity_accepted' => $accepted,
                    'quantity_rejected' => $rejected,
                    'rejection_reason' => $rejected > 0 ? ($data['reason'] ?? 'Belirtilmedi') : null
                ]);
                
                $totalReceived++;
            }

            if($totalReceived == 0) {
                throw new \Exception("En az bir ürün için miktar girmelisiniz.");
            }

            // 3. Siparişin Genel Durumunu Güncelle
            // Basit mantık: Bir kere bile mal girişi olduysa durumu güncelle
            $order->update(['status' => 'GoodsReceived']);

            DB::commit();
            return redirect()->route('admin.purchase.orders.show', $order->id)
                ->with('success', 'Mal kabul ve kalite kontrol işlemi kaydedildi.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage())->withInput();
        }
    }
}