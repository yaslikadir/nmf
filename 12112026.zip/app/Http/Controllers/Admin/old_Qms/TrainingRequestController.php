<?php

namespace App\Http\Controllers\Admin\Qms;

use App\Http\Controllers\Controller;
use App\Models\TrainingRequest;
use Illuminate\Http\Request;

class TrainingRequestController extends Controller
{
    // 1. TALEPLERİ LİSTELE
    public function index()
    {
        $requests = TrainingRequest::with('user')
                        ->orderByRaw("FIELD(status, 'Pending', 'Approved', 'Planned', 'Rejected')") // Bekleyenler en üste
                        ->orderByDesc('created_at')
                        ->get();

        return view('admin.qms.training_requests.index', compact('requests'));
    }

    // 2. DURUM GÜNCELLE (Onayla / Reddet)
    public function updateStatus(Request $request, $id)
    {
        $trainingRequest = TrainingRequest::findOrFail($id);
        
        $trainingRequest->update([
            'status' => $request->status,
            'admin_note' => $request->admin_note
        ]);

        return back()->with('success', 'Talep durumu güncellendi.');
    }

    // 3. TALEBİ SİL
    public function destroy($id)
    {
        TrainingRequest::findOrFail($id)->delete();
        return back()->with('success', 'Talep silindi.');
    }

    
}