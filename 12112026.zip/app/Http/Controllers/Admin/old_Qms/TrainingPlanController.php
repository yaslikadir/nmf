<?php

namespace App\Http\Controllers\Admin\Qms;

use App\Http\Controllers\Controller;
use App\Models\Training;
use App\Models\TrainingPlan;
use App\Models\TrainingRecord;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use App\Notifications\NewTrainingAssignedNotification;

class TrainingPlanController extends Controller
{
    // --- 1. PLANLAMA LİSTESİ (TAKVİM GÖRÜNÜMÜ) ---
    public function index()
    {
        // Gelecek ve Geçmiş planları ayrı listeyelim
        $upcomingPlans = TrainingPlan::with(['training', 'records'])
                            ->where('start_date', '>=', now())
                            ->orderBy('start_date', 'asc')
                            ->get();

        $pastPlans = TrainingPlan::with(['training', 'records'])
                            ->where('start_date', '<', now())
                            ->latest('start_date')
                            ->paginate(10);

        return view('admin.qms.training_plans.index', compact('upcomingPlans', 'pastPlans'));
    }

    // --- 2. YENİ PLAN OLUŞTURMA SAYFASI ---
    public function create(Request $request)
    {
        $trainings = Training::all();
        $users = User::with('department')->get();
        
        // URL'den gelen verileri al (Eğer talep sayfasından gelindiyse)
        $preSelectedUser = $request->user_id;
        $preFilledNote = $request->subject ? "Personel Talebi: " . $request->subject : '';
        $requestId = $request->request_id;

        return view('admin.qms.training_plans.create', compact('trainings', 'users', 'preSelectedUser', 'preFilledNote', 'requestId'));
    }

    // --- 3. PLANI KAYDETME VE ATAMA ---
    public function store(Request $request)
    {
        // 1. Validasyon
        $request->validate([
            'training_id' => 'required|exists:trainings,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'instructor' => 'required|string',
            'participants' => 'required|array|min:1',
            'duration_hours' => 'required|integer|min:1', // EKLENDİ
        ]);

        // 2. Planı Oluştur
        $plan = new TrainingPlan();
        $plan->training_id = $request->training_id;
        $plan->start_date = $request->start_date;
        $plan->end_date = $request->end_date;
        $plan->duration_hours = $request->duration_hours; // EKLENDİ
        $plan->location = $request->location ?? 'Online / LMS';
        $plan->instructor = $request->instructor;
        $plan->notes = $request->notes;
        $plan->status = 'Planned';
        $plan->save();

        // 3. Katılımcıları (Records) Oluştur
        foreach ($request->participants as $userId) {
            $record = new TrainingRecord();
            $record->training_plan_id = $plan->id; // Sütun adı kontrolü: training_plan_id
            $record->user_id = $userId;
            $record->result = 'Pending';
            $record->attended = false;
            $record->save();
        }

        // 4. BİLDİRİM GÖNDER
        try {
            $participants = User::whereIn('id', $request->participants)->get();
            Notification::send($participants, new NewTrainingAssignedNotification($plan));
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Eğitim bildirimi gönderilemedi: ' . $e->getMessage());
        }

        // Eğer bir talep üzerine oluşturulduysa, talebi güncelle
        if ($request->has('request_id') && $request->request_id) {
            \App\Models\TrainingRequest::where('id', $request->request_id)->update([
                'status' => 'Planned',
                'admin_note' => 'Eğitim planı oluşturuldu. Plan ID: ' . $plan->id
            ]);
        }

        return redirect()->route('admin.qms.plans.index')
                         ->with('success', 'Eğitim planlandı, ' . count($request->participants) . ' personele atandı.');
    }

    // --- 4. PLAN DETAYI ---
    public function show($id)
    {
        $plan = TrainingPlan::with(['training', 'records.user'])->findOrFail($id);
        return view('admin.qms.training_plans.show', compact('plan'));
    }
    
    // --- 5. PLANI İPTAL ETME ---
    public function cancel($id)
    {
        $plan = TrainingPlan::findOrFail($id);
        $plan->update(['status' => 'Cancelled']);
        return back()->with('info', 'Eğitim planı iptal edildi.');
    }

    // --- 6. KATILIM FORMUNU YAZDIR ---
    public function printForm($id)
    {
        $plan = TrainingPlan::with(['training', 'records.user.department'])->findOrFail($id);
        return view('admin.qms.training_plans.print_form', compact('plan'));
    }

    // --- 7. DÜZENLEME FORMU (EDIT) ---
    public function edit($id)
    {
        $plan = TrainingPlan::with('records')->findOrFail($id);
        
        if($plan->status == 'Completed') {
            return back()->with('error', 'Tamamlanmış eğitim planları düzenlenemez.');
        }

        $trainings = Training::all();
        $users = User::with('department')->get();
        
        $selectedParticipants = $plan->records->pluck('user_id')->toArray();

        return view('admin.qms.training_plans.edit', compact('plan', 'trainings', 'users', 'selectedParticipants'));
    }

    // --- 8. GÜNCELLEME (UPDATE) ---
    public function update(Request $request, $id)
    {
        $plan = TrainingPlan::findOrFail($id);

        $request->validate([
            'training_id' => 'required|exists:trainings,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'instructor' => 'required|string',
            'participants' => 'required|array|min:1', 
            'duration_hours' => 'required|integer|min:1', // EKLENDİ
        ]);

        // 1. Plan Bilgilerini Güncelle
        $plan->update([
            'training_id' => $request->training_id,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'duration_hours' => $request->duration_hours, // EKLENDİ
            'instructor' => $request->instructor,
            'location' => $request->location,
            'notes' => $request->notes
        ]);

        // 2. Katılımcıları Senkronize Et
        $currentRecordUserIds = $plan->records()->pluck('user_id')->toArray();
        $newParticipantIds = $request->participants;

        // A) SİLİNECEKLER (Sadece işlem yapmamış olanlar)
        $toDelete = array_diff($currentRecordUserIds, $newParticipantIds);
        if(!empty($toDelete)) {
            $plan->records()->whereIn('user_id', $toDelete)->where('result', 'Pending')->delete();
        }

        // B) EKLENECEKLER
        $toAdd = array_diff($newParticipantIds, $currentRecordUserIds);
        foreach($toAdd as $userId) {
            \App\Models\TrainingRecord::create([
                'training_plan_id' => $plan->id, // Sütun adı kontrolü: training_plan_id
                'user_id' => $userId,
                'status' => 'Assigned',
                'result' => 'Pending'
            ]);
            
            // Yeni eklenenlere de bildirim atılabilir (Opsiyonel)
        }

        return redirect()->route('admin.qms.plans.index')->with('success', 'Eğitim planı güncellendi.');
    }
}