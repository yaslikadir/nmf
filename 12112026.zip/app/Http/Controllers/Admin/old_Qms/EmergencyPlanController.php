<?php

namespace App\Http\Controllers\Admin\Qms;

use App\Http\Controllers\Controller;
use App\Models\EmergencyPlan;
use App\Models\EmergencyDrill; // Model import edildi
use App\Models\User;
use Illuminate\Http\Request;

class EmergencyPlanController extends Controller
{
    public function index()
    {
        $plans = EmergencyPlan::orderBy('next_drill_date', 'asc')->get();
        return view('admin.qms.emergency_plans.index', compact('plans'));
    }

    public function create()
    {
        $users = User::all();
        return view('admin.qms.emergency_plans.create', compact('users'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'scenario' => 'required|string',
            'procedure' => 'required|string',
            'drill_frequency_months' => 'required|integer|min:1',
            'team_members' => 'required|array',
            'team_members.*' => 'exists:users,id',
            'checklist_items' => 'nullable|array', // Kontrol listesi validasyonu
            'checklist_items.*' => 'nullable|string',
        ]);

        // (int) cast işlemi ile tarih hesaplama hatasını önlüyoruz
        $validated['next_drill_date'] = now()->addMonths((int) $validated['drill_frequency_months']);

        // Boş maddeleri temizle
        $checklistItems = $request->checklist_items ? array_filter($request->checklist_items) : null;

        $plan = EmergencyPlan::create([
            'title' => $validated['title'],
            'scenario' => $validated['scenario'],
            'procedure' => $validated['procedure'],
            'drill_frequency_months' => $validated['drill_frequency_months'],
            'next_drill_date' => $validated['next_drill_date'],
            'checklist_items' => $checklistItems, // Checklist JSON olarak kaydediliyor
            'response_team' => null
        ]);

        // Pivot tabloya ekibi kaydet
        $plan->teamMembers()->sync($validated['team_members']);

        // Bildirimler
        foreach ($plan->teamMembers as $user) {
            try {
                $user->notify(new \App\Notifications\EmergencyTeamAssignedNotification($plan));
            } catch (\Exception $e) {}
        }

        return redirect()->route('admin.qms.emergency-plans.index')
            ->with('success', 'Acil durum planı ve kontrol listesi oluşturuldu.');
    }

    public function show($id)
    {
        $plan = EmergencyPlan::with('teamMembers')->findOrFail($id);
        return view('admin.qms.emergency_plans.show', compact('plan'));
    }

    public function edit($id)
    {
        $plan = EmergencyPlan::with('teamMembers')->findOrFail($id);
        $users = User::all();
        return view('admin.qms.emergency_plans.edit', compact('plan', 'users'));
    }

    public function update(Request $request, $id)
    {
        $plan = EmergencyPlan::findOrFail($id);

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'scenario' => 'required|string',
            'procedure' => 'required|string',
            'drill_frequency_months' => 'required|integer|min:1',
            'team_members' => 'nullable|array',
            'team_members.*' => 'exists:users,id',
            'checklist_items' => 'nullable|array',
            'checklist_items.*' => 'nullable|string',
            'is_active' => 'boolean'
        ]);

        // Boş maddeleri temizle
        $checklistItems = $request->checklist_items ? array_filter($request->checklist_items) : null;

        $plan->update([
            'title' => $validated['title'],
            'scenario' => $validated['scenario'],
            'procedure' => $validated['procedure'],
            'drill_frequency_months' => $validated['drill_frequency_months'],
            'checklist_items' => $checklistItems, // Checklist güncelleme
            'is_active' => $request->has('is_active') ? 1 : 0
        ]);

        if ($request->has('team_members')) {
            $plan->teamMembers()->sync($validated['team_members']);
        }

        return redirect()->route('admin.qms.emergency-plans.index')
            ->with('success', 'Acil durum planı güncellendi.');
    }

    /**
     * Tatbikat Sonucunu Kaydet (Revize Edildi)
     * Saat ve Tür bilgileri eklendi.
     */
    public function storeDrillResult(Request $request, $id)
    {
        $plan = EmergencyPlan::findOrFail($id);

        $request->validate([
            'duration_minutes' => 'required|integer',
            'drill_time' => 'required', // Saat Zorunlu
            'drill_type' => 'required', // Tür Zorunlu (Haberli/Habersiz)
            'checklist_results' => 'nullable|array'
        ]);

        // 1. Geçmiş tablosuna kayıt at (Detaylı)
        EmergencyDrill::create([
            'emergency_plan_id' => $plan->id,
            'drill_date' => now(), // Tarih bugün
            'drill_time' => $request->drill_time, // Formdan gelen saat
            'drill_type' => $request->drill_type, // Formdan gelen tür
            'duration_minutes' => $request->duration_minutes,
            'notes' => $request->notes,
            'checklist_results' => $request->checklist_results, // JSON
            'conducted_by' => auth()->id()
        ]);

        // 2. Plan tarihlerini güncelle
        $plan->last_drill_date = now();
        $plan->next_drill_date = now()->addMonths((int) $plan->drill_frequency_months);
        $plan->save();

        return back()->with('success', 'Tatbikat başarıyla tamamlandı ve raporlandı.');
    }

    // Rapor Görüntüleme
    public function showDrillReport($id)
    {
        $drill = EmergencyDrill::with(['plan.teamMembers', 'conductor'])->findOrFail($id);
        return view('admin.qms.emergency_plans.report', compact('drill'));
    }

    public function destroy($id)
    {
        $plan = EmergencyPlan::findOrFail($id);
        $plan->delete();
        return back()->with('success', 'Plan silindi.');
    }
}