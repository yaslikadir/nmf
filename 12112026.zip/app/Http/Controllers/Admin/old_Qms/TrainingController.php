<?php

namespace App\Http\Controllers\Admin\Qms;

use App\Http\Controllers\Controller;
use App\Models\Training;
use App\Models\TrainingMaterial;
use App\Models\ExamQuestion;
use App\Models\ExamQuestionOption;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\TrainingPlan;
use App\Models\TrainingRecord;
use App\Models\TrainingRequest;
use App\Models\User;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;

class TrainingController extends Controller
{
    // --- 1. EĞİTİM LİSTESİ VE OLUŞTURMA ---

    public function index()
    {
        // Eğitimleri listele (En son eklenen en üstte)
        $trainings = Training::latest()->paginate(10);
        return view('admin.qms.trainings.index', compact('trainings'));
    }

    public function create()
    {
        return view('admin.qms.trainings.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'required',
        ]);

        // Otomatik Kod Üretimi (TRN-001)
        $count = Training::withTrashed()->count() + 1;
        $code = 'TRN-' . str_pad($count, 3, '0', STR_PAD_LEFT);

        $training = Training::create([
            'code' => $code,
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type, // Internal, External, Online
            'validity_months' => $request->validity_months, // 12, 24 ay vb.
            'has_exam' => $request->has('has_exam'), // Checkbox seçili mi?
            'passing_score' => $request->passing_score ?? 70,
        ]);

        return redirect()->route('admin.qms.trainings.show', $training->id)
                         ->with('success', 'Eğitim tanımı oluşturuldu. Şimdi içerik ekleyebilirsiniz.');
    }

    public function show($id)
    {
        // Eğitimi; materyalleri ve sorularıyla (şıkları dahil) getir
        $training = Training::with(['materials', 'questions.options'])->findOrFail($id);
        
        return view('admin.qms.trainings.show', compact('training'));
    }

    public function update(Request $request, $id)
    {
        $training = Training::findOrFail($id);
        
        $training->update([
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'validity_months' => $request->validity_months,
            'has_exam' => $request->has('has_exam'), // Checkbox kontrolü
            'passing_score' => $request->passing_score,
        ]);

        return back()->with('success', 'Eğitim bilgileri güncellendi.');
    }

    public function destroy($id)
    {
        Training::findOrFail($id)->delete();
        return redirect()->route('admin.qms.trainings.index')->with('success', 'Eğitim silindi.');
    }

    // --- 2. MATERYAL (DOSYA) YÖNETİMİ ---

    public function uploadMaterial(Request $request, $id)
    {
        $request->validate([
            'file' => 'required|file|max:51200', // Max 50MB (Video olabilir)
            'title' => 'required|string'
        ]);

        $file = $request->file('file');
        $path = $file->store('uploads/trainings', 'public');

        TrainingMaterial::create([
            'training_id' => $id,
            'title' => $request->title,
            'file_path' => $path,
            'file_type' => $file->extension(), // pdf, mp4, pptx
        ]);

        return back()->with('success', 'Eğitim materyali yüklendi.');
    }

    public function deleteMaterial($materialId)
    {
        $material = TrainingMaterial::findOrFail($materialId);
        
        // Fiziksel dosyayı sil
        if(Storage::disk('public')->exists($material->file_path)) {
            Storage::disk('public')->delete($material->file_path);
        }
        
        $material->delete();
        return back()->with('success', 'Materyal silindi.');
    }

    // --- 3. SORU BANKASI YÖNETİMİ ---

    public function storeQuestion(Request $request, $id)
    {
        // Validation: Soru metni ve en azından doğru şıkkın seçimi
        $request->validate([
            'question_text' => 'required',
            'correct_option' => 'required' // Hangi şık doğru? (0, 1, 2, 3) indexi
        ]);

        // 1. Soruyu Kaydet
        $question = ExamQuestion::create([
            'training_id' => $id,
            'question_text' => $request->question_text,
            'type' => 'Multiple_Choice', // Şimdilik sadece çoktan seçmeli
            'points' => $request->points ?? 10
        ]);

        // 2. Şıkları Kaydet (A, B, C, D)
        // Formdan "options[]" dizisi gelecek
        if($request->has('options')) {
            foreach($request->options as $index => $optionText) {
                if(!empty($optionText)) {
                    ExamQuestionOption::create([
                        'question_id' => $question->id,
                        'option_text' => $optionText,
                        'is_correct' => ($index == $request->correct_option) // Eğer index, seçilen radio butona eşitse doğrudur
                    ]);
                }
            }
        }

        return back()->with('success', 'Soru başarıyla eklendi.');
    }

    public function deleteQuestion($questionId)
    {
        // Cascade delete tanımlı olduğu için şıklar otomatik silinir
        ExamQuestion::destroy($questionId);
        return back()->with('success', 'Soru silindi.');
    }

    // --- YENİ: EĞİTİM TALEP ETME ---
    public function storeRequest(Request $request)
    {
        $request->validate([
            'subject' => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority' => 'required|in:Normal,Acil'
        ]);

        \App\Models\TrainingRequest::create([
            'user_id' => Auth::id(),
            'subject' => $request->subject,
            'description' => $request->description,
            'priority' => $request->priority,
            'status' => 'Pending'
        ]);

        return back()->with('success', 'Eğitim talebiniz yöneticilere iletildi.');
    }

    /**
     * EĞİTİM YÖNETİMİ DASHBOARD (ÖZET EKRANI)
     */
    public function dashboard()
    {
        // 1. ÜST KARTLAR (Sayısal Veriler)
        $counts = [
            'total_trainings' => \App\Models\Training::count(), // Toplam Tanımlı Eğitim
            'planned_active'  => TrainingPlan::where('status', 'Planned')->where('start_date', '>=', now())->count(), // Gelecek Planlar
            'pending_requests'=> TrainingRequest::where('status', 'Pending')->count(), // Bekleyen Talepler
            'certified_users' => TrainingRecord::where('result', 'Passed')->distinct('user_id')->count('user_id'), // Sertifikalı Personel Sayısı
        ];

        // 2. YAKLAŞAN EĞİTİMLER (Takvim Özeti - İlk 5)
        $upcomingPlans = TrainingPlan::with(['training', 'records'])
                            ->where('start_date', '>=', now())
                            ->orderBy('start_date', 'asc')
                            ->take(5)
                            ->get();

        // 3. SON SINAV SONUÇLARI (Son 5 Hareket)
        $latestRecords = TrainingRecord::with(['user', 'plan.training'])
                            ->whereNotNull('result')
                            ->where('result', '!=', 'Pending')
                            ->latest('updated_at')
                            ->take(5)
                            ->get();

        // 4. DEPARTMAN BAZLI EĞİTİM DURUMU (Grafiklik Veri)
        // Hangi departman kaç sertifika almış?
        $deptStats = TrainingRecord::where('result', 'Passed')
                    ->join('users', 'training_records.user_id', '=', 'users.id')
                    ->join('departments', 'users.department_id', '=', 'departments.id')
                    ->select('departments.name', DB::raw('count(*) as total'))
                    ->groupBy('departments.name')
                    ->orderByDesc('total')
                    ->take(5)
                    ->get();

        return view('admin.qms.trainings.dashboard', compact('counts', 'upcomingPlans', 'latestRecords', 'deptStats'));
    }

    /**
     * MANUEL GÖREV TETİKLEYİCİ (Localhost için)
     */
   public function runDailyJobs()
    {
        try {
            // 1. Eğitim Hatırlatmaları
            Artisan::call('qms:send-reminders');
            
            // 2. Sertifika Süre Kontrolleri (YENİ)
            Artisan::call('qms:check-expiry');
            
            return back()->with('success', 'Tüm sistem taramaları (Eğitim Hatırlatma + Sertifika Kontrol) başarıyla tamamlandı.');
        } catch (\Exception $e) {
            return back()->with('error', 'Servis çalıştırılırken hata oluştu: ' . $e->getMessage());
        }
    }
}