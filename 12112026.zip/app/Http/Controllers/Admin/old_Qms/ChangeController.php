<?php

namespace App\Http\Controllers\Admin\Qms;

use App\Http\Controllers\Controller;
use App\Models\QmsChange;
use App\Models\QmsChangeRisk;
use App\Models\QmsChangeAction;
use App\Models\QmsChangeAttachment; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage; 
use Illuminate\Support\Facades\Notification;
use App\Notifications\ChangeAnnouncementNotification;

class ChangeController extends Controller
{
    public function index()
    {
        $changes = QmsChange::with(['requester', 'department'])->latest()->paginate(15);
        return view('admin.qms.changes.index', compact('changes'));
    }

    public function create()
    {
        $departments = \App\Models\Department::all();
        return view('admin.qms.changes.create', compact('departments'));
    }

    public function store(Request $request)
    {
        // Kod üret (CHG-2026-001)
        $count = QmsChange::whereYear('created_at', date('Y'))->count() + 1;
        $code = 'CHG-' . date('Y') . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

        $change = QmsChange::create([
            'code' => $code,
            'title' => $request->title,
            'description' => $request->description,
            'reason' => $request->reason,
            'type' => $request->type,
            'priority' => $request->priority,
            'department_id' => $request->department_id,
            'request_user_id' => Auth::id(),
            'status' => 'Draft' // Başlangıçta taslak
        ]);

        return redirect()->route('admin.qms.changes.show', $change->id)->with('success', 'Değişiklik talebi oluşturuldu. Şimdi risk analizi yapın.');
    }

    public function show($id)
    {
        $change = QmsChange::with(['risks', 'actions.responsible', 'requester', 'approver', 'attachments'])->findOrFail($id);
        $users = \App\Models\User::all();
        return view('admin.qms.changes.show', compact('change', 'users'));
    }

    // --- RİSK İŞLEMLERİ ---
    public function addRisk(Request $request, $id)
    {
        $score = $request->probability * $request->impact;
        QmsChangeRisk::create([
            'change_id' => $id,
            'risk_description' => $request->risk_description,
            'probability' => $request->probability,
            'impact' => $request->impact,
            'risk_score' => $score,
            'mitigation_plan' => $request->mitigation_plan
        ]);
        
        // Durumu güncelle: Analiz yapılıyor
        QmsChange::where('id', $id)->update(['status' => 'Pending_Analysis']);
        
        return back()->with('success', 'Risk kaydı eklendi.');
    }

    public function deleteRisk($riskId)
    {
        QmsChangeRisk::destroy($riskId);
        return back()->with('success', 'Risk silindi.');
    }

    // --- ONAY VE KAPATMA ---
    public function submitForApproval($id)
    {
        // Risk analizi kontrolü
        $change = QmsChange::findOrFail($id);
        if($change->risks->count() == 0) {
            return back()->with('error', 'En az bir risk analizi yapmadan onaya gönderemezsiniz.');
        }
        
        $change->update(['status' => 'Pending_Approval']);
        
        // Burada Yöneticilere Bildirim (Notification) gönderebiliriz.
        
        return back()->with('success', 'Talep onaya gönderildi.');
    }

    public function approveChange(Request $request, $id)
    {
        $change = QmsChange::findOrFail($id);
        
        if($request->action == 'approve') {
            $change->update([
                'status' => 'Approved',
                'approved_by' => Auth::id(),
                'approved_at' => now()
            ]);
            $msg = 'Değişiklik onaylandı. Uygulama aşamasına geçildi.';
        } else {
            $change->update([
                'status' => 'Rejected',
                'rejection_reason' => $request->rejection_reason
            ]);
            $msg = 'Değişiklik reddedildi.';
        }

        return back()->with('success', $msg);
    }
    
    // --- AKSİYON EKLEME ---
    public function addAction(Request $request, $id)
    {
        QmsChangeAction::create([
            'change_id' => $id,
            'action_type' => $request->action_type,
            'description' => $request->description,
            'responsible_user_id' => $request->responsible_user_id,
            'due_date' => $request->due_date
        ]);
        return back()->with('success', 'Aksiyon planlandı.');
    }

    // --- AKSİYON TAMAMLAMA ---
    public function completeAction(Request $request, $actionId)
    {
        $action = QmsChangeAction::findOrFail($actionId);

        $action->update([
            'status' => 'Completed',
            'completed_at' => now(),
            'completion_note' => $request->completion_note
        ]);

        return back()->with('success', 'Aksiyon başarıyla tamamlandı.');
    }

    // --- RİSK GÜNCELLEME ---
    public function updateRisk(Request $request, $riskId)
    {
        $risk = QmsChangeRisk::findOrFail($riskId);
        
        $score = $request->probability * $request->impact; // Skoru yeniden hesapla

        $risk->update([
            'risk_description' => $request->risk_description,
            'probability' => $request->probability,
            'impact' => $request->impact,
            'risk_score' => $score,
            'mitigation_plan' => $request->mitigation_plan
        ]);

        return back()->with('success', 'Risk kaydı güncellendi.');
    }

    // --- AKSİYON GÜNCELLEME ---
    public function updateAction(Request $request, $actionId)
    {
        $action = QmsChangeAction::findOrFail($actionId);

        $action->update([
            'action_type' => $request->action_type,
            'description' => $request->description,
            'responsible_user_id' => $request->responsible_user_id,
            'due_date' => $request->due_date
        ]);

        return back()->with('success', 'Aksiyon güncellendi.');
    }

    // --- SÜREÇ: UYGULAMA TAMAMLANDI ---
    public function completeProcess($id)
    {
        $change = QmsChange::with('actions')->findOrFail($id);

        if($change->actions->where('status', '!=', 'Completed')->count() > 0) {
            return back()->with('error', 'Tüm aksiyonlar tamamlanmadan süreç bitirilemez.');
        }

        $change->update(['status' => 'Completed']); 

        return back()->with('success', 'Uygulama süreci tamamlandı. Değişiklik doğrulama aşamasına geçti.');
    }

    // --- SÜREÇ: DOĞRULAMA VE KAPATMA (FİNAL) ---
    public function verifyAndClose(Request $request, $id)
    {
        $change = QmsChange::findOrFail($id);

        $change->update([
            'status' => 'Closed',
            'verification_result' => $request->verification_result,
            'closed_date' => now()
        ]);

        return back()->with('success', 'Değişiklik başarıyla doğrulandı ve kapatıldı.');
    }

    // --- DOSYA YÜKLEME ---
    public function uploadAttachment(Request $request, $id)
    {
        $request->validate([
            'file' => 'required|file|max:10240' // Max 10MB
        ]);

        $file = $request->file('file');
        $name = $file->getClientOriginalName();
        $path = $file->store('uploads/changes', 'public');

        QmsChangeAttachment::create([
            'change_id' => $id,
            'file_name' => $name,
            'file_path' => $path,
            'file_type' => $file->extension(),
            'uploaded_by' => Auth::id()
        ]);

        return back()->with('success', 'Dosya başarıyla yüklendi.');
    }

    // --- DOSYA SİLME ---
    public function deleteAttachment($id)
    {
        $attachment = QmsChangeAttachment::findOrFail($id);
        
        // Fiziksel dosyayı sil
        if(Storage::disk('public')->exists($attachment->file_path)) {
            Storage::disk('public')->delete($attachment->file_path);
        }
        
        $attachment->delete();
        return back()->with('success', 'Dosya silindi.');
    }

    // --- RAPORLAMA ---
    public function report($id)
    {
        $change = QmsChange::with(['risks', 'actions.responsible', 'requester', 'approver', 'department'])->findOrFail($id);
        return view('admin.qms.changes.report', compact('change'));
    }

    // --- DUYURU YAYINLAMA ---
    public function sendAnnouncement(Request $request, $id)
    {
        $change = QmsChange::with('department')->findOrFail($id);

        // Hedef Kitleyi Belirle
        if ($request->target_audience == 'department' && $change->department_id) {
            // Sadece o departmandaki aktif kullanıcılar
            // Not: User modelinde department_id ilişkisi olduğunu varsayıyoruz. 
            // Eğer yoksa, bu filtreyi projenin User yapısına göre düzenlemelisin.
            $users = \App\Models\User::where('department_id', $change->department_id)->get();
        } else {
            // Tüm Şirket
            $users = \App\Models\User::all();
        }

        // Bildirimi Gönder
        // Notification Facade kullanarak toplu gönderim yapıyoruz (Daha performanslı)
        \Illuminate\Support\Facades\Notification::send($users, new \App\Notifications\ChangeAnnouncementNotification(
            $change, 
            $request->message,
            Auth::user()->name
        ));

        return back()->with('success', 'Duyuru ' . $users->count() . ' kişiye başarıyla gönderildi.');
    }
}