<?php

namespace App\Http\Controllers\Admin\Qms;

use App\Http\Controllers\Controller;
use App\Models\TrainingRecord;
use App\Models\ExamQuestion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Barryvdh\DomPDF\Facade\Pdf; // PDF Kütüphanesi

class MyTrainingController extends Controller
{
    /**
     * 1. EĞİTİMLERİM LİSTESİ
     */
    public function index()
    {
        $myTrainings = TrainingRecord::with(['plan.training'])
                        ->where('user_id', Auth::id())
                        ->orderByDesc('created_at')
                        ->get();

        return view('admin.qms.my_trainings.index', compact('myTrainings'));
    }

    /**
     * 2. EĞİTİM DETAYI
     */
    public function show($id)
    {
        $record = TrainingRecord::with(['plan.training.materials'])
                    ->where('user_id', Auth::id())
                    ->findOrFail($id);
        
        // İlk girişse 'Katıldı' işaretle
        if(!$record->attended) {
            $record->update(['attended' => true]);
        }

        return view('admin.qms.my_trainings.show', compact('record'));
    }

    /**
     * 3. SINAV EKRANI
     */
    public function startExam($id)
    {
        $record = TrainingRecord::where('user_id', Auth::id())->findOrFail($id);

        if ($record->result == 'Passed') {
            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('warning', 'Bu sınavı zaten başarıyla geçtiniz.');
        }

        $questions = ExamQuestion::with('options')
                        ->where('training_id', $record->plan->training_id)
                        ->inRandomOrder()
                        ->get();

        if($questions->count() == 0) {
            return back()->with('error', 'Bu eğitim için henüz soru hazırlanmamış.');
        }

        return view('admin.qms.my_trainings.exam', compact('record', 'questions'));
    }

    /**
     * 4. SINAVI BİTİR, PUANLA VE SERTİFİKA OLUŞTUR
     */
    public function submitExam(Request $request, $id)
    {
        $record = TrainingRecord::where('user_id', Auth::id())->findOrFail($id);
        $training = $record->plan->training;
        
        // Soruları çek ve puanla
        $questions = ExamQuestion::with('options')->where('training_id', $training->id)->get();
        $totalQuestions = $questions->count();
        $correctAnswers = 0;

        foreach($questions as $question) {
            $selectedOptionId = $request->input('answers.'.$question->id);
            $correctOption = $question->options()->where('is_correct', true)->first();
            
            if($correctOption && $selectedOptionId == $correctOption->id) {
                $correctAnswers++;
            }
        }

        $score = ($totalQuestions > 0) ? round(($correctAnswers / $totalQuestions) * 100) : 0;
        $result = ($score >= $training->passing_score) ? 'Passed' : 'Failed';

        // Sonucu kaydet
        $record->update([
            'exam_score' => $score,
            'result' => $result,
            'exam_date' => now()
        ]);

        // --- SERTİFİKA OLUŞTURMA İŞLEMİ ---
        if($result == 'Passed') {
            try {
                // 1. Doğrulama Kodunu Üret (Eğer yoksa)
                if(!$record->verification_code) {
                    $verifyCode = 'CRT-' . $record->id . '-' . strtoupper(Str::random(6));
                    $record->update(['verification_code' => $verifyCode]);
                } else {
                    $verifyCode = $record->verification_code;
                }

                // 2. Doğrulama Linkini Hazırla
                // Bu link view'e gidecek, view içindeki <img src="..."> etiketi Google API'den resmi çekecek.
                $verifyUrl = route('public.certificate.verify', $verifyCode);

                // 3. Logo Hazırlığı (Base64'e çeviriyoruz ki PDF içinde kesin görünsün)
                $logoPath = public_path('assets/img/logo.png'); 
                $logoBase64 = '';
                
                // Dosya kontrolü yapıyoruz, hata vermesin diye
                if(file_exists($logoPath)) {
                    $logoType = pathinfo($logoPath, PATHINFO_EXTENSION);
                    $logoData = file_get_contents($logoPath);
                    $logoBase64 = 'data:image/' . $logoType . ';base64,' . base64_encode($logoData);
                }

                // 4. PDF Oluşturma Ayarları
                // Template dosyasına değişkenleri gönderiyoruz
                $pdf = Pdf::loadView('admin.qms.certificates.template', compact('record', 'verifyUrl', 'logoBase64'));
                
                // --- KRİTİK NOKTA BURASI ---
                // Google API'den (dışarıdan) resim çekebilmesi için bu ayar ZORUNLUDUR.
                // Ayrıca 'chroot' ayarı yerel dosyalara erişim için gereklidir.
                $pdf->setOptions([
                    'isRemoteEnabled' => true, 
                    'chroot' => public_path()
                ]); 
                
                $pdf->setPaper('a4', 'landscape');

                // 5. Dosyayı Kaydet
                $fileName = 'certificate_' . $record->id . '_' . time() . '.pdf';
                $filePath = 'certificates/' . $fileName;

                // Storage/public/certificates klasörüne yaz
                Storage::disk('public')->put($filePath, $pdf->output());
                
                // 6. Veritabanını Güncelle (Bu satır çalışmazsa buton çıkmaz!)
                $record->update(['certificate_path' => $filePath]);

            } catch (\Exception $e) {
                // Hata olursa loglara yaz ama kullanıcıya sınav sonucunu yine de göster
                Log::error('Sertifika oluşturma hatası: ' . $e->getMessage());
            }

            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('success', 'TEBRİKLER! Sınavı geçtiniz. Sertifikanız oluşturuldu.');
        } else {
            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('error', 'Üzgünüz, sınavdan kaldınız. Puanınız: ' . $score);
        }
    }

    /**
     * EĞİTİM TALEP ETME (Personel Tarafı)
     */
    public function storeRequest(Request $request)
    {
        $request->validate([
            'subject' => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority' => 'required|in:Normal,Acil'
        ]);

        // TrainingRequest modelini kullanabilmek için en üste: use App\Models\TrainingRequest; eklemeyi unutma
        // Veya tam yolunu yazarak:
        \App\Models\TrainingRequest::create([
            'user_id' => Auth::id(),
            'subject' => $request->subject,
            'description' => $request->description,
            'priority' => $request->priority,
            'status' => 'Pending'
        ]);

        return back()->with('success', 'Eğitim talebiniz yöneticilere iletildi.');
    }

    /**
     * EĞİTİM DEĞERLENDİRME (ANKET) KAYDI
     */
    public function storeEvaluation(Request $request, $id)
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000'
        ]);

        $record = TrainingRecord::where('user_id', Auth::id())->findOrFail($id);

        // Zaten değerlendirmiş mi?
        if($record->evaluation) {
            return back()->with('error', 'Bu eğitimi zaten değerlendirdiniz.');
        }

        \App\Models\TrainingEvaluation::create([
            'training_record_id' => $record->id,
            'rating' => $request->rating,
            'comment' => $request->comment
        ]);

        return back()->with('success', 'Geri bildiriminiz için teşekkürler!');
    }
}