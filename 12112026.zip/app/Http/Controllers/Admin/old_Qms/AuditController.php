<?php

namespace App\Http\Controllers\Admin\Qms;

use App\Http\Controllers\Controller;
use App\Models\QmsAudit;
use App\Models\QmsAuditFinding;
use Illuminate\Http\Request;

class AuditController extends Controller
{
    // --- 1. STANDART RESOURCE METODLARI (Eksik Olanlar Eklendi) ---

    /**
     * Tüm Denetimlerin Listesi
     */
    public function index()
    {
        $audits = QmsAudit::with(['plan', 'leadAuditor', 'department', 'supplier'])
                    ->latest()
                    ->paginate(20);
        
        return view('admin.qms.audits.index', compact('audits'));
    }

    /**
     * Denetim Detayı (Show)
     * Burası genelde yönlendirme merkezi gibi çalışır.
     */
    public function show($id)
    {
        $audit = QmsAudit::findOrFail($id);

        // Eğer denetim tamamlandıysa Rapor'a, değilse Yürütme ekranına yönlendir
        if ($audit->status == 'Completed') {
            return redirect()->route('admin.qms.audits.report', $audit->id);
        } else {
            return redirect()->route('admin.qms.audits.perform', $audit->id);
        }
    }

    /**
     * Denetim Düzenleme Formu
     */
    public function edit($id)
    {
        $audit = QmsAudit::findOrFail($id);
        $users = \App\Models\User::all();
        $departments = \App\Models\Department::all();
        
        return view('admin.qms.audits.edit', compact('audit', 'users', 'departments'));
    }

    /**
     * Denetim Güncelleme
     */
    public function update(Request $request, $id)
    {
        $audit = QmsAudit::findOrFail($id);
        
        $request->validate([
            'title' => 'required|string',
            'planned_date' => 'required|date',
            'lead_auditor_id' => 'required|exists:users,id',
        ]);

        $audit->update([
            'title' => $request->title,
            'planned_date' => $request->planned_date,
            'lead_auditor_id' => $request->lead_auditor_id,
            'department_id' => $request->department_id,
            'scope' => $request->scope
        ]);

        return back()->with('success', 'Denetim bilgileri güncellendi.');
    }

    /**
     * Denetim Silme
     */
    public function destroy($id)
    {
        $audit = QmsAudit::findOrFail($id);
        
        // Sadece planlananlar silinebilir, tamamlananlar silinemez (Güvenlik)
        if($audit->status == 'Completed') {
            return back()->with('error', 'Tamamlanmış denetimler silinemez.');
        }

        $audit->delete();
        return back()->with('success', 'Denetim kaydı silindi.');
    }

    // --- 2. ÖZEL İŞLEM METODLARI (Mevcut Olanlar) ---

    // Denetim Planına Yeni Denetim Ekleme
    public function store(Request $request)
    {
        $request->validate([
            'audit_plan_id' => 'required|exists:qms_audit_plans,id',
            'title' => 'required|string',
            'type' => 'required|in:Internal,External,Supplier',
            'planned_date' => 'required|date',
            'lead_auditor_id' => 'required|exists:users,id',
            'checklist_ids' => 'required|array' 
        ]);

        // Kod üretme (AUD-2026-00X)
        $count = QmsAudit::whereYear('created_at', date('Y'))->count() + 1;
        $code = 'AUD-' . date('Y') . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

        $audit = QmsAudit::create([
            'audit_plan_id' => $request->audit_plan_id,
            'code' => $code,
            'title' => $request->title,
            'type' => $request->type,
            'planned_date' => $request->planned_date,
            'department_id' => $request->department_id,
            'supplier_id' => $request->supplier_id,
            'lead_auditor_id' => $request->lead_auditor_id,
            'scope' => $request->scope
        ]);

        // Soru Listelerini Eşle
        $audit->checklists()->attach($request->checklist_ids);
        
        // Ek Denetçileri Eşle
        if ($request->has('auditors')) {
            $audit->auditors()->attach($request->auditors, ['role' => 'Auditor']);
        }

        return back()->with('success', 'Denetim başarıyla planlandı.');
    }

    // Denetim Yürütme Ekranı (Perform)
    public function perform($id)
    {
        $audit = QmsAudit::with([
            'checklists.questions', 
            'findings', 
            'leadAuditor', 
            'department'
        ])->findOrFail($id);

        if($audit->status == 'Planned') {
            $audit->update(['status' => 'In_Progress', 'performed_date' => now()]);
        }

        return view('admin.qms.audits.perform', compact('audit'));
    }

    // Bulgu Kaydetme (AJAX)
    public function storeFinding(Request $request, $id)
    {
        $request->validate([
            'type' => 'required',
            'finding_details' => 'required'
        ]);

        $filePath = null;
        if($request->hasFile('attachment')) {
            $filePath = $request->file('attachment')->store('audit_evidences', 'public');
        }

        QmsAuditFinding::create([
            'audit_id' => $id,
            'question_id' => $request->question_id, 
            'type' => $request->type,
            'severity' => $request->severity,
            'finding_details' => $request->finding_details,
            'evidence' => $request->evidence,
            'attachment_path' => $filePath
        ]);

        return back()->with('success', 'Bulgu kaydedildi.');
    }

    // Denetimi Tamamla
    public function complete($id)
    {
        $audit = QmsAudit::findOrFail($id);
        $audit->update([
            'status' => 'Completed', 
            'summary' => request('summary')
        ]);
        
        return redirect()->route('admin.qms.audits.plans.show', $audit->audit_plan_id)
                         ->with('success', 'Denetim tamamlandı ve raporlandı.');
    }
    
    // Rapor Görüntüleme
    public function report($id)
    {
        $audit = QmsAudit::with(['findings', 'leadAuditor', 'department', 'checklists'])->findOrFail($id);
        return view('admin.qms.audits.report', compact('audit'));
    }

    // --- İSTATİSTİK VE ANALİZ (DASHBOARD) ---
    public function dashboard()
    {
        // 1. Üst Kartlar (Sayılar)
        $totalAudits = QmsAudit::count();
        $completedAudits = QmsAudit::where('status', 'Completed')->count();
        $openFindings = \App\Models\QmsAuditFinding::where('type', 'NonConformity')->count();
        
        // 2. Departman Bazlı Uygunsuzluk Sayıları (Pie Chart) - DÜZELTİLEN KISIM
        $findingsByDept = \App\Models\QmsAuditFinding::where('qms_audit_findings.type', 'NonConformity') // TABLO ADINI EKLEDİK
            ->join('qms_audits', 'qms_audit_findings.audit_id', '=', 'qms_audits.id')
            ->join('departments', 'qms_audits.department_id', '=', 'departments.id')
            ->select('departments.name', \DB::raw('count(*) as total'))
            ->groupBy('departments.name')
            ->get();

        // 3. Aylara Göre Denetim Sayısı (Bar Chart)
        $auditsByMonth = QmsAudit::selectRaw('MONTH(planned_date) as month, COUNT(*) as count')
            ->whereYear('planned_date', date('Y'))
            ->groupBy('month')
            ->orderBy('month')
            ->pluck('count', 'month');

        // Veriyi grafik formatına çevir (Boş ayları 0 doldur)
        $monthlyCounts = [];
        for ($i = 1; $i <= 12; $i++) {
            $monthlyCounts[] = $auditsByMonth[$i] ?? 0;
        }

        // 4. Bulgu Türü Dağılımı (Doughnut Chart)
        $findingTypes = \App\Models\QmsAuditFinding::select('type', \DB::raw('count(*) as total'))
            ->groupBy('type')
            ->pluck('total', 'type');

        return view('admin.qms.audits.dashboard', compact(
            'totalAudits', 'completedAudits', 'openFindings', 
            'findingsByDept', 'monthlyCounts', 'findingTypes'
        ));
    }
}