<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ScopeType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ScopeTypeController extends Controller
{
    public function index()
    {
        // Yetki kontrolü ekledik
        if (!auth()->user()->hasPermissionToAccessModule('parameters')) {
            abort(403);
        }
        $types = ScopeType::orderBy('name')->get();
        return view('admin.scope_types.index', compact('types'));
    }

    public function bulkUpdate(Request $request)
{
    // Gelen veriyi kontrol etmek için geçici olarak: dd($request->all());
    $items = $request->input('items', []);

    if (!auth()->user()->hasPermissionToAccessModule('parameters')) {
            return response()->json(['success' => false, 'message' => 'Yetkisiz erişim.'], 403);
        }

    if (empty($items)) {
        return response()->json(['success' => false, 'message' => 'Kaydedilecek veri bulunamadı.']);
    }

    try {
        DB::beginTransaction();
        foreach ($items as $id => $data) {
            if (empty($data['name'])) continue;

            if (str_starts_with($id, 'new_')) {
                ScopeType::create([
                    'name' => $data['name'],
                    'code' => $data['code']
                ]);
            } else {
                $type = ScopeType::find($id);
                if ($type) {
                    $type->update($data);
                }
            }
        }
        DB::commit();
        return response()->json(['success' => true]);
    } catch (\Exception $e) {
        DB::rollBack();
        return response()->json(['success' => false, 'message' => $e->getMessage()]);
    }
}
    public function destroy(ScopeType $scopeType)
    {
        $scopeType->delete();
        return back()->with('success', 'Silindi.');
    }
}