<?php

namespace App\Http\Controllers;

use App\Models\Sample;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PublicReportController extends Controller
{
    public function show($barcode)
    {
        // ÇÖZÜM BURADA: withoutGlobalScopes() eklendi!
        // Sisteme giriş yapmamış bir müşteri QR kodu okuttuğunda 
        // veritabanı güvenlik filtrelerine takılıp 404 vermesini engeller.
        $sample = Sample::withoutGlobalScopes()
                        ->where('barcode', $barcode)
                        ->firstOrFail();

        // Rapor dosyası var mı ve diskte mevcut mu?
        if (!$sample->report_file || !Storage::disk('public')->exists($sample->report_file)) {
            abort(404, 'Rapor dosyası bulunamadı veya henüz oluşturulmadı.');
        }

        // Dosyayı tarayıcıda aç (İndirme değil, doğrudan görüntüleme)
        return response()->file(storage_path('app/public/' . $sample->report_file), [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="Dogrulama_Raporu_'.$barcode.'.pdf"'
        ]);
    }
}