<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TrainingRecord;
use App\Models\Setting; // <-- Setting Modelini eklemeyi unutma (Varsa)
// Eğer Setting modelin yoksa direkt DB kullanabilirsin: use Illuminate\Support\Facades\DB;

class PublicController extends Controller
{
    public function verifyCertificate($code)
    {
        $record = TrainingRecord::with(['user', 'plan.training'])
                    ->where('verification_code', $code)
                    ->where('result', 'Passed')
                    ->firstOrFail();

        // --- SİTE BAŞLIĞINI ÇEKME ---
        // Ayarlar tablonun yapısına göre burayı düzenleyebilirsin.
        // Genelde yapı: key='site_title', value='Firma Adı' şeklindedir.
        
        // YÖNTEM 1: Setting Modeli varsa
        $siteTitle = \App\Models\Setting::where('key', 'site_title')->value('value');

        // YÖNTEM 2: Model yoksa direkt DB'den çekmek istersen
        // $siteTitle = \Illuminate\Support\Facades\DB::table('settings')->where('key', 'site_title')->value('value');

        // Eğer veritabanında ayar yoksa yine .env dosyasındaki ismi kullansın (Yedek plan)
        if (!$siteTitle) {
            $siteTitle = config('app.name');
        }

        return view('public.certificate_verify', compact('record', 'siteTitle'));
    }
}