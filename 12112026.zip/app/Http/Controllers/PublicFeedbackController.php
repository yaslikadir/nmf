<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FeedbackForm;
use App\Models\Feedback;
use Illuminate\Support\Str;

class PublicFeedbackController extends Controller
{
    // 1. FORMU GÖSTERME (lab.com/form/sikayet-bildir)
    public function show($slug)
    {
        // Sadece aktif olan formu bul, yoksa 404 ver
        $form = FeedbackForm::where('slug', $slug)
                    ->where('is_active', true)
                    ->with('fields') // Soruları da çek
                    ->firstOrFail();

        return view('public.feedback.show', compact('form'));
    }

    // 2. FORMU KAYDETME
    public function store(Request $request, $slug)
    {
        $form = FeedbackForm::where('slug', $slug)->where('is_active', true)->firstOrFail();

        // A) DİNAMİK VALIDASYON (ZORUNLU ALAN KONTROLÜ)
        $rules = [];
        
        foreach ($form->fields as $field) {
            $labelLower = mb_strtolower($field->label);
            
            // Bu özel alanlar boş bırakılabilsin diye zorunluluğunu eziyoruz.
            $isForceOptional = (
                str_contains($labelLower, 'ad') || 
                str_contains($labelLower, 'soyad') || 
                str_contains($labelLower, 'posta') || 
                str_contains($labelLower, 'email') || 
                str_contains($labelLower, 'telefon')
            );
            
            $isRequired = $isForceOptional ? false : $field->is_required;

            if ($isRequired) {
                $ruleType = ($field->type == 'file') ? 'file|max:10240' : 'required'; 
                $rules[$field->name] = $ruleType;
            } else {
                $rules[$field->name] = 'nullable';
            }
        }
        
        // Doğrulama kurallarını çalıştır
        $request->validate($rules);

        // B) VERİLERİ TOPLAMA VE ANONİM (BOŞ) ALANLARI DOLDURMA İŞLEMİ
        $submittedData = $request->except(['_token']);
        
        // Başlangıçta varsayılan anonim veriler (Tümü boş gelirse bu veriler kullanılacak)
        $guestName = 'anonim';
        $guestEmail = 'anonim@anonim.com';
        // Her anonim işlemde rastgele bir telefon numarası ataması yapıyoruz. 
        // Sabit isterseniz '123456789' olarak değiştirebilirsiniz.
        $randomPhone = '5' . rand(300000000, 599999999); 
        $guestPhone = $randomPhone; 

        foreach ($form->fields as $field) {
            $labelLower = mb_strtolower($field->label);
            $val = $request->input($field->name);

            // 1. Dosya Yükleme İşlemi
            if ($field->type == 'file' && $request->hasFile($field->name)) {
                $path = $request->file($field->name)->store('feedback_attachments', 'public');
                $submittedData[$field->name] = $path; // Yüklenen dosya yolunu kaydet
                continue; // Dosyaysa aşağıdaki metin/anonim kontrollerine girmesine gerek yok
            }

            // 2. İsim, E-posta ve Telefon alanları için boşluk/anonim kontrolü
            if (str_contains($labelLower, 'ad') || str_contains($labelLower, 'soyad')) {
                if (empty($val)) {
                    $submittedData[$field->name] = 'anonim'; // JSON detayında 'anonim' görünsün
                } else {
                    $guestName = $val; // Doluysa müşterinin girdiği ismi al
                }
            }
            elseif (str_contains($labelLower, 'posta') || str_contains($labelLower, 'email')) {
                if (empty($val)) {
                    $submittedData[$field->name] = 'anonim@anonim.com'; // JSON detayında e-posta anonim görünsün
                } else {
                    $guestEmail = $val; // Doluysa müşterinin girdiği e-postayı al
                }
            }
            elseif (str_contains($labelLower, 'telefon')) {
                if (empty($val)) {
                    $submittedData[$field->name] = $randomPhone; // JSON detayına rastgele telefon numarasını ekle
                } else {
                    $guestPhone = $val; // Doluysa müşterinin girdiği telefonu al
                }
            }
        }

        // C) VERİTABANINA KAYIT
        // Takip Kodu: FB-{YIL}-{Rastgele} (Örn: FB-2024-X9Y2)
        $trackingCode = 'FB-' . date('Y') . '-' . strtoupper(Str::random(6));

        $feedback = Feedback::create([
            'feedback_form_id' => $form->id,
            'tracking_code' => $trackingCode,
            'guest_name' => $guestName,         // Anonimse 'anonim' veya girilen isim
            'guest_email' => $guestEmail,       // Anonimse 'anonim@anonim.com' veya girilen email
            'guest_phone' => $guestPhone,       // Anonimse rastgele veya girilen telefon
            'data' => $submittedData,           // Güncellenmiş anonim/boş olmayan form detay verileri
            'status' => 'Pending'
        ]);

        // D) BAŞARI SAYFASINA YÖNLENDİR
        return redirect()->route('public.feedback.success', ['code' => $trackingCode]);
    }

    // 3. TEŞEKKÜR VE TAKİP EKRANI
    public function success($code)
    {
        return view('public.feedback.success', compact('code'));
    }

    // 4. SORGULAMA EKRANI (FORM)
    public function trackingForm()
    {
        return view('public.feedback.tracking_form');
    }

    // 5. SORGULAMA SONUCU
    public function track(Request $request)
    {
        $request->validate([
            'tracking_code' => 'required|string|min:10'
        ], [
            'tracking_code.required' => 'Lütfen takip kodunuzu giriniz.',
            'tracking_code.min' => 'Takip kodu en az 10 karakter olmalıdır.'
        ]);

        // Kodu bul
        $feedback = \App\Models\Feedback::with(['form', 'activities'])
                        ->where('tracking_code', $request->tracking_code)
                        ->first();

        if (!$feedback) {
            return back()->withErrors(['tracking_code' => 'Bu koda ait bir kayıt bulunamadı. Lütfen kodu kontrol ediniz.']);
        }

        return view('public.feedback.tracking_result', compact('feedback'));
    }
}