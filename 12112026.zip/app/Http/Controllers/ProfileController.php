<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\File; // Dosya işlemleri için gerekli
use Illuminate\View\View;

class ProfileController extends Controller
{
    /**
     * Kullanıcı profil formunu gösterir.
     */
    public function edit(Request $request): View
    {
        return view('profile.edit', [
            'user' => $request->user(),
        ]);
    }

    /**
     * Kullanıcı profil bilgilerini günceller (Fotoğraf ve İmza dahil).
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
    {
        $user = $request->user();
        
        // Validasyondan geçen verileri al (name, email vb.)
        $data = $request->validated();

        // ----------------------------------------------------------------
        // 1. PROFIL FOTOĞRAFI YÜKLEME
        // ----------------------------------------------------------------
        if ($request->hasFile('profile_photo')) {
            // Eski fotoğraf varsa sil
            if ($user->profile_photo && File::exists(public_path($user->profile_photo))) {
                File::delete(public_path($user->profile_photo));
            }

            $file = $request->file('profile_photo');
            $filename = 'profile_' . $user->id . '_' . time() . '.' . $file->getClientOriginalExtension();
            
            // Klasör yoksa oluştur
            $path = public_path('uploads/profiles');
            if(!File::exists($path)) {
                File::makeDirectory($path, 0755, true);
            }

            $file->move($path, $filename);
            
            // Veritabanı için yolu ata (Modelde $fillable içinde olmasa bile save() ile kaydolur)
            $user->profile_photo = 'uploads/profiles/' . $filename;
        }

        // ----------------------------------------------------------------
        // 2. İMZA / KAŞE YÜKLEME
        // ----------------------------------------------------------------
        if ($request->hasFile('signature_stamp')) {
            // Eski imza varsa sil
            if ($user->signature_stamp && File::exists(public_path($user->signature_stamp))) {
                File::delete(public_path($user->signature_stamp));
            }

            $file = $request->file('signature_stamp');
            $filename = 'sign_' . $user->id . '_' . time() . '.' . $file->getClientOriginalExtension();

            // Klasör yoksa oluştur
            $path = public_path('uploads/signatures');
            if(!File::exists($path)) {
                File::makeDirectory($path, 0755, true);
            }

            $file->move($path, $filename);
            
            $user->signature_stamp = 'uploads/signatures/' . $filename;
        }

        // ----------------------------------------------------------------
        // 3. STANDART BİLGİLERİ GÜNCELLE
        // ----------------------------------------------------------------
        $user->fill($data);

        // Eğer email değiştiyse doğrulama tarihini sıfırla
        if ($user->isDirty('email')) {
            $user->email_verified_at = null;
        }

        $user->save();

        return Redirect::route('profile.edit')->with('success', 'Profil bilgileri başarıyla güncellendi.');
    }

    /**
     * Kullanıcı hesabını siler.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }

    /**
     * Güvenlik ayarları sayfası (Şifre değiştirme vb.)
     */
    public function security(Request $request): View
    {
        // Eğer view dosyası yoksa hata vermemesi için kontrol eklenebilir
        // Ancak view oluşturduysanız direkt döndürün.
        return view('profile.security', [
            'user' => $request->user(),
        ]);
    }

    /**
     * Bildirim ayarları sayfası
     */
    public function notifications(Request $request): View
    {
        return view('profile.notifications', [
            'user' => $request->user(),
        ]);
    }
}