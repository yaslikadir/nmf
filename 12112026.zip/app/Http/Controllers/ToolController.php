<?php

namespace App\Http\Controllers;

use App\Models\Note;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http; // <-- Döviz için gerekli

class ToolController extends Controller {
    
    /**
     * TCMB'den Canlı Döviz Çekme
     */
    public function getExchangeRates() {
        try {
            // Http Client ile daha güvenli veri çekme
            $response = Http::get('https://www.tcmb.gov.tr/kurlar/today.xml');
            
            if ($response->failed()) {
                return response()->json(['error' => 'TCMB servisine ulaşılamadı'], 500);
            }

            $xml = simplexml_load_string($response->body());
            
            // USD ve EUR Satış Kurlarını alıyoruz
            return response()->json([
                'USD' => (string)$xml->Currency[0]->BanknoteSelling,
                'EUR' => (string)$xml->Currency[3]->BanknoteSelling
            ]);
        } catch (\Exception $e) { 
            return response()->json(['error' => 'Kur bilgisi alınamadı'], 500); 
        }
    }

    /**
     * Giriş yapmış kullanıcının notlarını listeler
     */
    public function getNotes() {
        if (!Auth::check()) return response()->json([]);
        
        return Note::where('user_id', Auth::id())->latest()->get();
    }

    /**
     * Yeni not ekler
     */
    public function addNote(Request $request) {
        // 1. Veri doğrulaması
        $validated = $request->validate([
            'content' => 'required|string|min:1'
        ]);

        // 2. Kullanıcı kontrolü
        if (!Auth::check()) {
            return response()->json(['error' => 'Oturum açmanız gerekiyor'], 401);
        }

        // 3. Notu oluştur
        $note = Note::create([
            'user_id' => Auth::id(),
            'content' => $validated['content']
        ]);

        return response()->json($note);
    }

    public function deleteNote($id) {
    try {
        // Güvenlik: Sadece giriş yapan kullanıcıya ait olan notu bul ve sil
        $note = Note::where('user_id', Auth::id())->findOrFail($id);
        $note->delete();

        return response()->json(['success' => true]);
    } catch (\Exception $e) {
        return response()->json(['error' => 'Not silinemedi'], 500);
    }
}
}