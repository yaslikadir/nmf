<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class LicenseActivationController extends Controller
{
    // Lisans girme ekranını gösterir
    public function showForm()
    {
        return view('license.activate');
    }

    // Formdan gelen lisansı .env dosyasına yazar ve sistemi yeniden başlatır
    public function verifyAndSave(Request $request)
    {
        $request->validate(['license_key' => 'required']);
        $cleanLicenseKey = trim(strtoupper($request->license_key));

        $path = base_path('.env');
        if (file_exists($path)) {
            $oldEnvFile = file_get_contents($path);
            
            if (str_contains($oldEnvFile, 'LICENSE_KEY=')) {
                $newEnvFile = preg_replace('/^LICENSE_KEY=.*/m', 'LICENSE_KEY=' . $cleanLicenseKey, $oldEnvFile);
            } else {
                $newEnvFile = $oldEnvFile . "\nLICENSE_KEY=" . $cleanLicenseKey;
            }
            file_put_contents($path, $newEnvFile);
        }

        // Sistemi uyandır ve cache'i sil
        Artisan::call('config:clear');
        Artisan::call('cache:clear');

        // Ana sayfaya yönlendir (Middleware orada tekrar kontrol edip ya içeri alacak ya da geri buraya atacak)
        return redirect('/')->with('success', 'Lisans kontrol ediliyor, lütfen bekleyin...');
    }
}