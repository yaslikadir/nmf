<?php

namespace App\Http\Controllers;

use App\Models\Device;
use Illuminate\Http\Request;

class PublicDeviceController extends Controller
{
    public function show($inventory_no)
    {
        // Cihazı envanter numarasına göre bul (ID yerine Envanter No daha güvenli ve profesyonel durur)
        $device = Device::where('inventory_no', $inventory_no)
                        ->with(['maintenances', 'calibrations', 'responsible', 'location'])
                        ->firstOrFail();

        return view('public.device-card', compact('device'));
    }
}