<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CheckUserActive
{
    public function handle(Request $request, Closure $next): Response
    {
        if (Auth::check()) {
            $user = Auth::user();

            // 1. Kullanıcı pasifse oturumu kapat
            if (!$user->is_active) {
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();

                return redirect()->route('login')->withErrors([
                    'email' => 'Hesabınız yönetici tarafından pasife alınmıştır. Lütfen Bilgi İşlem ile iletişime geçin.',
                ]);
            }

            // 2. Kullanıcının aktif rolü boşsa veya silinmiş bir role işaret ediyorsa ilk rolünü ata
            if ((!$user->active_role_id || !$user->roles->contains('id', $user->active_role_id)) && $user->roles->count() > 0) {
                $user->active_role_id = $user->roles->first()->id;
                $user->saveQuietly();
            }

            // 3. Session'da aktif şube yoksa kullanıcının yetkili olduğu ilk şubeyi (yoksa 1'i) ata
            if (!session()->has('active_branch_id')) {
                $defaultBranch = null;
                if (method_exists($user, 'branches') && $user->branches()->count() > 0) {
                    $defaultBranch = $user->branches()->orderByDesc('branch_user.is_default')->first();
                }
                if (!$defaultBranch) {
                    $defaultBranch = DB::table('branches')->whereNull('deleted_at')->where('is_active', 1)->orderBy('id')->first();
                }
                if ($defaultBranch) {
                    session([
                        'active_branch_id'   => $defaultBranch->id,
                        'active_branch_name' => $defaultBranch->name,
                    ]);
                }
            }
        }

        return $next($request);
    }
}