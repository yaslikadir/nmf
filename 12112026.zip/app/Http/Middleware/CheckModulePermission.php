<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\RolePermission;

class CheckModulePermission
{
    public function handle(Request $request, Closure $next, string $moduleKey): Response
    {
        $user = auth()->user();

        if (!$user) {
            return redirect()->route('login');
        }

        // Admin ise doğrudan geçir
        if ((method_exists($user, 'isAdmin') && $user->isAdmin()) || (method_exists($user, 'hasRole') && $user->hasRole('admin'))) {
            return $next($request);
        }

        // 1. Kullanıcının aktif bir rolü yoksa ilk rolünü güvenli şekilde ata
        if (!$user->active_role_id && $user->roles->count() > 0) {
            $user->active_role_id = $user->roles->first()->id;
            $user->saveQuietly();
        }

        // 2. Aktif rolün bu modüle "view_level > 0" yetkisi var mı kontrol et
        $hasAccess = RolePermission::where('role_id', $user->active_role_id)
            ->whereHas('module', fn($q) => $q->where('module_key', $moduleKey))
            ->where('view_level', '>', 0)
            ->exists();

        if (!$hasAccess) {
            return redirect()->route('dashboard')->with('error', 'Bu modüle erişim yetkiniz bulunmamaktadır.');
        }

        return $next($request);
    }
}