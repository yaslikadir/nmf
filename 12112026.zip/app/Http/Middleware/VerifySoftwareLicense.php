<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;

class VerifySoftwareLicense
{
    public function handle(Request $request, Closure $next)
    {
        // KYS ERP Lisans kontrolü iptal edildi, kapılar sonuna kadar açık! :)
        return $next($request);
    }
}