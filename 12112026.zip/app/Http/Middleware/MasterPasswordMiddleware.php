<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class MasterPasswordMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        // Eğer session'da 'kasa açıldı' bilgisi yoksa
        if (!session('master_unlocked')) {
            // Kullanıcının gitmek istediği yeri hafızaya al ki şifreyi girince oraya yönlendirelim
            session(['url.intended' => $request->url()]);
            // Şifre sorma ekranına şutla
            return redirect()->route('admin.master.login');
        }

        return $next($request);
    }
}