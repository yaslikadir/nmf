<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

if (!function_exists('canDo')) {
    /**
     * Gelişmiş Yetki Kontrol Helper'ı
     * * @param string $moduleKey Modülün veritabanındaki anahtarı (örn: tasks)
     * @param string $action Aksiyon tipi: 'view', 'create', 'update', 'delete', 'export'
     * @param mixed $record (Opsiyonel) Üzerinde işlem yapılan veritabanı kaydı (Model)
     * @return bool
     */
    function canDo($moduleKey, $action = 'view', $record = null) {
        $user = Auth::user();
        if (!$user) return false;

        // 1. ADMIN VE KALİTE YÖNETİCİSİ HER ZAMAN YETKİLİDİR (God Mode)
        if ($user->isAdmin() || $user->role === 'Kalite Yöneticisi') {
            return true;
        }

        // 2. KULLANICININ AKTİF ROLÜNDEKİ YETKİ SATIRINI BUL
$permission = \App\Models\RolePermission::where('role_id', $user->active_role_id)
    ->whereHas('module', fn($q) => $q->where('module_key', $moduleKey))
    ->first();

        if (!$permission) return false;

        // 3. AKSİYON BAZLI KONTROL
        switch ($action) {
            case 'create':
                return (bool) $permission->can_create;

            case 'export':
                return (bool) $permission->can_export;

            case 'view':
                return checkLevelAccess($permission->view_level, $user, $record);

            case 'update':
                return checkLevelAccess($permission->update_level, $user, $record);

            case 'delete':
                return checkLevelAccess($permission->delete_level, $user, $record);

            default:
                return false;
        }
    }
}

/**
 * Seviye Bazlı (Level 1, 2, 3) Karşılaştırma Mantığı
 */
if (!function_exists('checkLevelAccess')) {
    function checkLevelAccess($level, $user, $record) {
        $level = (int)$level;

        // Seviye 0 ise yetki yok
        if ($level === 0) return false;

        // Seviye 3 ise her şeyi görebilir/işlem yapabilir
        if ($level === 3) return true;

        // Eğer kontrol edilecek bir kayıt (satır) verilmemişse, 
        // Level > 0 olması sayfaya girmek için yeterlidir.
        if (!$record) return $level > 0;

        // SEVİYE 1: Sadece Kendi Kaydı
        if ($level === 1) {
            return isset($record->created_by) && $record->created_by == $user->id;
        }

        // SEVİYE 2: Kendi Departmanının Kaydı
        if ($level === 2) {
            // Kaydı oluşturanın departmanı ile kullanıcının departmanı aynı mı?
            // Not: Record modelinde 'creator' ilişkisi tanımlı olmalı.
            return isset($record->creator->department_id) && $record->creator->department_id == $user->department_id;
        }

        return false;
    }
}