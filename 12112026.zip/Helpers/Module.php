<?php

namespace App\Helpers;

use Illuminate\Support\Facades\File;

class Module
{
    /**
     * Verilen modülün aktif olup olmadığını kontrol eder.
     * Büyük/Küçük harf farklılıklarını tolere eder.
     */
    public static function isEnabled($slug)
    {
        // Olası klasör yolları (Tam eşleşme, İlk harfi büyük, Hepsi küçük)
        $possiblePaths = [
            base_path('modules/' . $slug . '/manifest.json'),
            base_path('modules/' . ucfirst($slug) . '/manifest.json'),
            base_path('modules/' . strtolower($slug) . '/manifest.json'),
        ];

        foreach ($possiblePaths as $path) {
            if (File::exists($path)) {
                $manifest = json_decode(File::get($path), true);
                
                // Manifest dosyası okunduysa ve enabled değeri true ise
                if (isset($manifest['enabled']) && $manifest['enabled'] === true) {
                    return true;
                }
                
                // Dosyayı buldu ama enabled false ise döngüyü kır ve false dön
                return false;
            }
        }

        // Klasör veya manifest dosyası hiç bulunamadıysa pasif say
        return false;
    }
}