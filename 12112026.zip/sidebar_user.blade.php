<style>
/* ═══════════════════════════════════════════════════════════════
   KULLANICI SIDENAV - PROFESYONEL & CREATIVE TASARIM
═══════════════════════════════════════════════════════════════ */
body.dark-mode .topnav {
    background-color: #1e293b !important;
    border-bottom: 1px solid #334155 !important;
}

body.dark-mode .topnav .btn-transparent-dark, 
body.dark-mode .topnav .nav-link, 
body.dark-mode .topnav .navbar-brand,
body.dark-mode .topnav .text-muted {
    color: #f1f5f9 !important;
}

body.dark-mode .topnav #sidebarToggle {
    color: #f1f5f9 !important;
}

body.dark-mode .sidenav {
    background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%) !important;
    border-right: 1px solid rgba(255,255,255,0.05);
}

body.dark-mode .sidenav-menu-heading {
    color: rgba(255,255,255,0.4) !important;
}

body.dark-mode .sidenav-menu-heading::before {
    background: linear-gradient(90deg, rgba(255,255,255,0.1) 0%, transparent 100%);
}

body.dark-mode .sidenav .nav-link {
    color: #cbd5e1 !important;
}

body.dark-mode .sidenav .nav-link:hover {
    color: #fff !important;
    background: rgba(102, 126, 234, 0.15) !important;
}

body.dark-mode .sidenav .nav-link.active {
    color: #818cf8 !important;
    background: linear-gradient(90deg, rgba(102, 126, 234, 0.2) 0%, transparent 100%) !important;
}

body.dark-mode .sidenav-menu-nested {
    background: rgba(0,0,0,0.2);
    border-left: 2px solid rgba(102, 126, 234, 0.3);
}

body.dark-mode .sidenav-menu-nested .nav-link {
    color: #94a3b8 !important;
}

body.dark-mode .sidenav .profile-card {
    background: linear-gradient(135deg, #312e81 0%, #4c1d95 100%);
}

.sidenav .profile-image-wrapper {
    width: 50px;
    height: 50px;
    flex-shrink: 0;
}

.sidenav .profile-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border: 2px solid rgba(255,255,255,0.3);
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
}

.sidenav {
    position: fixed !important;
    top: 0;
    left: 0;
    height: 100vh;
    width: 225px;
    z-index: 1038;
    display: flex;
    flex-direction: column;
    background: linear-gradient(180deg, #f8f9fc 0%, #eef1f6 100%);
    border-right: 1px solid rgba(0,0,0,0.08);
    transition: transform 0.3s ease-in-out;
}

#layoutSidenav_content {
    margin-left: 225px;
    width: calc(100% - 225px);
    transition: margin 0.3s ease-in-out, width 0.3s ease-in-out;
}

.sb-topnav {
    padding-left: 225px;
    transition: padding-left 0.3s ease-in-out;
}

body.sb-sidenav-toggled #layoutSidenav_nav {
    transform: translateX(-225px);
}

body.sb-sidenav-toggled #layoutSidenav_content {
    margin-left: 0;
    width: 100%;
}

body.sb-sidenav-toggled .sb-topnav {
    padding-left: 0;
}

.sidenav .profile-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 0;
    padding: 1.25rem;
    margin: 0;
    position: relative;
    overflow: hidden;
}

.sidenav .profile-card::before {
    content: "";
    position: absolute;
    top: -50%;
    right: -50%;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    pointer-events: none;
}

.sidenav .profile-card .user-name {
    font-weight: 600;
    font-size: 0.95rem;
    color: #fff;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2);
}

.sidenav .profile-card .user-role {
    font-size: 0.65rem;
    color: rgba(255,255,255,0.75);
    text-transform: uppercase;
    letter-spacing: 1px;
    background: rgba(0,0,0,0.2);
    padding: 2px 8px;
    border-radius: 10px;
    display: inline-block;
    margin-top: 4px;
}

.sidenav .profile-card .welcome-text {
    font-size: 0.7rem;
    color: rgba(255,255,255,0.9);
    font-weight: 500;
}

.sidenav-menu {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding-bottom: 1rem;
}

.sidenav-menu::-webkit-scrollbar {
    width: 4px;
}

.sidenav-menu::-webkit-scrollbar-track {
    background: transparent;
}

.sidenav-menu::-webkit-scrollbar-thumb {
    background: rgba(0,0,0,0.12);
    border-radius: 4px;
}

.sidenav-menu::-webkit-scrollbar-thumb:hover {
    background: rgba(0,0,0,0.2);
}

.sidenav-menu-heading {
    font-size: 0.65rem !important;
    font-weight: 700 !important;
    letter-spacing: 1.5px !important;
    text-transform: uppercase !important;
    color: rgba(0,0,0,0.4) !important;
    padding: 1.25rem 1rem 0.5rem 1rem !important;
    margin-top: 0.5rem;
    position: relative;
}

.sidenav-menu-heading::before {
    content: "";
    position: absolute;
    left: 1rem;
    right: 1rem;
    top: 0.5rem;
    height: 1px;
    background: linear-gradient(90deg, rgba(0,0,0,0.08) 0%, transparent 100%);
}

.sidenav .nav-link {
    color: #4a5568 !important;
    padding: 0.75rem 1rem !important;
    font-size: 0.8rem !important;
    font-weight: 500 !important;
    letter-spacing: 0.3px;
    transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
    border-left: 3px solid transparent;
    margin: 2px 0;
    position: relative;
}

.sidenav .nav-link:hover {
    color: #1a202c !important;
    background: rgba(102, 126, 234, 0.08) !important;
    border-left-color: rgba(102, 126, 234, 0.5);
}

.sidenav .nav-link.active {
    color: #667eea !important;
    background: linear-gradient(90deg, rgba(102, 126, 234, 0.12) 0%, transparent 100%) !important;
    border-left-color: #667eea !important;
}

.sidenav .nav-link-icon.icon-inventory { background: rgba(245, 158, 11, 0.15); color: #f59e0b !important; }

.sidenav .nav-link-icon {
    width: 32px;
    height: 32px;
    min-width: 32px;
    display: inline-flex !important;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    margin-right: 0.75rem !important;
    transition: all 0.25s ease;
    font-size: 0.9rem;
    flex-shrink: 0;
}

.sidenav .nav-link-icon svg,
.sidenav .nav-link-icon i {
    width: 16px !important;
    height: 16px !important;
    display: block;
}

.sidenav .nav-link-icon.icon-home { background: rgba(99, 102, 241, 0.15); color: #818cf8 !important; }
.sidenav .nav-link-icon.icon-customer { background: rgba(16, 185, 129, 0.15); color: #34d399 !important; }
.sidenav .nav-link-icon.icon-activity { background: rgba(14, 165, 233, 0.15); color: #38bdf8 !important; }
.sidenav .nav-link-icon.icon-request { background: rgba(245, 158, 11, 0.15); color: #fbbf24 !important; }
.sidenav .nav-link-icon.icon-offer { background: rgba(99, 102, 241, 0.15); color: #818cf8 !important; }
.sidenav .nav-link-icon.icon-sample { background: rgba(239, 68, 68, 0.15); color: #f87171 !important; }
.sidenav .nav-link-icon.icon-planning { background: rgba(168, 85, 247, 0.15); color: #c084fc !important; }
.sidenav .nav-link-icon.icon-analysis { background: rgba(34, 197, 94, 0.15); color: #4ade80 !important; }
.sidenav .nav-link-icon.icon-device { background: rgba(107, 114, 128, 0.15); color: #9ca3af !important; }
.sidenav .nav-link-icon.icon-report { background: rgba(59, 130, 246, 0.15); color: #60a5fa !important; }

.sidenav .nav-link:hover .nav-link-icon {
    transform: scale(1.05);
}

.sidenav-collapse-arrow {
    margin-left: auto;
    transition: transform 0.3s ease;
}

.sidenav .nav-link:not(.collapsed) .sidenav-collapse-arrow {
    transform: rotate(180deg);
}

.sidenav-menu-nested {
    background: rgba(102, 126, 234, 0.04);
    border-left: 2px solid rgba(102, 126, 234, 0.15);
    margin-left: 1.5rem;
    padding: 0.5rem 0;
    border-radius: 0 0 0 8px;
}

.sidenav-menu-nested .nav-link {
    padding: 0.5rem 1rem 0.5rem 0.75rem !important;
    font-size: 0.75rem !important;
    font-weight: 400 !important;
    color: #64748b !important;
    border-left: none !important;
}

.sidenav-menu-nested .nav-link:hover {
    color: #1a202c !important;
    background: rgba(102, 126, 234, 0.06) !important;
    padding-left: 1rem !important;
}

.sidenav-menu-nested .nav-link.active {
    color: #667eea !important;
    background: transparent !important;
}

.sidenav-menu-nested .nav-link .dot-icon {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 0.75rem;
    transition: all 0.2s ease;
}

.sidenav-menu-nested .nav-link:hover .dot-icon {
    transform: scale(1.3);
    box-shadow: 0 0 8px currentColor;
}

.badge-notification {
    background-color: #ef4444;
    color: white;
    font-size: 0.65rem;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: auto;
    box-shadow: 0 0 5px rgba(239, 68, 68, 0.4);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 18px;
}

@media (max-width: 991.98px) {
    .sidenav {
        transform: translateX(-225px);
        z-index: 1041;
    }

    body.sb-sidenav-toggled .sidenav {
        transform: translateX(0);
    }

    #layoutSidenav_content {
        margin-left: 0;
        width: 100%;
    }

    .sb-topnav {
        padding-left: 0;
    }

    body.sb-sidenav-toggled::after {
        content: "";
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0,0,0,0.5);
        z-index: 1030;
        display: block;
    }
}
</style>

@php
    $user = auth()->user();

    // 1. Kullanıcının aktif rolü boşsa ilk rolünü güvenli şekilde ata
    if ($user && !$user->active_role_id && $user->roles && $user->roles->count() > 0) {
        $user->active_role_id = $user->roles->first()->id;
        $user->saveQuietly();
    }

    // 2. Aktif Rol ve Admin Kontrolü:
    // Kullanıcı sağ üstten başka bir role geçiş yaptığında o rolün yetkilerini test edebilmesi için
    // önce seçili olan aktif rolün 'admin' olup olmadığına bakıyoruz!
    $isAdmin = false;
    $isAnalystRole = false;
    if ($user) {
        if ($user->activeRole) {
            $activeRoleName = mb_strtolower(trim($user->activeRole->name));
            $isAdmin = ($activeRoleName === 'admin');
            $isAnalystRole = ($activeRoleName === 'analyst' || $activeRoleName === 'analist');
        } else {
            $isAdmin = (method_exists($user, 'isAdmin') && $user->isAdmin());
            $isAnalystRole = (method_exists($user, 'hasRole') && $user->hasRole('analyst'));
        }
    }

    // 3. Aktif rolün tüm modül izinlerini (view_level) tek sorguda çek
    $moduleViewLevels = [];
    if ($user && $user->active_role_id) {
        try {
            $moduleViewLevels = \Illuminate\Support\Facades\DB::table('role_permissions')
                ->join('modules', 'role_permissions.module_id', '=', 'modules.id')
                ->where('role_permissions.role_id', $user->active_role_id)
                ->pluck('role_permissions.view_level', 'modules.module_key')
                ->map(fn($v) => (int) $v)
                ->toArray();
        } catch (\Throwable $e) {
            $moduleViewLevels = [];
        }
    }

    // 4. Aktif rolün sabit menü izinlerini (menu_permissions) güvenli dizi olarak al
    $roleMenuPerms = [];
    if ($user && $user->active_role_id) {
        try {
            $rawMenuPerms = \Illuminate\Support\Facades\DB::table('roles')
                ->where('id', $user->active_role_id)
                ->value('menu_permissions');
            if (is_string($rawMenuPerms)) {
                $decoded = json_decode($rawMenuPerms, true);
                $roleMenuPerms = is_array($decoded) ? $decoded : [];
            } elseif (is_array($rawMenuPerms)) {
                $roleMenuPerms = $rawMenuPerms;
            }
        } catch (\Throwable $e) {
            $roleMenuPerms = [];
        }
    }

    // 5. Yardımcı Kontroller (Doğrudan role_permissions ve menu_permissions tablosundan okur)
    $canMod = function (string $moduleKey, int $minLevel = 1) use ($isAdmin, $moduleViewLevels): bool {
        if ($isAdmin) return true;
        return ($moduleViewLevels[$moduleKey] ?? 0) >= $minLevel;
    };

    $modLevel = function (string $moduleKey) use ($isAdmin, $moduleViewLevels): int {
        if ($isAdmin) return 3;
        return $moduleViewLevels[$moduleKey] ?? 0;
    };

    $canMenu = function (string $menuKey) use ($isAdmin, $roleMenuPerms): bool {
        if ($isAdmin) return true;
        return in_array($menuKey, $roleMenuPerms, true) || !empty($roleMenuPerms[$menuKey]);
    };

    $modEnabled = function (string $slug): bool {
        try {
            if (class_exists('\App\Helpers\Module') && method_exists('\App\Helpers\Module', 'isEnabled')) {
                return \App\Helpers\Module::isEnabled($slug)
                    || \App\Helpers\Module::isEnabled(ucfirst(strtolower($slug)))
                    || \App\Helpers\Module::isEnabled(strtolower($slug));
            }
        } catch (\Throwable $e) {}
        return true;
    };

    // 6. Bekleyen Teklif (İş Dosyası) Sayısını Güvenli Hesapla
    $pendingOfferCount = 0;
    try {
        if (class_exists('\Modules\Sales\Models\Offer')) {
            $pendingOfferCount = \Modules\Sales\Models\Offer::whereHas('samples', function($q) {
                $q->whereIn('global_status', ['Laboratuvara Alındı', 'Ön İşlem Bekliyor', 'Ön İşlemde'])
                  ->orWhere(function($subQ) {
                      $subQ->where('status', 'Kabul Edildi')->whereNull('lab_accepted_at');
                  });
            })->count();
        }
    } catch (\Throwable $e) {
        $pendingOfferCount = 0;
    }

    $purLevel = $modLevel('purchase');
    $supLevel = $modLevel('suppliers');
    $trLevel  = $modLevel('qms_trainings');
@endphp

<nav class="sidenav shadow-right sidenav-light" id="sidenavAccordion">
    <div class="sidenav-menu">
        
        {{-- PROFİL KARTI --}}
        <div class="profile-card d-flex align-items-center">
            <div class="profile-image-wrapper me-3">
                <img class="profile-image rounded-circle" src="{{ $user && $user->profile_photo ? asset($user->profile_photo) : asset('assets/img/illustrations/profiles/profile-1.png') }}" alt="Profil Resmi" />
            </div>
            <div class="d-flex flex-column">
                <span class="welcome-text">Hoşgeldin</span>
                <span class="user-name">{{ $user->name ?? 'Kullanıcı' }}</span>
                <span class="user-role">{{ $user->activeRole?->name ?? 'Kullanıcı' }}</span>
            </div>
        </div>

        <div class="nav accordion" id="accordionUserSidenav">
            
            {{-- ANA SAYFA (Herkes Görür) --}}
            <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ Route::has('dashboard') ? route('dashboard') : '#' }}">
                <div class="nav-link-icon icon-home"><i data-feather="home"></i></div>
                Ana Sayfa
            </a>

            {{-- =================================================== --}}
            {{-- 1. BÖLÜM: CRM & SATIŞ YÖNETİMİ                      --}}
            {{-- =================================================== --}}
            @if($canMod('customers') || $canMod('requests') || $canMod('offers') || $canMod('offer_templates') || $canMod('contacts') || $canMod('activities') || $canMod('meetings'))
            <div class="sidenav-menu-heading small text-muted">Müşteri İlişkileri</div>

                {{-- MÜŞTERİLER --}}
                @if($modEnabled('Customers') && ($canMod('customers') || $canMod('contacts') || $canMod('activities')))
                <a class="nav-link {{ request()->is('admin/customers*') || request()->is('admin/contacts*') || request()->is('admin/activities*') ? 'active' : 'collapsed' }}" 
                   href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseMusteri">
                    <div class="nav-link-icon icon-customer"><i data-feather="users"></i></div>
                    Müşteri Yönetimi
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse {{ request()->is('admin/customers*') || request()->is('admin/contacts*') || request()->is('admin/activities*') ? 'show' : '' }}" id="collapseMusteri" data-bs-parent="#accordionUserSidenav">
                    <nav class="sidenav-menu-nested nav">
                        @if($canMod('customers'))
                        <a class="nav-link {{ request()->is('admin/customers*') ? 'active' : '' }}" href="{{ Route::has('admin.customers.index') ? route('admin.customers.index') : '#' }}"><span class="dot-icon" style="background: #34d399;"></span>Müşteriler</a>
                        @endif
                        @if($canMod('contacts'))
                        <a class="nav-link {{ request()->is('admin/contacts*') ? 'active' : '' }}" href="{{ Route::has('admin.contacts.index') ? route('admin.contacts.index') : '#' }}"><span class="dot-icon" style="background: #34d399;"></span>Kontaklar</a>
                        @endif
                        @if($canMod('activities'))
                        <a class="nav-link {{ request()->is('admin/activities*') ? 'active' : '' }}" href="{{ Route::has('admin.activities.index') ? route('admin.activities.index') : '#' }}"><span class="dot-icon" style="background: #38bdf8;"></span>Görüşme Kayıtları</a>
                        @endif
                    </nav>
                </div>
                @endif

                {{-- TOPLANTI & AJANDA YÖNETİMİ --}}
                @if($modEnabled('Meetings') && $canMod('meetings'))
                <a class="nav-link {{ request()->is('admin/meetings*') ? 'active' : 'collapsed' }}" 
                   href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseMeetings">
                    <div class="nav-link-icon icon-meeting"><i data-feather="calendar"></i></div>
                    Toplantı & Ajanda
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse {{ request()->is('admin/meetings*') ? 'show' : '' }}" id="collapseMeetings" data-bs-parent="#accordionUserSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="{{ Route::has('admin.meetings.dashboard') ? route('admin.meetings.dashboard') : '#' }}"><span class="dot-icon" style="background: #a855f7;"></span>Dashboard</a>
                        <a class="nav-link" href="{{ Route::has('admin.meetings.index') ? route('admin.meetings.index') : '#' }}"><span class="dot-icon" style="background: #ec4899;"></span>Toplantılar</a>
                    </nav>
                </div>
                @endif

                {{-- SATIŞ SÜRECİ --}}
                @if($modEnabled('Sales') && ($canMod('requests') || $canMod('offers') || $canMod('offer_templates')))
                <a class="nav-link {{ request()->is('admin/requests*') || request()->is('admin/offers*') || request()->is('admin/offer-templates*') ? 'active' : 'collapsed' }}" 
                   href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseSatis">
                    <div class="nav-link-icon icon-offer"><i data-feather="briefcase"></i></div>
                    Satış Yönetimi
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse {{ request()->is('admin/requests*') || request()->is('admin/offers*') || request()->is('admin/offer-templates*') ? 'show' : '' }}" id="collapseSatis" data-bs-parent="#accordionUserSidenav">
                    <nav class="sidenav-menu-nested nav">
                        @if($canMod('requests'))
                        <a class="nav-link {{ request()->is('admin/requests*') ? 'active' : '' }}" href="{{ Route::has('admin.requests.index') ? route('admin.requests.index') : '#' }}"><span class="dot-icon" style="background: #fbbf24;"></span>Müşteri Talepleri</a>
                        @endif
                        @if($canMod('offers'))
                        <a class="nav-link {{ request()->is('admin/offers*') ? 'active' : '' }}" href="{{ Route::has('admin.offers.index') ? route('admin.offers.index') : '#' }}"><span class="dot-icon" style="background: #818cf8;"></span>Teklifler</a>
                        @endif
                        @if($canMod('offer_templates'))
                        <a class="nav-link {{ request()->is('admin/offer-templates*') ? 'active' : '' }}" href="{{ Route::has('admin.offer-templates.index') ? route('admin.offer-templates.index') : '#' }}"><span class="dot-icon" style="background: #64748b;"></span>Teklif Şablonları</a>
                        @endif
                    </nav>
                </div>
                @endif
            @endif

            {{-- =================================================== --}}
            {{-- 2. BÖLÜM: LABORATUVAR & NUMUNE (LIMS)               --}}
            {{-- =================================================== --}}
            @if($canMod('lims') || $canMod('sample_management') || $canMod('sample_transfers') || $canMod('storage_locations') || $canMod('sample_disposals') || $canMod('test_management') || $canMod('reporting') || $canMod('methods') || $canMod('sample_preparations') || $canMod('parameters') || ($modEnabled('ReportArchive') && $canMod('reporting')))
            <div class="sidenav-menu-heading small text-muted">Laboratuvar (LIMS)</div>

                {{-- NUMUNE YÖNETİMİ --}}
                @if($modEnabled('Samples') && ($canMod('sample_management') || $canMod('sample_transfers') || $canMod('storage_locations') || $canMod('sample_disposals')))
                <a class="nav-link {{ request()->is('admin/samples*') || request()->is('admin/sample-management*') || request()->is('admin/sample-transfers*') || request()->is('admin/sample-disposals*') || request()->is('admin/barcode-tracker*') || request()->is('admin/storage-locations*') ? 'active' : 'collapsed' }}" 
                   href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseNumune">
                    <div class="nav-link-icon icon-sample"><i data-feather="package"></i></div>
                    Numune Yönetimi
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse {{ request()->is('admin/samples*') || request()->is('admin/sample-management*') || request()->is('admin/sample-transfers*') || request()->is('admin/sample-disposals*') || request()->is('admin/barcode-tracker*') || request()->is('admin/storage-locations*') ? 'show' : '' }}" id="collapseNumune" data-bs-parent="#accordionUserSidenav">
                    <nav class="sidenav-menu-nested nav">
                        @if($canMod('sample_management'))
                        <a class="nav-link {{ request()->is('admin/samples/create') ? 'active' : '' }}" href="{{ Route::has('admin.samples.create') ? route('admin.samples.create') : '#' }}"><span class="dot-icon" style="background: #f87171;"></span>Barkod Oluştur</a>
                        <a class="nav-link {{ request()->is('admin/sample-management*') ? 'active' : '' }}" href="{{ Route::has('admin.sample-management.index') ? route('admin.sample-management.index') : '#' }}"><span class="dot-icon" style="background: #f87171;"></span>Kabul & Takip</a>
                        <a class="nav-link {{ request()->is('admin/barcode-tracker*') ? 'active' : '' }}" href="{{ Route::has('admin.barcode-tracker.index') ? route('admin.barcode-tracker.index') : '#' }}">
                            <span class="dot-icon" style="background: #3b82f6;"></span>BKM
                        </a>
                        @endif

                        @if($canMod('sample_transfers'))
                        <a class="nav-link {{ request()->is('admin/sample-transfers*') ? 'active' : '' }}" href="{{ Route::has('admin.sample-transfers.index') ? route('admin.sample-transfers.index') : '#' }}"><span class="dot-icon" style="background: #f87171;"></span>Transfer & Lojistik</a>
                        @endif
                        @if($canMod('sample_disposals'))
                        <a class="nav-link {{ request()->is('admin/sample-disposals*') ? 'active' : '' }}" href="{{ Route::has('admin.sample-disposals.index') ? route('admin.sample-disposals.index') : '#' }}"><span class="dot-icon" style="background: #dc2626;"></span>Numune İmha</a>
                        @endif
                        @if($canMod('storage_locations'))
                        <a class="nav-link {{ request()->is('admin/storage-locations*') ? 'active' : '' }}" href="{{ Route::has('admin.storage-locations.index') ? route('admin.storage-locations.index') : '#' }}"><span class="dot-icon" style="background: #9ca3af;"></span>Depo Tanımları</a>
                        @endif
                    </nav>
                </div>
                @endif

                {{-- ANALİZ & RAPORLAMA --}}
                @if(($modEnabled('Analysis') && ($canMod('test_management') || $canMod('reporting') || $canMod('methods') || $canMod('sample_preparations') || $canMod('parameters'))) || ($modEnabled('ReportArchive') && $canMod('reporting')))
                <a class="nav-link {{ request()->is('admin/test-management*') || request()->is('admin/methods*') || request()->is('admin/reporting*') || request()->is('admin/report-archive*') || request()->is('admin/sample-preparations*') || request()->is('admin/scope-parameters*') ? 'active' : 'collapsed' }}" 
                   href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseAnaliz">
                    <div class="nav-link-icon icon-analysis"><i class="fas fa-flask"></i></div>
                    Analiz & Rapor
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse {{ request()->is('admin/test-management*') || request()->is('admin/methods*') || request()->is('admin/reporting*') || request()->is('admin/report-archive*') || request()->is('admin/sample-preparations*') || request()->is('admin/scope-parameters*') ? 'show' : '' }}" id="collapseAnaliz" data-bs-parent="#accordionUserSidenav">
                    <nav class="sidenav-menu-nested nav">
                        @if($canMod('sample_preparations'))
                            <a class="nav-link d-flex align-items-center {{ request()->is('admin/sample-preparations*') ? 'active' : '' }}" href="{{ Route::has('admin.sample-preparations.index') ? route('admin.sample-preparations.index') : '#' }}">
                                <span class="dot-icon" style="background: #4ade80;"></span>
                                <span class="me-auto">Ön İşlem & Hazırlık</span>
                                @if(!empty($pendingOfferCount) && $pendingOfferCount > 0)
                                    <span class="badge-notification">{{ $pendingOfferCount }}</span>
                                @endif
                            </a>
                        @endif
                        
                        @if($canMod('test_management'))
                            @if($isAnalystRole && !$isAdmin)
                                <a class="nav-link {{ request()->is('admin/test-management*') ? 'active' : '' }}" href="{{ Route::has('admin.test-management.index') ? route('admin.test-management.index') : '#' }}">
                                    <span class="dot-icon" style="background: #3b82f6;"></span>Analiz Görevlerim
                                </a>
                            @else
                                <a class="nav-link {{ request()->is('admin/test-management*') ? 'active' : '' }}" href="{{ Route::has('admin.test-management.index') ? route('admin.test-management.index') : '#' }}">
                                    <span class="dot-icon" style="background: #4ade80;"></span>Analiz İş Emirleri
                                </a>
                            @endif
                        @endif

                        @if($canMod('reporting'))
                        <a class="nav-link {{ request()->is('admin/reporting*') ? 'active' : '' }}" href="{{ Route::has('admin.reporting.index') ? route('admin.reporting.index') : '#' }}"><span class="dot-icon" style="background: #16a34a;"></span>Raporlama & Onay</a>
                        @endif
                        @if($modEnabled('ReportArchive') && $canMod('reporting'))
                        <a class="nav-link {{ request()->is('admin/report-archive*') ? 'active' : '' }}" href="{{ Route::has('admin.report-archive.index') ? route('admin.report-archive.index') : '#' }}"><span class="dot-icon" style="background: #0ea5e9;"></span>QR Rapor Arşivi</a>
                        @endif
                        @if($canMod('methods'))
                        <a class="nav-link {{ request()->is('admin/methods*') ? 'active' : '' }}" href="{{ Route::has('admin.methods.index') ? route('admin.methods.index') : '#' }}"><span class="dot-icon" style="background: #86efac;"></span>Metot Yönetimi</a>
                        @endif
                        @if($canMod('parameters'))
                        <a class="nav-link {{ request()->is('admin/scope-parameters*') ? 'active' : '' }}" href="{{ Route::has('admin.scope-parameters.index') ? route('admin.scope-parameters.index') : '#' }}"><span class="dot-icon" style="background: #86efac;"></span>Parametreler</a>
                        @endif
                    </nav>
                </div>
                @endif
            @endif

            @if($canMod('reporting'))
            <a class="nav-link {{ request()->is('admin/standart-raporlar*') || request()->is('admin/laboratuvar-yeterlilik-takibi*') ? 'active' : 'collapsed' }}" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseRaporlar" aria-expanded="{{ request()->is('admin/standart-raporlar*') || request()->is('admin/laboratuvar-yeterlilik-takibi*') ? 'true' : 'false' }}">
                <div class="nav-link-icon"><i class="fas fa-chart-bar"></i></div>Raporlar<div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse {{ request()->is('admin/standart-raporlar*') || request()->is('admin/laboratuvar-yeterlilik-takibi*') ? 'show' : '' }}" id="collapseRaporlar" data-bs-parent="#accordionUserSidenav">
                <nav class="sidenav-menu-nested nav">
                    <a class="nav-link {{ request()->is('admin/standart-raporlar*') ? 'active' : '' }}" href="{{ route('admin.standart-raporlar.index') }}"><span class="dot-icon" style="background: #38bdf8;"></span>Standart Raporlar</a>
                    <a class="nav-link {{ request()->is('admin/laboratuvar-yeterlilik-takibi*') ? 'active' : '' }}" href="{{ route('admin.laboratuvar-yeterlilik.index') }}"><span class="dot-icon" style="background: #38bdf8;"></span>Yeterlilik Takibi</a>
                </nav>
            </div>
            @endif

            {{-- =================================================== --}}
            {{-- 3. BÖLÜM: PLANLAMA & SAHA OPERASYON                 --}}
            {{-- =================================================== --}}
            @if($modEnabled('Planning') && ($canMod('planning') || $canMod('planning_calendar') || $canMod('tasks')))
            <div class="sidenav-menu-heading small text-muted">Planlama & Saha Operasyon</div>

            <a class="nav-link {{ request()->is('admin/planning*') || request()->is('admin/tasks*') ? 'active' : 'collapsed' }}" 
               href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapsePlanlama">
                <div class="nav-link-icon icon-planning"><i data-feather="trello"></i></div>
                İş Planlama
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse {{ request()->is('admin/planning*') || request()->is('admin/tasks*') ? 'show' : '' }}" id="collapsePlanlama" data-bs-parent="#accordionUserSidenav">
                <nav class="sidenav-menu-nested nav">
                    @if($canMod('planning'))
                    <a class="nav-link {{ request()->is('admin/planning*') && !request()->is('admin/planning/calendar*') ? 'active' : '' }}" href="{{ Route::has('admin.planning.index') ? route('admin.planning.index') : '#' }}"><span class="dot-icon" style="background: #c084fc;"></span>Ölçüm Planlama</a>
                    @endif
                    @if($canMod('planning_calendar'))
                    <a class="nav-link {{ request()->is('admin/planning/calendar*') ? 'active' : '' }}" href="{{ Route::has('admin.planning.calendar') ? route('admin.planning.calendar') : '#' }}"><span class="dot-icon" style="background: #c084fc;"></span>Ölçüm Takvimi</a>
                    @endif
                    @if($canMod('tasks'))
                    <a class="nav-link {{ request()->is('admin/tasks*') ? 'active' : '' }}" href="{{ Route::has('admin.tasks.index') ? route('admin.tasks.index') : '#' }}"><span class="dot-icon" style="background: #c084fc;"></span>Görev Yönetimi</a>
                    @endif
                </nav>
            </div>
            @endif

            {{-- =================================================== --}}
            {{-- 4. BÖLÜM: ENVANTER & KAYNAKLAR                      --}}
            {{-- =================================================== --}}
            @if($modEnabled('Inventory') && ($canMod('materials') || $canMod('devices')))
            <div class="sidenav-menu-heading small text-muted">Kaynak Yönetimi</div>
            <a class="nav-link {{ request()->is('admin/materials*') || request()->is('admin/devices*') || request()->is('admin/inventory*') ? 'active' : 'collapsed' }}" 
               href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseStok">
                <div class="nav-link-icon icon-inventory"><i data-feather="box"></i></div>
                Stok & Cihaz
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse {{ request()->is('admin/materials*') || request()->is('admin/devices*') || request()->is('admin/inventory*') ? 'show' : '' }}" id="collapseStok" data-bs-parent="#accordionUserSidenav">
                <nav class="sidenav-menu-nested nav">
                    @if($canMod('materials'))
                    <a class="nav-link {{ request()->routeIs('admin.materials.index') ? 'active' : '' }}" href="{{ Route::has('admin.materials.index') ? route('admin.materials.index') : '#' }}"><span class="dot-icon" style="background: #f59e0b;"></span>RM / CRM / Kimyasal</a>
                    <a class="nav-link {{ request()->routeIs('admin.materials.movements') ? 'active' : '' }}" href="{{ Route::has('admin.materials.movements') ? route('admin.materials.movements') : '#' }}"><span class="dot-icon" style="background: #f59e0b;"></span>Stok Hareketleri</a>
                    @endif
                    @if($canMod('devices'))
                    <a class="nav-link {{ request()->is('admin/devices*') ? 'active' : '' }}" href="{{ Route::has('admin.devices.index') ? route('admin.devices.index') : '#' }}"><span class="dot-icon" style="background: #f59e0b;"></span>Cihazlar & Kalibrasyon</a>
                    @endif
                </nav>
            </div>
            @endif

            {{-- =================================================== --}}
            {{-- 5. BÖLÜM: SATIN ALMA & TEDARİK                      --}}
            {{-- =================================================== --}}
            @if($modEnabled('Purchasing') && ($purLevel > 0 || $supLevel > 0))
            <div class="sidenav-menu-heading small text-muted">Satın Alma & Lojistik</div>

            <a class="nav-link {{ request()->is('admin/purchase*') || request()->is('admin/suppliers*') ? 'active' : 'collapsed' }}" 
               href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseSatinAlma">
                <div class="nav-link-icon" style="background: rgba(236, 72, 153, 0.15); color: #ec4899;"><i data-feather="shopping-cart"></i></div>
                Satın Alma
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse {{ request()->is('admin/purchase*') || request()->is('admin/suppliers*') ? 'show' : '' }}" id="collapseSatinAlma" data-bs-parent="#accordionUserSidenav">
                <nav class="sidenav-menu-nested nav">
                    @if($supLevel > 0)
                    <a class="nav-link {{ request()->routeIs('admin.suppliers.*') ? 'active' : '' }}" href="{{ Route::has('admin.suppliers.index') ? route('admin.suppliers.index') : '#' }}"><span class="dot-icon" style="background: #ec4899;"></span>Tedarikçiler</a>
                    @endif

                    @if($purLevel >= 1)
                    <a class="nav-link {{ request()->routeIs('admin.purchase.requests.*') ? 'active' : '' }}" href="{{ Route::has('admin.purchase.requests.index') ? route('admin.purchase.requests.index') : '#' }}"><span class="dot-icon" style="background: #ec4899;"></span>Satın Alma Talepleri</a>
                    @endif
                    
                    @if($purLevel >= 2)
                    <a class="nav-link {{ request()->routeIs('admin.purchase.offers.*') ? 'active' : '' }}" href="{{ Route::has('admin.purchase.offers.index') ? route('admin.purchase.offers.index') : '#' }}"><span class="dot-icon" style="background: #ec4899;"></span>Alınan Teklifler</a>
                    <a class="nav-link {{ request()->routeIs('admin.purchase.orders.*') ? 'active' : '' }}" href="{{ Route::has('admin.purchase.orders.index') ? route('admin.purchase.orders.index') : '#' }}"><span class="dot-icon" style="background: #ec4899;"></span>Siparişler</a>
                    @endif
                </nav>
            </div>
            @endif
            
            {{-- =================================================== --}}
            {{-- 6. BÖLÜM: KALİTE YÖNETİMİ (QMS)                     --}}
            {{-- =================================================== --}}
            @if($modEnabled('Qms') && ($canMod('qms') || $canMod('qms_documents') || $canMod('qms_changes') || $trLevel > 0 || $canMod('qms_plans') || $canMod('qms_requests') || $canMod('qms_my_trainings') || $canMod('qms_audits') || $canMod('qms_capas') || $canMod('qms_feedbacks') || $canMod('qms_risks') || $canMod('qms_emergency')))
            <div class="sidenav-menu-heading small text-muted">Kalite & Uyumluluk</div>

            <a class="nav-link {{ request()->is('admin/qms*') || request()->is('admin/kullanim-kilavuzu*') ? 'active' : 'collapsed' }}" 
               href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseQMS">
                <div class="nav-link-icon text-info"><i class="fas fa-certificate"></i></div>
                Kalite Yönetimi (QMS)
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>

            <div class="collapse {{ request()->is('admin/qms*') || request()->is('admin/kullanim-kilavuzu*') ? 'show' : '' }}" id="collapseQMS" data-bs-parent="#accordionUserSidenav">
                <nav class="sidenav-menu-nested nav accordion" id="accordionQMSPages">
                    @if($canMod('qms_documents'))
                    <a class="nav-link {{ request()->routeIs('admin.qms.documents.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.documents.index') ? route('admin.qms.documents.index') : '#' }}">
                        <span class="dot-icon" style="background: #0ea5e9;"></span>Doküman Yönetimi
                    </a>
                    @endif
                    @if($canMod('qms_changes'))
                    <a class="nav-link {{ request()->routeIs('admin.qms.changes.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.changes.index') ? route('admin.qms.changes.index') : '#' }}">
                        <span class="dot-icon" style="background: #6366f1;"></span>Değişiklik Yönetimi
                    </a>
                    @endif

                    {{-- EĞİTİM YÖNETİMİ BLOK --}}
                    @if($trLevel > 0)
                    <a class="nav-link {{ request()->routeIs('admin.qms.trainings.*') || request()->routeIs('admin.qms.plans.*') || request()->routeIs('admin.qms.requests.*') || request()->routeIs('admin.qms.my-trainings.*') ? 'active' : 'collapsed' }}" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseEgitim">
                        <span class="dot-icon" style="background: #8b5cf6;"></span>Eğitim Yönetimi
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse {{ request()->routeIs('admin.qms.trainings.*') || request()->routeIs('admin.qms.plans.*') || request()->routeIs('admin.qms.requests.*') || request()->routeIs('admin.qms.my-trainings.*') ? 'show' : '' }}" id="collapseEgitim" data-bs-parent="#accordionQMSPages">
                        <nav class="sidenav-menu-nested nav">
                            @if($trLevel >= 2)
                            <a class="nav-link {{ request()->routeIs('admin.qms.trainings.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.trainings.index') ? route('admin.qms.trainings.index') : '#' }}">Eğitim Tanımları</a>
                            <a class="nav-link {{ request()->routeIs('admin.qms.plans.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.plans.index') ? route('admin.qms.plans.index') : '#' }}">Yıllık Planlar</a>
                            <a class="nav-link {{ request()->routeIs('admin.qms.requests.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.requests.index') ? route('admin.qms.requests.index') : '#' }}">Eğitim Talepleri</a>
                            @endif

                            @if($trLevel >= 1)
                            <a class="nav-link {{ request()->routeIs('admin.qms.my-trainings.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.my-trainings.index') ? route('admin.qms.my-trainings.index') : '#' }}">Eğitimlerim (Personel)</a>
                            @endif
                        </nav>
                    </div>
                    @endif

                    @if($canMod('qms_audits'))
                    <a class="nav-link {{ request()->routeIs('admin.qms.audits.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.audits.plans.index') ? route('admin.qms.audits.plans.index') : '#' }}">
                        <span class="dot-icon" style="background: #f59e0b;"></span>Denetimler (Audit)
                    </a>
                    @endif
                    @if($canMod('qms_capas'))
                    <a class="nav-link {{ request()->routeIs('admin.qms.capas.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.capas.index') ? route('admin.qms.capas.index') : '#' }}">
                        <span class="dot-icon" style="background: #e11d48;"></span>DÖF / CAPA
                    </a>
                    @endif
                    @if($canMod('qms_feedbacks'))
                    <a class="nav-link {{ request()->routeIs('admin.qms.feedbacks.*') ? 'active' : 'collapsed' }}" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapsefedSub">
                        <span class="dot-icon" style="background: #14b8a6;"></span>Geri Bildirimler
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse {{ request()->routeIs('admin.qms.feedbacks.*') ? 'show' : '' }}" id="collapsefedSub" data-bs-parent="#accordionQMSPages">
                        <nav class="sidenav-menu-nested nav">
                            <a class="nav-link {{ request()->routeIs('admin.qms.feedbacks.index') ? 'active' : '' }}" href="{{ Route::has('admin.qms.feedbacks.index') ? route('admin.qms.feedbacks.index') : '#' }}">Geri Bildirimler</a>
                            <a class="nav-link {{ request()->routeIs('admin.qms.feedbacks.forms') ? 'active' : '' }}" href="{{ Route::has('admin.qms.feedbacks.forms') ? route('admin.qms.feedbacks.forms') : '#' }}">Linkler</a>
                        </nav>
                    </div>
                    @endif
                    @if($canMod('qms_risks'))
                    <a class="nav-link {{ request()->routeIs('admin.qms.risks.*') || request()->routeIs('admin.qms.emergency-plans.*') ? 'active' : 'collapsed' }}" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseRiskSub">
                        <span class="dot-icon" style="background: #dc2626;"></span>Risk & Acil Durum
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse {{ request()->routeIs('admin.qms.risks.*') || request()->routeIs('admin.qms.emergency-plans.*') ? 'show' : '' }}" id="collapseRiskSub" data-bs-parent="#accordionQMSPages">
                        <nav class="sidenav-menu-nested nav">
                            <a class="nav-link {{ request()->routeIs('admin.qms.risks.dashboard') ? 'active' : '' }}" href="{{ Route::has('admin.qms.risks.dashboard') ? route('admin.qms.risks.dashboard') : '#' }}">Risk Paneli</a>
                            <a class="nav-link {{ request()->routeIs('admin.qms.risks.index') ? 'active' : '' }}" href="{{ Route::has('admin.qms.risks.index') ? route('admin.qms.risks.index') : '#' }}">Risk Kayıtları</a>
                            <a class="nav-link {{ request()->routeIs('admin.qms.emergency-plans.*') ? 'active' : '' }}" href="{{ Route::has('admin.qms.emergency-plans.index') ? route('admin.qms.emergency-plans.index') : '#' }}">Acil Durum Planları</a>
                        </nav>
                    </div>
                    @endif

                    @if($isAdmin && Route::has('admin.knowledge-base.index'))
                    <a class="nav-link {{ request()->is('admin/kullanim-kilavuzu*') ? 'active' : '' }}"
                       href="{{ route('admin.knowledge-base.index') }}">
                        <span class="dot-icon" style="background: #0f766e;"></span>
                        Kullanım Kılavuzu / Wiki
                    </a>
                    @endif
                </nav>
            </div>
            @endif

            {{-- =================================================== --}}
            {{-- 7. BÖLÜM: PROJE YÖNETİMİ                            --}}
            {{-- =================================================== --}}
            @if($modEnabled('ProjectManagement') && $canMod('project_management'))
            <div class="sidenav-menu-heading small text-muted">Operasyon & Yönetim</div>

            <a class="nav-link {{ request()->is('admin/projects*') || request()->is('admin/pm*') ? 'active' : 'collapsed' }}" 
               href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseProjectManagement">
                <div class="nav-link-icon text-primary"><i class="fas fa-project-diagram"></i></div>
                Proje Yönetimi
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>

            <div class="collapse {{ request()->is('admin/projects*') || request()->is('admin/pm*') ? 'show' : '' }}" id="collapseProjectManagement" data-bs-parent="#accordionUserSidenav">
                <nav class="sidenav-menu-nested nav accordion" id="accordionProjectPages">
                    <a class="nav-link {{ request()->routeIs('admin.pm.dashboard.*') || request()->is('admin/pm/dashboard') ? 'active' : '' }}" href="{{ Route::has('admin.pm.dashboard.index') ? route('admin.pm.dashboard.index') : '#' }}">
                        <span class="dot-icon" style="background: #3b82f6;"></span>PM Paneli
                    </a>
                    <a class="nav-link {{ request()->is('admin/projects*') ? 'active' : '' }}" href="{{ Route::has('admin.projects.index') ? route('admin.projects.index') : '#' }}">
                        <span class="dot-icon" style="background: #10b981;"></span>Projeler
                    </a>
                    <a class="nav-link {{ request()->is('admin/tasks*') ? 'active' : '' }}" href="{{ Route::has('admin.tasks.index') ? route('admin.tasks.index') : '#' }}">
                        <span class="dot-icon" style="background: #f59e0b;"></span>Görevler
                    </a>
                </nav>
            </div>
            @endif

            {{-- =================================================== --}}
            {{-- 8. BÖLÜM: RAPORLAMA                                 --}}
            {{-- =================================================== --}}
            @if($modEnabled('Reporting') && ($isAdmin || $canMod('reporting') || $canMod('Reporting') || $canMod('reports')))
            <div class="sidenav-menu-heading small text-muted">Raporlama</div>
            <a class="nav-link {{ request()->is('admin/standart-raporlar*') ? 'active' : '' }}"
               href="{{ url('/admin/standart-raporlar') }}">
                <div class="nav-link-icon icon-report"><i data-feather="bar-chart-2"></i></div>
                Raporlar
            </a>
            @endif

            {{-- =================================================== --}}
            {{-- 9. BÖLÜM: HABERLEŞME & DUYURU (HİBRİT MENÜ)         --}}
            {{-- =================================================== --}}
            @if($canMenu('announcements_csb') || $canMenu('announcements_turkak') || $canMenu('turkak_documents') || $canMenu('bots'))
            <div class="sidenav-menu-heading small text-muted">Haberleşme</div>

            <a class="nav-link {{ request()->is('admin/announcements*') || request()->is('admin/turkak-documents*') || request()->is('admin/bots*') ? 'active' : 'collapsed' }}" 
               href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseHaber">
                <div class="nav-link-icon text-primary"><i data-feather="rss"></i></div>
                Duyuru & Entegrasyon
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse {{ request()->is('admin/announcements*') || request()->is('admin/turkak-documents*') || request()->is('admin/bots*') ? 'show' : '' }}" id="collapseHaber" data-bs-parent="#accordionUserSidenav">
                <nav class="sidenav-menu-nested nav">
                    @if($canMenu('announcements_csb'))
                    <a class="nav-link" href="{{ Route::has('admin.announcements.index') ? route('admin.announcements.index', ['source' => 'CSB']) : '#' }}">
                        <span class="dot-icon" style="background: #e11d48;"></span>ÇŞB Duyuruları
                    </a>
                    @endif
                    
                    @if($canMenu('announcements_turkak'))
                    <a class="nav-link" href="{{ Route::has('admin.announcements.index') ? route('admin.announcements.index', ['source' => 'TURKAK']) : '#' }}">
                        <span class="dot-icon" style="background: #0284c7;"></span>TÜRKAK Duyuruları
                    </a>
                    @endif
                    
                    @if($canMenu('turkak_documents'))
                    <a class="nav-link" href="{{ Route::has('admin.turkak-documents.index') ? route('admin.turkak-documents.index') : '#' }}">
                        <span class="dot-icon" style="background: #0284c7;"></span>Asist Dokümanlarım
                    </a>
                    @endif
                    
                    @if($canMenu('bots'))
                    <a class="nav-link" href="{{ Route::has('admin.bots.index') ? route('admin.bots.index') : '#' }}">
                        <span class="dot-icon" style="background: #64748b;"></span>Robot Yönetimi
                    </a>
                    @endif
                </nav>
            </div>
            @endif

            {{-- =================================================== --}}
            {{-- 10. BÖLÜM: SİSTEM YÖNETİMİ (HİBRİT MENÜ)            --}}
            {{-- =================================================== --}}
            @if($canMod('users') || $canMod('settings') || $canMenu('personnel') || $canMenu('departments') || $canMenu('permissions') || $canMenu('logs') || $canMenu('definitions'))
            <div class="sidenav-menu-heading small text-muted">Sistem</div>
            
            <a class="nav-link {{ request()->is('admin/users*') || request()->is('admin/settings*') || request()->is('admin/permissions*') || request()->is('admin/modules*') || request()->is('admin/personnel*') || request()->is('admin/departments*') || request()->is('admin/logs*') || request()->is('admin/definitions*') ? 'active' : 'collapsed' }}" 
               href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseSystem">
                <div class="nav-link-icon text-secondary"><i data-feather="settings"></i></div>
                Yönetim Paneli
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse {{ request()->is('admin/users*') || request()->is('admin/settings*') || request()->is('admin/permissions*') || request()->is('admin/modules*') || request()->is('admin/personnel*') || request()->is('admin/departments*') || request()->is('admin/logs*') || request()->is('admin/definitions*') ? 'show' : '' }}" id="collapseSystem" data-bs-parent="#accordionUserSidenav">
                <nav class="sidenav-menu-nested nav">
                    @if($canMod('users'))
                    <a class="nav-link {{ request()->is('admin/users*') ? 'active' : '' }}" href="{{ Route::has('admin.users.index') ? route('admin.users.index') : '#' }}">Kullanıcılar</a>
                    @endif
                    
                    @if($canMenu('personnel'))
                    <a class="nav-link {{ request()->is('admin/personnel*') ? 'active' : '' }}" href="{{ Route::has('admin.personnel.index') ? route('admin.personnel.index') : '#' }}">Personel Listesi</a>
                    @endif
                    
                    @if($canMenu('departments'))
                    <a class="nav-link {{ request()->is('admin/departments*') ? 'active' : '' }}" href="{{ Route::has('admin.departments.index') ? route('admin.departments.index') : '#' }}">Departmanlar</a>
                    @endif
                    
                    @if($canMenu('permissions'))
                    <a class="nav-link {{ request()->is('admin/permissions*') ? 'active' : '' }}" href="{{ Route::has('admin.permissions.index') ? route('admin.permissions.index') : '#' }}">Yetki & Roller</a>
                    @endif
                    
                    @if($canMod('settings'))
                    <a class="nav-link {{ request()->is('admin/settings*') ? 'active' : '' }}" href="{{ Route::has('admin.settings.index') ? route('admin.settings.index') : '#' }}">Genel Ayarlar</a>
                    @endif
                    
                    @if($canMenu('logs'))
                    <a class="nav-link {{ request()->is('admin/logs*') ? 'active' : '' }}" href="{{ Route::has('admin.logs.index') ? route('admin.logs.index') : '#' }}">İşlem Kayıtları (Log)</a>
                    @endif
                    
                    @if($canMenu('definitions'))
                    <a class="nav-link {{ request()->is('admin/definitions*') ? 'active' : '' }}" href="{{ Route::has('admin.definitions.index') ? route('admin.definitions.index') : '#' }}">Sistem Tanımları</a>
                    @endif

                    @if($isAdmin)
                    <a class="nav-link {{ request()->is('admin/modules*') ? 'active' : '' }}" href="{{ Route::has('admin.modules.index') ? route('admin.modules.index') : '#' }}">
                        <span class="dot-icon" style="background: #f43f5e; box-shadow: 0 0 8px #f43f5e;"></span>Modül Yönetimi
                    </a>
                    @endif
                </nav>
            </div>
            @endif

        </div>
    </div>
</nav>
