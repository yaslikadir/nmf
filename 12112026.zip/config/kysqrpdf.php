<?php

return [

    /*
    |--------------------------------------------------------------------------
    | KysQrPdf - %100 Saf PHP PDF Kütüphanesi
    |--------------------------------------------------------------------------
    |
    | HİÇBİR HARİCİ BAĞIMLILIK GEREKTİRMEZ!
    | - FPDI/FPDF YOK
    | - Ghostscript YOK
    | - PDF 1.5+ Sıkıştırılmış PDF Desteği VAR
    |
    */

    /*
    |--------------------------------------------------------------------------
    | Varsayılan Watermark Ayarları
    |--------------------------------------------------------------------------
    */

    'watermark' => [
        // Pozisyon seçenekleri:
        // top-left, top-center, top-right
        // center-left, center, center-right
        // bottom-left, bottom-center, bottom-right
        'position' => 'bottom-right',

        // Genişlik (PDF point cinsinden, 72 point = 1 inch ≈ 2.54 cm)
        // 80 point yaklaşık 2.8 cm'ye tekabül eder.
        'width' => 80,

        // Yükseklik (PDF point cinsinden)
        'height' => 80,

        // Şeffaflık (0 ile 1 arası, 1 = tam görünür)
        // QR kodun okunabilirliği için 0.8 ve üzeri önerilir.
        'opacity' => 0.9,

        // Kenar boşluğu (PDF point cinsinden)
        'margin' => 20,

        // Hangi sayfalara eklenecek:
        // 'all' = tüm sayfalar
        // 'first' = sadece ilk sayfa
        // 'last' = sadece son sayfa
        // [1, 3, 5] = belirli sayfalar (array)
        'pages' => 'all',
    ],

    /*
    |--------------------------------------------------------------------------
    | Geçici Dosya Dizini (Kritik Ayar)
    |--------------------------------------------------------------------------
    |
    | Aldığınız "Permission Denied" hatasını çözmek için burayı Laravel'in
    | storage dizinine yönlendirdik. PHP'nin root klasöre yazma yetkisi
    | genellikle kısıtlıdır.
    |
    */

    'temp_dir' => storage_path('app/temp_processing'),

];