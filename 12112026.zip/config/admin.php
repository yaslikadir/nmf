<?php

return [
    'master_page_password' => env('MASTER_PAGE_PASSWORD'),
];
