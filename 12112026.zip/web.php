<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ToolController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\LicenseActivationController;
use App\Http\Controllers\Admin\BackupController;
use App\Http\Controllers\Admin\KnowledgeBaseController;

// Kontrolcüler - ADMIN
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\UserLogController;
use App\Http\Controllers\Admin\DefinitionController;
use App\Http\Controllers\Admin\PermissionController;
use App\Http\Controllers\Admin\DepartmentController;
use App\Http\Controllers\Admin\ScopeTypeController;
use App\Http\Controllers\Admin\EquipmentController;
use App\Http\Controllers\Admin\PersonnelController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\Admin\AnnouncementController;
use App\Http\Controllers\Admin\BotController;
use App\Http\Controllers\Admin\RoleController;

// PUBLIC KONTROLCÜLER
use App\Http\Controllers\PublicReportController;
use App\Http\Controllers\PublicController;
use App\Http\Controllers\PublicFeedbackController;
use Modules\Inventory\Http\Controllers\PublicDeviceController;

/*
|--------------------------------------------------------------------------
| Web Rotaları
|--------------------------------------------------------------------------
*/
Route::get('/license-activation', [LicenseActivationController::class, 'showForm'])->name('license.activation');
Route::post('/license-verify', [LicenseActivationController::class, 'verifyAndSave'])->name('license.verify');

Route::get('/', function () {
    return redirect()->route('dashboard');
});

Route::get('/timeline_demo', function () {
    return view('admin.timeline_demo');
});

// --- DIŞA AÇIK FORM ROTALARI ---
Route::prefix('form')->name('public.feedback.')->group(function () {
    Route::get('/durum-sorgula', [PublicFeedbackController::class, 'trackingForm'])->name('tracking');
    Route::post('/durum-sorgula', [PublicFeedbackController::class, 'track'])->name('track');
    Route::get('/sonuc/{code}', [PublicFeedbackController::class, 'success'])->name('success');
    Route::get('/{slug}', [PublicFeedbackController::class, 'show'])->name('show');
    Route::post('/{slug}', [PublicFeedbackController::class, 'store'])->name('store');
});

// --- HERKESE AÇIK QR HEDEFLERİ ---
Route::get('/device-verification/{inventory_no}', [PublicDeviceController::class, 'show'])->name('public.device.show');
Route::get('/verify-report/{barcode}', [PublicReportController::class, 'show'])->name('public.report.show');
Route::get('/verify-certificate/{code}', [PublicController::class, 'verifyCertificate'])->name('public.certificate.verify');

// --- YETKİLİ KULLANICI GRUBU ---
Route::middleware(['auth', 'verified', 'active_user'])->group(function () {

    Route::get('switch-role/{roleId}', [\App\Http\Controllers\Admin\RoleController::class, 'switchRole'])
        ->name('user.switch-role');

    // --- DASHBOARD ---
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // --- PROFİL YÖNETİMİ ---
    Route::controller(ProfileController::class)->group(function () {
        Route::get('/profile', 'edit')->name('profile.edit');
        Route::get('/profile/security', 'security')->name('profile.security');
        Route::get('/profile/notifications', 'notifications')->name('profile.notifications');
        Route::patch('/profile', 'update')->name('profile.update');
        Route::delete('/profile', 'destroy')->name('profile.destroy');
    });

    // --- ADMİN PANELİ ANA GRUBU ---
    Route::prefix('admin')->name('admin.')->group(function () {

        // Modül Yönetimi
        Route::middleware(['role:admin'])->prefix('modules')->name('modules.')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\ModuleController::class, 'index'])->name('index');
            Route::post('/toggle/{slug}', [\App\Http\Controllers\Admin\ModuleController::class, 'toggle'])->name('toggle');
            Route::post('/upload', [\App\Http\Controllers\Admin\ModuleController::class, 'upload'])->name('upload');
            Route::get('/export/{slug}', [\App\Http\Controllers\Admin\ModuleController::class, 'export'])->name('export');
            Route::delete('/destroy/{slug}', [\App\Http\Controllers\Admin\ModuleController::class, 'destroy'])->name('destroy');
        });

        // KULLANIM KILAVUZU / KNOWLEDGE BASE
        Route::prefix('kullanim-kilavuzu')->name('knowledge-base.')->group(function () {
            Route::get('/', [KnowledgeBaseController::class, 'index'])->name('index');
            Route::get('/{category}/{filename}/goruntule', [KnowledgeBaseController::class, 'view'])
                ->whereIn('category', ['moduller', 'qms', 'satis', 'sozlesmeler', 'politikalar'])
                ->name('view');
            Route::get('/{category}/{filename}/indir', [KnowledgeBaseController::class, 'download'])
                ->whereIn('category', ['moduller', 'qms', 'satis', 'sozlesmeler', 'politikalar'])
                ->name('download');
        });

        // GERİ DÖNÜŞÜM KUTUSU
        Route::prefix('recycle-bin')->name('recycle-bin.')->controller(\App\Http\Controllers\Admin\RecycleBinController::class)->group(function () {
            Route::get('/', 'index')->name('index');
            Route::post('/restore/{modelKey}/{id}', 'restore')->name('restore');
            Route::delete('/force-delete/{modelKey}/{id}', 'forceDelete')->name('force-delete');
        });

        Route::prefix('trash')->name('trash.')->controller(\App\Http\Controllers\Admin\TrashController::class)->group(function () {
            Route::get('/', 'index')->name('index');
            Route::post('/restore/{modelKey}/{id}', 'restore')->name('restore');
            Route::delete('/force-delete/{modelKey}/{id}', 'forceDelete')->name('force-delete');
        });

        // DUYURU VE ROBOT SİSTEMİ
        Route::get('/announcements', [AnnouncementController::class, 'index'])->name('announcements.index');
        Route::middleware(['role:admin'])->prefix('bots')->name('bots.')->group(function () {
            Route::get('/', [BotController::class, 'index'])->name('index');
            Route::post('/run/{bot_key}', [BotController::class, 'run'])->name('run');
        });

        // TÜRKAK ASİST DOKÜMANLARI
        Route::get('/turkak-documents', [App\Http\Controllers\Admin\TurkakDocumentController::class, 'index'])->name('turkak-documents.index');
        Route::post('/turkak-documents/sync', [App\Http\Controllers\Admin\TurkakDocumentController::class, 'sync'])->name('turkak-documents.sync');
        Route::post('/turkak-settings/update', [App\Http\Controllers\Admin\TurkakDocumentController::class, 'updateSettings'])->name('turkak-settings.update');
        Route::get('/turkak-documents/download/{id}', [App\Http\Controllers\Admin\TurkakDocumentController::class, 'download'])->name('turkak-documents.download');

        // KULLANICI AYARLARI
        Route::post('/user/update-settings', [UserController::class, 'updateSettings'])->name('user.update-settings');

        // GLOBAL SİSTEM AYARLARI
        Route::middleware(['role:admin'])->group(function () {
            Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
            Route::post('/settings', [SettingsController::class, 'update'])->name('settings.update');
        });

        // BİLDİRİMLER
        Route::post('/notifications/read/{id}', function ($id) {
            $notification = auth()->user()->notifications()->find($id);
            if ($notification) {
                $notification->markAsRead();
            }
            return response()->json(['success' => true]);
        })->name('notifications.read');

        Route::get('/notifications/mark-all-read', function () {
            auth()->user()->unreadNotifications->markAsRead();
            return back();
        })->name('notifications.mark-all-read');

        // NOTLAR & ARAÇLAR
        Route::get('/get-notes', [ToolController::class, 'getNotes']);
        Route::post('/add-note', [ToolController::class, 'addNote']);
        Route::delete('/delete-note/{id}', [ToolController::class, 'deleteNote']);
        Route::get('/get-exchange-rates', [ToolController::class, 'getExchangeRates'])->name('get.rates');

        // GENEL KAYNAK ROTALARI
        Route::resource('equipment', EquipmentController::class);
        Route::resource('departments', DepartmentController::class);

        // PERSONEL YÖNETİMİ - 360 DERECE PERSONEL DOSYASI
        Route::resource('personnel', PersonnelController::class);
        Route::get('personnel/{id}/authorization-form/print', [PersonnelController::class, 'printAuthorizationForm'])
            ->name('personnel.authorization-form.print');
        Route::get('personnel/authorization-form/all/print', [PersonnelController::class, 'printAllAuthorizationForm'])
            ->name('personnel.authorization-form.all.print');
        Route::post('personnel/authorization-form/logo', [PersonnelController::class, 'uploadSiteLogo'])
            ->name('personnel.authorization-form.logo');
        Route::post('personnel/{id}/documents', [PersonnelController::class, 'storeDocument'])
            ->name('personnel.documents.store');
        Route::get('personnel-documents/{id}/view', [PersonnelController::class, 'viewDocument'])
            ->name('personnel.documents.view');
        Route::get('personnel-documents/{id}/edit', [PersonnelController::class, 'editDocument'])
            ->name('personnel.documents.edit');
        Route::put('personnel-documents/{id}', [PersonnelController::class, 'updateDocument'])
            ->name('personnel.documents.update');
        Route::delete('personnel-documents/{id}', [PersonnelController::class, 'destroyDocument'])
            ->name('personnel.documents.destroy');
        Route::post('personnel/{id}/orientation', [PersonnelController::class, 'storeOrientation'])
            ->name('personnel.orientation.store');
        Route::get('personnel/{userId}/orientation/{recordId}/documents/{documentId}', [PersonnelController::class, 'viewOrientationDocument'])
            ->name('personnel.orientation.document');
        Route::get('personnel/{userId}/orientation/{recordId}', [PersonnelController::class, 'showOrientation'])
            ->name('personnel.orientation.show');
        Route::get('personnel/{userId}/orientation/{recordId}/evidence', [PersonnelController::class, 'viewOrientationEvidence'])
            ->name('personnel.orientation.evidence');
        Route::get('personnel/{userId}/orientation/{recordId}/video', [PersonnelController::class, 'viewOrientationVideo'])
            ->name('personnel.orientation.video');
        Route::get('personnel/{userId}/orientation/{recordId}/edit', [PersonnelController::class, 'editOrientation'])
            ->name('personnel.orientation.edit');
        Route::put('personnel/{userId}/orientation/{recordId}', [PersonnelController::class, 'updateOrientation'])
            ->name('personnel.orientation.update');
        Route::delete('personnel/{userId}/orientation/{recordId}', [PersonnelController::class, 'destroyOrientation'])
            ->name('personnel.orientation.destroy');
        Route::post('personnel/{userId}/competency-assessments', [PersonnelController::class, 'storeCompetencyAssessment'])
            ->name('personnel.competency-assessments.store');
        Route::get('personnel/{userId}/competency-assessments/{assessmentId}/evidence', [PersonnelController::class, 'viewCompetencyEvidence'])
            ->name('personnel.competency-assessments.evidence');
        Route::get('personnel/{userId}/competency-assessments/{assessmentId}/edit', [PersonnelController::class, 'editCompetencyAssessment'])
            ->name('personnel.competency-assessments.edit');
        Route::get('personnel/{userId}/competency-assessments/{assessmentId}/history', [PersonnelController::class, 'showCompetencyHistory'])
            ->name('personnel.competency-assessments.history');
        Route::put('personnel/{userId}/competency-assessments/{assessmentId}', [PersonnelController::class, 'updateCompetencyAssessment'])
            ->name('personnel.competency-assessments.update');
        Route::delete('personnel/{userId}/competency-assessments/{assessmentId}', [PersonnelController::class, 'destroyCompetencyAssessment'])
            ->name('personnel.competency-assessments.destroy');
        Route::post('personnel/{userId}/competency-assessments/{assessmentId}/approve', [PersonnelController::class, 'approveCompetencyAssessment'])
            ->name('personnel.competency-assessments.approve');
        Route::post('personnel/{userId}/competency-assessments/{assessmentId}/reject', [PersonnelController::class, 'rejectCompetencyAssessment'])
            ->name('personnel.competency-assessments.reject');
        Route::post('personnel/{id}/authorizations', [PersonnelController::class, 'storeAuthorization'])
            ->name('personnel.authorizations.store');
        Route::get('personnel/{userId}/authorizations', function ($userId) {
            return redirect()->route('admin.personnel.show', $userId)->with('open_personnel_tab', 'yetkilendirme');
        })->name('personnel.authorizations.index');
        Route::post('personnel/{userId}/authorization-matrices', [PersonnelController::class, 'storeAuthorizationMatrix'])
            ->name('personnel.authorization-matrices.store');
        Route::get('personnel/{userId}/authorization-matrices/{matrixId}/edit', [PersonnelController::class, 'editAuthorizationMatrix'])
            ->name('personnel.authorization-matrices.edit');
        Route::put('personnel/{userId}/authorization-matrices/{matrixId}', [PersonnelController::class, 'updateAuthorizationMatrix'])
            ->name('personnel.authorization-matrices.update');
        Route::delete('personnel/{userId}/authorization-matrices/{matrixId}', [PersonnelController::class, 'destroyAuthorizationMatrix'])
            ->name('personnel.authorization-matrices.destroy');
        Route::get('personnel/{userId}/authorizations/{authorizationId}', [PersonnelController::class, 'showAuthorization'])
            ->name('personnel.authorizations.show');
        Route::get('personnel/{userId}/authorizations/{authorizationId}/document', [PersonnelController::class, 'viewAuthorizationDocument'])
            ->name('personnel.authorizations.document');
        Route::get('personnel/{userId}/authorizations/{authorizationId}/documents/{documentId}', [PersonnelController::class, 'viewAuthorizationAttachment'])
            ->name('personnel.authorizations.documents.view');
        Route::get('personnel/{userId}/authorizations/{authorizationId}/edit', [PersonnelController::class, 'editAuthorization'])
            ->name('personnel.authorizations.edit');
        Route::put('personnel/{userId}/authorizations/{authorizationId}', [PersonnelController::class, 'updateAuthorization'])
            ->name('personnel.authorizations.update');
        Route::delete('personnel/{userId}/authorizations/{authorizationId}', [PersonnelController::class, 'destroyAuthorization'])
            ->name('personnel.authorizations.destroy');
        Route::post('personnel/{userId}/authorizations/{authorizationId}/approve', [PersonnelController::class, 'approveAuthorization'])
            ->name('personnel.authorizations.approve');
        Route::post('personnel/{userId}/authorizations/{authorizationId}/reject', [PersonnelController::class, 'rejectAuthorization'])
            ->name('personnel.authorizations.reject');
        Route::post('personnel/{id}/scope-authorizations', [PersonnelController::class, 'storeScopeAuthorization'])
            ->name('personnel.scope-authorizations.store');
        Route::get('personnel/{userId}/scope-authorizations/{scopeId}/edit', [PersonnelController::class, 'editScopeAuthorization'])
            ->name('personnel.scope-authorizations.edit');
        Route::put('personnel/{userId}/scope-authorizations/{scopeId}', [PersonnelController::class, 'updateScopeAuthorization'])
            ->name('personnel.scope-authorizations.update');
        Route::delete('personnel/{userId}/scope-authorizations/{scopeId}', [PersonnelController::class, 'destroyScopeAuthorization'])
            ->name('personnel.scope-authorizations.destroy');
        Route::post('personnel/{userId}/scope-authorizations/{scopeId}/approve', [PersonnelController::class, 'approveScopeAuthorization'])
            ->name('personnel.scope-authorizations.approve');
        Route::post('personnel/{userId}/scope-authorizations/{scopeId}/reject', [PersonnelController::class, 'rejectScopeAuthorization'])
            ->name('personnel.scope-authorizations.reject');
        Route::post('personnel/{userId}/competency-assessments/{assessmentId}/renew', [PersonnelController::class, 'renewCompetencyAssessment'])
            ->name('personnel.competency-assessments.renew');

        Route::get('templates', [\Modules\Sales\Http\Controllers\OfferTemplateController::class, 'index'])->name('templates.index');
        
        // SABİT DEĞERLER (DEFINITIONS) ROTALARI - bulkUpdate EKLENDİ!
        Route::post('definitions/bulk-update', [DefinitionController::class, 'bulkUpdate'])->name('definitions.bulkUpdate');
        Route::resource('definitions', DefinitionController::class);

        // --- SADECE SÜPER ADMİNLER ---
        Route::middleware(['role:admin'])->group(function () {
            Route::get('/toggle-view', function () {
                if (session()->has('view_as_user')) {
                    session()->forget('view_as_user');
                } else {
                    session(['view_as_user' => true]);
                }
                return back();
            })->name('toggle-view');

            Route::prefix('roles')->name('roles.')->group(function () {
                Route::get('/', [RoleController::class, 'index'])->name('index');
                Route::post('/', [RoleController::class, 'store'])->name('store');
                Route::put('/{role}', [RoleController::class, 'update'])->name('update');
                Route::delete('/{role}', [RoleController::class, 'destroy'])->name('destroy');
            });

            Route::prefix('users')->name('users.')->group(function () {
                Route::get('/{user}/roles', [\App\Http\Controllers\Admin\UserController::class, 'getUserRoles'])->name('get-roles');
                Route::post('/{user}/roles', [\App\Http\Controllers\Admin\UserController::class, 'updateRoles'])->name('update-roles');
            });

            // GİZLİ KASA VE YEDEKLEME
            Route::get('/kasa-sifresi', [\App\Http\Controllers\Admin\MasterAuthController::class, 'show'])->name('master.login');
            Route::post('/kasa-sifresi', [\App\Http\Controllers\Admin\MasterAuthController::class, 'verify'])->name('master.verify');

            Route::middleware([\App\Http\Middleware\MasterPasswordMiddleware::class])
                ->prefix('backups')
                ->name('backups.')
                ->group(function () {
                    Route::get('/', [BackupController::class, 'index'])->name('index');
                    Route::post('/create', [BackupController::class, 'create'])->name('create');
                    Route::get('/download/{file_name}', [BackupController::class, 'download'])->name('download');
                    Route::delete('/delete/{file_name}', [BackupController::class, 'destroy'])->name('destroy');
                    Route::get('/logs', [BackupController::class, 'getLogs'])->name('logs');
                });

            Route::resource('users', UserController::class);
            Route::patch('/users/{user}/toggle', [UserController::class, 'toggleStatus'])->name('users.toggle');
            Route::get('/users/{user}/quick-view', [UserController::class, 'quickView'])->name('users.quick-view');
            Route::get('/logs', [UserLogController::class, 'index'])->name('logs.index');

            Route::resource('scope-types', ScopeTypeController::class);
            Route::post('scope-types/bulk-update', [ScopeTypeController::class, 'bulkUpdate'])->name('scope-types.bulkUpdate');
            Route::get('/permissions', [PermissionController::class, 'index'])->name('permissions.index');
            Route::post('/permissions', [PermissionController::class, 'store'])->name('permissions.store');

            // IMPORT ROTALARI
            Route::prefix('ayarlar')->name('settings.')->group(function () {
                Route::get('/import', [\App\Http\Controllers\Admin\ImportController::class, 'index'])->name('import.index');
                Route::post('/import/customers', [\App\Http\Controllers\Admin\ImportController::class, 'importCustomers'])->name('import.customers');
                Route::post('/import/chemicals', [\App\Http\Controllers\Admin\ImportController::class, 'importChemicals'])->name('import.chemicals');
            });
        });
    });
});

require __DIR__ . '/auth.php';
