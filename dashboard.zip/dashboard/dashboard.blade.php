@extends('layouts.admin')

@section('title', 'Yönetim Paneli')

@section('content')
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container-xl px-4">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i data-feather="activity"></i></div>
                            Laboratuvar Yönetim Merkezi
                        </h1>
                        <div class="page-header-subtitle">Hoş geldin {{ Auth::user()->name }}, yetkili olduğun modüllerin durumu aşağıdadır.</div>
                        <div class="small text-white-75 mt-2"><i data-feather="map-pin"></i> Aktif Şube: <strong>{{ $activeBranchName ?? session('active_branch_name', 'Şube seçilmedi') }}</strong></div>
                    </div>
                    <div class="col-12 col-xl-auto mt-4">
                        <div class="small text-white-50">Son Güncelleme: {{ now()->format('d.m.Y H:i') }}</div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="container-xl px-4 mt-n10">
        
        {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
        {{-- KRİTİK UYARI KARTLARI (Dinamik Yetkilendirme) --}}
        {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
        <div class="row">
            
            {{-- 1. ANALİZ DURUMU (LIMS Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('lims') || auth()->user()->hasPermissionToAccessModule('sample_management'))
            <div class="col-lg-6 col-xl-3 mb-4">
                <div class="card bg-primary text-white h-100 shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="me-3">
                                <div class="text-white-50 small text-uppercase fw-bold">Aktif Analizler</div>
                                <div class="text-lg fw-bold">{{ $stats['active_tasks'] ?? 0 }}</div>
                            </div>
                            <i class="feather-xl text-white-50" data-feather="activity"></i>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between small">
                        <a class="text-white stretched-link" href="{{ Route::has('admin.test-management.index') ? route('admin.test-management.index') : '#' }}">İş Emirlerini Gör</a>
                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            @endif

            {{-- 2. METOT ONAYLARI (LIMS veya Kalite Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('lims') || auth()->user()->hasPermissionToAccessModule('qms_audits'))
            <div class="col-lg-6 col-xl-3 mb-4">
                <div class="card bg-warning text-white h-100 shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="me-3">
                                <div class="text-white-50 small text-uppercase fw-bold">Onay Bekleyen Metotlar</div>
                                <div class="text-lg fw-bold">{{ $stats['pending_methods'] ?? 0 }}</div>
                            </div>
                            <i class="feather-xl text-white-50" data-feather="check-square"></i>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between small">
                        <a class="text-white stretched-link" href="{{ Route::has('admin.methods.index') ? route('admin.methods.index') : '#' }}">Listeyi Aç</a>
                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            @endif

            {{-- 3. KRİTİK STOK (Envanter Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('inventory'))
            <div class="col-lg-6 col-xl-3 mb-4">
                <div class="card {{ ($stats['critical_stock'] ?? 0) > 0 ? 'bg-danger animate__animated animate__pulse animate__infinite' : 'bg-success' }} text-white h-100 shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="me-3">
                                <div class="text-white-50 small text-uppercase fw-bold">Kritik Stok Uyarısı</div>
                                <div class="text-lg fw-bold">{{ $stats['critical_stock'] ?? 0 }} Malzeme</div>
                            </div>
                            <i class="feather-xl text-white-50" data-feather="alert-triangle"></i>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between small">
                        <a class="text-white stretched-link" href="{{ Route::has('admin.materials.index') ? route('admin.materials.index', ['filter' => 'critical']) : '#' }}">Eksikleri Gör</a>
                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6 col-xl-3 mb-4">
                <div class="card {{ ($stats['expired_soon'] ?? 0) > 0 ? 'bg-danger' : 'bg-secondary' }} text-white h-100 shadow border-start-lg border-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="me-3">
                                <div class="text-white-50 small text-uppercase fw-bold">Yaklaşan SKT (30 Gün)</div>
                                <div class="text-lg fw-bold">{{ $stats['expired_soon'] ?? 0 }} Kalem</div>
                            </div>
                            <i class="feather-xl text-white-50" data-feather="calendar"></i>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between small">
                        <a class="text-white stretched-link" href="{{ Route::has('admin.materials.movements') ? route('admin.materials.movements', ['filter' => 'expiring']) : '#' }}">Kontrol Et</a>
                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            @endif
        </div>

        {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
        {{-- İKİNCİ SATIR (Müşteri ve Teklifler - GÜNDÜZ MODU İÇİN YENİDEN TASARLANDI) --}}
        {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
        <div class="row">
            {{-- MÜŞTERİ SAYISI (CRM Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('customers'))
            <div class="col-lg-6 col-xl-3 mb-4">
                <div class="card border-start-lg border-primary h-100 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="me-3">
                                <div class="text-muted small text-uppercase fw-bold">Toplam Müşteri</div>
                                <div class="text-lg fw-bold text-primary">{{ $stats['total_customers'] ?? 0 }}</div>
                                <div class="small text-muted">{{ $stats['new_customers_this_month'] ?? 0 }} bu ay eklendi</div>
                            </div>
                            <i class="feather-xl text-primary opacity-50" data-feather="users"></i>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between small bg-transparent border-0 pt-0">
                        <a class="text-primary stretched-link fw-bold text-decoration-none" href="{{ Route::has('admin.customers.index') ? route('admin.customers.index') : '#' }}">Müşteri Listesi</a>
                        <div class="text-primary"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            @endif

            {{-- TEKLİF DURUMU (Teklif Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('offers'))
            <div class="col-lg-6 col-xl-3 mb-4">
                <div class="card border-start-lg border-success h-100 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="me-3">
                                <div class="text-muted small text-uppercase fw-bold">Bekleyen Teklifler</div>
                                <div class="text-lg fw-bold text-success">{{ $stats['pending_offers'] ?? 0 }}</div>
                                <div class="small text-muted">₺{{ number_format($stats['pending_offers_total'] ?? 0, 2) }}</div>
                            </div>
                            <i class="feather-xl text-success opacity-50" data-feather="file-text"></i>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between small bg-transparent border-0 pt-0">
                        <a class="text-success stretched-link fw-bold text-decoration-none" href="{{ Route::has('admin.offers.index') ? route('admin.offers.index', ['status' => 'pending']) : '#' }}">Teklifleri Gör</a>
                        <div class="text-success"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            @endif

            {{-- NUMUNE DURUMU (Numune Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('sample_management'))
            <div class="col-lg-6 col-xl-3 mb-4">
                <div class="card border-start-lg border-warning h-100 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="me-3">
                                <div class="text-muted small text-uppercase fw-bold">Aktif Numuneler</div>
                                <div class="text-lg fw-bold text-warning">{{ $stats['active_samples'] ?? 0 }}</div>
                                <div class="small text-muted">{{ $stats['samples_in_analysis'] ?? 0 }} analizde</div>
                            </div>
                            <i class="feather-xl text-warning opacity-50" data-feather="droplet"></i>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between small bg-transparent border-0 pt-0">
                        <a class="text-warning stretched-link fw-bold text-decoration-none" href="{{ Route::has('admin.sample-management.index') ? route('admin.sample-management.index') : '#' }}">Numune Takibi</a>
                        <div class="text-warning"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            @endif

            {{-- KALİBRASYON (Cihaz Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('devices'))
            <div class="col-lg-6 col-xl-3 mb-4">
                <div class="card {{ ($stats['calibration_due'] ?? 0) > 0 ? 'bg-danger text-white' : 'border-start-lg border-info' }} h-100 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="me-3">
                                <div class="{{ ($stats['calibration_due'] ?? 0) > 0 ? 'text-white-50' : 'text-muted' }} small text-uppercase fw-bold">Kalibrasyon Bekleyen</div>
                                <div class="text-lg fw-bold {{ ($stats['calibration_due'] ?? 0) > 0 ? 'text-white' : 'text-info' }}">{{ $stats['calibration_due'] ?? 0 }} Cihaz</div>
                                <div class="small {{ ($stats['calibration_due'] ?? 0) > 0 ? 'text-white-50' : 'text-muted' }}">{{ $stats['calibration_overdue'] ?? 0 }} süresi geçmiş</div>
                            </div>
                            <i class="feather-xl {{ ($stats['calibration_due'] ?? 0) > 0 ? 'text-white-50' : 'text-info opacity-50' }}" data-feather="tool"></i>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between small bg-transparent border-0 pt-0">
                        <a class="{{ ($stats['calibration_due'] ?? 0) > 0 ? 'text-white' : 'text-info' }} stretched-link fw-bold text-decoration-none" href="{{ Route::has('admin.equipment.index') ? route('admin.equipment.index', ['filter' => 'calibration']) : '#' }}">Cihazları Gör</a>
                        <div class="{{ ($stats['calibration_due'] ?? 0) > 0 ? 'text-white' : 'text-info' }}"><i class="fas fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
            @endif
        </div>

        <div class="row">
            {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
            {{-- SOL KOLON --}}
            {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
            <div class="col-xxl-8">
                
                {{-- HIZLI MODÜL ERİŞİMİ --}}
                <div class="row">
                    @php
                        // Yetkiye göre modülleri filtrele
                        $modules = [];
                        if(auth()->user()->hasPermissionToAccessModule('customers')) 
                            $modules[] = ['title' => 'Müşteri Yönetimi', 'desc' => 'Müşteri ve kontak işlemleri', 'icon' => 'user-check', 'color' => 'bg-green-soft text-green', 'route' => 'admin.customers.index', 'count' => $stats['total_customers'] ?? 0];
                        if(auth()->user()->hasPermissionToAccessModule('offers')) 
                            $modules[] = ['title' => 'Teklif Yönetimi', 'desc' => 'Teklif oluştur ve takip et', 'icon' => 'file-text', 'color' => 'bg-blue-soft text-blue', 'route' => 'admin.offers.index', 'count' => $stats['total_offers'] ?? 0];
                        if(auth()->user()->hasPermissionToAccessModule('sample_management')) 
                            $modules[] = ['title' => 'Numune Yönetimi', 'desc' => 'Numune kabul ve takip', 'icon' => 'droplet', 'color' => 'bg-red-soft text-red', 'route' => 'admin.sample-management.index', 'count' => $stats['active_samples'] ?? 0];
                        if(auth()->user()->hasPermissionToAccessModule('inventory')) 
                            $modules[] = ['title' => 'Stok Yönetimi', 'desc' => 'Malzeme ve sarf takibi', 'icon' => 'box', 'color' => 'bg-orange-soft text-orange', 'route' => 'admin.materials.index', 'count' => $stats['total_materials'] ?? 0];
                        if(auth()->user()->hasPermissionToAccessModule('personnel')) 
                            $modules[] = ['title' => 'Personel', 'desc' => 'Personel ve görev yönetimi', 'icon' => 'users', 'color' => 'bg-purple-soft text-purple', 'route' => 'admin.personnel.index', 'count' => $stats['total_personnel'] ?? 0];
                        if(auth()->user()->hasPermissionToAccessModule('reports')) 
                            $modules[] = ['title' => 'Raporlar', 'desc' => 'Analiz ve istatistik raporları', 'icon' => 'bar-chart-2', 'color' => 'bg-cyan-soft text-cyan', 'route' => 'admin.reports.index', 'count' => null];
                        if(auth()->user()->hasPermissionToAccessModule('devices')) 
                            $modules[] = ['title' => 'Cihaz/Ekipman', 'desc' => 'Ekipman ve kalibrasyon', 'icon' => 'cpu', 'color' => 'bg-teal-soft text-teal', 'route' => 'admin.equipment.index', 'count' => $stats['total_equipment'] ?? 0];
                    @endphp

                    @foreach($modules as $mod)
                    <div class="col-md-6 col-lg-3 mb-4">
                        <a class="card card-icon-animated h-100 shadow-sm border-0 text-decoration-none lift" href="{{ Route::has($mod['route']) ? route($mod['route']) : '#' }}">
                            <div class="card-body text-center py-4">
                                <div class="icon-stack icon-stack-lg {{ $mod['color'] }} mb-3 mx-auto">
                                    <i data-feather="{{ $mod['icon'] }}"></i>
                                </div>
                                <div class="text-dark fw-bold mb-1">{{ $mod['title'] }}</div>
                                <div class="small text-muted">{{ $mod['desc'] }}</div>
                                @if($mod['count'] !== null)
                                <div class="badge bg-light text-dark mt-2 border">{{ $mod['count'] }} kayıt</div>
                                @endif
                            </div>
                        </a>
                    </div>
                    @endforeach
                </div>

                {{-- SON TEKLİFLER TABLOSU --}}
                @if(auth()->user()->hasPermissionToAccessModule('offers'))
                <div class="card mb-4 shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <i class="me-1" data-feather="file-text"></i>
                            Son Teklifler
                        </div>
                        <a href="{{ Route::has('admin.offers.index') ? route('admin.offers.index') : '#' }}" class="btn btn-sm btn-primary">Tümünü Gör</a>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="ps-3">Teklif No</th>
                                        <th>Müşteri</th>
                                        <th>Tarih</th>
                                        <th>Tutar</th>
                                        <th>Durum</th>
                                        <th class="text-end pe-3">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($latestOffers ?? [] as $offer)
                                    <tr>
                                        <td class="ps-3">
                                            <span class="fw-bold text-primary">{{ $offer->offer_no }}</span>
                                        </td>
                                        <td>
                                            <div class="fw-bold">{{ $offer->customer->company_name ?? '-' }}</div>
                                            <div class="small text-muted">{{ $offer->contact->name ?? '-' }}</div>
                                        </td>
                                        <td class="small">{{ $offer->created_at->format('d.m.Y') }}</td>
                                        <td class="fw-bold">
                                            {{ $offer->currency ?? '₺' }}{{ number_format($offer->total_amount ?? 0, 2) }}
                                        </td>
                                        <td>
                                            {{-- Status Badge (Aynı Kod) --}}
                                            <span class="badge bg-secondary">{{ $offer->status }}</span>
                                        </td>
                                        <td class="text-end pe-3">
                                            <a href="{{ Route::has('admin.offers.show') ? route('admin.offers.show', $offer->id) : '#' }}" class="btn btn-datatable btn-icon btn-transparent-dark">
                                                <i data-feather="eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="6" class="text-center py-4 text-muted">Henüz teklif kaydı bulunmuyor.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                @endif

                {{-- AKTİF NUMUNELER (Numune Yetkisi) --}}
                @if(auth()->user()->hasPermissionToAccessModule('sample_management'))
                <div class="card mb-4 shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <i class="me-1" data-feather="droplet"></i>
                            Aktif Numuneler ve Analiz Durumu
                        </div>
                        <a href="{{ Route::has('admin.sample-management.index') ? route('admin.sample-management.index') : '#' }}" class="btn btn-sm btn-outline-primary">Tümünü Gör</a>
                    </div>
                    <div class="card-body p-0">
                        {{-- Tablo Aynı Kalacak --}}
                        <div class="table-responsive">
                            {{-- ... --}}
                        </div>
                    </div>
                </div>
                @endif

                {{-- SON STOK HAREKETLERİ (Stok Yetkisi) --}}
                @if(auth()->user()->hasPermissionToAccessModule('inventory'))
                <div class="card mb-4 shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <i class="me-1" data-feather="repeat"></i>
                            Son Stok Hareketleri
                        </div>
                        <a href="{{ Route::has('admin.materials.movements') ? route('admin.materials.movements') : '#' }}" class="btn btn-sm btn-outline-primary">Tümünü Gör</a>
                    </div>
                    <div class="card-body p-0">
                        {{-- Tablo Aynı Kalacak --}}
                    </div>
                </div>
                @endif

                {{-- BEKLEYEN GÖREVLER (Herkese Açık ama Kişisel Filtreli) --}}
                <div class="card mb-4 shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <i class="me-1" data-feather="clipboard"></i>
                            Bekleyen Görevler
                        </div>
                        <a href="{{ Route::has('admin.tasks.index') ? route('admin.tasks.index') : '#' }}" class="btn btn-sm btn-outline-primary">Tümünü Gör</a>
                    </div>
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush">
                            @forelse($pendingTasks ?? [] as $task)
                            <a href="{{ Route::has('admin.tasks.show') ? route('admin.tasks.show', $task->id) : '#' }}" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-0">{{ $task->title }}</h6>
                                        <small class="text-muted">Son Tarih: {{ $task->due_date ? $task->due_date->format('d.m.Y') : '-' }}</small>
                                    </div>
                                </div>
                            </a>
                            @empty
                            <div class="list-group-item text-center text-muted py-4">Bekleyen görev bulunmuyor</div>
                            @endforelse
                        </div>
                    </div>
                </div>

            </div>

            {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
            {{-- SAĞ KOLON (Yetkilendirilmiş) --}}
            {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
            <div class="col-xxl-4">

                {{-- KRİTİK STOK LİSTESİ (Envanter Yetkisi) --}}
                @if(auth()->user()->hasPermissionToAccessModule('inventory'))
                <div class="card mb-4 shadow-sm border-start-lg border-danger">
                    <div class="card-header bg-danger text-white">
                        <i class="me-1" data-feather="alert-triangle"></i>
                        Kritik Stok Seviyesi
                    </div>
                    <div class="card-body p-0">
                        {{-- Liste Aynı --}}
                    </div>
                </div>
                @endif

                {{-- SATIN ALMA TALEPLERİ (Satın Alma Yetkisi) --}}
                @if(auth()->user()->hasPermissionToAccessModule('purchase'))
                <div class="card mb-4 shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <i class="me-1" data-feather="shopping-bag"></i>
                            Satın Alma Talepleri
                        </div>
                        <span class="badge bg-primary">{{ count($purchaseRequests ?? []) }}</span>
                    </div>
                    <div class="card-body p-0">
                        {{-- Liste Aynı --}}
                    </div>
                </div>
                @endif

                {{-- KALİBRASYON TAKVİMİ (Cihaz Yetkisi) --}}
                @if(auth()->user()->hasPermissionToAccessModule('devices'))
                <div class="card mb-4 shadow-sm">
                    <div class="card-header">
                        <i class="me-1" data-feather="tool"></i>
                        Kalibrasyon Takvimi
                    </div>
                    <div class="card-body p-0">
                        {{-- Liste Aynı --}}
                    </div>
                </div>
                @endif

                {{-- SARFIYAT DURUMU (Envanter Yetkisi) --}}
                @if(auth()->user()->hasPermissionToAccessModule('inventory'))
                <div class="card card-header-actions mb-4 shadow-sm">
                    <div class="card-header">
                        Sarfiyat Durumu
                        <i class="text-gray-500" data-feather="pie-chart"></i>
                    </div>
                    <div class="card-body">
                        {{-- Grafikler Aynı --}}
                    </div>
                </div>
                @endif

                {{-- DEPARTMAN ANALİZLERİ (LIMS Yetkisi) --}}
                @if(auth()->user()->hasPermissionToAccessModule('lims'))
                <div class="card mb-4 shadow-sm">
                    <div class="card-header">
                        <i class="me-1" data-feather="git-branch"></i>
                        Departman Bazlı Analizler
                    </div>
                    <div class="card-body">
                        {{-- Liste Aynı --}}
                    </div>
                </div>
                @endif

                {{-- AKTİF PERSONEL (Herkese Açık) --}}
                <div class="card shadow-sm">
                    <div class="card-header">
                        <i class="me-1" data-feather="users"></i>
                        Aktif Personel
                    </div>
                    <div class="card-body p-0">
                        {{-- Liste Aynı --}}
                    </div>
                </div>

            </div>
        </div>

        {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
        {{-- GRAFİKLER (Yetkilendirilmiş) --}}
        {{-- ═══════════════════════════════════════════════════════════════════════════════ --}}
        <div class="row">
            {{-- AYLIK ANALİZ GRAFİĞİ (LIMS Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('lims'))
            <div class="col-xl-6 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <i class="me-1" data-feather="bar-chart-2"></i>
                        Aylık Analiz Sayıları
                    </div>
                    <div class="card-body">
                        <canvas id="monthlyAnalysisChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>
            @endif

            {{-- TEKLİF DÖNÜŞÜM ORANI (Teklif Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('offers'))
            <div class="col-xl-6 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <i class="me-1" data-feather="trending-up"></i>
                        Teklif Dönüşüm Oranları
                    </div>
                    <div class="card-body">
                        <canvas id="offerConversionChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>
            @endif
        </div>

        <div class="row">
            {{-- MÜŞTERİ BAZLI GELİR (CRM veya Teklif Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('customers') || auth()->user()->hasPermissionToAccessModule('offers'))
            <div class="col-xl-4 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <i class="me-1" data-feather="pie-chart"></i>
                        Müşteri Bazlı Gelir Dağılımı
                    </div>
                    <div class="card-body">
                        <canvas id="customerRevenueChart" style="height: 250px;"></canvas>
                    </div>
                </div>
            </div>
            @endif

            {{-- ANALİZ TİPİ DAĞILIMI (LIMS Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('lims'))
            <div class="col-xl-4 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <i class="me-1" data-feather="target"></i>
                        Analiz Tipi Dağılımı
                    </div>
                    <div class="card-body">
                        <canvas id="analysisTypeChart" style="height: 250px;"></canvas>
                    </div>
                </div>
            </div>
            @endif

            {{-- STOK HAREKET TRENDİ (Envanter Yetkisi) --}}
            @if(auth()->user()->hasPermissionToAccessModule('inventory'))
            <div class="col-xl-4 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <i class="me-1" data-feather="activity"></i>
                        Stok Hareket Trendi
                    </div>
                    <div class="card-body">
                        <canvas id="stockMovementChart" style="height: 250px;"></canvas>
                    </div>
                </div>
            </div>
            @endif
        </div>

    </div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Aylık Analiz Grafiği
    const monthlyCtx = document.getElementById('monthlyAnalysisChart');
    if (monthlyCtx) {
        new Chart(monthlyCtx, {
            type: 'bar',
            data: {
                labels: {!! json_encode($chartData['monthly_labels'] ?? ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara']) !!},
                datasets: [{
                    label: 'Tamamlanan Analizler',
                    data: {!! json_encode($chartData['monthly_completed'] ?? [45, 52, 38, 65, 72, 58, 80, 75, 68, 90, 85, 78]) !!},
                    backgroundColor: 'rgba(0, 172, 105, 0.8)',
                    borderRadius: 4,
                }, {
                    label: 'Başlanan Analizler',
                    data: {!! json_encode($chartData['monthly_started'] ?? [50, 58, 45, 70, 78, 65, 88, 82, 75, 95, 90, 85]) !!},
                    backgroundColor: 'rgba(0, 123, 255, 0.8)',
                    borderRadius: 4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }

    // Teklif Dönüşüm Grafiği
    const conversionCtx = document.getElementById('offerConversionChart');
    if (conversionCtx) {
        new Chart(conversionCtx, {
            type: 'line',
            data: {
                labels: {!! json_encode($chartData['monthly_labels'] ?? ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara']) !!},
                datasets: [{
                    label: 'Gönderilen Teklifler',
                    data: {!! json_encode($chartData['offers_sent'] ?? [20, 25, 18, 30, 35, 28, 40, 38, 32, 45, 42, 38]) !!},
                    borderColor: 'rgba(0, 123, 255, 1)',
                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                    fill: true,
                    tension: 0.4,
                }, {
                    label: 'Onaylanan Teklifler',
                    data: {!! json_encode($chartData['offers_approved'] ?? [15, 18, 12, 22, 28, 20, 32, 30, 25, 38, 35, 30]) !!},
                    borderColor: 'rgba(0, 172, 105, 1)',
                    backgroundColor: 'rgba(0, 172, 105, 0.1)',
                    fill: true,
                    tension: 0.4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }

    // Müşteri Bazlı Gelir Grafiği
    const customerCtx = document.getElementById('customerRevenueChart');
    if (customerCtx) {
        new Chart(customerCtx, {
            type: 'doughnut',
            data: {
                labels: {!! json_encode($chartData['top_customers'] ?? ['Müşteri A', 'Müşteri B', 'Müşteri C', 'Müşteri D', 'Diğer']) !!},
                datasets: [{
                    data: {!! json_encode($chartData['customer_revenue'] ?? [35, 25, 20, 12, 8]) !!},
                    backgroundColor: [
                        'rgba(0, 123, 255, 0.8)',
                        'rgba(0, 172, 105, 0.8)',
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(111, 66, 193, 0.8)',
                        'rgba(108, 117, 125, 0.8)',
                    ],
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }

    // Analiz Tipi Dağılımı
    const analysisCtx = document.getElementById('analysisTypeChart');
    if (analysisCtx) {
        new Chart(analysisCtx, {
            type: 'pie',
            data: {
                labels: {!! json_encode($chartData['analysis_types'] ?? ['Kimyasal', 'Mikrobiyolojik', 'Fiziksel', 'Organoleptik']) !!},
                datasets: [{
                    data: {!! json_encode($chartData['analysis_counts'] ?? [45, 30, 15, 10]) !!},
                    backgroundColor: [
                        'rgba(0, 123, 255, 0.8)',
                        'rgba(0, 172, 105, 0.8)',
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(220, 53, 69, 0.8)',
                    ],
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }

    // Stok Hareket Trendi
    const stockCtx = document.getElementById('stockMovementChart');
    if (stockCtx) {
        new Chart(stockCtx, {
            type: 'line',
            data: {
                labels: {!! json_encode($chartData['stock_days'] ?? ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz']) !!},
                datasets: [{
                    label: 'Giriş',
                    data: {!! json_encode($chartData['stock_in'] ?? [12, 8, 15, 10, 18, 5, 3]) !!},
                    borderColor: 'rgba(0, 172, 105, 1)',
                    backgroundColor: 'rgba(0, 172, 105, 0.2)',
                    fill: true,
                    tension: 0.4,
                }, {
                    label: 'Çıkış',
                    data: {!! json_encode($chartData['stock_out'] ?? [8, 12, 10, 14, 9, 6, 2]) !!},
                    borderColor: 'rgba(220, 53, 69, 1)',
                    backgroundColor: 'rgba(220, 53, 69, 0.2)',
                    fill: true,
                    tension: 0.4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }

    // Feather icons'ları yenile
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
});
</script>
@endpush