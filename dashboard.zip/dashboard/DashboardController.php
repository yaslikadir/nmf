<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

// Model importları
use Modules\Customers\Models\Customer;
use Modules\Customers\Models\Contact;
use Modules\ProjectManagement\Models\Task;
use Modules\Sales\Models\Offer;

use Modules\Sales\Models\OfferItem;

use App\Models\Sample;
use App\Models\SampleAnalysis;
use App\Models\Material;
use App\Models\Inventory;
use App\Models\StockMovement;
use App\Models\Equipment;
use App\Models\Personnel;
use App\Models\Department;
use App\Models\PurchaseRequest;
use App\Models\AnalysisMethod;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        // ═══════════════════════════════════════════════════════════════════════════
        // ANA İSTATİSTİKLER (Tüm Modellere withoutGlobalScopes() eklendi!)
        // ═══════════════════════════════════════════════════════════════════════════
        
        $criticalStockCount = $this->branchTable(DB::table('materials'), 'materials')
            ->where('materials.min_stock', '>', 0)
            ->whereRaw('(SELECT COALESCE(SUM(quantity), 0) FROM inventories i WHERE i.material_id = materials.id AND i.branch_id = ?) <= materials.min_stock', [$this->branchId()])
            ->count();

        $stats = [
            'active_tasks' => $this->branchModel(Task::query(), 'project_management_tasks')->whereIn('status', ['pending', 'in_progress'])->count(),
            'pending_methods' => $this->branchModel(AnalysisMethod::query(), 'analysis_methods')->where('status', 'pending_approval')->count(),
            'critical_stock' => $criticalStockCount,
            'expired_soon' => DB::table('inventories')
                ->where('inventories.expiration_date', '<=', Carbon::now()->addDays(30))
                ->where('inventories.expiration_date', '>', Carbon::now())
                ->where('inventories.branch_id', $this->branchId())
                ->where('quantity', '>', 0)
                ->count(),
            
            'total_customers' => $this->branchModel(Customer::query(), 'customers')->where('status', 'active')->count(),
            'new_customers_this_month' => $this->branchModel(Customer::query(), 'customers')
                                                   ->whereMonth('created_at', Carbon::now()->month)
                                                   ->whereYear('created_at', Carbon::now()->year)
                                                   ->count(),
            'pending_offers' => $this->branchModel(Offer::query(), 'offers')->where('status', 'pending')->count(),
            'pending_offers_total' => $this->branchModel(Offer::query(), 'offers')->where('status', 'pending')->sum('total_amount'),
            'total_offers' => $this->branchModel(Offer::query(), 'offers')->count(),
            'active_samples' => $this->branchModel(Sample::query(), 'samples')->whereIn('status', ['pending', 'in_progress', 'in_analysis'])->count(),
            'samples_in_analysis' => $this->branchModel(Sample::query(), 'samples')->where('status', 'in_analysis')->count(),
            'calibration_due' => $this->branchModel(Equipment::query(), 'equipment')->where('next_calibration_date', '<=', Carbon::now()->addDays(30))->count(),
            'calibration_overdue' => $this->branchModel(Equipment::query(), 'equipment')->where('next_calibration_date', '<', Carbon::now())->count(),
            
            'total_materials' => $this->branchModel(Material::query(), 'materials')->count(),
            'total_personnel' => Personnel::query()->where('status', 'active')->count(),
            'total_equipment' => $this->branchModel(Equipment::query(), 'equipment')->where('status', 'active')->count(),
            'total_templates' => $this->branchTable(DB::table('document_templates'), 'document_templates')->count(),
            
            'chemical_usage_percent' => $this->calculateUsagePercent('kimyasallar'),
            'critical_stock_percent' => $this->calculateCriticalStockPercent(),
            'consumable_usage_percent' => $this->calculateUsagePercent('sarf-malzemeler'),
            'reference_usage_percent' => $this->calculateUsagePercent('cihaz-parcalari'),
        ];

        // ═══════════════════════════════════════════════════════════════════════════
        // SON TEKLİFLER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $latestOffers = $this->branchModel(Offer::query(), 'offers')
            ->with(['customer', 'contact', 'consultant'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // AKTİF NUMUNELER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $activeSamples = $this->branchModel(Sample::query(), 'samples')
            ->with(['offer.customer', 'storageLocation'])
            ->whereIn('status', ['pending', 'in_progress', 'in_analysis'])
            ->orderBy('received_at', 'desc')
            ->limit(6)
            ->get()
            ->map(function ($sample) {
                // İlişkilerde de kalkanı aşmak için withoutGlobalScopes() eklenebilir
                $totalAnalyses = $sample->workOrders()->count();
                $completedAnalyses = $sample->workOrders()->where('status', 'completed')->count();
                $sample->analysis_progress = $totalAnalyses > 0 
                    ? round(($completedAnalyses / $totalAnalyses) * 100) 
                    : 0;
                return $sample;
            });

        // ═══════════════════════════════════════════════════════════════════════════
        // SON STOK HAREKETLERİ (DB::table olduğu için güvenli)
        // ═══════════════════════════════════════════════════════════════════════════
        
        $latestMovements = DB::table('stock_movements')
            ->join('materials', 'stock_movements.material_id', '=', 'materials.id')
            ->leftJoin('users', 'stock_movements.user_id', '=', 'users.id')
            ->where('stock_movements.branch_id', $this->branchId())
            ->where('materials.branch_id', $this->branchId())
            ->select(
                'stock_movements.*',
                'materials.name as material_name',
                'materials.code as material_code',
                'users.name as user_name'
            )
            ->orderBy('stock_movements.created_at', 'desc')
            ->limit(8)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // KRİTİK STOK LİSTESİ
        // ═══════════════════════════════════════════════════════════════════════════
        
        $criticalStockItems = $this->branchModel(Material::query(), 'materials')
            ->select('materials.*')
            ->selectSub(function ($query) {
                $query->from('inventories')
                    ->selectRaw('COALESCE(SUM(quantity), 0)')
                    ->whereColumn('inventories.material_id', 'materials.id')
                    ->where('inventories.branch_id', $this->branchId());
            }, 'current_stock')
            ->whereRaw('(
                SELECT COALESCE(SUM(quantity), 0)
                FROM inventories
                WHERE inventories.material_id = materials.id
                  AND inventories.branch_id = ?
            ) <= materials.min_stock', [$this->branchId()])
            ->orderByRaw('current_stock / NULLIF(min_stock, 0) ASC')
            ->limit(10)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // YAKLAŞAN SKT (DB::table olduğu için güvenli)
        // ═══════════════════════════════════════════════════════════════════════════
        
        $expiringMaterials = DB::table('inventories')
            ->join('materials', 'inventories.material_id', '=', 'materials.id')
            ->where('inventories.branch_id', $this->branchId())
            ->where('materials.branch_id', $this->branchId())
            ->select(
                'inventories.*',
                'materials.name as material_name',
                'materials.code as material_code',
                'materials.unit as material_unit'
            )
            ->where('inventories.expiration_date', '<=', Carbon::now()->addDays(30))
            ->where('inventories.expiration_date', '>', Carbon::now())
            ->where('inventories.quantity', '>', 0)
            ->orderBy('inventories.expiration_date', 'asc')
            ->limit(8)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // BEKLEYEN GÖREVLER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $pendingTasks = $this->branchModel(Task::query(), 'project_management_tasks')
            ->with(['assignedTo', 'department'])
            ->whereIn('status', ['pending', 'in_progress'])
            ->orderByRaw("FIELD(priority, 'urgent', 'high', 'medium', 'low')")
            ->orderBy('due_date', 'asc')
            ->limit(5)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // SATIN ALMA TALEPLERİ
        // ═══════════════════════════════════════════════════════════════════════════
        
        $purchaseRequests = $this->branchModel(PurchaseRequest::query(), 'purchase_requests')
            ->with('requester')
            ->whereIn('status', ['pending', 'approved', 'ordered'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // KALİBRASYON TAKVİMİ
        // ═══════════════════════════════════════════════════════════════════════════
        
        $upcomingCalibrations = $this->branchModel(Equipment::query(), 'equipment')
            ->where('status', 'active')
            ->whereNotNull('next_calibration_date')
            ->where('next_calibration_date', '<=', Carbon::now()->addDays(60))
            ->orderBy('next_calibration_date', 'asc')
            ->limit(5)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // DEPARTMAN BAZLI İSTATİSTİKLER
        // ═══════════════════════════════════════════════════════════════════════════
        
        $departmentStats = Department::query()->get()->map(function ($department) {
            $department->active_count = 0;
            $department->completed_count = 0;
            if (Schema::hasTable('project_management_tasks')
                && Schema::hasColumn('project_management_tasks', 'department_id')
                && $this->branchId()) {
                $base = DB::table('project_management_tasks')
                    ->where('branch_id', $this->branchId())
                    ->where('department_id', $department->id);
                $department->active_count = (clone $base)->whereIn('status', ['pending', 'in_progress'])->count();
                $department->completed_count = (clone $base)->where('status', 'completed')
                    ->whereMonth('completed_at', Carbon::now()->month)->count();
            }
            return $department;
        });

        // ═══════════════════════════════════════════════════════════════════════════
        // AKTİF KULLANICILAR
        // ═══════════════════════════════════════════════════════════════════════════
        
        $activeUsers = User::query()
            ->with('department')
            ->where('last_activity_at', '>=', Carbon::now()->subMinutes(15))
            ->orderBy('last_activity_at', 'desc')
            ->limit(6)
            ->get();

        // ═══════════════════════════════════════════════════════════════════════════
        // GRAFİK VERİLERİ
        // ═══════════════════════════════════════════════════════════════════════════
        
        $chartData = $this->getChartData();
        $activeBranchName = session('active_branch_name', 'Şube seçilmedi');

        return view('admin.dashboard', compact(
            'stats',
            'latestOffers',
            'activeSamples',
            'latestMovements',
            'criticalStockItems',
            'expiringMaterials',
            'pendingTasks',
            'purchaseRequests',
            'upcomingCalibrations',
            'departmentStats',
            'activeUsers',
            'chartData',
            'activeBranchName'
        ));

        $isKnowledgeBaseAuthorized = auth()->user()->can('knowledge_base_access');

    return view('admin.dashboard', compact('isKnowledgeBaseAuthorized', 'digerDegiskenler'));
    }

    private function branchId(): int
    {
        return (int) session('active_branch_id', 0);
    }

    private function branchTable($query, string $table)
    {
        if (!$this->branchId() || !Schema::hasTable($table) || !Schema::hasColumn($table, 'branch_id')) {
            return $query->whereRaw('1 = 0');
        }

        return $query->where($table . '.branch_id', $this->branchId());
    }

    private function branchModel($query, string $table)
    {
        return $this->branchTable($query, $table);
    }

    private function calculateUsagePercent(string $categorySlug): int
    {
        $categoryId = DB::table('inventory_categories')
            ->where('branch_id', $this->branchId())
            ->where('slug', $categorySlug)
            ->value('id');
        if (!$categoryId) return 0;
        
        $totalCapacity = DB::table('materials')->where('branch_id', $this->branchId())->where('category_id', $categoryId)->sum('min_stock') * 5;
        
        $currentStock = DB::table('inventories')
            ->join('materials', 'inventories.material_id', '=', 'materials.id')
            ->where('materials.branch_id', $this->branchId())
            ->where('inventories.branch_id', $this->branchId())
            ->where('materials.category_id', $categoryId)
            ->sum('inventories.quantity');
        
        if ($totalCapacity <= 0) return 0;
        
        $usagePercent = (($totalCapacity - $currentStock) / $totalCapacity) * 100;
        return (int) max(0, min(100, round($usagePercent)));
    }

    private function calculateCriticalStockPercent(): int
    {
        // Burada da Material:: kullandığımız için ezdik
        $total = $this->branchModel(Material::query(), 'materials')->where('min_stock', '>', 0)->count();
        if ($total <= 0) return 0;
        
        $critical = $this->branchTable(DB::table('materials'), 'materials')
            ->where('materials.min_stock', '>', 0)
            ->whereRaw('(SELECT COALESCE(SUM(quantity), 0) FROM inventories i WHERE i.material_id = materials.id AND i.branch_id = ?) <= materials.min_stock', [$this->branchId()])
            ->count();
        $critical = [(object) ['cnt' => $critical]];
        
        $criticalCount = $critical[0]->cnt ?? 0;
        
        return (int) round(($criticalCount / $total) * 100);
    }

    private function getChartData(): array
    {
        $months = [];
        $monthlyCompleted = [];
        $monthlyStarted = [];
        $offersSent = [];
        $offersApproved = [];

        for ($i = 11; $i >= 0; $i--) {
            $date = Carbon::now()->subMonths($i);
            $months[] = $date->translatedFormat('M');
            
            // Grafiklerdeki Eloquent çağrılarını da ezdik
            $monthlyCompleted[] = SampleAnalysis::query()
                ->whereMonth('completed_at', $date->month)
                ->whereYear('completed_at', $date->year)
                ->where('status', 'completed')
                ->count();
            
            $monthlyStarted[] = SampleAnalysis::query()
                ->whereMonth('created_at', $date->month)
                ->whereYear('created_at', $date->year)
                ->count();
            
            $offersSent[] = $this->branchModel(Offer::query(), 'offers')
                ->whereMonth('created_at', $date->month)
                ->whereYear('created_at', $date->year)
                ->whereIn('status', ['sent', 'approved', 'rejected'])
                ->count();
            
            $offersApproved[] = $this->branchModel(Offer::query(), 'offers')
                ->whereMonth('approved_at', $date->month)
                ->whereYear('approved_at', $date->year)
                ->where('status', 'approved')
                ->count();
        }

        $topCustomers = $this->branchModel(Offer::query(), 'offers')
            ->select('customer_id', DB::raw('SUM(total_amount) as total'))
            ->where('status', 'approved')
            ->whereYear('created_at', Carbon::now()->year)
            ->groupBy('customer_id')
            ->orderBy('total', 'desc')
            ->limit(4)
            ->with('customer')
            ->get();

        $customerNames = $topCustomers->pluck('customer.company_name')->toArray();
        $customerRevenue = $topCustomers->pluck('total')->toArray();
        
        $otherRevenue = $this->branchModel(Offer::query(), 'offers')
            ->where('status', 'approved')
            ->whereYear('created_at', Carbon::now()->year)
            ->whereNotIn('customer_id', $topCustomers->pluck('customer_id'))
            ->sum('total_amount');
        
        if ($otherRevenue > 0) {
            $customerNames[] = 'Diğer';
            $customerRevenue[] = $otherRevenue;
        }

        $analysisTypes = SampleAnalysis::query()
            ->select('analysis_type', DB::raw('COUNT(*) as count'))
            ->whereYear('created_at', Carbon::now()->year)
            ->groupBy('analysis_type')
            ->orderBy('count', 'desc')
            ->get();

        $stockDays = [];
        $stockIn = [];
        $stockOut = [];
        
        for ($i = 6; $i >= 0; $i--) {
            $date = Carbon::now()->subDays($i);
            $stockDays[] = $date->translatedFormat('D');
            
            $stockIn[] = $this->branchModel(StockMovement::query(), 'stock_movements')
                ->whereDate('created_at', $date)
                ->where('type', 'in')
                ->count();
            
            $stockOut[] = $this->branchModel(StockMovement::query(), 'stock_movements')
                ->whereDate('created_at', $date)
                ->where('type', 'out')
                ->count();
        }

        return [
            'monthly_labels' => $months,
            'monthly_completed' => $monthlyCompleted,
            'monthly_started' => $monthlyStarted,
            'offers_sent' => $offersSent,
            'offers_approved' => $offersApproved,
            'top_customers' => $customerNames,
            'customer_revenue' => $customerRevenue,
            'analysis_types' => $analysisTypes->pluck('analysis_type')->toArray(),
            'analysis_counts' => $analysisTypes->pluck('count')->toArray(),
            'stock_days' => $stockDays,
            'stock_in' => $stockIn,
            'stock_out' => $stockOut,
        ];
    }
}