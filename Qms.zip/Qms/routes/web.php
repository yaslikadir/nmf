<?php

use Illuminate\Support\Facades\Route;

// QMS Kontrolcüleri
use Modules\Qms\Http\Controllers\DocumentController;
use Modules\Qms\Http\Controllers\TrainingRequestController;
use Modules\Qms\Http\Controllers\TrainingController;
use Modules\Qms\Http\Controllers\TrainingPlanController;
use Modules\Qms\Http\Controllers\MyTrainingController;
use Modules\Qms\Http\Controllers\FeedbackController;
use Modules\Qms\Http\Controllers\RiskController;
use Modules\Qms\Http\Controllers\EmergencyPlanController;
use Modules\Qms\Http\Controllers\RiskDashboardController;
use Modules\Qms\Http\Controllers\AuditController;
use Modules\Qms\Http\Controllers\AuditPlanController;
use Modules\Qms\Http\Controllers\AuditChecklistController;
use Modules\Qms\Http\Controllers\CapaController;
use Modules\Qms\Http\Controllers\ChangeController;
use Modules\Qms\Http\Middleware\QmsBranchAccess;

Route::middleware(QmsBranchAccess::class)->group(function () {

// --- 0. DASHBOARDLAR ---
Route::get('risks/dashboard', [RiskDashboardController::class, 'index'])->name('risks.dashboard');
Route::get('trainings/dashboard', [TrainingController::class, 'dashboard'])->name('trainings.dashboard');
Route::get('audits/dashboard', [AuditController::class, 'dashboard'])->name('audits.dashboard');

// 1. EĞİTİM TALEPLERİ
Route::prefix('requests')->name('requests.')->group(function () {
    Route::get('/', [TrainingRequestController::class, 'index'])->name('index');
    Route::post('/{id}/update', [TrainingRequestController::class, 'updateStatus'])->name('update');
    Route::delete('/{id}', [TrainingRequestController::class, 'destroy'])->name('destroy');
});

// 2. DOKÜMAN YÖNETİMİ
Route::controller(DocumentController::class)->prefix('documents')->name('documents.')->group(function () {
    Route::get('/', 'index')->name('index');
    Route::get('/create', 'create')->name('create');
    Route::post('/', 'store')->name('store');
    Route::post('/folder/{id}/unlock', 'unlockFolder')->name('folder.unlock');
    Route::post('/store-bulk', 'storeBulk')->name('store-bulk');
    Route::post('/store-bulk-history', 'storeBulkHistory')->name('store-bulk-history');
    Route::get('/{id}/print-distribution', 'printDistributionForm')->name('print-distribution');
    Route::get('/{id}', 'show')->name('show');
    Route::delete('/{id}', 'destroy')->name('destroy');
    Route::get('/download/{versionId}', 'download')->name('download');
    Route::post('/approve/{versionId}', 'approve')->name('approve');
    Route::post('/{id}/revise', 'revise')->name('revise');
    Route::post('/create-folder', 'storeFolder')->name('create-folder');
    Route::post('/folder/{id}/update', 'updateFolder')->name('folder.update');
    Route::delete('/folder/{id}', 'destroyFolder')->name('folder.destroy');
    Route::post('/distribute/{versionId}', 'distribute')->name('distribute');
    Route::post('/mark-read/{versionId}', 'markAsRead')->name('mark-read');
});

// 3. DENETİM YÖNETİMİ
Route::prefix('audits')->name('audits.')->group(function () {
    Route::resource('plans', AuditPlanController::class);
    Route::resource('checklists', AuditChecklistController::class);
    Route::post('checklists/{id}/questions', [AuditChecklistController::class, 'storeQuestion'])->name('checklists.questions.store');
    Route::delete('questions/{id}', [AuditChecklistController::class, 'destroyQuestion'])->name('questions.destroy');
    Route::get('/{id}/perform', [AuditController::class, 'perform'])->name('perform');
    Route::post('/{id}/findings', [AuditController::class, 'storeFinding'])->name('findings.store');
    Route::post('/{id}/complete', [AuditController::class, 'complete'])->name('complete');
    Route::get('/{id}/report', [AuditController::class, 'report'])->name('report');
    Route::resource('/', AuditController::class)->parameters(['' => 'audit']);
});

// 4. CAPA YÖNETİMİ
Route::prefix('capas')->name('capas.')->group(function () {
    Route::resource('/', CapaController::class)->parameters(['' => 'capa']);
    Route::post('/{id}/save-root-cause', [CapaController::class, 'saveRootCause'])->name('save-root-cause');
    Route::post('/{id}/add-action', [CapaController::class, 'addAction'])->name('add-action');
    Route::post('/action/{actionId}/complete', [CapaController::class, 'completeAction'])->name('actions.complete');
    Route::get('/{id}/report', [CapaController::class, 'report'])->name('report');
    Route::post('/{id}/close', [CapaController::class, 'closeCapa'])->name('close');
});

// 5. DEĞİŞİKLİK YÖNETİMİ
Route::prefix('changes')->name('changes.')->group(function () {
    Route::resource('/', ChangeController::class)->parameters(['' => 'change']);
    Route::post('/{id}/add-risk', [ChangeController::class, 'addRisk'])->name('add-risk');
    Route::post('/risk/{riskId}/update', [ChangeController::class, 'updateRisk'])->name('update-risk');
    Route::delete('/risk/{riskId}', [ChangeController::class, 'deleteRisk'])->name('delete-risk');
    Route::post('/{id}/add-action', [ChangeController::class, 'addAction'])->name('add-action');
    Route::post('/action/{actionId}/update', [ChangeController::class, 'updateAction'])->name('update-action');
    Route::post('/action/{actionId}/complete', [ChangeController::class, 'completeAction'])->name('actions.complete');
    Route::post('/{id}/submit-approval', [ChangeController::class, 'submitForApproval'])->name('submit-approval');
    Route::post('/{id}/approve', [ChangeController::class, 'approveChange'])->name('approve');
    Route::post('/{id}/complete-process', [ChangeController::class, 'completeProcess'])->name('complete-process');
    Route::post('/{id}/verify-close', [ChangeController::class, 'verifyAndClose'])->name('verify-close');
    Route::post('/{id}/upload', [ChangeController::class, 'uploadAttachment'])->name('upload');
    Route::delete('/attachment/{id}', [ChangeController::class, 'deleteAttachment'])->name('delete-attachment');
    Route::get('/{id}/report', [ChangeController::class, 'report'])->name('report');
    Route::post('/{id}/announce', [ChangeController::class, 'sendAnnouncement'])->name('announce');
});

// 6. EĞİTİM YÖNETİMİ
Route::prefix('trainings')->name('trainings.')->group(function () {
    Route::post('/run-daily-jobs', [TrainingController::class, 'runDailyJobs'])->name('run-daily-jobs');
    Route::resource('/', TrainingController::class)->parameters(['' => 'training']);
    Route::post('/{id}/upload-material', [TrainingController::class, 'uploadMaterial'])->name('upload-material');
    Route::delete('/material/{materialId}', [TrainingController::class, 'deleteMaterial'])->name('delete-material');
    Route::post('/{id}/questions', [TrainingController::class, 'storeQuestion'])->name('questions.store');
    Route::delete('/questions/{questionId}', [TrainingController::class, 'deleteQuestion'])->name('questions.destroy');
});

// 7. EĞİTİM PLANLAMA
Route::prefix('training-plans')->name('plans.')->group(function () {
    Route::get('/', [TrainingPlanController::class, 'index'])->name('index');
    Route::get('/create', [TrainingPlanController::class, 'create'])->name('create');
    Route::post('/', [TrainingPlanController::class, 'store'])->name('store');
    Route::get('/{id}', [TrainingPlanController::class, 'show'])->name('show');
    Route::post('/{id}/cancel', [TrainingPlanController::class, 'cancel'])->name('cancel');
    Route::get('/{id}/print', [TrainingPlanController::class, 'printForm'])->name('print-form');
    Route::get('/{id}/edit', [TrainingPlanController::class, 'edit'])->name('edit');
    Route::put('/{id}', [TrainingPlanController::class, 'update'])->name('update');
});

// 8. PERSONEL EĞİTİM EKRANLARI
Route::prefix('my-trainings')->name('my-trainings.')->group(function () {
    Route::get('/', [MyTrainingController::class, 'index'])->name('index');
    Route::get('/material/{materialId}/view', [MyTrainingController::class, 'viewMaterial'])->name('material.view');
    Route::get('/{id}', [MyTrainingController::class, 'show'])->name('show');
    Route::post('/{id}/complete', [MyTrainingController::class, 'completeWithoutExam'])->name('complete');
    Route::get('/{id}/exam', [MyTrainingController::class, 'startExam'])->name('exam.start');
    Route::post('/{id}/exam', [MyTrainingController::class, 'submitExam'])->name('exam.submit');
    Route::post('/{id}/evaluate', [MyTrainingController::class, 'storeEvaluation'])->name('evaluate.store');
    Route::post('/request-training', [MyTrainingController::class, 'storeRequest'])->name('request.store');
});

// 9. GERİ BİLDİRİM
Route::prefix('feedbacks')->name('feedbacks.')->group(function () {
    Route::get('/report', [FeedbackController::class, 'report'])->name('report');
    Route::get('/forms', [FeedbackController::class, 'forms'])->name('forms');
    Route::get('/{id}/print', [FeedbackController::class, 'printForm'])->name('print');
    Route::get('/', [FeedbackController::class, 'index'])->name('index');
    Route::get('/{id}', [FeedbackController::class, 'show'])->name('show');
    Route::put('/{id}', [FeedbackController::class, 'update'])->name('update');
});

// 10. RİSK VE FIRSAT YÖNETİMİ
Route::get('risks/general-report', [RiskController::class, 'generalReport'])->name('risks.general-report');
Route::post('risks/{risk}/action', [RiskController::class, 'storeAction'])->name('risks.action.store');
Route::put('risks/action/{id}/complete', [RiskController::class, 'completeAction'])->name('risks.action.complete');
Route::resource('risks', RiskController::class);

// 11. ACİL DURUM PLANLARI
Route::post('emergency-plans/{id}/complete-drill', [EmergencyPlanController::class, 'completeDrill'])->name('emergency-plans.complete-drill');
Route::post('emergency-plans/{id}/store-drill', [EmergencyPlanController::class, 'storeDrillResult'])->name('emergency-plans.store-drill');
Route::get('emergency-drills/{id}/report', [EmergencyPlanController::class, 'showDrillReport'])->name('emergency-drills.report');
Route::resource('emergency-plans', EmergencyPlanController::class);

});