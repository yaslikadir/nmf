<?php

namespace Modules\Qms\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;

class QmsServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // Migrations
        $this->loadMigrationsFrom(__DIR__ . '/../../database/migrations');

        // Views (Ana projede 'qms::' olarak çağırılacak)
        $this->loadViewsFrom(__DIR__ . '/../../resources/views', 'qms');

        // Routes
        $this->registerRoutes();
    }

    protected function registerRoutes(): void
    {
        Route::middleware(['web', 'auth', 'verified', 'active_user'])
            ->prefix('admin/qms')
            ->name('admin.qms.')
            ->group(__DIR__ . '/../../routes/web.php');
    }
}