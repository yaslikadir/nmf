<?php

namespace Modules\Qms\Services;

use Modules\Qms\Models\QmsDocument;
use Modules\Qms\Models\QmsDocumentApproval;
use Modules\Qms\Models\QmsDocumentLog;
use Modules\Qms\Models\QmsDocumentVersion;
use Modules\Qms\Models\QmsDocumentFolder;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class QmsDocumentService
{
    public function createDocument(array $data, UploadedFile $file): QmsDocument
    {
        return DB::transaction(function () use ($data, $file) {
            // Global branch scope ile klasörün aktif şubeye ait olduğu doğrulanır.
            QmsDocumentFolder::findOrFail($data['folder_id']);

            $document = QmsDocument::create([
                'document_code' => $data['document_code'] ?? null,
                'name' => $data['name'],
                'folder_id' => $data['folder_id'],
                'security_level' => $data['security_level'] ?? 'Internal',
                'retention_period_years' => (int) ($data['retention_period_years'] ?? 5),
                'owner_id' => auth()->id(),
                'status' => 'Draft',
            ]);

            $version = $this->persistVersion($document, $file, '1.0', null, $data['approvers'] ?? []);
            $this->logAction($document->id, 'CREATE', 'Doküman taslağı oluşturuldu.');

            return $document->load('versions', 'owner');
        });
    }

    public function createVersion(
        int $documentId,
        UploadedFile $file,
        string $versionNo,
        ?string $revisionReason = null,
        array $approvers = []
    ): QmsDocumentVersion {
        return DB::transaction(function () use ($documentId, $file, $versionNo, $revisionReason, $approvers) {
            $document = QmsDocument::findOrFail($documentId);
            $version = $this->persistVersion($document, $file, $versionNo, $revisionReason, $approvers);
            $this->logAction($document->id, 'REVISION', 'Yeni doküman versiyonu oluşturuldu: Rev' . $versionNo);

            return $version;
        });
    }

    public function approveVersion(int $versionId, ?string $comments = null): QmsDocumentVersion
    {
        return DB::transaction(function () use ($versionId, $comments) {
            $version = QmsDocumentVersion::with('document')->findOrFail($versionId);

            $version->update([
                'status' => 'Approved',
                'approved_by' => auth()->id(),
                'published_at' => now(),
                'is_current' => true,
            ]);

            QmsDocumentVersion::where('document_id', $version->document_id)
                ->where('id', '!=', $version->id)
                ->update(['is_current' => false]);

            $version->document->update(['status' => 'Published']);
            $version->approvals()->create([
                'user_id' => auth()->id(),
                'status' => 'Approved',
                'comments' => $comments,
                'action_date' => now(),
                'order' => 1,
            ]);
            $this->logAction($version->document_id, 'APPROVE', 'Doküman versiyonu onaylandı: Rev' . $version->version_no);

            return $version->fresh();
        });
    }

    public function logAction(int $documentId, string $action, ?string $description = null): QmsDocumentLog
    {
        return QmsDocumentLog::create([
            'document_id' => $documentId,
            'user_id' => auth()->id(),
            'action' => $action,
            'description' => $description,
        ]);
    }

    private function persistVersion(
        QmsDocument $document,
        UploadedFile $file,
        string $versionNo,
        ?string $revisionReason,
        array $approvers
    ): QmsDocumentVersion {
        $path = $file->store('qms_documents/' . now()->format('Y'), 'local');

        $version = $document->versions()->create([
            'version_no' => $versionNo,
            'file_path' => $path,
            'file_hash' => hash_file('sha256', $file->getRealPath()),
            'status' => 'InReview',
            'revision_reason' => $revisionReason,
            'created_by' => auth()->id(),
            'is_current' => false,
        ]);

        foreach (array_unique(array_filter(array_map('intval', $approvers))) as $order => $userId) {
            $version->approvals()->create([
                'user_id' => $userId,
                'status' => 'Pending',
                'order' => $order + 1,
            ]);
        }

        return $version;
    }
}
