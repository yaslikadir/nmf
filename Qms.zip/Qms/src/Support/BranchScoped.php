<?php

namespace Modules\Qms\Support;

use Illuminate\Database\Eloquent\Builder;

trait BranchScoped
{
    protected static function bootBranchScoped(): void
    {
        static::addGlobalScope('qms_branch', function (Builder $builder): void {
            $branchId = session('active_branch_id');

            if (!$branchId) {
                $builder->whereRaw('1 = 0');
                return;
            }

            $builder->where($builder->getModel()->getTable() . '.branch_id', $branchId);
        });

        static::creating(function ($model): void {
            $branchId = session('active_branch_id');

            if (!$branchId) {
                throw new \RuntimeException('QMS kaydı oluşturulmadan önce aktif şube seçilmelidir.');
            }

            $model->branch_id = $branchId;
        });

        static::updating(function ($model): void {
            $branchId = session('active_branch_id');

            if (!$branchId || (string) $model->branch_id !== (string) $branchId) {
                throw new \RuntimeException('QMS kaydı farklı bir şubeye taşınamaz.');
            }
        });
    }
}
