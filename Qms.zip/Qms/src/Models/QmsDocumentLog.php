<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsDocumentLog extends Model
{
    use BranchScoped;
    // Log tablosu olduğu için timestamps false yapılabilir, 
    // ama created_at'i migration'da useCurrent() yaptık, o yüzden dokunmuyoruz.
    public $timestamps = false; 

    protected $guarded = ['branch_id'];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    public function document()
    {
        return $this->belongsTo(QmsDocument::class, 'document_id');
    }

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
}