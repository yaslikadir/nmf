<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsCapaAction extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];
    protected $casts = ['due_date' => 'date', 'completed_at' => 'date'];

    public function capa()
    {
        return $this->belongsTo(QmsCapa::class);
    }

    public function responsible()
    {
        return $this->belongsTo(\App\Models\User::class, 'responsible_user_id');
    }
}