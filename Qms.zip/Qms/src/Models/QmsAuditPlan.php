<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;
use Illuminate\Database\Eloquent\SoftDeletes;

class QmsAuditPlan extends Model
{
    use BranchScoped;
    use SoftDeletes;
    protected $guarded = ['branch_id'];

    public function audits()
    {
        return $this->hasMany(QmsAudit::class, 'audit_plan_id');
    }
    
    public function creator()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }
}