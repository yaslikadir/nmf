<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsAuditFinding extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];

    public function audit()
    {
        return $this->belongsTo(QmsAudit::class);
    }

    public function question()
    {
        return $this->belongsTo(QmsAuditQuestion::class);
    }
}