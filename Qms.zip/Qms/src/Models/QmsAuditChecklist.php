<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsAuditChecklist extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];

    public function questions()
    {
        return $this->hasMany(QmsAuditQuestion::class, 'checklist_id')->orderBy('order');
    }
}