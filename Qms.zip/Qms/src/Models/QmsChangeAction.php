<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsChangeAction extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];
    protected $casts = ['due_date' => 'date', 'completed_at' => 'datetime'];

    public function responsible() {
        return $this->belongsTo(\App\Models\User::class, 'responsible_user_id');
    }
    
    // Aksiyon Tipi Türkçesi
    public function getTypeLabelAttribute() {
        $map = [
            'Training' => 'Eğitim',
            'Document_Revision' => 'Doküman Revizyonu',
            'Purchase' => 'Satın Alma',
            'Other' => 'Diğer'
        ];
        return $map[$this->action_type] ?? $this->action_type;
    }
}