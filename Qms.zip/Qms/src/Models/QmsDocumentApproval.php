<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsDocumentApproval extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];

    protected $casts = [
        'action_date' => 'datetime',
    ];

    public function version()
    {
        return $this->belongsTo(QmsDocumentVersion::class, 'document_version_id');
    }

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    // Onay bekleyen kayıtları bulmak için scope
    public function scopePending($query)
    {
        return $query->where('status', 'Pending');
    }
}