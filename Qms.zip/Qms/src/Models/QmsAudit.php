<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;
use Illuminate\Database\Eloquent\SoftDeletes;

class QmsAudit extends Model
{
    use BranchScoped;
    use SoftDeletes;
    protected $guarded = ['branch_id'];

    protected $casts = [
        'planned_date' => 'date',
        'performed_date' => 'date',
    ];

    public function plan()
    {
        return $this->belongsTo(QmsAuditPlan::class, 'audit_plan_id');
    }

    public function leadAuditor()
    {
        return $this->belongsTo(\App\Models\User::class, 'lead_auditor_id');
    }

    // Ekip (Pivot Tablo)
    public function auditors()
    {
        return $this->belongsToMany(\App\Models\User::class, 'qms_audit_auditors', 'audit_id', 'user_id')
                    ->withPivot('role');
    }

    public function department()
    {
        return $this->belongsTo(\App\Models\Department::class);
    }

    // --- EKSİK OLAN İLİŞKİ (BUNU EKLEDİK) ---
    public function supplier()
    {
        // Tedarikçi modelinizin adı neyse onu yazın (Genelde \App\Models\Supplier::class)
        return $this->belongsTo(\App\Models\Supplier::class);
    }
    // ----------------------------------------
    
    // Bağlı Soru Listeleri
    public function checklists()
    {
        return $this->belongsToMany(QmsAuditChecklist::class, 'qms_audit_checklist_assignments', 'audit_id', 'checklist_id');
    }

    public function findings()
    {
        return $this->hasMany(QmsAuditFinding::class, 'audit_id');
    }

    // 1. KAYNAK (SOURCE) İÇİN TÜRKÇE KARŞILIK
    public function getSourceLabelAttribute()
    {
        $map = [
            'Audit' => 'Denetim Bulgusu',
            'Complaint' => 'Müşteri Şikayeti',
            'Risk' => 'Risk Analizi',
            'Incident' => 'Olay / Kaza',
            'Other' => 'Diğer'
        ];
        
        return $map[$this->source] ?? $this->source;
    }

    // 2. DURUM (STATUS) İÇİN TÜRKÇE KARŞILIK VE RENK
    public function getStatusLabelAttribute()
    {
        $map = [
            'Opened' => ['text' => 'Yeni / Açık', 'class' => 'bg-secondary'],
            'Root_Cause_Analysis' => ['text' => 'Kök Neden Analizi', 'class' => 'bg-warning text-dark'],
            'Action_Planning' => ['text' => 'Aksiyon Planlama', 'class' => 'bg-info text-dark'],
            'Verification' => ['text' => 'Doğrulama', 'class' => 'bg-primary'],
            'Closed' => ['text' => 'Kapalı', 'class' => 'bg-success'],
            'Cancelled' => ['text' => 'İptal', 'class' => 'bg-dark'],
        ];

        return $map[$this->status] ?? ['text' => $this->status, 'class' => 'bg-secondary'];
    }
}