<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsAuditQuestion extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];

    public function checklist()
    {
        return $this->belongsTo(QmsAuditChecklist::class);
    }
}