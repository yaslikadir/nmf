<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsChangeRisk extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];

    // Risk Seviyesi Hesaplama (1-25)
    public function getRiskLevelAttribute() {
        $score = $this->risk_score;
        if($score >= 15) return ['text' => 'Yüksek', 'class' => 'bg-danger text-white'];
        if($score >= 8) return ['text' => 'Orta', 'class' => 'bg-warning text-dark'];
        return ['text' => 'Düşük', 'class' => 'bg-success text-white'];
    }
}