<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsDocumentVersion extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];

    protected $casts = [
        'change_logs' => 'array',
        'valid_from' => 'date',
        'valid_until' => 'date',
        'is_current' => 'boolean',
    ];

    // Hangi ana dokümana ait?
    public function document()
    {
        return $this->belongsTo(QmsDocument::class, 'document_id');
    }

    // Versiyonu oluşturan
    public function creator()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }

    // Nihai onayı veren (Yayınlayan)
    public function approver()
    {
        return $this->belongsTo(\App\Models\User::class, 'approved_by');
    }

    // Onay Akışı (Sıralı Liste)
    public function approvals()
    {
        return $this->hasMany(QmsDocumentApproval::class, 'document_version_id')->orderBy('order', 'asc');
    }

    // Dağıtım Listesi (Okuması Gerekenler)
    public function distributions()
    {
        return $this->hasMany(QmsDocumentDistribution::class, 'document_version_id');
    }

    // --- HELPER ---
    
    // Dosyanın tam yolu (Storage linki için)
    public function getDownloadUrlAttribute()
    {
        // Güvenlik için direkt link vermek yerine, route üzerinden kontrolle indirme yaptıracağız.
        return route('admin.qms.documents.download', $this->id);
    }
}