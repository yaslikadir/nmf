<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;
use Illuminate\Database\Eloquent\SoftDeletes;

class QmsCapa extends Model
{
    use BranchScoped;
    use SoftDeletes;
    protected $guarded = ['branch_id'];

    protected $casts = [
        'target_date' => 'date',
        'closed_date' => 'date',
    ];

    // --- İLİŞKİLER ---

    public function lead()
    {
        return $this->belongsTo(\App\Models\User::class, 'lead_user_id');
    }

    public function department()
    {
        return $this->belongsTo(\App\Models\Department::class);
    }

    public function actions()
    {
        return $this->hasMany(QmsCapaAction::class, 'capa_id');
    }

    public function auditFinding()
    {
        return $this->belongsTo(QmsAuditFinding::class, 'audit_finding_id');
    }

    // --- SİHİRLİ ÇEVİRİCİLER (ACCESSORS) ---
    // Bu kısımlar olmazsa "status_label" hatası alırsın.

    // 1. KAYNAK (SOURCE) ÇEVİRİSİ
    public function getSourceLabelAttribute()
    {
        $map = [
            'Audit' => 'Denetim Bulgusu',
            'Complaint' => 'Müşteri Şikayeti',
            'Risk' => 'Risk Analizi',
            'Incident' => 'Olay / Kaza',
            'Other' => 'Diğer'
        ];
        
        return $map[$this->source] ?? $this->source;
    }

    // 2. DURUM (STATUS) ÇEVİRİSİ VE RENKLENDİRME
    public function getStatusLabelAttribute()
    {
        $map = [
            'Opened' => ['text' => 'Yeni / Açık', 'class' => 'bg-secondary'],
            'Root_Cause_Analysis' => ['text' => 'Kök Neden Analizi', 'class' => 'bg-warning text-dark'],
            'Action_Planning' => ['text' => 'Aksiyon Planlama', 'class' => 'bg-info text-white'],
            'Verification' => ['text' => 'Doğrulama', 'class' => 'bg-primary'],
            'Closed' => ['text' => 'Kapalı', 'class' => 'bg-success'],
            'Cancelled' => ['text' => 'İptal', 'class' => 'bg-dark'],
        ];

        // Eğer veritabanındaki durum listede yoksa varsayılanı döndür
        return $map[$this->status] ?? ['text' => $this->status, 'class' => 'bg-secondary'];
    }

    public function risk()
{
    return $this->belongsTo(\App\Models\Risk::class, 'risk_id');
}
}