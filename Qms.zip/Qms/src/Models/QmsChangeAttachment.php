<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsChangeAttachment extends Model
{
    use BranchScoped;
    // Mass Assignment hatasını çözen satır:
    // Tüm sütunların doldurulmasına izin ver.
    protected $guarded = ['branch_id'];

    // --- İLİŞKİLER (Opsiyonel ama faydalı) ---

    public function change()
    {
        return $this->belongsTo(QmsChange::class, 'change_id');
    }

    public function uploader()
    {
        return $this->belongsTo(\App\Models\User::class, 'uploaded_by');
    }
}