<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;
use Illuminate\Database\Eloquent\SoftDeletes;

class QmsChange extends Model
{
    use BranchScoped;
    use SoftDeletes;
    protected $guarded = ['branch_id'];

    protected $casts = [
        'approved_at' => 'datetime',
        'closed_date' => 'date',
    ];

    // İlişkiler
    public function requester() {
        return $this->belongsTo(\App\Models\User::class, 'request_user_id');
    }

    public function approver() {
        return $this->belongsTo(\App\Models\User::class, 'approved_by');
    }

    public function department() {
        return $this->belongsTo(\App\Models\Department::class);
    }

    public function risks() {
        return $this->hasMany(QmsChange\App\Models\Risk::class, 'change_id');
    }

    public function actions() {
        return $this->hasMany(QmsChangeAction::class, 'change_id');
    }

    // Accessor: Türkçe Tip
    public function getTypeLabelAttribute() {
        $map = [
            'Procedure' => 'Prosedür / Doküman',
            'Equipment' => 'Cihaz / Ekipman',
            'Software' => 'Yazılım',
            'Personnel' => 'Personel / Organizasyon',
            'Facility' => 'Tesis / Altyapı',
            'Other' => 'Diğer'
        ];
        return $map[$this->type] ?? $this->type;
    }

    // Accessor: Türkçe Durum
    public function getStatusLabelAttribute() {
        $map = [
            'Draft' => ['text' => 'Taslak', 'class' => 'bg-secondary'],
            'Pending_Analysis' => ['text' => 'Risk Analizi Bekliyor', 'class' => 'bg-warning text-dark'],
            'Pending_Approval' => ['text' => 'Onay Bekliyor', 'class' => 'bg-info text-dark'],
            'Approved' => ['text' => 'Onaylandı / Uygulamada', 'class' => 'bg-primary'],
            'Rejected' => ['text' => 'Reddedildi', 'class' => 'bg-danger'],
            'Completed' => ['text' => 'Tamamlandı', 'class' => 'bg-success'],
            'Closed' => ['text' => 'Kapatıldı', 'class' => 'bg-dark']
        ];
        return $map[$this->status] ?? ['text' => $this->status, 'class' => 'bg-secondary'];
    }

    public function attachments() {
    return $this->hasMany(QmsChangeAttachment::class, 'change_id');
}
}