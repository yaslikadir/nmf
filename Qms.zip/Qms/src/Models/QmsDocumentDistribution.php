<?php

namespace Modules\Qms\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Qms\Support\BranchScoped;

class QmsDocumentDistribution extends Model
{
    use BranchScoped;
    protected $guarded = ['branch_id'];

    protected $casts = [
        'read_at' => 'datetime',
        'is_read_required' => 'boolean',
        'is_read' => 'boolean',
    ];

    public function version()
    {
        return $this->belongsTo(QmsDocumentVersion::class, 'document_version_id');
    }

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    public function department()
    {
        return $this->belongsTo(\App\Models\Department::class, 'department_id');
    }
}