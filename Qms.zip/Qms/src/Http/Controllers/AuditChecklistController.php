<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Qms\Models\QmsAuditChecklist;
use Modules\Qms\Models\QmsAuditQuestion;
use Illuminate\Http\Request;

class AuditChecklistController extends Controller
{
    public function index()
    {
        $checklists = QmsAuditChecklist::withCount('questions')->get();
        return view('qms::audits.checklists.index', compact('checklists'));
    }

    public function store(Request $request)
    {
        $request->validate(['name' => 'required|string']);
        QmsAuditChecklist::create($request->all());
        return back()->with('success', 'Soru listesi oluşturuldu.');
    }

    public function show($id)
    {
        $checklist = QmsAuditChecklist::with('questions')->findOrFail($id);
        return view('qms::audits.checklists.show', compact('checklist'));
    }

    // Soru Ekleme
    public function storeQuestion(Request $request, $id)
    {
        $request->validate([
            'question' => 'required|string',
            'order' => 'nullable|integer'
        ]);

        QmsAuditQuestion::create([
            'checklist_id' => $id,
            'question' => $request->question,
            'reference_standard' => $request->reference_standard,
            'order' => $request->order ?? 0
        ]);

        return back()->with('success', 'Soru eklendi.');
    }
    
    public function destroyQuestion($id)
    {
        QmsAuditQuestion::findOrFail($id)->delete();
        return back()->with('success', 'Soru silindi.');
    }
}