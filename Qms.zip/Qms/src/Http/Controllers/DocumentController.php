<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Qms\Models\QmsDocument;
use Modules\Qms\Models\QmsDocumentFolder;
use Modules\Qms\Services\QmsDocumentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Notification;
use App\Notifications\DocumentDistributedNotification;
use Spatie\Permission\Models\Role; 
use Illuminate\Support\Str; 

class DocumentController extends Controller
{
    protected $documentService;

    public function __construct(QmsDocumentService $documentService)
    {
        $this->documentService = $documentService;
    }

    /**
     * DUZELTiLDi: Yetki kontrolu - quality_manager rolu artik tum islemleri yapabilir
     * Admin, Kalite Yoneticisi veya quality_manager rolu tam yetkilidir.
     */
    private function checkPermission()
    {
        $user = auth()->user();
        
        // Admin her zaman gecer
        if ($user->isAdmin()) {
            return;
        }
        
        // quality_manager rolu her zaman gecer (403 hatasi duzeltmesi)
        if ($user->role === 'quality_manager' || $user->hasRole('quality_manager')) {
            return;
        }
        
        // Kalite Yoneticisi rolu (Turkce) her zaman gecer
        if ($user->role === 'Kalite Yöneticisi' || $user->hasRole('Kalite Yöneticisi')) {
            return;
        }
        
        // qms_documents modulunde create yetkisi olanlar gecer
        if (function_exists('canDo') && canDo('qms_documents', 'create')) {
            return;
        }
        
        abort(403, 'Bu islem icin yetkiniz bulunmamaktadir.');
    }

    /**
     * DUZELTiLDi: Yonetici kontrolu - quality_manager dahil edildi
     */
    private function isManager()
    {
        $user = auth()->user();
        
        if ($user->isAdmin()) {
            return true;
        }
        
        if ($user->role === 'quality_manager' || $user->hasRole('quality_manager')) {
            return true;
        }
        
        if ($user->role === 'Kalite Yöneticisi' || $user->hasRole('Kalite Yöneticisi')) {
            return true;
        }
        
        if (function_exists('canDo') && canDo('qms_documents', 'create')) {
            return true;
        }
        
        return false;
    }

    private function checkFolderAccess($folderId)
    {
        if (!$folderId) return null; 

        $folder = QmsDocumentFolder::find($folderId);
        if (!$folder) return null;

        // Yetki kontrolu
        if (!$folder->userHasAccess(auth()->user())) {
            return redirect()->route('admin.qms.documents.index')->with('error', 'Bu alana erisim izniniz yok.');
        }
        
        // Sifre kontrolu (Yonetici degilse)
        if ($folder->hasPasswordProtection() && session('unlocked_folder_' . $folderId) !== true) {
             if (!$this->isManager()) {
                 // 403 YERiNE MODALI ACTIRACAK SiHiRLi YONLENDiRME
                 return redirect()->route('admin.qms.documents.index')
                        ->with('locked_folder_id', $folderId)
                        ->with('locked_folder_name', $folder->name)
                        ->with('warning', 'Bu icerigi gormek icin klasor sifresini girmelisiniz.');
             }
        }
        
        return null;
    }

    public function index(Request $request)
    {
        $roles = Role::orderBy('name')->get(); 
        $users = \App\Models\User::orderBy('name')->get(); 

        if ($request->has('folder_id')) {
            // Yonlendirme varsa islemi kes ve uygula
            if ($redirect = $this->checkFolderAccess($request->folder_id)) return $redirect;
        }

        $query = QmsDocument::with(['owner', 'publishedVersion']);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('document_code', 'like', "%{$search}%")
                  ->orWhereHas('owner', function($subQ) use ($search) {
                      $subQ->where('name', 'like', "%{$search}%");
                  });
            });
        }

        if ($request->has('folder_id')) {
            $query->where('folder_id', $request->folder_id);
        }

        if (!$this->isManager()) {
            $forbiddenFolderIds = QmsDocumentFolder::all()->filter(function($f) {
                return !$f->userHasAccess(auth()->user());
            })->pluck('id');
            $query->whereNotIn('folder_id', $forbiddenFolderIds);
        }

        $documents = $query->latest()->paginate(20);
        $allFolders = QmsDocumentFolder::whereNull('parent_id')->with('children')->get();
        $folders = $allFolders; 

        return view('qms::documents.index', compact('documents', 'folders', 'roles', 'users'));
    }

    public function create()
    {
        $this->checkPermission(); 

        $folders = QmsDocumentFolder::all(); 
        $users = \App\Models\User::all(); 
        return view('qms::documents.create', compact('folders', 'users'));
    }

    public function store(Request $request)
    {
        $this->checkPermission();

        $request->validate([
            'name' => 'required|string|max:255',
            'document_code' => 'nullable|string|max:50', 
            'folder_id' => 'required|exists:qms_document_folders,id',
            'file' => 'required|file|mimes:pdf,docx,xlsx|max:10240',
            'approvers' => 'required|array|min:1', 
            'retention_period_years' => 'required|numeric', 
            'security_level' => 'required|string'          
        ]);

        try {
            $data = [
                'name' => $request->name,
                'document_code' => $request->document_code, 
                'folder_id' => $request->folder_id,
                'approvers' => $request->approvers,
                'retention_period_years' => $request->retention_period_years,
                'security_level' => $request->security_level
            ];

            $this->documentService->createDocument($data, $request->file('file'));
            
            return redirect()->route('admin.qms.documents.index')->with('success', 'Dokuman taslagi basariyla olusturuldu, onayicilara bildirim gonderildi.');
        } catch (\Exception $e) {
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    public function storeBulk(Request $request)
    {
        $this->checkPermission();

        $request->validate([
            'folder_id'              => 'required|exists:qms_document_folders,id',
            'files'                  => 'required|array|min:1',
            'doc_codes'              => 'nullable|array',
            'retention_period_years' => 'nullable|array', 
            'security_levels'        => 'nullable|array'  
        ]);

        try {
            $uploadedCount = 0;
            $failedFiles = [];
            $defaultApprovers = [auth()->id()];

            $files = $request->file('files');
            $docCodes = $request->input('doc_codes', []);
            $retentionYears = $request->input('retention_period_years', []);
            $securityLevels = $request->input('security_levels', []);

            if (!$files) {
                return back()->with('error', 'Sunucuya dosya ulasmadi. Toplam boyut sunucu limitini asmis olabilir.');
            }

            foreach ($files as $index => $file) {
                try {
                    $originalName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
                    
                    $uniqueFallbackCode = null; 
                    $customCode = isset($docCodes[$index]) && !empty(trim($docCodes[$index])) ? trim($docCodes[$index]) : $uniqueFallbackCode;

                    $retention = isset($retentionYears[$index]) && is_numeric($retentionYears[$index]) ? (int)$retentionYears[$index] : 5;
                    $security = isset($securityLevels[$index]) && !empty(trim($securityLevels[$index])) ? trim($securityLevels[$index]) : 'Internal';

                    $data = [
                        'name' => $originalName,
                        'document_code' => $customCode,
                        'folder_id' => $request->folder_id,
                        'description' => 'Toplu yukleme ile eklendi.',
                        'approvers' => $defaultApprovers,
                        'retention_period_years' => $retention, 
                        'security_level' => $security          
                    ];

                    $this->documentService->createDocument($data, $file);
                    $uploadedCount++;
                    
                } catch (\Exception $subException) {
                    $failedFiles[] = $file->getClientOriginalName() . ' -> HATA: ' . $subException->getMessage();
                }
            }

            if ($uploadedCount === 0) {
                $hataDetayi = implode(' | ', $failedFiles);
                return back()->with('error', "Dosyalar yuklenemedi! Sistem Hatasi: " . $hataDetayi);
            }

            if (count($failedFiles) > 0) {
                return back()->with('warning', "{$uploadedCount} adet yuklendi. Hatalilar: " . implode(' | ', $failedFiles));
            }
            
            return back()->with('success', "{$uploadedCount} adet dokuman basariyla eklendi.");

        } catch (\Exception $e) {
            return back()->with('error', 'Toplu yukleme sirasinda sunucu hatasi: ' . $e->getMessage());
        }
    }

    public function destroy($id)
    {
        $this->checkPermission();

        try {
            $document = \Modules\Qms\Models\QmsDocument::withTrashed()->findOrFail($id);
            $trashFolder = $this->getTrashFolder();

            if ($document->folder_id == $trashFolder->id) {
                \Modules\Qms\Models\QmsDocumentLog::where('document_id', $document->id)->delete();

                $versionIds = \Modules\Qms\Models\QmsDocumentVersion::where('document_id', $document->id)->pluck('id');
                if ($versionIds->count() > 0) {
                    \Illuminate\Support\Facades\DB::table('qms_document_approvals')->whereIn('document_version_id', $versionIds)->delete();
                    \Illuminate\Support\Facades\DB::table('qms_document_distributions')->whereIn('document_version_id', $versionIds)->delete();
                }

                $versions = \Modules\Qms\Models\QmsDocumentVersion::where('document_id', $document->id)->get();
                foreach($versions as $version) {
                    if(\Illuminate\Support\Facades\Storage::disk('local')->exists($version->file_path)) {
                        \Illuminate\Support\Facades\Storage::disk('local')->delete($version->file_path);
                    }
                    $version->delete();
                }
                
                $document->forceDelete(); 
                return back()->with('success', 'Dokuman cop kutusundan TAMAMEN silindi ve yok edildi.');
            } 
            else {
                $document->update([
                    'folder_id' => $trashFolder->id,
                    'status' => 'Obsolete' 
                ]);

                $this->documentService->logAction($document->id, 'TRASH', 'Dokuman cop kutusuna tasindi.');
                return back()->with('success', 'Dokuman basariyla Cop Kutusuna tasindi.');
            }

        } catch (\Exception $e) {
            return back()->with('error', 'Islem sirasinda hata: ' . $e->getMessage());
        }
    }

    public function show($id)
    {
        $document = QmsDocument::with(['versions.creator', 'logs.user'])->findOrFail($id);
        
        // Yonlendirme varsa uygula
        if ($redirect = $this->checkFolderAccess($document->folder_id)) return $redirect;

        return view('qms::documents.show', compact('document'));
    }

    /**
     * DUZELTiLDi: PDF ONiZLEME - response()->file() kullanilarak CORS sorunu cozuldu
     * Tarayicinin yerlesik PDF viewer'ini kullanir.
     */
    public function download(\Illuminate\Http\Request $request, $versionId)
    {
        $version = \Modules\Qms\Models\QmsDocumentVersion::with('document')->findOrFail($versionId);
        
        // Yonlendirme (Sifreli Klasor Korumasi) varsa uygula
        if ($redirect = $this->checkFolderAccess($version->document->folder_id)) return $redirect;

        $filePath = $version->file_path;
        
        // Dosya var mi kontrol et
        if (!Storage::disk('local')->exists($filePath)) {
            abort(404, 'Dosya bulunamadi.');
        }
        
        $mimeType = Storage::disk('local')->mimeType($filePath);
        $fileName = basename($filePath);
        
        // Gercek dosya yolunu al
        $fullPath = Storage::disk('local')->path($filePath);

        // 1. DURUM: Buyutece Tiklandiysa (Onizleme / Inline)
        if ($request->has('view') && $request->view === 'inline') {
            $this->documentService->logAction($version->document_id, 'PREVIEW', "Rev{$version->version_no} onizlendi.");
            
            // DUZELTiLDi: response()->file() ile tarayicinin PDF'i gostermesini sagliyoruz
            return response()->file($fullPath, [
                'Content-Type' => $mimeType,
                'Content-Disposition' => 'inline; filename="' . $fileName . '"',
                'Cache-Control' => 'no-cache, no-store, must-revalidate',
                'Pragma' => 'no-cache',
                'Expires' => '0',
            ]);
        }

        // 2. DURUM: Indir Butonuna Tiklandiysa (Normal Indirme)
        $this->documentService->logAction($version->document_id, 'DOWNLOAD', "Rev{$version->version_no} indirildi.");
        
        return Storage::disk('local')->download($filePath);
    }
    
    public function approve(Request $request, $versionId)
    {
        try {
            $this->documentService->approveVersion($versionId, $request->comments);
            return back()->with('success', 'Onay islemi basarili.');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function revise(Request $request, $id)
    {
        $this->checkPermission();

        $request->validate([
            'revision_reason' => 'required|string',
            'file' => 'required|file|mimes:pdf,docx,xlsx|max:10240'
        ]);

        try {
            $doc = QmsDocument::findOrFail($id);
            
            $highestVersion = \Modules\Qms\Models\QmsDocumentVersion::where('document_id', $doc->id)
                ->orderByRaw('CAST(version_no AS DECIMAL(8,2)) DESC')
                ->first();
            
            $currentVerNo = $highestVersion ? (float)$highestVersion->version_no : 0.0;
            $newVerNo = number_format($currentVerNo + 0.1, 1);
            
            $approvers = [$doc->owner_id]; 

            $this->documentService->createVersion(
                $doc->id, 
                $request->file('file'), 
                $newVerNo, 
                $request->revision_reason, 
                $approvers
            );
            
            $doc->update(['status' => 'InReview']);

            return back()->with('success', 'Revizyon sureci baslatildi (Rev' . $newVerNo . ').');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function storeFolder(Request $request)
    {
        $this->checkPermission();

        $request->validate([
            'name' => 'required|string|max:100',
            'parent_id' => 'nullable|exists:qms_document_folders,id',
            'allowed_roles' => 'nullable|array',
            'allowed_users' => 'nullable|array'
        ]);

        try {
            $accessRules = [];
            if ($request->has('allowed_roles')) $accessRules['roles'] = $request->allowed_roles;
            if ($request->has('allowed_users')) $accessRules['users'] = $request->allowed_users;
            if ($request->filled('folder_password')) $accessRules['password'] = $request->folder_password;

            \Modules\Qms\Models\QmsDocumentFolder::create([
                'name' => $request->name,
                'parent_id' => $request->parent_id,
                'access_rules' => empty($accessRules) ? null : $accessRules
            ]);

            return back()->with('success', 'Klasor basariyla olusturuldu.');
        } catch (\Exception $e) {
            return back()->with('error', 'Hata: ' . $e->getMessage());
        }
    }

    public function updateFolder(Request $request, $id)
    {
        $this->checkPermission();

        $request->validate([
            'name' => 'required|string|max:100',
            'allowed_roles' => 'nullable|array',
            'allowed_users' => 'nullable|array'
        ]);
        
        $folder = \Modules\Qms\Models\QmsDocumentFolder::findOrFail($id);

        $accessRules = [];
        if ($request->has('allowed_roles')) $accessRules['roles'] = $request->allowed_roles;
        if ($request->has('allowed_users')) $accessRules['users'] = $request->allowed_users;
        if ($request->filled('folder_password')) $accessRules['password'] = $request->folder_password;

        $folder->update([
            'name' => $request->name,
            'access_rules' => empty($accessRules) ? null : $accessRules
        ]);

        return back()->with('success', 'Klasor bilgileri guncellendi.');
    }

    public function destroyFolder($id)
    {
        $this->checkPermission();

        try {
            $trashFolder = $this->getTrashFolder();

            if ($id == $trashFolder->id) {
                return back()->with('error', 'Sistem klasoru olan Cop Kutusu silinemez!');
            }

            $folder = \Modules\Qms\Models\QmsDocumentFolder::findOrFail($id);

            $childCount = \Modules\Qms\Models\QmsDocumentFolder::where('parent_id', $id)->count();
            if ($childCount > 0) {
                return back()->with('error', 'Silinemez! Bu klasorun icinde alt klasorler var.');
            }

            $docs = \Modules\Qms\Models\QmsDocument::withTrashed()->where('folder_id', $id)->get();
            foreach($docs as $doc) {
                $doc->update([
                    'folder_id' => $trashFolder->id,
                    'status' => 'Obsolete'
                ]);
                $this->documentService->logAction($doc->id, 'TRASH', "Bulundugu klasor silindigi icin otomatik olarak cope tasindi.");
            }

            $folder->delete();
            
            return back()->with('success', 'Klasor silindi. Icindeki dokumanlar Cop Kutusuna tasindi.');
        } catch (\Exception $e) {
            return back()->with('error', 'Klasor silinirken hata: ' . $e->getMessage());
        }
    }

    public function distribute(Request $request, $versionId)
    {
        $this->checkPermission();

        $version = \Modules\Qms\Models\QmsDocumentVersion::with('document')->findOrFail($versionId);
        
        if ($version->status != 'Published') {
            return back()->with('error', 'Sadece yayinlanmis dokumanlar dagitilabilir.');
        }

        $userIdsToNotify = [];

        if ($request->has('users')) {
            foreach ($request->users as $userId) {
                \Modules\Qms\Models\QmsDocumentDistribution::firstOrCreate(
                    ['document_version_id' => $version->id, 'user_id' => $userId],
                    ['is_read_required' => true, 'is_read' => false]
                );
                $userIdsToNotify[] = $userId;
            }
        }

        if ($request->has('departments')) {
            $deptUsers = \App\Models\User::whereIn('department_id', $request->departments)->pluck('id');
            foreach ($deptUsers as $uId) {
                \Modules\Qms\Models\QmsDocumentDistribution::firstOrCreate(
                    ['document_version_id' => $version->id, 'user_id' => $uId],
                    ['is_read_required' => true, 'is_read' => false]
                );
                $userIdsToNotify[] = $uId;
            }
        }

        $userIdsToNotify = array_unique($userIdsToNotify);

        if (count($userIdsToNotify) > 0) {
            $users = \App\Models\User::whereIn('id', $userIdsToNotify)->get();
            Notification::send($users, new DocumentDistributedNotification($version->document, $version->id));
        }

        $this->documentService->logAction($version->document_id, 'DISTRIBUTE', 'Dokuman personele teblig edildi ve bildirimler gonderildi.');

        return back()->with('success', 'Dokuman dagitimi basariyla yapildi. Kullanicilara bildirim gonderildi.');
    }

    public function markAsRead($versionId)
    {
        $userId = auth()->id();
        
        $distribution = \Modules\Qms\Models\QmsDocumentDistribution::where('document_version_id', $versionId)
                            ->where('user_id', $userId)
                            ->first();

        if (!$distribution) {
            return back()->with('error', 'Bu dokuman size atanmamis.');
        }

        $distribution->update([
            'is_read' => true,
            'read_at' => now()
        ]);

        $this->documentService->logAction(
            $distribution->version->document_id, 
            'READ_CONFIRM', 
            'Kullanici dokumani okudugunu ve anladigini beyan etti.'
        );

        return back()->with('success', 'Tesekkurler. Okuma kaydiniz olusturuldu.');
    }

    /**
     * DÜZELTİLDİ: TOPLU REVİZYON YÜKLEME (AKILLI GRUPLAMA VE SIRALAMA)
     * Artık tüm revizyonları doğru sıraya dizer ve sadece EN YÜKSEK olanı Published yapar.
     */
    public function storeBulkHistory(Request $request)
    {
        $this->checkPermission();

        $request->validate([
            'folder_id' => 'required|exists:qms_document_folders,id',
            'files' => 'required|array|min:1',
            'doc_codes' => 'required|array',
            'doc_names' => 'required|array',
            'rev_nos' => 'required|array',
            'rev_reasons' => 'required|array',
            'retention_period_years' => 'nullable|array',
            'security_levels' => 'nullable|array'
        ]);

        try {
            return \Illuminate\Support\Facades\DB::transaction(function () use ($request) {
                $files = $request->file('files');
                $docCodes = $request->input('doc_codes');
                $revNos = $request->input('rev_nos');
                $revReasons = $request->input('rev_reasons');
                $retentionYears = $request->input('retention_period_years', []);
                $securityLevels = $request->input('security_levels', []);

                $documentsData = [];

                // 1. Dosyaları Doküman Koduna Göre Grupla
                foreach ($files as $index => $file) {
                    $docCode = trim($docCodes[$index]);
                    $documentsData[$docCode][] = [
                        'file' => $file,
                        'rev_no' => trim($revNos[$index]),
                        'reason' => trim($revReasons[$index]),
                        'retention' => isset($retentionYears[$index]) ? (int)$retentionYears[$index] : 5,
                        'security' => isset($securityLevels[$index]) && !empty(trim($securityLevels[$index])) ? trim($securityLevels[$index]) : 'Internal',
                        'original_name' => pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)
                    ];
                }

                // 2. Her Grup (Doküman) İçin İşlem Yap
                foreach ($documentsData as $docCode => $versionsData) {
                    // Revizyon numarasına göre PHP ile kusursuz sıralama (Örn: 0.1, 0.2, 1.0)
                    usort($versionsData, function($a, $b) {
                        return version_compare($a['rev_no'], $b['rev_no']);
                    });

                    // En yüksek (son) versiyonun bilgilerini ana doküman için baz alıyoruz
                    $latestData = end($versionsData);

                    $document = QmsDocument::firstOrCreate(
                        ['document_code' => $docCode],
                        [
                            'name' => $latestData['original_name'],
                            'folder_id' => $request->folder_id,
                            'security_level' => $latestData['security'],
                            'retention_period_years' => $latestData['retention'],
                            'owner_id' => auth()->id(),
                            'status' => 'Published' // Sona doğru kesinleşecek
                        ]
                    );

                    // Bu dokümanın veritabanındaki ESKİ versiyonlarını da obsolete yapalım (garanti olsun)
                    \Modules\Qms\Models\QmsDocumentVersion::where('document_id', $document->id)
                        ->update(['status' => 'Obsolete', 'is_current' => false]);

                    $totalVersions = count($versionsData);

                    // Şimdi bu yüklenen versiyonları sırayla veritabanına işleyelim
                    foreach ($versionsData as $idx => $vData) {
                        $isLast = ($idx === ($totalVersions - 1)); // Döngüdeki SON eleman (En yüksek revizyon) mu?
                        
                        $path = $vData['file']->store('qms_documents/' . date('Y'), 'local');
                        
                        \Modules\Qms\Models\QmsDocumentVersion::create([
                            'document_id' => $document->id,
                            'version_no' => $vData['rev_no'],
                            'file_path' => $path,
                            'file_hash' => md5_file($vData['file']->getRealPath()),
                            'revision_reason' => $vData['reason'],
                            'created_by' => auth()->id(),
                            'is_current' => $isLast, 
                            'status' => $isLast ? 'Published' : 'Obsolete', // Sadece en yüksek numara Published olur!
                            'published_at' => $isLast ? now() : null,
                            'approved_by' => $isLast ? auth()->id() : null
                        ]);

                        if ($isLast) {
                            $this->documentService->logAction($document->id, 'PUBLISH', "Arşiv yüklemesi sonucu Rev{$vData['rev_no']} en güncel olarak yayınlandı.");
                        } else {
                            $this->documentService->logAction($document->id, 'ARCHIVE_IMPORT', "Eski Revizyon ({$vData['rev_no']}) arşive eklendi.");
                        }
                    }

                    // Dokümanın adını ve ana statüsünü en son yüklenene göre garantiye al
                    $document->update([
                        'status' => 'Published',
                        'name' => $latestData['original_name']
                    ]);
                }

                return back()->with('success', "Arşiv dosyaları revizyon sırasına göre gruplandı ve başarıyla aktarıldı!");
            });

        } catch (\Exception $e) {
            return back()->with('error', 'Toplu arşiv yükleme hatası: ' . $e->getMessage());
        }
    }

    public function unlockFolder(Request $request, $id)
    {
        $folder = \Modules\Qms\Models\QmsDocumentFolder::findOrFail($id);
        $effectivePassword = $folder->getEffectivePassword();
        
        if($effectivePassword && $effectivePassword == $request->password) {
            session(['unlocked_folder_' . $id => true]);
            
            $children = \Modules\Qms\Models\QmsDocumentFolder::where('parent_id', $id)->get();
            foreach($children as $child) {
                 session(['unlocked_folder_' . $child->id => true]);
            }
            
            return redirect()->route('admin.qms.documents.index', ['folder_id' => $id])->with('success', 'Klasor kilidi basariyla acildi!');
        }

        return back()->with('error', 'Hatali sifre girdiniz!');
    }

    private function getTrashFolder()
    {
        return \Modules\Qms\Models\QmsDocumentFolder::firstOrCreate(
            ['name' => 'Cop Kutusu / Arsiv'],
            [
                'parent_id' => null,
                'access_rules' => ['roles' => ['admin']] 
            ]
        );
    }

    public function printDistributionForm($id)
    {
        $document = \Modules\Qms\Models\QmsDocument::with(['versions' => function($q) {
            $q->orderBy('version_no', 'desc');
        }, 'distributions.user'])->findOrFail($id);

        $latestVersion = $document->versions->first();

        return view('qms::documents.print-distribution', compact('document', 'latestVersion'));
    }
}
