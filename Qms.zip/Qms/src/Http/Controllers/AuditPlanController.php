<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Qms\Models\QmsAuditPlan;
use Illuminate\Http\Request;

class AuditPlanController extends Controller
{
    public function index()
    {
        $plans = QmsAuditPlan::withCount('audits')->latest()->paginate(10);
        return view('qms::audits.plans.index', compact('plans'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'year' => 'required|digits:4'
        ]);

        QmsAuditPlan::create([
            'name' => $request->name,
            'year' => $request->year,
            'created_by' => auth()->id()
        ]);

        return back()->with('success', 'Denetim planı oluşturuldu.');
    }

    public function show($id)
    {
        $plan = QmsAuditPlan::with(['audits.leadAuditor', 'audits.department'])->findOrFail($id);
        
        // Denetim oluştururken kullanacağımız listeler
        $departments = \App\Models\Department::all();
        $users = \App\Models\User::all(); // Denetçiler için
        $checklists = \Modules\Qms\Models\QmsAuditChecklist::where('is_active', true)->get();

        return view('qms::audits.plans.show', compact('plan', 'departments', 'users', 'checklists'));
    }
}