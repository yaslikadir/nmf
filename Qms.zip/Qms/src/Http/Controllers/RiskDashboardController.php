<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Risk; // Risk modelinin yolu
use App\Models\EmergencyDrill; // Tatbikat modeli
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RiskDashboardController extends Controller
{
    public function index()
    {
        // 1. GENEL İSTATİSTİKLER
        $totalRisks = Risk::count();
        $openActions = 0; // Risk aksiyonları tablosu varsa oradan count alınır, şimdilik placeholder
        
        // Risk Seviyelerine Göre Dağılım (Risk Skoru = Olasılık x Şiddet)
        // 1-4: Düşük, 5-9: Orta, 10-15: Yüksek, 16-25: Kritik
        $risks = Risk::all();
        $riskLevels = [
            'dusuk' => $risks->where('risk_score', '<=', 4)->count(),
            'orta' => $risks->whereBetween('risk_score', [5, 9])->count(),
            'yuksek' => $risks->whereBetween('risk_score', [10, 15])->count(),
            'kritik' => $risks->where('risk_score', '>=', 16)->count(),
        ];

        // 2. ISI HARİTASI (HEATMAP) VERİSİ
        // 5x5 Matrisin her hücresindeki risk sayısını hesapla
        // Format: $matrix[Olasılık][Şiddet] = Sayı
        $matrix = [];
        for ($p = 5; $p >= 1; $p--) { // Olasılık (Y Ekseni)
            for ($i = 1; $i <= 5; $i++) { // Şiddet (X Ekseni)
                $matrix[$p][$i] = Risk::where('probability', $p)
                                      ->where('impact', $i)
                                      ->count();
            }
        }

        // 3. TREND ANALİZİ (Son 6 ayda oluşturulan riskler)
        $trendData = Risk::select(DB::raw('DATE_FORMAT(created_at, "%Y-%m") as month'), DB::raw('count(*) as count'))
            ->where('created_at', '>=', now()->subMonths(6))
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        $trendLabels = $trendData->pluck('month')->map(fn($m) => \Carbon\Carbon::parse($m)->format('M Y'));
        $trendValues = $trendData->pluck('count');

        // 4. ACİL DURUM TATBİKAT İSTATİSTİKLERİ
        $totalDrills = EmergencyDrill::count();
        $avgDrillDuration = EmergencyDrill::avg('duration_minutes');
        $lastDrill = EmergencyDrill::latest('drill_date')->first();

        return view('qms::risks.dashboard', compact(
            'totalRisks', 'riskLevels', 'matrix', 'trendLabels', 'trendValues',
            'totalDrills', 'avgDrillDuration', 'lastDrill'
        ));
    }
}