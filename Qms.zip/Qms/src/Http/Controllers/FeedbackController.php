<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Feedback;
use App\Models\User;
use App\Models\FeedbackActivity;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification;
use App\Notifications\ComplaintResolvedNotification; // Bildirim sınıfını ekledik

class FeedbackController extends Controller
{
    // --- 1. LİSTELEME EKRANI (HAVUZ) ---
    public function index(Request $request)
    {
        // Filtreleme (Tip ve Durum)
        $query = Feedback::with(['form', 'assignedUser'])->latest();

        if ($request->has('type') && $request->type != 'all') {
            $query->whereHas('form', function($q) use ($request) {
                $q->where('type', $request->type);
            });
        }

        if ($request->has('status') && $request->status != 'all') {
            $query->where('status', $request->status);
        }

        $feedbacks = $query->paginate(15)->withQueryString();

        return view('qms::feedbacks.index', compact('feedbacks'));
    }

    // --- 2. DETAY VE YÖNETİM EKRANI (KOKPİT) ---
    public function show($id)
    {
        $feedback = Feedback::with(['form', 'assignedUser', 'activities.user'])->findOrFail($id);
        $users = User::all(); // Atama yapmak için personel listesi

        return view('qms::feedbacks.show', compact('feedback', 'users'));
    }

    // --- 3. GÜNCELLEME (DURUM DEĞİŞTİRME / ATAMA YAPMA) ---
    public function update(Request $request, $id)
    {
        $feedback = Feedback::findOrFail($id);
        
        // A) PERSONEL ATAMA İŞLEMİ
        if ($request->has('assigned_user_id') && $request->assigned_user_id != $feedback->assigned_user_id) {
            $oldUser = $feedback->assignedUser->name ?? 'Atanmamış';
            // Yeni atanan null değilse ismini al, null ise 'Atanmamış' yap
            $newUserObj = User::find($request->assigned_user_id);
            $newUserName = $newUserObj ? $newUserObj->name : 'Atanmamış';
            
            $feedback->assigned_user_id = $request->assigned_user_id;
            $feedback->save();

            // Logla
            FeedbackActivity::create([
                'feedback_id' => $feedback->id,
                'user_id' => Auth::id(),
                'action' => 'Atama Yapıldı',
                'description' => "Sorumlu değiştirildi: $oldUser -> $newUserName"
            ]);
        }

        // B) DURUM DEĞİŞTİRME (Status) & BİLDİRİM
        if ($request->has('status') && $request->status != $feedback->status) {
            $oldStatus = $feedback->status;
            $feedback->status = $request->status;
            $feedback->save();

            // Logla
            FeedbackActivity::create([
                'feedback_id' => $feedback->id,
                'user_id' => Auth::id(),
                'action' => 'Durum Değişti',
                'description' => "Durum güncellendi: $oldStatus -> {$request->status}"
            ]);

            // --- OTOMATİK MAİL GÖNDERİMİ ---
            // Eğer durum 'Resolved' (Çözüldü) olduysa ve e-posta varsa
            if ($request->status == 'Resolved' && !empty($feedback->guest_email)) {
                try {
                    // Kayıtlı kullanıcı olmadığı için 'route' metodu ile mail atıyoruz
                    Notification::route('mail', $feedback->guest_email)
                        ->notify(new ComplaintResolvedNotification($feedback));
                        
                    // Mail gönderildiğini de loglayalım
                    FeedbackActivity::create([
                        'feedback_id' => $feedback->id,
                        'user_id' => Auth::id(),
                        'action' => 'Anket Gönderildi',
                        'description' => 'Çözüm bildirimi ve memnuniyet anketi müşteriye iletildi.'
                    ]);
                } catch (\Exception $e) {
                    // Mail hatası olursa işlemi durdurma, sadece loga yaz veya pas geç
                    // \Log::error('Mail Gönderim Hatası: ' . $e->getMessage());
                }
            }
        }

        // C) ÖNCELİK DEĞİŞTİRME (Priority)
        if ($request->has('priority') && $request->priority != $feedback->priority) {
            $feedback->priority = $request->priority;
            $feedback->save();
        }

        return back()->with('success', 'Kayıt başarıyla güncellendi.');
    }

    // --- 4. MEMNUNİYET ANALİZ RAPORU (DASHBOARD) ---
    public function report()
    {
        // Sadece "Satisfaction" (Memnuniyet) tipindeki form yanıtlarını çek
        $surveys = Feedback::whereHas('form', function($q){
            $q->where('type', 'Satisfaction');
        })->latest()->get();

        $totalCount = $surveys->count();
        $stats = [];

        // Hangi alanların (input name) puanlama (rating) olduğunu tanımlayalım
        // Veritabanındaki "name" alanları ile eşleşmeli
        $ratingFields = [
            'q1_staff_politeness' => 'Personel Nezaketi',
            'q2_sample_staff' => 'Numune Kabul',
            'q3_reliability' => 'Güvenilirlik',
            'q4_timing' => 'Zamanlama',
            'q5_report_format' => 'Rapor Formatı',
            'q6_feedback_speed' => 'Dönüş Hızı'
        ];

        // İstatistikleri Hesapla
        foreach ($ratingFields as $key => $label) {
            $sum = 0;
            $count = 0;
            
            foreach ($surveys as $survey) {
                // Data JSON sütununda bu anahtar var mı ve sayısal mı?
                if (isset($survey->data[$key]) && is_numeric($survey->data[$key])) {
                    $sum += (int)$survey->data[$key];
                    $count++;
                }
            }
            
            // Ortalamayı hesapla (Sıfıra bölme hatasını önle)
            $stats[$label] = $count > 0 ? round($sum / $count, 1) : 0;
        }

        return view('qms::feedbacks.report', compact('stats', 'totalCount', 'surveys'));
    }

    

    // 5. FORM LİNKLERİ VE AYARLARI SAYFASI
    public function forms()
    {
        // Formları, kaç başvuru aldığı bilgisiyle (feedbacks_count) çekelim
        $forms = \App\Models\FeedbackForm::withCount('feedbacks')->get();
        
        return view('qms::feedbacks.forms', compact('forms'));
    }

    // 6. FORM YAZDIR (PDF/HTML ÇIKTI)
    public function printForm($id)
    {
        $feedback = \App\Models\Feedback::with(['form', 'assignedUser', 'activities.user'])->findOrFail($id);
        
        // 1. EĞER ŞİKAYET FORMUYSA -> ESKİ TASARIM
        if($feedback->form->type == 'Complaint') {
            return view('qms::feedbacks.print_form', compact('feedback'));
        }

        // 2. EĞER MEMNUNİYET ANKETİ İSE -> YENİ TASARIM (FR-08-02)
        if($feedback->form->type == 'Satisfaction') {
            return view('qms::feedbacks.print_survey', compact('feedback'));
        }

        return back()->with('error', 'Bu form tipi için yazdırma şablonu bulunamadı.');
    }
}

