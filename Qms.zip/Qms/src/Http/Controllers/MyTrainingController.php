<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\TrainingRecord;
use App\Models\TrainingMaterial;
use App\Models\ExamQuestion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Barryvdh\DomPDF\Facade\Pdf; // PDF Kütüphanesi

class MyTrainingController extends Controller
{
    /**
     * 1. EĞİTİMLERİM LİSTESİ
     */
    public function index()
    {
        $myTrainings = TrainingRecord::with(['plan.training'])
                        ->where('user_id', Auth::id())
                        ->orderByDesc('created_at')
                        ->get();

        return view('qms::my_trainings.index', compact('myTrainings'));
    }

    /**
     * 2. EĞİTİM DETAYI
     */
    public function show($id)
    {
        $record = TrainingRecord::with(['plan.training.materials'])
                    ->where('user_id', Auth::id())
                    ->findOrFail($id);
        
        // İlk girişse 'Katıldı' işaretle
        if(!$record->attended) {
            $record->update(['attended' => true]);
        }

        // Zorunlu eğitim süresi hesaplama (Başlangıç ve Bitiş arasındaki fark)
        $plan = $record->plan;
        $requiredSeconds = 0;

        if ($plan && $plan->start_date && $plan->end_date) {
            $start = \Carbon\Carbon::parse($plan->start_date);
            $end = \Carbon\Carbon::parse($plan->end_date);
            $diffInSeconds = $start->diffInSeconds($end, false);

            // Eğer başlangıç-bitiş farkı pozitif ve 24 saatten (86400 sn) küçük/eşitse doğrudan bu farkı baz al,
            // çok günlü bir aralık girildiyse ama duration_hours tanımlıysa duration_hours baz al
            if ($diffInSeconds > 0 && $diffInSeconds <= 86400) {
                $requiredSeconds = $diffInSeconds;
            } elseif (!empty($plan->duration_hours) && $plan->duration_hours > 0) {
                $requiredSeconds = (int) $plan->duration_hours * 3600;
            } elseif ($diffInSeconds > 0) {
                $requiredSeconds = $diffInSeconds;
            }
        } elseif ($plan && !empty($plan->duration_hours) && $plan->duration_hours > 0) {
            $requiredSeconds = (int) $plan->duration_hours * 3600;
        }

        return view('qms::my_trainings.show', compact('record', 'requiredSeconds'));
    }

    /**
     * 2.1. EĞİTİM MATERYALİNİ MODAL İÇİNDE / INLINE GÖRÜNTÜLE (İndirme Korumalı)
     */
    public function viewMaterial($materialId)
    {
        $material = TrainingMaterial::findOrFail($materialId);

        abort_unless(Storage::disk('public')->exists($material->file_path), 404, 'Eğitim materyali dosyası bulunamadı.');

        $fullPath = Storage::disk('public')->path($material->file_path);
        $mimeType = Storage::disk('public')->mimeType($material->file_path) ?: 'application/octet-stream';
        $ext = strtolower(pathinfo($material->file_path, PATHINFO_EXTENSION) ?: $material->file_type);
        $safeFilename = Str::slug($material->title ?: 'egitim-materyali') . ($ext ? '.' . $ext : '');

        return response()->file($fullPath, [
            'Content-Type' => $mimeType,
            'Content-Disposition' => 'inline; filename="' . addslashes($safeFilename) . '"',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    /**
     * 2.2. SINAVSIZ EĞİTİMİ TAMAMLA (Okudum, İzledim, Anladım + Süre Kontrolü)
     */
    public function completeWithoutExam(Request $request, $id)
    {
        $record = TrainingRecord::with(['plan.training'])
                    ->where('user_id', Auth::id())
                    ->findOrFail($id);

        $training = $record->plan->training;
        $plan = $record->plan;

        if ($training->has_exam) {
            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('error', 'Bu eğitim sınavlı bir eğitimdir. Tamamlamak için sınava katılmalısınız.');
        }

        if ($record->result === 'Passed') {
            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('info', 'Bu eğitimi zaten tamamladınız.');
        }

        // Zorunlu süre kontrolü (Backend doğrulaması)
        $requiredSeconds = 0;
        if ($plan && $plan->start_date && $plan->end_date) {
            $start = \Carbon\Carbon::parse($plan->start_date);
            $end = \Carbon\Carbon::parse($plan->end_date);
            $diffInSeconds = $start->diffInSeconds($end, false);
            if ($diffInSeconds > 0 && $diffInSeconds <= 86400) {
                $requiredSeconds = $diffInSeconds;
            } elseif (!empty($plan->duration_hours) && $plan->duration_hours > 0) {
                $requiredSeconds = (int) $plan->duration_hours * 3600;
            } elseif ($diffInSeconds > 0) {
                $requiredSeconds = $diffInSeconds;
            }
        } elseif ($plan && !empty($plan->duration_hours) && $plan->duration_hours > 0) {
            $requiredSeconds = (int) $plan->duration_hours * 3600;
        }

        $spentSeconds = (int) $request->input('spent_seconds', 0);
        if ($requiredSeconds > 0 && $spentSeconds < $requiredSeconds) {
            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('error', 'Eğitimi tamamlamak için belirlenen eğitim süresini aktif olarak bu sayfada tamamlamanız gerekmektedir.');
        }

        $record->update([
            'attended' => true,
            'result' => 'Passed',
            'exam_score' => 100,
            'exam_date' => now(),
            'completed_at' => now(),
        ]);

        // Sertifika oluşturma ve oryantasyon senkronizasyonu
        $this->generateCertificateIfNeeded($record);
        $this->syncOrientationRecord($record);

        // Plan altındaki tüm katılımcılar tamamladıysa plan durumunu da güncelle
        $pendingCount = TrainingRecord::where('plan_id', $record->plan_id)
                            ->where('result', 'Pending')
                            ->count();
        if ($pendingCount === 0 && $record->plan && $record->plan->status === 'Planned') {
            $record->plan->update(['status' => 'Completed']);
        }

        return redirect()->route('admin.qms.my-trainings.show', $id)
                         ->with('success', 'Eğitimi başarıyla tamamladınız!');
    }

    /**
     * 3. SINAV EKRANI
     */
    public function startExam($id)
    {
        $record = TrainingRecord::where('user_id', Auth::id())->findOrFail($id);

        if ($record->result == 'Passed') {
            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('warning', 'Bu sınavı zaten başarıyla geçtiniz.');
        }

        $questions = ExamQuestion::with('options')
                        ->where('training_id', $record->plan->training_id)
                        ->inRandomOrder()
                        ->get();

        if($questions->count() == 0) {
            return back()->with('error', 'Bu eğitim için henüz soru hazırlanmamış.');
        }

        return view('qms::my_trainings.exam', compact('record', 'questions'));
    }

    /**
     * 4. SINAVI BİTİR, PUANLA VE SERTİFİKA OLUŞTUR
     */
    public function submitExam(Request $request, $id)
    {
        $record = TrainingRecord::with(['plan.training'])->where('user_id', Auth::id())->findOrFail($id);
        $training = $record->plan->training;
        
        // Soruları çek ve puanla
        $questions = ExamQuestion::with('options')->where('training_id', $training->id)->get();
        $totalQuestions = $questions->count();
        $correctAnswers = 0;

        foreach($questions as $question) {
            $selectedOptionId = $request->input('answers.'.$question->id);
            $correctOption = $question->options()->where('is_correct', true)->first();
            
            if($correctOption && $selectedOptionId == $correctOption->id) {
                $correctAnswers++;
            }
        }

        $score = ($totalQuestions > 0) ? round(($correctAnswers / $totalQuestions) * 100) : 0;
        $result = ($score >= $training->passing_score) ? 'Passed' : 'Failed';

        // Sonucu kaydet
        $record->update([
            'attended' => true,
            'exam_score' => $score,
            'result' => $result,
            'exam_date' => now(),
            'completed_at' => now(),
        ]);

        // --- SERTİFİKA OLUŞTURMA VE ORYANTASYON SENKRONİZASYONU ---
        if($result == 'Passed') {
            $this->generateCertificateIfNeeded($record);
            $this->syncOrientationRecord($record);

            $pendingCount = TrainingRecord::where('plan_id', $record->plan_id)
                                ->where('result', 'Pending')
                                ->count();
            if ($pendingCount === 0 && $record->plan && $record->plan->status === 'Planned') {
                $record->plan->update(['status' => 'Completed']);
            }

            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('success', 'TEBRİKLER! Sınavı geçtiniz. Sertifikanız oluşturuldu.');
        } else {
            return redirect()->route('admin.qms.my-trainings.show', $id)
                             ->with('error', 'Üzgünüz, sınavdan kaldınız. Puanınız: ' . $score);
        }
    }

    /**
     * Sertifika PDF oluşturma yardımcı metodu
     */
    protected function generateCertificateIfNeeded(TrainingRecord $record): void
    {
        try {
            if(!$record->verification_code) {
                $verifyCode = 'CRT-' . $record->id . '-' . strtoupper(Str::random(6));
                $record->update(['verification_code' => $verifyCode]);
            } else {
                $verifyCode = $record->verification_code;
            }

            $verifyUrl = route('public.certificate.verify', $verifyCode);

            $logoPath = public_path('assets/img/logo.png'); 
            $logoBase64 = '';
            
            if(file_exists($logoPath)) {
                $logoType = pathinfo($logoPath, PATHINFO_EXTENSION);
                $logoData = file_get_contents($logoPath);
                $logoBase64 = 'data:image/' . $logoType . ';base64,' . base64_encode($logoData);
            }

            $pdf = Pdf::loadview('qms::certificates.template', compact('record', 'verifyUrl', 'logoBase64'));
            
            $pdf->setOptions([
                'isRemoteEnabled' => true, 
                'chroot' => public_path()
            ]); 
            
            $pdf->setPaper('a4', 'landscape');

            $fileName = 'certificate_' . $record->id . '_' . time() . '.pdf';
            $filePath = 'certificates/' . $fileName;

            Storage::disk('public')->put($filePath, $pdf->output());
            
            $record->update(['certificate_path' => $filePath]);

        } catch (\Exception $e) {
            Log::error('Sertifika oluşturma hatası: ' . $e->getMessage());
        }
    }

    /**
     * Eğer eğitim Oryantasyon kategorisindeyse Personel Oryantasyon sekmesindeki kaydı oluştur/güncelle ve bitiş tarihini aktar
     */
    protected function syncOrientationRecord(TrainingRecord $record): void
    {
        try {
            $plan = $record->plan;
            $training = $plan ? $plan->training : null;

            if (!$plan || !$training) {
                return;
            }

            if (($training->profile_category ?? 'general') !== 'orientation') {
                return;
            }

            if (!class_exists(\App\Models\PersonnelOrientationRecord::class)) {
                return;
            }

            $plannedDate = $plan->start_date ? \Carbon\Carbon::parse($plan->start_date)->toDateString() : null;
            $endDate = $plan->end_date ? \Carbon\Carbon::parse($plan->end_date)->toDateString() : null;
            $completedDate = $record->completed_at ? \Carbon\Carbon::parse($record->completed_at)->toDateString() : now()->toDateString();

            $orientationRecord = \App\Models\PersonnelOrientationRecord::where('user_id', $record->user_id)
                ->where('title', $training->title)
                ->where('planned_date', $plannedDate)
                ->first();

            $payload = [
                'user_id' => $record->user_id,
                'title' => $training->title,
                'category' => 'general',
                'content' => $training->description,
                'planned_date' => $plannedDate,
                'completed_date' => $completedDate,
                'end_date' => $endDate,
                'duration_minutes' => $plan->duration_hours ? ((int) $plan->duration_hours * 60) : null,
                'trainer_name' => $plan->instructor,
                'status' => 'completed',
                'score' => $record->exam_score,
                'passed' => true,
                'evidence_notes' => $training->has_exam
                    ? 'Eğitim modülü üzerinden online sınav başarıyla tamamlandı. (Plan #' . $plan->id . ')'
                    : 'Eğitim modülü üzerinden "Okudum, İzledim, Anladım" onayı ile tamamlandı. (Plan #' . $plan->id . ')',
            ];

            if ($orientationRecord) {
                $orientationRecord->update($payload);
            } else {
                \App\Models\PersonnelOrientationRecord::create($payload);
            }
        } catch (\Throwable $e) {
            Log::error('Oryantasyon kaydı senkronizasyon hatası: ' . $e->getMessage());
        }
    }

    /**
     * EĞİTİM TALEP ETME (Personel Tarafı)
     */
    public function storeRequest(Request $request)
    {
        $request->validate([
            'subject' => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority' => 'required|in:Normal,Acil'
        ]);

        \App\Models\TrainingRequest::create([
            'user_id' => Auth::id(),
            'subject' => $request->subject,
            'description' => $request->description,
            'priority' => $request->priority,
            'status' => 'Pending'
        ]);

        return back()->with('success', 'Eğitim talebiniz yöneticilere iletildi.');
    }

    /**
     * EĞİTİM DEĞERLENDİRME (ANKET) KAYDI
     */
    public function storeEvaluation(Request $request, $id)
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000'
        ]);

        $record = TrainingRecord::where('user_id', Auth::id())->findOrFail($id);

        // Zaten değerlendirmiş mi?
        if($record->evaluation) {
            return back()->with('error', 'Bu eğitimi zaten değerlendirdiniz.');
        }

        \App\Models\TrainingEvaluation::create([
            'training_record_id' => $record->id,
            'rating' => $request->rating,
            'comment' => $request->comment
        ]);

        return back()->with('success', 'Geri bildiriminiz için teşekkürler!');
    }
}
