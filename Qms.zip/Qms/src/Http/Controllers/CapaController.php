<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Qms\Models\QmsCapa; // Senin Modelin
use Modules\Qms\Models\QmsCapaAction; // Aksiyon Modelin
use App\Models\Feedback; // Şikayet Modeli
use App\Models\Risk; // RİSK MODELİ (Bunu eklemeyi unutma)
use App\Models\User;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use App\Notifications\UserAssignedNotification;

class CapaController extends Controller
{
    public function index()
    {
        $capas = QmsCapa::with(['lead', 'department'])->latest()->paginate(15);
        return view('qms::capas.index', compact('capas'));
    }

    public function create(Request $request)
    {
        $users = User::all();
        $departments = Department::all();
        
        $prefilled = [];

        // 1. SENARYO: DENETİMDEN GELDİYSE
        if ($request->has('audit_finding_id')) {
            $finding = \Modules\Qms\Models\QmsAuditFinding::with('audit')->find($request->audit_finding_id);
            if ($finding) {
                $prefilled['source'] = 'Audit';
                $prefilled['audit_finding_id'] = $finding->id;
                $prefilled['subject'] = 'Denetim Bulgusu: ' . ($finding->audit->code ?? 'Bilinmiyor');
                $prefilled['description'] = $finding->finding_details;
                $prefilled['department_id'] = $finding->audit->department_id ?? null;
            }
        }

        // 2. SENARYO: ŞİKAYETTEN (FEEDBACK) GELDİYSE
        if ($request->has('feedback_id')) {
            $fb = Feedback::find($request->feedback_id);
            if ($fb) {
                $prefilled['source'] = 'Complaint';
                $prefilled['feedback_id'] = $fb->id;
                $prefilled['subject'] = 'Şikayet No: ' . $fb->tracking_code;
                $prefilled['description'] = "Müşteri: " . ($fb->guest_name ?? 'Anonim') . "\n" .
                                            "Detay: " . ($fb->data['message'] ?? '-');
            }
        }

        // 3. SENARYO: RİSK ANALİZİNDEN GELİYORSA (YENİ EKLENEN KISIM)
        if ($request->has('risk_id')) {
            $risk = Risk::find($request->risk_id); // Risk Modelini import etmeyi unutma
            if ($risk) {
                $prefilled['source'] = 'Risk';
                $prefilled['risk_id'] = $risk->id;
                $prefilled['subject'] = 'Risk Kaynaklı Tedbir: ' . $risk->code;
                
                // Risk detaylarını açıklama alanına taşıyoruz
                $prefilled['description'] = "İlgili Risk: " . $risk->description . "\n\n" .
                                            "Olası Etki: " . $risk->potential_impact . "\n\n" .
                                            "Bu DÖF, risk skorunu düşürmek veya riski ortadan kaldırmak amacıyla başlatılmıştır.";
                
                $prefilled['department_id'] = $risk->department_id;
            }
        }

        return view('qms::capas.create', compact('users', 'departments', 'prefilled'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'subject' => 'required|string',
            'description' => 'required|string',
            'source' => 'required',
            'lead_user_id' => 'required|exists:users,id'
        ]);

        // Kod üret (CAPA-2026-001)
        $count = QmsCapa::whereYear('created_at', date('Y'))->count() + 1;
        $code = 'CAPA-' . date('Y') . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

        // KAYIT İŞLEMİ (Risk ID'yi de ekledik)
        $capa = QmsCapa::create([
            'code' => $code,
            'subject' => $request->subject,
            'description' => $request->description,
            'source' => $request->source,
            'department_id' => $request->department_id,
            'lead_user_id' => $request->lead_user_id,
            'priority' => $request->priority,
            'target_date' => $request->target_date,
            'audit_finding_id' => $request->audit_finding_id ?? null,
            'feedback_id' => $request->feedback_id ?? null,
            'risk_id' => $request->risk_id ?? null, // <--- BURAYI EKLEDİK (Veritabanındaki risk_id sütunu)
            'status' => 'Root_Cause_Analysis'
        ]);

        // BİLDİRİM GÖNDERME
        try {
            $details = [
                'title' => 'Yeni DÖF Atandı',
                'message' => "Size {$code} kodlu yeni bir Düzeltici Faaliyet atandı.",
                'url' => route('admin.qms.capas.show', $capa->id)
            ];

            $leadUser = User::find($request->lead_user_id);
            if($leadUser) {
                $leadUser->notify(new UserAssignedNotification($details));
            }
        } catch (\Exception $e) {
            // Log::error('Bildirim hatası: ' . $e->getMessage());
        }

        // Eğer Şikayet üzerinden geldiyse güncelle
        if($request->feedback_id) {
            $fb = Feedback::find($request->feedback_id);
            if($fb) {
                $fb->update(['status' => 'Investigating']);
                \App\Models\FeedbackActivity::create([
                    'feedback_id' => $fb->id,
                    'user_id' => auth()->id(),
                    'action' => 'DÖF Başlatıldı',
                    'description' => "Bu şikayet için {$code} kodlu DÖF süreci başlatıldı."
                ]);
            }
        }

        // Eğer Risk üzerinden geldiyse riski güncelle (Opsiyonel: Riskin durumunu 'İşlemde' yapabilirsin)
        if($request->risk_id) {
            $risk = Risk::find($request->risk_id);
            if($risk) {
                $risk->update(['status' => 'In_Progress']); // Riski işlemdeye çek
            }
        }

        return redirect()->route('admin.qms.capas.index')->with('success', 'CAPA kaydı açıldı. Analiz bekleniyor.');
    }

    public function show($id)
    {
        $capa = QmsCapa::with(['actions', 'lead'])->findOrFail($id);
        $users = User::all(); 
        return view('qms::capas.show', compact('capa', 'users'));
    }

    // Kök Neden Kaydetme
    public function saveRootCause(Request $request, $id)
    {
        $capa = QmsCapa::findOrFail($id);
        $capa->update([
            'root_cause' => $request->root_cause,
            'immediate_action' => $request->immediate_action,
            'status' => 'Action_Planning'
        ]);
        return back()->with('success', 'Kök neden analizi kaydedildi.');
    }

    // Yeni Aksiyon Ekleme
    public function addAction(Request $request, $id)
    {
        $request->validate([
            'action_description' => 'required',
            'responsible_user_id' => 'required',
            'due_date' => 'required|date'
        ]);

        $capa = QmsCapa::findOrFail($id);

        QmsCapaAction::create([
            'capa_id' => $id, // Modelindeki ilişki adına dikkat et
            'action_description' => $request->action_description,
            'responsible_user_id' => $request->responsible_user_id,
            'due_date' => $request->due_date,
            'status' => 'Pending'
        ]);

        // Bildirim...
        try {
            $details = [
                'title' => 'Yeni Aksiyon Atandı',
                'message' => "{$capa->code} nolu DÖF kapsamında size yeni bir görev atandı.",
                'url' => route('admin.qms.capas.show', $id)
            ];
            $responsible = User::find($request->responsible_user_id);
            if($responsible) {
                $responsible->notify(new UserAssignedNotification($details));
            }
        } catch (\Exception $e) {}

        return back()->with('success', 'Aksiyon eklendi.');
    }

    // Aksiyonu Tamamlama
    public function completeAction(Request $request, $actionId)
    {
        $action = QmsCapaAction::findOrFail($actionId);
        $action->update([
            'status' => 'Completed',
            'completed_at' => now(),
            'completion_note' => $request->completion_note
        ]);
        return back()->with('success', 'Aksiyon tamamlandı.');
    }

    // CAPA Kapatma
    public function closeCapa(Request $request, $id)
    {
        $capa = QmsCapa::findOrFail($id);
        
        if($capa->actions()->where('status', '!=', 'Completed')->exists()){
            return back()->with('error', 'Kapatılamaz! Açık aksiyonlar var.');
        }

        $capa->update([
            'status' => 'Closed',
            'closed_date' => now()
        ]);

        return back()->with('success', 'CAPA başarıyla kapatıldı ve doğrulandı.');
    }

    public function report($id)
    {
        $capa = QmsCapa::with(['actions', 'lead', 'department'])->findOrFail($id);
        return view('qms::capas.report', compact('capa'));
    }
}