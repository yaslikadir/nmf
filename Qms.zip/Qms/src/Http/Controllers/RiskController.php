<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Risk;
use App\Models\RiskAction;
use App\Models\User;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RiskController extends Controller
{
    /**
     * ISO 17025: Madde 8.5.2 - Risklerin Belirlenmesi
     * Risk Listesi ve Filtreleme
     */
    public function index(Request $request)
    {
        $query = Risk::with(['owner', 'department']);

        // Filtreler (Risk Türü, Seviyesi, Departman)
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('risk_level')) {
            $query->where('risk_level', $request->risk_level);
        }
        if ($request->filled('department_id')) {
            $query->where('department_id', $request->department_id);
        }

        // Önce en yüksek risk skoru olanları getir (Önceliklendirme)
        $risks = $query->orderBy('risk_score', 'desc')->paginate(10);

        // Dashboard için mini istatistikler
        $stats = [
            'total' => Risk::count(),
            'critical' => Risk::where('risk_level', 'Critical')->count(),
            'opportunities' => Risk::where('type', 'Opportunity')->count(),
        ];

        // EKSİK OLAN SATIR BURASIYDI 👇
        $departments = Department::all(); 

        return view('qms::risks.index', compact('risks', 'stats', 'departments'));
    }

    /**
     * Yeni Risk Tanımlama Formu
     */
    public function create()
    {
        $users = User::all();
        $departments = Department::all();
        return view('qms::risks.create', compact('users', 'departments'));
    }

    /**
     * Risk Kaydetme İşlemi
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:Risk,Opportunity',
            'category' => 'required|string', // İSG, Ekipman, Analiz Süreci vb.
            'description' => 'required|string',
            'source' => 'nullable|string',
            'potential_impact' => 'required|string',
            'department_id' => 'required|exists:departments,id',
            'probability' => 'required|integer|min:1|max:5', // 1-5 arası puan
            'impact' => 'required|integer|min:1|max:5',      // 1-5 arası puan
            'owner_id' => 'required|exists:users,id',
            'review_date' => 'nullable|date',
        ]);

        $validated['created_by'] = auth()->id();
        
        // Not: risk_score ve risk_level, Model'deki boot() metodunda otomatik hesaplanıyor.
        Risk::create($validated);

        return redirect()->route('admin.qms.risks.index')
            ->with('success', 'Risk/Fırsat başarıyla kayıt altına alındı.');
    }

    /**
     * Risk Analiz Detayı ve Aksiyonlar
     */
    public function show($id)
    {
        // Riski ve ona bağlı aksiyonları (yapan kişiyle beraber) çekiyoruz
        $risk = Risk::with(['actions.responsible', 'owner', 'department'])->findOrFail($id);
        $users = User::all(); // Yeni aksiyon atamak için gerekli
        
        return view('qms::risks.show', compact('risk', 'users'));
    }

    /**
     * Risk Güncelleme (Yeniden Değerlendirme)
     */
    public function update(Request $request, $id)
    {
        $risk = Risk::findOrFail($id);

        $validated = $request->validate([
            'status' => 'required',
            'probability' => 'required|integer|min:1|max:5',
            'impact' => 'required|integer|min:1|max:5',
            'review_date' => 'nullable|date',
            'owner_id' => 'required|exists:users,id',
        ]);

        $risk->update($validated);
        // Puan değiştiyse Model otomatik olarak seviyeyi güncelleyecektir.

        return back()->with('success', 'Risk değerlendirmesi güncellendi.');
    }

    /**
     * Riski Silme (Soft Delete)
     */
    public function destroy($id)
    {
        $risk = Risk::findOrFail($id);
        $risk->delete();
        return redirect()->route('admin.qms.risks.index')->with('success', 'Risk kaydı silindi.');
    }

    /**
     * ---------------------------------------------------
     * RISK AKSİYONLARI (Preventive Actions) - Madde 8.5.3
     * ---------------------------------------------------
     * Ayrı bir controller yerine burada yönetmek daha pratik.
     */
    public function storeAction(Request $request, $risk_id)
    {
        $validated = $request->validate([
            'action_description' => 'required|string',
            'type' => 'required|in:Preventive,Corrective,Improvement',
            'assigned_to' => 'required|exists:users,id',
            'due_date' => 'required|date',
        ]);

        $validated['risk_id'] = $risk_id;

        RiskAction::create($validated);

        return back()->with('success', 'Önleyici faaliyet başarıyla atandı.');
    }

    public function completeAction(Request $request, $action_id)
    {
        $action = RiskAction::findOrFail($action_id);
        
        $action->update([
            'completed_at' => now(),
            'result_notes' => $request->input('result_notes')
        ]);

        return back()->with('success', 'Aksiyon tamamlandı ve sonucu kaydedildi.');
    }

    // Sınıfın içine en alta ekleyin:

public function generalReport()
{
    // 1. GENEL İSTATİSTİKLER
    $risks = \App\Models\Risk::with(['department', 'owner'])->orderBy('risk_score', 'desc')->get();
    
    $stats = [
        'total'    => $risks->count(),
        'open'     => $risks->where('status', '!=', 'Closed')->count(),
        'closed'   => $risks->where('status', 'Closed')->count(),
        'critical' => $risks->where('risk_score', '>=', 16)->count(),
        'high'     => $risks->whereBetween('risk_score', [10, 15])->count(),
        'medium'   => $risks->whereBetween('risk_score', [5, 9])->count(),
        'low'      => $risks->where('risk_score', '<=', 4)->count(),
    ];

    // 2. MATRİS (HEATMAP) VERİSİ
    $matrix = [];
    for ($p = 5; $p >= 1; $p--) {
        for ($i = 1; $i <= 5; $i++) {
            $matrix[$p][$i] = $risks->where('probability', $p)->where('impact', $i)->count();
        }
    }

    // 3. TREND VERİSİ (Son 6 Ay)
    $monthlyStats = collect([]);
    for ($i = 5; $i >= 0; $i--) {
        $monthKey = now()->subMonths($i)->format('Y-m');
        $monthlyStats->put($monthKey, 0);
    }
    
    $rawTrend = \App\Models\Risk::where('created_at', '>=', now()->subMonths(6))
        ->get()
        ->groupBy(function($item) { return $item->created_at->format('Y-m'); })
        ->map->count();

    $trendData = $monthlyStats->merge($rawTrend);
    $trendLabels = $trendData->keys()->map(fn($d) => \Carbon\Carbon::createFromFormat('Y-m', $d)->translatedFormat('M Y'));
    $trendValues = $trendData->values();

    return view('qms::risks.general_report', compact('risks', 'stats', 'matrix', 'trendLabels', 'trendValues'));
}
}