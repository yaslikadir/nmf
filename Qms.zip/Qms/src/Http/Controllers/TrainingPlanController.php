<?php

namespace Modules\Qms\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Training;
use App\Models\TrainingPlan;
use App\Models\TrainingRecord;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Log;

class TrainingPlanController extends Controller
{
    // --- 1. PLANLAMA LİSTESİ (TAKVİM GÖRÜNÜMÜ) ---
    public function index()
    {
        $upcomingPlans = TrainingPlan::with(['training', 'records'])
                            ->where('start_date', '>=', now())
                            ->orderBy('start_date', 'asc')
                            ->get();

        $pastPlans = TrainingPlan::with(['training', 'records'])
                            ->where('start_date', '<', now())
                            ->latest('start_date')
                            ->paginate(10);

        return view('qms::training_plans.index', compact('upcomingPlans', 'pastPlans'));
    }

    // --- 2. YENİ PLAN OLUŞTURMA SAYFASI ---
    public function create(Request $request)
    {
        $trainings = Training::all();
        $users = User::with('department')->get();
        
        $preSelectedUser = $request->user_id;
        $preFilledNote = $request->subject ? "Personel Talebi: " . $request->subject : '';
        $requestId = $request->request_id;

        return view('qms::training_plans.create', compact('trainings', 'users', 'preSelectedUser', 'preFilledNote', 'requestId'));
    }

    // --- 3. PLANI KAYDETME VE ATAMA ---
    public function store(Request $request)
    {
        $request->validate([
            'training_id' => 'required|exists:trainings,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'instructor' => 'required|string',
            'participants' => 'required|array|min:1',
            'duration_hours' => 'required|integer|min:1', 
        ]);

        try {
            $training = Training::findOrFail($request->training_id);

            $plan = new TrainingPlan();
            $plan->training_id = $request->training_id;
            
            $userBranch = auth()->user() ? auth()->user()->branches()->first() : null;
            $plan->branch_id = $userBranch ? $userBranch->id : 1; 

            $plan->start_date = \Carbon\Carbon::parse($request->start_date);
            $plan->end_date = \Carbon\Carbon::parse($request->end_date);
            $plan->duration_hours = $request->duration_hours;
            $plan->location = $request->location ?? 'Online / LMS';
            $plan->instructor = $request->instructor;
            $plan->notes = $request->notes;
            $plan->status = 'Planned';
            $plan->save();

            foreach ($request->participants as $userId) {
                $record = new TrainingRecord();
                // İŞTE BÜYÜK DEĞİŞİKLİK BURADA: training_plan_id yerine plan_id kullanıyoruz.
                $record->plan_id = $plan->id; 
                $record->user_id = $userId;
                $record->result = 'Pending';
                $record->attended = false;
                $record->save();

                // Eğer eğitim oryantasyon kategorisindeyse personel oryantasyon sekmesine başlangıç ve bitiş tarihiyle yansıt
                $this->syncPlannedOrientationRecord($plan, $training, (int) $userId);
            }

            try {
                if (class_exists('\App\Notifications\NewTrainingAssignedNotification')) {
                    $participants = User::whereIn('id', $request->participants)->get();
                    Notification::send($participants, new \App\Notifications\NewTrainingAssignedNotification($plan));
                }
            } catch (\Throwable $e) {
                Log::error('Eğitim bildirimi gönderilemedi: ' . $e->getMessage());
            }

            if ($request->has('request_id') && $request->request_id) {
                \App\Models\TrainingRequest::where('id', $request->request_id)->update([
                    'status' => 'Planned',
                    'admin_note' => 'Eğitim planı oluşturuldu. Plan ID: ' . $plan->id
                ]);
            }

            return redirect()->route('admin.qms.plans.index')
                             ->with('success', 'Eğitim planlandı, ' . count($request->participants) . ' personele atandı.');

        } catch (\Throwable $th) {
            dd([
                'HATA MESAJI' => $th->getMessage(),
                'DOSYA' => $th->getFile(),
                'SATIR' => $th->getLine()
            ]);
        }
    }

    // --- 4. PLAN DETAYI ---
    public function show($id)
    {
        $plan = TrainingPlan::with(['training', 'records.user'])->findOrFail($id);
        return view('qms::training_plans.show', compact('plan'));
    }
    
    // --- 5. PLANI İPTAL ETME ---
    public function cancel($id)
    {
        $plan = TrainingPlan::findOrFail($id);
        $plan->update(['status' => 'Cancelled']);
        return back()->with('info', 'Eğitim planı iptal edildi.');
    }

    // --- 6. KATILIM FORMUNU YAZDIR ---
    public function printForm($id)
    {
        $plan = TrainingPlan::with(['training', 'records.user.department'])->findOrFail($id);
        return view('qms::training_plans.print_form', compact('plan'));
    }

    // --- 7. DÜZENLEME FORMU (EDIT) ---
    public function edit($id)
    {
        $plan = TrainingPlan::with('records')->findOrFail($id);
        
        if($plan->status == 'Completed') {
            return back()->with('error', 'Tamamlanmış eğitim planları düzenlenemez.');
        }

        $trainings = Training::all();
        $users = User::with('department')->get();
        
        $selectedParticipants = $plan->records->pluck('user_id')->toArray();

        return view('qms::training_plans.edit', compact('plan', 'trainings', 'users', 'selectedParticipants'));
    }

    // --- 8. GÜNCELLEME (UPDATE) ---
    public function update(Request $request, $id)
    {
        $plan = TrainingPlan::findOrFail($id);

        $request->validate([
            'training_id' => 'required|exists:trainings,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'instructor' => 'required|string',
            'participants' => 'required|array|min:1', 
            'duration_hours' => 'required|integer|min:1', 
        ]);

        try {
            $oldStartDate = $plan->start_date ? \Carbon\Carbon::parse($plan->start_date)->toDateString() : null;
            $oldTraining = $plan->training;

            $plan->update([
                'training_id' => $request->training_id,
                'start_date' => \Carbon\Carbon::parse($request->start_date),
                'end_date' => \Carbon\Carbon::parse($request->end_date),
                'duration_hours' => $request->duration_hours, 
                'instructor' => $request->instructor,
                'location' => $request->location,
                'notes' => $request->notes
            ]);

            $training = Training::findOrFail($request->training_id);

            $currentRecordUserIds = $plan->records()->pluck('user_id')->toArray();
            $newParticipantIds = $request->participants;

            $toDelete = array_diff($currentRecordUserIds, $newParticipantIds);
            if(!empty($toDelete)) {
                $plan->records()->whereIn('user_id', $toDelete)->where('result', 'Pending')->delete();
            }

            $toAdd = array_diff($newParticipantIds, $currentRecordUserIds);
            foreach($toAdd as $userId) {
                \App\Models\TrainingRecord::create([
                    'plan_id' => $plan->id, // BURADA DA plan_id OLARAK DEĞİŞTİRİLDİ
                    'user_id' => $userId,
                    'result' => 'Pending'
                ]);
            }

            // Mevcut ve yeni katılımcıların oryantasyon kayıtlarını (başlangıç ve bitiş tarihi dahil) senkronize et
            foreach ($newParticipantIds as $userId) {
                $this->syncPlannedOrientationRecord($plan, $training, (int) $userId, $oldStartDate, $oldTraining ? $oldTraining->title : null);
            }

            return redirect()->route('admin.qms.plans.index')->with('success', 'Eğitim planı güncellendi.');

        } catch (\Throwable $th) {
            dd([
                'HATA MESAJI' => $th->getMessage(),
                'DOSYA' => $th->getFile(),
                'SATIR' => $th->getLine()
            ]);
        }
    }

    /**
     * Eğitim Oryantasyon kategorisindeyse Personel Oryantasyon tablosuna başlangıç ve bitiş tarihini senkronize eder.
     */
    protected function syncPlannedOrientationRecord(TrainingPlan $plan, Training $training, int $userId, ?string $oldStartDate = null, ?string $oldTitle = null): void
    {
        try {
            if (($training->profile_category ?? 'general') !== 'orientation') {
                return;
            }

            if (!class_exists(\App\Models\PersonnelOrientationRecord::class)) {
                return;
            }

            $plannedDate = $plan->start_date ? \Carbon\Carbon::parse($plan->start_date)->toDateString() : null;
            $endDate = $plan->end_date ? \Carbon\Carbon::parse($plan->end_date)->toDateString() : null;

            $query = \App\Models\PersonnelOrientationRecord::where('user_id', $userId);
            if ($oldTitle && $oldStartDate) {
                $existing = (clone $query)->where('title', $oldTitle)->where('planned_date', $oldStartDate)->first();
            } else {
                $existing = null;
            }

            if (!$existing) {
                $existing = (clone $query)->where('title', $training->title)->where('planned_date', $plannedDate)->first();
            }

            if ($existing) {
                $existing->update([
                    'title' => $training->title,
                    'content' => $training->description,
                    'planned_date' => $plannedDate,
                    'end_date' => $endDate,
                    'duration_minutes' => $plan->duration_hours ? ((int) $plan->duration_hours * 60) : $existing->duration_minutes,
                    'trainer_name' => $plan->instructor,
                ]);
            } else {
                \App\Models\PersonnelOrientationRecord::create([
                    'user_id' => $userId,
                    'title' => $training->title,
                    'category' => 'general',
                    'content' => $training->description,
                    'planned_date' => $plannedDate,
                    'end_date' => $endDate,
                    'duration_minutes' => $plan->duration_hours ? ((int) $plan->duration_hours * 60) : null,
                    'trainer_name' => $plan->instructor,
                    'status' => 'planned',
                    'evidence_notes' => 'Eğitim planlama modülü üzerinden atandı. (Plan #' . $plan->id . ')',
                ]);
            }
        } catch (\Throwable $e) {
            Log::error('Plan oryantasyon senkronizasyon hatası: ' . $e->getMessage());
        }
    }
}