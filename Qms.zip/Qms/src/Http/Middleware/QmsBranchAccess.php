<?php

namespace Modules\Qms\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class QmsBranchAccess
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route("login");
        }

        if (!session()->has("active_branch_id") || empty(session("active_branch_id"))) {
            session([
                "active_branch_id"   => 1,
                "active_branch_name" => "Merkez Şube",
            ]);
        }

        return $next($request);
    }
}