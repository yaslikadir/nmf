@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0 text-gray-800 fw-bold">
            <i class="fas fa-plus-circle me-2 text-primary"></i>Yeni Doküman Oluştur
        </h4>
        <a href="{{ route('admin.qms.documents.index') }}" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left me-1"></i> Listeye Dön
        </a>
    </div>

    <form action="{{ route('admin.qms.documents.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="row">
            {{-- SOL KOLON: TEMEL BİLGİLER --}}
            <div class="col-lg-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold">Doküman Bilgileri</div>
                    <div class="card-body">
                        
                        {{-- Doküman Adı --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold">Doküman Adı <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control form-control-lg" placeholder="Örn: Satın Alma Prosedürü" required>
                        </div>

                        <div class="row">
                            {{-- DOKÜMAN KODU (Otomatik veya Manuel) --}}
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold d-flex justify-content-between">
                                    <span>Doküman No</span>
                                    <div class="form-check form-switch m-0 p-0 d-flex align-items-center">
                                        <input class="form-check-input ms-0 me-2 mt-0" type="checkbox" id="manualCodeSwitch" onchange="toggleManualCode()">
                                        <label class="form-check-label text-primary x-small fw-normal" for="manualCodeSwitch" style="cursor: pointer;">Elle Gir</label>
                                    </div>
                                </label>
                                <input type="text" name="document_code" id="documentCodeInput" class="form-control text-muted bg-light" placeholder="Sistem Otomatik Atayacak" readonly>
                                <div class="form-text x-small">İsterseniz yandaki butonu açarak kendiniz numara verebilirsiniz.</div>
                            </div>

                            {{-- Klasör Seçimi --}}
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Klasör / Kategori <span class="text-danger">*</span></label>
                                <select name="folder_id" class="form-select select2" required>
                                    <option value="">Seçiniz...</option>
                                    @foreach($folders as $folder)
                                        <option value="{{ $folder->id }}" {{ request('folder_id') == $folder->id ? 'selected' : '' }}>
                                            {{ $folder->name }}
                                        </option>
                                        @foreach($folder->children as $child)
                                            <option value="{{ $child->id }}">-- {{ $child->name }}</option>
                                        @endforeach
                                    @endforeach
                                </select>
                            </div>

                            {{-- Saklama Süresi (Tablodan dolayı zorunlu) --}}
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Saklama Süresi (Yıl) <span class="text-danger">*</span></label>
                                <input type="number" name="retention_period_years" class="form-control" placeholder="Örn: 5" value="5" required>
                            </div>

                            {{-- Gizlilik Seviyesi --}}
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Gizlilik Seviyesi</label>
                                <select name="security_level" class="form-select">
                                    <option value="Public">Açık (Genel)</option>
                                    <option value="Internal" selected>Kurum İçi</option>
                                    <option value="Confidential">Gizli</option>
                                    <option value="Restricted">Kısıtlı (Çok Gizli)</option>
                                </select>
                            </div>
                        </div>

                        {{-- Dosya Yükleme --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold">Doküman Dosyası (Taslak) <span class="text-danger">*</span></label>
                            <input type="file" name="file" class="form-control" accept=".pdf,.docx,.xlsx" required>
                            <div class="form-text text-muted">
                                <i class="fas fa-info-circle me-1"></i> PDF, Word veya Excel formatında yükleyiniz. (Max: 10MB)
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            {{-- SAĞ KOLON: ONAY VE AYARLAR --}}
            <div class="col-lg-4">
                
                {{-- ONAY AKIŞI --}}
                <div class="card shadow-sm mb-4 border-warning">
                    <div class="card-header bg-warning text-dark fw-bold">
                        <i class="fas fa-signature me-2"></i>Onay Akışı Tanımla
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning small">
                            Doküman yayınlanmadan önce sırasıyla aşağıdaki kişilerin onayına sunulacaktır.
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Onaylayıcılar (Sıralı)</label>
                            <select name="approvers[]" class="form-select select2" multiple required style="width: 100%;">
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->department->name ?? '-' }})</option>
                                @endforeach
                            </select>
                            <div class="form-text x-small">Kişileri onay sırasına göre seçiniz.</div>
                        </div>
                    </div>
                </div>

                {{-- KAYDET BUTONU --}}
                <div class="card shadow-none bg-transparent">
                    <button type="submit" class="btn btn-primary btn-lg w-100 fw-bold shadow">
                        <i class="fas fa-save me-2"></i> TASLAĞI OLUŞTUR
                    </button>
                </div>

            </div>
        </div>
    </form>
</div>

@push('scripts')
<script>
    function toggleManualCode() {
        let input = document.getElementById('documentCodeInput');
        let isChecked = document.getElementById('manualCodeSwitch').checked;

        if (isChecked) {
            input.removeAttribute('readonly');
            input.classList.remove('text-muted', 'bg-light');
            input.placeholder = "Kodu giriniz (Örn: FRM-022)";
            input.focus();
        } else {
            input.setAttribute('readonly', true);
            input.classList.add('text-muted', 'bg-light');
            input.value = "";
            input.placeholder = "Sistem Otomatik Atayacak";
        }
    }
</script>
@endpush
@endsection