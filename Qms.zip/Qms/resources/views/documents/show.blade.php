@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4 mt-4">

    {{-- YETKİ KONTROLÜ (Sahibi veya Admin mi?) --}}
    @php
        $canManage = (auth()->id() == $document->owner_id || auth()->user()->role == 'admin');
    @endphp

    {{-- BAŞLIK ALANI --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <div class="d-flex align-items-center gap-2">
                <span class="badge bg-primary fs-6">{{ $document->document_code }}</span>
                <h3 class="mb-0 text-gray-800 fw-bold">{{ $document->name }}</h3>
            </div>
            <div class="text-muted small mt-1">
                <i class="far fa-folder-open me-1"></i> {{ $document->folder->name }} | 
                <i class="fas fa-user-circle me-1"></i> Sahibi: {{ $document->owner->name }}
            </div>
        </div>
        <div class="d-flex gap-2">
            
            {{-- YÖNETİM BUTONLARI (Sadece Yetkililer Görebilir) --}}
            @if($canManage && $document->status == 'Published')
                {{-- Dağıtım Butonu --}}
                <button type="button" class="btn btn-info text-white shadow-sm" data-bs-toggle="modal" data-bs-target="#distributeModal">
                    <i class="fas fa-bullhorn me-1"></i> Dağıtım Yap
                </button>
                
                {{-- Revizyon Butonu --}}
                <button type="button" class="btn btn-warning shadow-sm" data-bs-toggle="modal" data-bs-target="#reviseModal">
                    <i class="fas fa-sync-alt me-1"></i> Yeni Revizyon
                </button>
            @endif

            <a href="{{ route('admin.qms.documents.index') }}" class="btn btn-secondary shadow-sm">
                <i class="fas fa-arrow-left me-1"></i> Geri Dön
            </a>

            <a href="{{ route('admin.qms.documents.print-distribution', $document->id) }}" target="_blank" class="btn btn-outline-dark shadow-sm">
    <i class="fas fa-print me-1"></i> Dağıtım Formu Çıktısı
</a>
        </div>
    </div>

    {{-- OKUMA GÖREVİ UYARISI (Herkes Görebilir - Kendisine Atandıysa) --}}
    @php
        $latestVersion = $document->versions->first();
        $myDistribution = null;
        if(isset($latestVersion)) {
            $myDistribution = \Modules\Qms\Models\QmsDocumentDistribution::where('document_version_id', $latestVersion->id)
                                ->where('user_id', auth()->id())
                                ->first();
        }
    @endphp

    @if($myDistribution && !$myDistribution->is_read)
        <div class="alert alert-danger shadow-sm border-danger d-flex align-items-center justify-content-between mb-4">
            <div>
                <h5 class="alert-heading fw-bold mb-1"><i class="fas fa-exclamation-circle me-2"></i>Okuma Görevi Atandı</h5>
                <p class="mb-0 small">Bu doküman size tebliğ edilmiştir. Lütfen içeriği okuduktan sonra yandaki <strong>"Okudum ve Anladım"</strong> butonuna basınız.</p>
            </div>
            <form action="{{ route('admin.qms.documents.mark-read', $latestVersion->id) }}" method="POST">
                @csrf
                <button type="submit" id="btnReadConfirm" class="btn btn-danger fw-bold" disabled>
                    <i class="fas fa-check-double me-1"></i> OKUDUM VE ANLADIM (<span id="readTimer">5</span>)
                </button>
            </form>
        </div>

        @push('scripts')
        <script>
            let seconds = 5;
            const btn = document.getElementById('btnReadConfirm');
            const timerSpan = document.getElementById('readTimer');
            const interval = setInterval(() => {
                seconds--;
                timerSpan.innerText = seconds;
                if (seconds <= 0) {
                    clearInterval(interval);
                    btn.removeAttribute('disabled');
                    btn.classList.remove('btn-danger');
                    btn.classList.add('btn-success');
                    btn.innerHTML = '<i class="fas fa-check-double me-1"></i> OKUDUM VE ANLADIM';
                }
            }, 1000);
        </script>
        @endpush
    @elseif($myDistribution && $myDistribution->is_read)
        <div class="alert alert-success d-flex align-items-center py-2 mb-4">
            <i class="fas fa-check-circle fa-2x me-3"></i>
            <div>
                <strong>Teşekkürler!</strong>
                <div class="small">Bu dokümanı {{ $myDistribution->read_at->format('d.m.Y H:i') }} tarihinde okuduğunuzu beyan ettiniz.</div>
            </div>
        </div>
    @endif

    <div class="row">
        
        {{-- SOL KOLON --}}
        <div class="col-lg-8">
            
            {{-- AKTİF VERSİYON KARTI --}}
            @php
                $isPendingMyApproval = false;
                $myApprovalRecord = null;

                if($latestVersion && $latestVersion->status != 'Published' && $latestVersion->status != 'Obsolete') {
                    $myApprovalRecord = $latestVersion->approvals()
                                        ->where('user_id', auth()->id())
                                        ->where('status', 'Pending')
                                        ->first();
                    if($myApprovalRecord) $isPendingMyApproval = true;
                }
            @endphp

            <div class="card shadow-sm mb-4 border-top-lg border-primary">
                <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="fas fa-file-alt me-2"></i>
                        @if($latestVersion->status == 'Draft' || $latestVersion->status == 'InReview')
                            TASLAK (Rev{{ $latestVersion->version_no }})
                        @else
                            GEÇERLİ KOPYA (Rev{{ $latestVersion->version_no }})
                        @endif
                    </h6>
                    
                    {{-- DURUM ROZETİ --}}
                    @if($latestVersion->status == 'Published')
                        <span class="badge bg-success px-3 py-2"><i class="fas fa-check-circle me-1"></i> YAYINDA</span>
                    @elseif($latestVersion->status == 'InReview')
                        <span class="badge bg-warning text-dark px-3 py-2"><i class="fas fa-clock me-1"></i> ONAY BEKLİYOR</span>
                    @else
                        <span class="badge bg-secondary px-3 py-2">TASLAK</span>
                    @endif
                </div>
                
                <div class="card-body">
                    <div class="alert alert-light border d-flex align-items-center justify-content-between">
                        <div>
                            <strong><i class="fas fa-paperclip me-2"></i>Dosya:</strong>
                            <span class="text-muted">{{ basename($latestVersion->file_path) }}</span>
                        </div>
                        <a href="{{ route('admin.qms.documents.download', $latestVersion->id) }}" class="btn btn-sm btn-outline-primary fw-bold" target="_blank">
                            <i class="fas fa-download me-1"></i> İNDİR / GÖRÜNTÜLE
                        </a>
                    </div>

                    {{-- ONAY KUTUSU --}}
                    @if($isPendingMyApproval)
                        <div class="card border-warning mb-3">
                            <div class="card-body bg-warning-soft">
                                <h6 class="fw-bold text-dark"><i class="fas fa-signature me-2"></i>Onayınız Bekleniyor</h6>
                                <p class="small mb-2">Bu dokümanın yayınlanabilmesi için inceleyip onaylamanız gerekmektedir.</p>
                                
                                <form action="{{ route('admin.qms.documents.approve', $latestVersion->id) }}" method="POST">
                                    @csrf
                                    <textarea name="comments" class="form-control mb-2" rows="2" placeholder="Varsa notunuzu buraya ekleyebilirsiniz..."></textarea>
                                    <div class="d-flex gap-2">
                                        <button type="submit" class="btn btn-success fw-bold flex-grow-1">
                                            <i class="fas fa-check me-1"></i> ONAYLA
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    @endif

                    {{-- ONAY AKIŞI DURUMU --}}
                    <h6 class="small fw-bold text-uppercase text-muted mt-4 mb-2">Onay Akışı Durumu</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th style="width: 50px;">Sıra</th>
                                    <th>Onaylayıcı</th>
                                    <th class="text-center">Durum</th>
                                    <th>İşlem Tarihi</th>
                                    <th>Notlar</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($latestVersion->approvals as $approval)
                                <tr>
                                    <td class="text-center">{{ $approval->order }}</td>
                                    <td>
                                        <div class="fw-bold">{{ $approval->user->name }}</div>
                                        <div class="x-small text-muted">{{ $approval->user->department->name ?? '-' }}</div>
                                    </td>
                                    <td class="text-center align-middle">
                                        @if($approval->status == 'Approved')
                                            <span class="badge bg-success"><i class="fas fa-check"></i> Onaylandı</span>
                                        @elseif($approval->status == 'Rejected')
                                            <span class="badge bg-danger">Reddedildi</span>
                                        @else
                                            <span class="badge bg-warning text-dark">Bekliyor</span>
                                        @endif
                                    </td>
                                    <td class="small align-middle">
                                        {{ $approval->action_date ? $approval->action_date->format('d.m.Y H:i') : '-' }}
                                    </td>
                                    <td class="small text-muted align-middle">
                                        {{ $approval->comments ?? '-' }}
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

            {{-- VERSİYON GEÇMİŞİ --}}
            <div class="card shadow-sm">
                <div class="card-header bg-light fw-bold">
                    <i class="fas fa-history me-1"></i> Revizyon Tarihçesi
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 small">
                        <thead>
                            <tr>
                                <th>Rev.</th>
                                <th>Tarih</th>
                                <th>Revizyon Nedeni</th>
                                <th>Oluşturan</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($document->versions->sortByDesc('version_no') as $ver)
                            <tr class="{{ $ver->is_current ? 'table-success' : '' }}">
                                <td class="fw-bold">Rev{{ $ver->version_no }}</td>
                                <td>{{ $ver->created_at->format('d.m.Y') }}</td>
                                <td>{{ Str::limit($ver->revision_reason, 50) }}</td>
                                <td>{{ $ver->creator->name }}</td>
                                <td>
                                    <a href="{{ route('admin.qms.documents.download', $ver->id) }}" class="btn btn-xs btn-outline-dark">
                                        <i class="fas fa-download"></i>
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        {{-- SAĞ KOLON: META VERİLER VE LOGLAR --}}
        <div class="col-lg-4">
            
            {{-- DOKÜMAN KİMLİĞİ --}}
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light fw-bold small text-uppercase">Doküman Künyesi</div>
                <div class="card-body p-0">
                    <table class="table table-sm table-striped mb-0">
                        <tr>
                            <td class="text-muted ps-3 py-2">Kayıt Tarihi:</td>
                            <td class="fw-bold py-2">{{ $document->created_at->format('d.m.Y') }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted ps-3 py-2">Gizlilik:</td>
                            <td class="fw-bold py-2">
                                @php
                                    // Veritabanındaki İngilizce değerleri Türkçeye çeviriyoruz
                                    $secLevelTr = match($document->security_level) {
                                        'Public' => 'Herkese Açık',
                                        'Internal' => 'Kurum İçi',
                                        'Confidential' => 'Gizli / Hassas',
                                        'Restricted' => 'Kısıtlı (Çok Gizli)',
                                        default => $document->security_level
                                    };
                                @endphp
                                @if($document->security_level == 'Confidential' || $document->security_level == 'Restricted')
                                    <span class="text-danger"><i class="fas fa-lock me-1"></i> {{ $secLevelTr }}</span>
                                @else
                                    <span class="text-success">{{ $secLevelTr }}</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <td class="text-muted ps-3 py-2">Saklama Süresi:</td>
                            <td class="fw-bold py-2">{{ $document->retention_period_years }} Yıl</td>
                        </tr>
                    </table>
                </div>
            </div>

            {{-- DENETİM İZİ (LOGLAR) --}}
            <div class="card shadow-sm" style="max-height: 500px; overflow-y: auto;">
                <div class="card-header bg-light fw-bold small text-uppercase">
                    <i class="fas fa-shoe-prints me-1"></i> Erişim Logları
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush border-start border-3 ms-2" style="border-color: #e9ecef !important;">
                        @foreach($document->logs->take(30) as $log)
                        <li class="list-group-item border-0 py-2 ps-3 position-relative">
                            <div class="position-absolute top-50 start-0 translate-middle border border-white rounded-circle bg-secondary" style="width: 10px; height: 10px;"></div>
                            <div class="d-flex justify-content-between">
                                <span class="fw-bold x-small">{{ $log->user->name ?? 'Sistem' }}</span>
                                <span class="text-muted x-small">{{ $log->created_at->format('d.m H:i') }}</span>
                            </div>
                            
                            {{-- LOG İÇİNDEKİ "Versiyon" ve "v" İBARELERİNİ "Rev" OLARAK DEĞİŞTİRİYORUZ --}}
                            <div class="small text-dark">
    @php
        // Metni al
        $logText = $log->details;
        
        // "Versiyon 0.1" -> "Rev0.1" yapar
        $logText = preg_replace('/Versiyon\s+([0-9\.]+)/i', 'Rev$1', $logText);
        
        // Tek başına duran " v0.1" -> " Rev0.1" yapar (kelime içindeki 'v' lere dokunmaz!)
        $logText = preg_replace('/\bv([0-9\.]+)/i', 'Rev$1', $logText);
    @endphp
    {{ $logText }}
</div>
                            
                            {{-- LOG AKSİYONLARINI TÜRKÇEYE ÇEVİRİYORUZ --}}
                            @php
                                $actionTr = match($log->action) {
                                    'CREATE' => 'Oluşturma',
                                    'APPROVE' => 'Onay İşlemi',
                                    'PUBLISH' => 'Yayınlama',
                                    'DOWNLOAD' => 'İndirme / Görüntüleme',
                                    'TRASH' => 'Çöpe Taşıma',
                                    'ARCHIVE_IMPORT' => 'Arşiv Aktarımı',
                                    'READ_CONFIRM' => 'Okuma Onayı',
                                    'DISTRIBUTE' => 'Tebliğ / Dağıtım',
                                    default => $log->action
                                };
                            @endphp
                            <div class="x-small text-muted fst-italic">{{ $actionTr }}</div>
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>

{{-- MODALLAR --}}
@if($canManage)
    {{-- REVİZYON MODALI --}}
    <div class="modal fade" id="reviseModal" tabindex="-1">
        <div class="modal-dialog">
            <form action="{{ route('admin.qms.documents.revise', $document->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-content">
                    <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title fw-bold"><i class="fas fa-sync-alt me-2"></i>Yeni Revizyon Başlat</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-info small">
                            Mevcut doküman (Rev{{ $latestVersion->version_no }}) üzerinden yeni bir taslak oluşturulacak.
                        </div>
                        
                        <div class="mb-3">
                            <label class="fw-bold">Revizyon Nedeni <span class="text-danger">*</span></label>
                            <textarea name="revision_reason" class="form-control" required placeholder="Neden değişiklik yapılıyor? (Örn: ISO standartları güncellendi)"></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="fw-bold">Yeni Dosya <span class="text-danger">*</span></label>
                            <input type="file" name="file" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary fw-bold">Revizyonu Başlat</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    {{-- DAĞITIM MODALI KORUNDU... --}}
    <div class="modal fade" id="distributeModal" tabindex="-1">
        <div class="modal-dialog">
            <form action="{{ route('admin.qms.documents.distribute', $latestVersion->id ?? 0) }}" method="POST">
                @csrf
                <div class="modal-content">
                    <div class="modal-header bg-info text-white">
                        <h5 class="modal-title fw-bold"><i class="fas fa-bullhorn me-2"></i>Doküman Dağıtımı</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p class="small text-muted">Bu dokümanı okuması zorunlu olan personel veya departmanları seçiniz.</p>
                        
                        <div class="mb-3">
                            <label class="fw-bold small">Departmanlara Ata</label>
                            <select name="departments[]" class="form-select select2" multiple style="width: 100%">
                                @foreach(\App\Models\Department::all() as $dept)
                                    <option value="{{ $dept->id }}">{{ $dept->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="text-center text-muted small my-2">- VEYA / VE -</div>

                        <div class="mb-3">
                            <label class="fw-bold small">Kişilere Ata</label>
                            <select name="users[]" class="form-select select2" multiple style="width: 100%">
                                @foreach(\App\Models\User::all() as $user)
                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-info text-white fw-bold">Dağıtımı Başlat</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endif

@endsection