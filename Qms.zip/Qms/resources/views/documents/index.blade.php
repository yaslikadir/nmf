@extends('layouts.admin')

@push('css')
<style>
    .hover-bg-light:hover { background-color: #f8f9fa; cursor: pointer; }
    .folder-tree ul { list-style: none; padding-left: 1rem; }
    .status-Draft { background-color: #6c757d; color: white; }
    .status-InReview { background-color: #ffc107; color: black; }
    .status-Published { background-color: #198754; color: white; }
    .status-Obsolete { background-color: #dc3545; color: white; text-decoration: line-through; }
    
    /* YENi: Klasor toggle butonu icin stil */
    .folder-toggle-btn {
        width: 24px;
        height: 24px;
        padding: 0;
        border: none;
        background: transparent;
        color: #6c757d;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        transition: color 0.2s, transform 0.2s;
    }
    .folder-toggle-btn:hover {
        color: #0d6efd;
    }
    .folder-toggle-btn.expanded i {
        transform: rotate(90deg);
    }
    .folder-toggle-btn.no-children {
        visibility: hidden;
    }
    
    /* Klasor satiri hover efekti */
    .folder-item-row {
        transition: background-color 0.15s ease;
    }
    
    /* Alt klasor listesi gizli baslasin */
    .folder-tree .folder-children {
        display: none;
    }

    /* =============================================
       YENIDEN BOYUTLANDIRILABİLİR SOL PANEL
       ============================================= */
    #sidebar-panel {
        position: relative;
        min-width: 160px;
        max-width: 600px;
        flex-shrink: 0;
    }

    #resize-handle {
        position: absolute;
        top: 0;
        right: -5px;
        width: 10px;
        height: 100%;
        cursor: col-resize;
        z-index: 100;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
    }

    #resize-handle::after {
        content: '';
        display: block;
        width: 4px;
        height: 40px;
        background: #dee2e6;
        border-radius: 4px;
        transition: background 0.2s, height 0.2s;
    }

    #resize-handle:hover::after,
    #resize-handle.dragging::after {
        background: #0d6efd;
        height: 60px;
    }

    /* Suruklerken metin secimini engelle */
    body.resizing {
        user-select: none;
        cursor: col-resize;
    }

    /* Iki kolon yapisini flex'e al ki genislik dinamik calissin */
    #qms-layout-row {
        display: flex;
        align-items: flex-start;
        gap: 0;
    }

    #content-panel {
        flex: 1 1 0;
        min-width: 0;
        padding-left: 1rem;
    }
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">
    
    @php
        // DUZELTiLDi: quality_manager rolu eklendi
        $canManage = in_array(auth()->user()->role, ['admin', 'quality_manager', 'Kalite Yoneticisi']) || 
                     (auth()->user()->hasRole('quality_manager') ?? false) ||
                     (auth()->user()->hasRole('Kalite Yoneticisi') ?? false); 
    @endphp

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-0 text-gray-800 fw-bold">
                <i class="fas fa-book me-2 text-primary"></i>Dokuman Yonetimi
            </h4>
            <div class="text-muted small mt-1">Kalite Yonetim Sistemi (QMS) dokuman kutuphanesi</div>
        </div>
        <div class="d-flex gap-2">
            {{-- KLASOR YONETiMi ($canManage) VE MODUL OLUSTURMA YETKiSi (canDo) BiRLiKTE KONTROL EDiLiYOR --}}
            @if($canManage && canDo('qms_documents', 'create'))
                
                @if(request('folder_id'))
                    <button type="button" class="btn btn-warning shadow-sm fw-bold text-dark" data-bs-toggle="modal" data-bs-target="#bulkUploadModal">
                        <i class="fas fa-upload me-1"></i> Toplu Yukle
                    </button>

                    <button type="button" class="btn btn-dark shadow-sm fw-bold" data-bs-toggle="modal" data-bs-target="#bulkHistoryUploadModal">
                        <i class="fas fa-history me-1"></i> Toplu Rev Ekle
                    </button>
                @endif
                
                <a href="{{ route('admin.qms.documents.create', ['folder_id' => request('folder_id')]) }}" class="btn btn-primary shadow-sm fw-bold">
                    <i class="fas fa-plus-circle me-1"></i> Yeni Dokuman Olustur
                </a>
                
            @endif
        </div>
    </div>

    <div class="row" id="qms-layout-row">
        {{-- SOL KOLON: KLASOR AGACI --}}
        <div id="sidebar-panel" class="mb-4">
            {{-- YENIDEN BOYUTLANDIRMA TUTAMACI --}}
            <div id="resize-handle" title="Surukleyerek genisletebilirsiniz"></div>
            <div class="card shadow-sm h-100">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <span class="fw-bold text-uppercase small"><i class="fas fa-sitemap me-1"></i> Klasorler</span>
                    @if($canManage)
                    <button class="btn btn-xs btn-outline-primary" data-bs-toggle="modal" data-bs-target="#createFolderModal">
                        <i class="fas fa-plus"></i> Ekle
                    </button>
                    @endif
                </div>
                
                <div class="card-body p-2 folder-tree" style="max-height: 700px; overflow-y: auto;">
                    <div class="mb-2">
                        <a href="{{ route('admin.qms.documents.index') }}" 
                           class="d-block p-2 rounded {{ !request('folder_id') ? 'bg-primary text-white' : 'text-dark hover-bg-light' }} text-decoration-none fw-bold">
                            <i class="fas fa-home me-2"></i> Ana Dizin (Tumu)
                        </a>
                    </div>
                    
                    <ul class="list-group list-group-flush">
                        @if($folders->count() > 0)
                            @php
                                // Klasorleri isme gore sirala (PR-01, PR-02...)
                                // "Cop Kutusu" veya "Arsiv" gibi klasorleri en sona atmak icin ozel siralama
                                $sortedFolders = $folders->sortBy(function($folder) {
                                    $name = strtolower($folder->name);
                                    // Eger isimde 'cop' veya 'arsiv' geciyorsa siralama degerini yuksek tut (en sona gider)
                                    if (str_contains($name, 'cop') || str_contains($name, 'çöp') || str_contains($name, 'arsiv') || str_contains($name, 'arşiv')) {
                                        return 'zzzz_' . $folder->name;
                                    }
                                    return $folder->name;
                                });
                            @endphp
                             @include('qms::documents.partials._folder_item', ['folders' => $sortedFolders, 'canManage' => $canManage])

                        @else
                            <div class="text-center text-muted small py-3">
                                <i class="far fa-folder-open mb-1"></i><br>Henuz klasor yok.
                            </div>
                        @endif
                    </ul>
                </div>
            </div>
        </div>

        {{-- SAG KOLON: DOKUMAN LiSTESi --}}
        <div id="content-panel">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        @if(request('folder_id'))
                            <i class="fas fa-folder-open me-2"></i> Secili Klasor icerigi
                        @else
                            <i class="fas fa-list me-2"></i> Tum Dokumanlar
                        @endif
                    </h6>
                    
                    <form action="{{ route('admin.qms.documents.index') }}" method="GET" class="d-inline-block">
                        @if(request('folder_id'))
                            <input type="hidden" name="folder_id" value="{{ request('folder_id') }}">
                        @endif
                        
                        <div class="input-group input-group-sm" style="width: 250px;">
                            <input type="text" name="search" class="form-control bg-light border-0 small" placeholder="Kod, isim veya Yazar ara..." value="{{ request('search') }}">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit"><i class="fas fa-search fa-sm"></i></button>
                            </div>
                            @if(request()->filled('search'))
                                <div class="input-group-append ms-1">
                                    <a href="{{ route('admin.qms.documents.index', ['folder_id' => request('folder_id')]) }}" class="btn btn-outline-secondary" title="Aramayi Temizle">
                                        <i class="fas fa-times fa-sm"></i>
                                    </a>
                                </div>
                            @endif
                        </div>
                    </form>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light text-uppercase small text-muted">
                            <tr>
                                <th style="width: 15%">Dokuman No</th>
                                <th style="width: 35%">Dokuman Adi</th>
                                <th style="width: 10%" class="text-center">Rev</th>
                                <th style="width: 15%" class="text-center">Durum</th>
                                <th style="width: 15%">Sahibi / Bolum</th>
                                <th style="width: 10%" class="text-end">islem</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($documents as $doc)
                            <tr>
                                <td class="fw-bold text-primary font-monospace" style="font-size: 0.9rem;">
                                    {{ $doc->document_code }}
                                </td>
                                <td>
                                    <div class="fw-bold text-dark">{{ $doc->name }}</div>
                                    <div class="small text-muted"><i class="far fa-folder-open me-1"></i> {{ $doc->folder->name ?? 'Ana Dizin' }}</div>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-light text-dark border">
                                        Rev{{ $doc->publishedVersion->version_no ?? ($doc->versions->first()->version_no ?? '0.0') }}
                                    </span>
                                </td>
                                <td class="text-center">
                                    @php 
                                        $status = $doc->status; 
                                        $label = match($status) {
                                            'Draft' => 'Taslak', 'InReview' => 'Onay Bekliyor', 'Published' => 'Yayinda', 'Obsolete' => 'iptal', default => $status
                                        };
                                    @endphp
                                    <span class="badge status-{{ $status }} px-2 py-1 rounded-pill fw-normal">{{ $label }}</span>
                                </td>
                                <td>
                                    <div class="small"><i class="fas fa-user-circle me-1 text-muted"></i> {{ $doc->owner->name }}</div>
                                    <div class="x-small text-muted">{{ $doc->created_at->format('d.m.Y') }}</div>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group" role="group">
                                        {{-- YENi: ONiZLEME BUYUTEC BUTONU --}}
                                        @php 
                                            $previewVerId = $doc->publishedVersion->id ?? ($doc->versions->first()->id ?? 0);
                                        @endphp
                                        <button type="button" class="btn btn-sm btn-outline-info shadow-sm" onclick="previewDocument('{{ route('admin.qms.documents.download', $previewVerId) }}', '{{ addslashes($doc->name) }}')" title="Dokumani Onizle">
                                            <i class="fas fa-search-plus"></i>
                                        </button>

                                        <a href="{{ route('admin.qms.documents.show', $doc->id) }}" class="btn btn-sm btn-outline-primary shadow-sm" title="Detay ve Tarihce">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        @if($canManage)
                                        <button type="button" class="btn btn-sm btn-outline-danger shadow-sm" onclick="deleteDocument({{ $doc->id }}, '{{ addslashes($doc->name) }}')" title="Dokumani Sil">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <div class="mb-2"><i class="far fa-file-alt fa-3x opacity-25"></i></div>
                                    Bu klasorde henuz dokuman bulunmuyor.
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                
                <div class="card-footer bg-white py-3">
                    {{ $documents->withQueryString()->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

{{-- YONETiCi MODALLARI BASLANGICI --}}
@if($canManage)

    {{-- TOPLU REViZYON (GECMiS) YUKLEME MODALI --}}
    <div class="modal fade" id="bulkHistoryUploadModal" tabindex="-1">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <form action="{{ route('admin.qms.documents.store-bulk-history') }}" method="POST" enctype="multipart/form-data" id="bulkHistoryUploadForm">
                @csrf
                <input type="hidden" name="folder_id" value="{{ request('folder_id') }}">
                <div class="modal-content">
                    <div class="modal-header bg-dark py-3">
                        <h6 class="modal-title fw-bold text-white"><i class="fas fa-archive me-2"></i>Eski Arsivleri Toplu Yukle (Revizyon Gecmisi)</h6>
                        <button type="button" class="btn-close btn-close-white btn-sm" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body bg-light">
                        <div class="alert alert-info small border-0 shadow-sm mb-3">
                            <i class="fas fa-info-circle me-1"></i> <strong>Ayni Dokuman No'ya</strong> sahip dosyalar tek bir dokumanda birlesir. En yuksek Rev numarasi otomatik olarak "Gecerli (Published)" yapilir, digerleri arsive kaldirilir.
                        </div>

                        <div class="mb-3 bg-white p-3 border rounded shadow-sm text-center">
                            <input type="file" name="files[]" id="bulkHistoryFileInput" class="form-control form-control-lg" multiple accept=".pdf,.doc,.docx,.xls,.xlsx" required>
                        </div>

                        <div id="bulkHistoryPreviewArea" style="display: none;">
                            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                                <table class="table table-sm table-bordered bg-white align-middle mb-0">
                                    <thead class="bg-light text-muted small text-center">
                                        <tr>
                                            <th width="20%">Dosya Orj Adi</th>
                                            <th width="15%">Dokuman No <span class="text-danger">*</span></th>
                                            <th width="20%">Dosya Adi</th>
                                            
                                            <th width="10%">Rev <span class="text-danger">*</span></th>
                                            <th width="20%">Revizyon Nedeni <span class="text-danger">*</span></th>
                                            <th width="10%">Saklama (Yil)</th>
                                            <th width="15%">Gizlilik Seviyesi</th>
                                        </tr>
                                    </thead>
                                    <tbody id="bulkHistoryPreviewBody">
                                        {{-- JS ile Dolacak --}}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer py-2 border-0 bg-light">
                        <button type="button" class="btn btn-secondary btn-sm fw-bold" data-bs-dismiss="modal">iptal</button>
                        <button type="submit" class="btn btn-dark btn-sm fw-bold px-4" id="btnBulkHistorySubmit"><i class="fas fa-save me-1"></i> ARSiVi YUKLE</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    {{-- TOPLU YUKLEME MODALI (GELiSMiS EKRAN) --}}
    @if(request('folder_id'))
    <div class="modal fade" id="bulkUploadModal" tabindex="-1">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <form action="{{ route('admin.qms.documents.store-bulk') }}" method="POST" enctype="multipart/form-data" id="bulkUploadForm">
                @csrf
                <input type="hidden" name="folder_id" value="{{ request('folder_id') }}">
                <div class="modal-content">
                    <div class="modal-header bg-warning py-3">
                        <h6 class="modal-title fw-bold text-dark"><i class="fas fa-layer-group me-2"></i>Klasore Toplu Dokuman Yukle</h6>
                        <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body bg-light">
                        
                        <div class="mb-3 bg-white p-3 border rounded shadow-sm text-center">
                            <label class="fw-bold mb-2 text-primary d-block">Dosyalari Secin (Coklu Secim Yapabilirsiniz)</label>
                            <input type="file" name="files[]" id="bulkFileInput" class="form-control form-control-lg" multiple accept=".pdf,.doc,.docx,.xls,.xlsx" required>
                            <div class="form-text mt-2 text-muted small">izin verilen formatlar: PDF, Word, Excel</div>
                        </div>

                        <div id="bulkPreviewArea" style="display: none;">
                            <h6 class="fw-bold text-dark mb-2"><i class="fas fa-list-ol me-1"></i> Dosya Detaylari</h6>
                            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                                <table class="table table-sm table-bordered bg-white align-middle mb-0">
                                    <thead class="bg-light text-muted small text-center">
                                        <tr>
                                            <th width="15%">Dokuman No</th>
                                            <th>Dosya Adi</th>
                                            
                                            <th width="20%">Saklama Suresi</th>
                                            <th width="20%">Gizlilik Seviyesi</th>
                                        </tr>
                                    </thead>
                                    <tbody id="bulkPreviewBody">
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer py-2 border-0 bg-light">
                        <button type="button" class="btn btn-secondary btn-sm fw-bold" data-bs-dismiss="modal">iptal</button>
                        <button type="submit" class="btn btn-warning btn-sm fw-bold px-4 text-dark" id="btnBulkSubmit"><i class="fas fa-save me-1"></i> YUKLE VE KAYDET</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    @endif

   {{-- DOKUMAN SiLME MODALI --}}
    <div class="modal fade" id="deleteDocModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h6 class="modal-title fw-bold">Dokuman islemi</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <p class="mb-1"><strong><span id="deleteDocName" class="text-primary"></span></strong></p>
                    <p class="small text-muted mb-0">Bu dokuman <strong>Cop Kutusuna</strong> tasinacak ve personelden gizlenecektir.</p>
                    <hr>
                    <p class="text-danger fw-bold x-small mb-0"><i class="fas fa-info-circle me-1"></i> (Eger dokuman zaten cop kutusundaysa tamamen yok edilecektir!)</p>
                </div>
                <div class="modal-footer justify-content-center border-0">
                    <form id="deleteDocForm" method="POST">
                        @csrf 
                        @method('DELETE')
                        <button type="button" class="btn btn-secondary btn-sm fw-bold" data-bs-dismiss="modal">iptal</button>
                        <button type="submit" class="btn btn-danger btn-sm fw-bold px-4">Uygula</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{-- KLASOR EKLEME MODALI (KiLiTLi YAPI) --}}
    <div class="modal fade" id="createFolderModal" tabindex="-1">
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <form action="{{ route('admin.qms.documents.create-folder') }}" method="POST">
                @csrf
                <div class="modal-content">
                    <div class="modal-header bg-light py-2">
                        <h6 class="modal-title fw-bold"><i class="fas fa-folder-plus me-2"></i>Yeni Klasor</h6>
                        <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="small fw-bold">Klasor Adi <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" required autofocus>
                        </div>
                        <div class="mb-3">
                            <label class="small fw-bold">Ana Klasor</label>
                            <select name="parent_id" class="form-select form-select-sm">
                                <option value="">-- Ana Dizin (Kok) --</option>
                                @foreach(\Modules\Qms\Models\QmsDocumentFolder::whereNull('parent_id')->get() as $f)
                                    <option value="{{ $f->id }}" {{ request('folder_id') == $f->id ? 'selected' : '' }}>{{ $f->name }}</option>
                                    @foreach($f->children as $child)
                                        <option value="{{ $child->id }}" {{ request('folder_id') == $child->id ? 'selected' : '' }}>-- {{ $child->name }}</option>
                                    @endforeach
                                @endforeach
                            </select>
                        </div>
                        
                        {{-- KLASOR KiLiT SALTERi --}}
                        <div class="form-check form-switch mb-2 mt-3">
                            <input class="form-check-input" type="checkbox" id="createLockSwitch" onchange="toggleCreateLock()">
                            <label class="form-check-label small fw-bold text-danger" for="createLockSwitch"><i class="fas fa-shield-alt me-1"></i>Klasoru Korumaya Al</label>
                        </div>
                        
                        <div id="createRolesWrapper" style="display: none; background: #f8f9fa; padding: 10px; border-radius: 5px;">
                            <div class="mb-2">
                                <label class="small fw-bold text-primary">Sadece Bu Roller Gorebilsin:</label>
                                <select name="allowed_roles[]" id="createAllowedRoles" class="form-select form-select-sm select2" multiple style="width: 100%">
                                    @foreach($roles as $role)
                                        <option value="{{ $role->name }}">{{ strtoupper(str_replace('_', ' ', $role->name)) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="small fw-bold text-primary">Sadece Bu Kullanicilar Gorebilsin:</label>
                                <select name="allowed_users[]" id="createAllowedUsers" class="form-select form-select-sm select2" multiple style="width: 100%">
                                    @foreach($users as $user)
                                        <option value="{{ $user->id }}">{{ $user->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="small fw-bold text-danger"><i class="fas fa-key me-1"></i>Klasor Sifresi (Opsiyonel):</label>
                                <input type="text" name="folder_password" id="createFolderPassword" class="form-control form-control-sm" placeholder="Sifre belirlerseniz, girmeyen icerigini goremez">
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer py-1 border-0">
                        <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">OLUSTUR</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    {{-- KLASOR DUZENLEME MODALI (KiLiTLi YAPI) --}}
    <div class="modal fade" id="editFolderModal" tabindex="-1">
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <form id="editFolderForm" method="POST">
                @csrf
                <div class="modal-content">
                    <div class="modal-header bg-light py-2">
                        <h6 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i>Klasor Duzenle</h6>
                        <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="small fw-bold">Klasor Adi</label>
                            <input type="text" name="name" id="editFolderName" class="form-control" required>
                        </div>
                        
                        {{-- KLASOR KiLiT SALTERi --}}
                        <div class="form-check form-switch mb-2 mt-3">
                            <input class="form-check-input" type="checkbox" id="editLockSwitch" onchange="toggleEditLock()">
                            <label class="form-check-label small fw-bold text-danger" for="editLockSwitch"><i class="fas fa-shield-alt me-1"></i>Klasoru Korumaya Al</label>
                        </div>
                        
                        <div id="editRolesWrapper" style="display: none; background: #f8f9fa; padding: 10px; border-radius: 5px;">
                            <div class="mb-2">
                                <label class="small fw-bold text-primary">Sadece Bu Roller Gorebilsin:</label>
                                <select name="allowed_roles[]" id="editAllowedRoles" class="form-select form-select-sm select2" multiple style="width: 100%">
                                    @foreach($roles as $role)
                                        <option value="{{ $role->name }}">{{ strtoupper(str_replace('_', ' ', $role->name)) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="small fw-bold text-primary">Sadece Bu Kullanicilar Gorebilsin:</label>
                                <select name="allowed_users[]" id="editAllowedUsers" class="form-select form-select-sm select2" multiple style="width: 100%">
                                    @foreach($users as $user)
                                        <option value="{{ $user->id }}">{{ $user->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="small fw-bold text-danger"><i class="fas fa-key me-1"></i>Klasor Sifresi (Opsiyonel):</label>
                                <input type="text" name="folder_password" id="editFolderPassword" class="form-control form-control-sm" placeholder="Sifre belirlerseniz, girmeyen icerigini goremez">
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer py-1 border-0">
                        <button type="submit" class="btn btn-warning btn-sm w-100 fw-bold">GUNCELLE</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

@endif
{{-- YONETiCi MODALLARI BiTiSi --}}


{{-- ================================================================= --}}
{{-- SiFRE SORMA MODALI (HERKES iCiN - @if($canManage) DISINDA OLMALI) --}}
{{-- ================================================================= --}}
<div class="modal fade" id="unlockFolderModal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <form id="unlockFolderForm" method="POST">
            @csrf
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header bg-dark text-white py-2">
                    <h6 class="modal-title fw-bold"><i class="fas fa-key me-2 text-warning"></i>Klasor Sifresi Gerekli</h6>
                    <button type="button" class="btn-close btn-close-white btn-sm" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center bg-light">
                    <p class="small text-muted mb-3"><strong id="unlockFolderName" class="text-dark fs-6"></strong><br>klasorunun icerigini gormek icin lutfen sifreyi giriniz.</p>
                    <input type="password" name="password" class="form-control text-center fs-5 shadow-sm" placeholder="****" required autofocus>
                </div>
                <div class="modal-footer border-0 py-2 bg-light">
                    <button type="submit" class="btn btn-warning w-100 fw-bold text-dark shadow-sm"><i class="fas fa-unlock me-2"></i>KiLiDi AC</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- DOKUMAN ONiZLEME MODALI --}}
<div class="modal fade" id="previewDocModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content h-100 shadow-lg border-0">
            <div class="modal-header bg-dark text-white py-2">
                <h6 class="modal-title fw-bold" id="previewDocTitle">
                    <i class="fas fa-file-pdf me-2 text-danger"></i>Dokuman Onizleme
                </h6>
                <button type="button" class="btn-close btn-close-white btn-sm" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0 bg-light" style="height: 85vh;">
                {{-- Onizleme Iframe'i --}}
                <iframe id="previewIframe" src="" style="width: 100%; height: 100%; border: none;"></iframe>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // ==========================================
    // KiLiT SALTERi VE MODAL FONKSiYONLARI
    // ==========================================
    function toggleCreateLock() {
        if($('#createLockSwitch').is(':checked')) {
            $('#createRolesWrapper').slideDown();
        } else {
            $('#createRolesWrapper').slideUp();
            $('#createAllowedRoles').val(null).trigger('change');
            $('#createAllowedUsers').val(null).trigger('change');
            $('#createFolderPassword').val('');
        }
    }

    function toggleEditLock() {
        if($('#editLockSwitch').is(':checked')) {
            $('#editRolesWrapper').slideDown();
        } else {
            $('#editRolesWrapper').slideUp();
            $('#editAllowedRoles').val(null).trigger('change');
            $('#editAllowedUsers').val(null).trigger('change');
            $('#editFolderPassword').val('');
        }
    }

    // Klasor Duzenleme Fonksiyonu
    function editFolder(id, name, rules) {
        document.getElementById('editFolderName').value = name;
        let url = "{{ route('admin.qms.documents.folder.update', ':id') }}";
        document.getElementById('editFolderForm').action = url.replace(':id', id);
        
        // Eger kural varsa JSON objesinden degerleri alip dolduruyoruz
        if (rules && (rules.roles || rules.users || rules.password)) { 
            $('#editLockSwitch').prop('checked', true);
            $('#editRolesWrapper').show();
            $('#editAllowedRoles').val(rules.roles || []).trigger('change'); 
            $('#editAllowedUsers').val(rules.users || []).trigger('change'); 
            $('#editFolderPassword').val(rules.password || ''); 
        } else { 
            $('#editLockSwitch').prop('checked', false);
            $('#editRolesWrapper').hide();
            $('#editAllowedRoles').val(null).trigger('change'); 
            $('#editAllowedUsers').val(null).trigger('change'); 
            $('#editFolderPassword').val(''); 
        }
        $('#editFolderModal').modal('show');
    }

    // Dokuman Silme Fonksiyonu
    function deleteDocument(id, name) {
        document.getElementById('deleteDocName').innerText = name;
        let url = "{{ route('admin.qms.documents.destroy', ':id') }}";
        document.getElementById('deleteDocForm').action = url.replace(':id', id);
        $('#deleteDocModal').modal('show');
    }

    // Sifre Sorma Modalini Acan Fonksiyon
    function openUnlockModal(id, name) {
        document.getElementById('unlockFolderName').innerText = name;
        let url = "{{ route('admin.qms.documents.folder.unlock', ':id') }}";
        document.getElementById('unlockFolderForm').action = url.replace(':id', id);
        $('#unlockFolderModal').modal('show');
    }

    // ==========================================
    // DUZELTiLDi: DOKUMAN ONiZLEME FONKSiYONU (Tarayici PDF Viewer)
    // ==========================================
    function previewDocument(url, name) {
        document.getElementById('previewDocTitle').innerHTML = '<i class="fas fa-file-pdf me-2 text-danger"></i>' + name;
        
        // Inline parametresi ekle - tarayicinin yerlesik PDF viewer'ini kullan
        let pdfUrl = url + (url.includes('?') ? '&' : '?') + 'view=inline';
        
        // Dogrudan iframe'e yukle (CORS sorunu olmaz cunku ayni domain)
        document.getElementById('previewIframe').src = pdfUrl;
        $('#previewDocModal').modal('show');
    }


    // ==========================================
    // DOCUMENT READY (SAYFA YUKLENDiGiNDE)
    // ==========================================
    $(document).ready(function() {

        // Onizleme Modali kapandiginda Iframe'i temizle (arkada dosya acik kalmasin)
        $('#previewDocModal').on('hidden.bs.modal', function () {
            $('#previewIframe').attr('src', '');
        });

        // ------------------------------------------
        // DUZELTiLDi: DiNAMiK KLASOR AGACI (ACCORDION) MANTIGI
        // ------------------------------------------
        
        // 1. Baslangicta tum alt klasorleri (ic ice ul'leri) gizle
        $('.folder-tree .folder-children').hide();

        // 2. Aktif olan (secili) klasoru bul ve ust ebeveynlerini ac
        let activeLink = $('.folder-tree .folder-item-row.bg-primary');
        
        if (activeLink.length > 0) {
            // Aktif klasorun ust ebeveynlerini (parent ul) gorunur yap
            activeLink.parents('.folder-children').show();
            // Aktif klasorun hemen altindaki cocuklari (child ul) gorunur yap
            activeLink.siblings('.folder-children').show();
            // Ust klasorlerin toggle butonlarini "expanded" yap
            activeLink.parents('li').find('> .folder-item-row .folder-toggle-btn').addClass('expanded');
            // Aktif klasorun toggle butonunu da "expanded" yap
            activeLink.find('.folder-toggle-btn').addClass('expanded');
        }

        // 3. DUZELTiLDi: SADECE TOGGLE BUTONUNA TIKLANINCA ACILSIN/KAPANSIN
        // Ayri bir buton elementi kullanarak cift tiklama sorununu cozuyoruz
        $(document).on('click', '.folder-tree .folder-toggle-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            
            let $btn = $(this);
            let $parentLi = $btn.closest('li');
            let $childUl = $parentLi.find('> .folder-children');
            
            if ($childUl.length > 0) {
                if ($childUl.is(':visible')) {
                    // Kapat
                    $childUl.slideUp(300);
                    $btn.removeClass('expanded');
                } else {
                    // Ac
                    $childUl.slideDown(300);
                    $btn.addClass('expanded');
                }
            }
            
            return false;
        });


        // ------------------------------------------
        // TOPLU YUKLEME: JS TABLO URETiCi
        // ------------------------------------------
        $('#bulkFileInput').on('change', function() {
            let files = this.files;
            let tbody = $('#bulkPreviewBody');
            tbody.empty(); 

            if (files.length > 0) {
                $('#bulkPreviewArea').slideDown();
                
                for (let i = 0; i < files.length; i++) {
                    let fileName = files[i].name;
                    
                    let tr = `
                        <tr>
                            <td class="text-primary fw-bold small align-middle">
                                <i class="far fa-file-alt me-1 text-muted"></i>${fileName}
                            </td>
                            <td>
                                <input type="text" name="doc_codes[]" class="form-control form-control-sm border-warning" placeholder="Bos birak, sistem atasin">
                            </td>
                            <td>
                                <input type="number" name="retention_period_years[]" class="form-control form-control-sm" placeholder="Yil (Orn: 5)" value="5">
                            </td>
                            <td>
                                <select name="security_levels[]" class="form-select form-select-sm">
                                    <option value="Public">Acik (Genel)</option>
                                    <option value="Internal" selected>Kurum ici</option>
                                    <option value="Confidential">Gizli</option>
                                    <option value="Restricted">Kisitli (Cok Gizli)</option>
                                </select>
                            </td>
                        </tr>
                    `;
                    tbody.append(tr);
                }
            } else {
                $('#bulkPreviewArea').slideUp();
            }
        });

        // Yukleme Spinner
        $('#bulkUploadForm').on('submit', function() {
            let btn = $('#btnBulkSubmit');
            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i> Yukleniyor...');
        });


        // TOPLU REVİZYON YÜKLEME: JS TABLO ÜRETİCİ
        $('#bulkHistoryFileInput').on('change', function() {
            let files = this.files;
            let tbody = $('#bulkHistoryPreviewBody');
            tbody.empty(); 

            if (files.length > 0) {
                $('#bulkHistoryPreviewArea').slideDown();
                
                // Tablo başlıklarına Doküman Adı'nı da ekleyelim (Eğer yukarıdaki HTML tablosunda thead kısmına eklemediysen oraya da '<th>Doküman Adı</th>' eklemeyi unutma)
                
                for (let i = 0; i < files.length; i++) {
                    let fileName = files[i].name;
                    // Uzantıyı silip sadece dosya adını alıyoruz (Varsayılan olarak inputa yazdırmak için)
                    let cleanFileName = fileName.replace(/\.[^/.]+$/, ""); 
                    
                    let tr = `
                        <tr>
                            <td class="text-primary fw-bold x-small align-middle" title="${fileName}">
                                <i class="far fa-file-alt me-1 text-muted"></i>
                                ${fileName.length > 15 ? fileName.substring(0,15) + '...' : fileName}
                            </td>
                            <td><input type="text" name="doc_codes[]" class="form-control form-control-sm border-dark" placeholder="Örn: FR-01" required></td>
                            
                            <td><input type="text" name="doc_names[]" class="form-control form-control-sm border-dark" value="${cleanFileName}" required></td>
                            
                            <td><input type="text" name="rev_nos[]" class="form-control form-control-sm border-dark" placeholder="0.1" required></td>
                            <td><input type="text" name="rev_reasons[]" class="form-control form-control-sm border-dark" placeholder="Örn: İlk Yayın" required></td>
                            <td><input type="number" name="retention_period_years[]" class="form-control form-control-sm" value="5"></td>
                            <td>
                                <select name="security_levels[]" class="form-select form-select-sm">
                                    <option value="Public">Açık (Genel)</option>
                                    <option value="Internal" selected>Kurum İçi</option>
                                    <option value="Confidential">Gizli</option>
                                    <option value="Restricted">Kısıtlı (Çok Gizli)</option>
                                </select>
                            </td>
                        </tr>
                    `;
                    tbody.append(tr);
                }
            } else {
                $('#bulkHistoryPreviewArea').slideUp();
            }
        });

        $('#bulkHistoryUploadForm').on('submit', function() {
            let btn = $('#btnBulkHistorySubmit');
            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i> Yukleniyor...');
        });

        // EGER CONTROLLER BiZi BURAYA "SiFRE GiR" DiYE YONLENDiRDiYSE MODALI OTOMATiK AC
        @if(session('locked_folder_id'))
            openUnlockModal({{ session('locked_folder_id') }}, "{!! addslashes(session('locked_folder_name')) !!}");
        @endif

        // ==========================================
        // YENIDEN BOYUTLANDIRILABİLİR SOL PANEL (DRAG-TO-RESIZE)
        // ==========================================
        (function() {
            var sidebar   = document.getElementById('sidebar-panel');
            var handle    = document.getElementById('resize-handle');
            var STORAGE_KEY = 'qms_sidebar_width';
            var MIN_W = 160;
            var MAX_W = 600;
            var DEFAULT_W = 280; // piksel cinsinden varsayilan genislik

            // Kayitli genisligi yukle
            var saved = parseInt(localStorage.getItem(STORAGE_KEY), 10);
            if (saved && saved >= MIN_W && saved <= MAX_W) {
                sidebar.style.width = saved + 'px';
            } else {
                sidebar.style.width = DEFAULT_W + 'px';
            }

            var startX, startW;

            handle.addEventListener('mousedown', function(e) {
                e.preventDefault();
                startX = e.clientX;
                startW = sidebar.offsetWidth;
                handle.classList.add('dragging');
                document.body.classList.add('resizing');

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });

            function onMouseMove(e) {
                var newW = startW + (e.clientX - startX);
                newW = Math.max(MIN_W, Math.min(MAX_W, newW));
                sidebar.style.width = newW + 'px';
            }

            function onMouseUp() {
                handle.classList.remove('dragging');
                document.body.classList.remove('resizing');
                // Genisligi kaydet
                localStorage.setItem(STORAGE_KEY, sidebar.offsetWidth);
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onMouseUp);
            }

            // Cift tiklayinca varsayilana sifirla
            handle.addEventListener('dblclick', function() {
                sidebar.style.width = DEFAULT_W + 'px';
                localStorage.setItem(STORAGE_KEY, DEFAULT_W);
            });
        })();
    });
</script>


@endsection