@foreach($folders as $folder)
    {{-- MİRAS ZEKASI: Kullanıcının bu klasörü (veya atalarını) görme yetkisi var mı? --}}
    @if($folder->userHasAccess(auth()->user()))
        
        @php
            // Kilit ve Şifre Durumlarını Temizce Hesaplıyoruz
            $isPasswordProtected = $folder->hasPasswordProtection();
            $isUnlocked = session('unlocked_folder_' . $folder->id) == true;
            $canBypass = in_array(auth()->user()->role, ['admin', 'Kalite Yöneticisi']);
            
            // Eğer şifreliyse, kilidi açılmamışsa ve kişi Admin/KY değilse şifre girmesi ZORUNLUDUR!
            $needsPassword = $isPasswordProtected && !$isUnlocked && !$canBypass;
            
            // Alt klasör var mı kontrol et
            $hasChildren = $folder->children->count() > 0;
        @endphp

        <li class="list-group-item border-0 p-0 mb-1">
            <div class="d-flex align-items-center p-2 rounded justify-content-between folder-item-row {{ request('folder_id') == $folder->id ? 'bg-primary text-white shadow-sm' : 'hover-bg-light' }}">
                
                {{-- SOL TARAFI: TOGGLE BUTONU, İKON, İSİM VE ROZETLER --}}
                <div class="d-flex align-items-center flex-grow-1" style="gap: 4px; min-width: 0;">
                    
                    {{-- DÜZELTİLDİ: AYRI TOGGLE BUTONU (Sadece alt klasör varsa görünür) --}}
                    @if($hasChildren && !$needsPassword)
                        <button type="button" class="folder-toggle-btn {{ request('folder_id') == $folder->id ? 'text-white' : '' }}" title="Alt klasörleri aç/kapat">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    @else
                        <span style="width: 24px; display: inline-block;"></span>
                    @endif
                    
                    {{-- KLASÖR LİNKİ (Sadece klasöre gitmek için) --}}
                    <a 
                        @if($needsPassword)
                            {{-- Şifre Gerekliyse JavaScript Modalını Tetikle --}}
                            href="javascript:void(0);" 
                            onclick="openUnlockModal({{ $folder->id }}, '{{ htmlspecialchars($folder->name, ENT_QUOTES) }}')"
                        @else
                            {{-- Şifre Gerekli Değilse Direkt Klasörün İçine Git --}}
                            href="{{ route('admin.qms.documents.index', ['folder_id' => $folder->id]) }}"
                        @endif
                        class="d-flex align-items-center text-decoration-none flex-grow-1 text-truncate {{ request('folder_id') == $folder->id ? 'text-white' : 'text-dark' }}"
                        style="gap: 8px;">
                        
                        {{-- Klasör İkonu --}}
                        <span class="{{ request('folder_id') == $folder->id ? 'text-white' : 'text-warning' }}">
                            @if($needsPassword)
                                <i class="fas fa-folder-minus text-danger"></i> {{-- Şifreli ve Kilitli İkon --}}
                            @else
                                <i class="fas fa-folder{{ request('folder_id') == $folder->id ? '-open' : '' }}"></i>
                            @endif
                        </span>
                        
                        {{-- Klasör Adı --}}
                        <span class="fw-bold text-truncate">{{ $folder->name }}</span>

                        {{-- Kilit/Şifre İkonları --}}
                        @if($isPasswordProtected)
                            @if($isUnlocked || $canBypass)
                                <i class="fas fa-unlock fa-xs text-success" title="Şifre Açık"></i>
                            @else
                                <i class="fas fa-key fa-xs text-danger" title="Şifre Korumalı"></i>
                            @endif
                        @endif

                        {{-- Rol veya Kullanıcı Kısıtlaması İkonu --}}
                        @if(isset($folder->access_rules['roles']) || isset($folder->access_rules['users']))
                            <i class="fas fa-user-shield fa-xs {{ request('folder_id') == $folder->id ? 'text-white-50' : 'text-muted' }}" title="Rol/Kullanıcı Bazlı Erişim Kısıtlaması"></i>
                        @endif

                        {{-- Doküman Sayısı --}}
                        @if(isset($folder->documents_count) && $folder->documents_count > 0)
                            <span class="badge rounded-pill {{ request('folder_id') == $folder->id ? 'bg-white text-primary' : 'bg-light text-muted border' }}" style="font-size: 0.6rem;">
                                {{ $folder->documents_count }}
                            </span>
                        @endif
                    </a>
                </div>

                {{-- SAĞ TARAFI: AKSİYON BUTONLARI (Sadece Yetkili Görür) --}}
                @if($canManage ?? false)
                    <div class="d-flex gap-1 action-buttons flex-shrink-0">
                        {{-- DÜZENLE --}}
                        <button type="button" 
                                class="btn btn-xs {{ request('folder_id') == $folder->id ? 'btn-outline-light' : 'btn-outline-secondary' }} border-0" 
                                onclick='editFolder({{ $folder->id }}, "{{ addslashes($folder->name) }}", @json($folder->access_rules ?? []))'
                                title="Düzenle">
                            <i class="fas fa-pencil-alt fa-xs"></i>
                        </button>

                        {{-- SİL --}}
                        <form action="{{ route('admin.qms.documents.folder.destroy', $folder->id) }}" method="POST" onsubmit="return confirm('Bu klasörü silmek istediğinize emin misiniz?');" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" 
                                    class="btn btn-xs {{ request('folder_id') == $folder->id ? 'btn-outline-light' : 'btn-outline-danger' }} border-0" 
                                    title="Sil">
                                <i class="fas fa-trash fa-xs"></i>
                            </button>
                        </form>
                    </div>
                @endif
            </div>

            {{-- ALT KLASÖRLER (Recursive Çağrı) --}}
            @if($hasChildren)
                {{-- Eğer ebeveyn klasör şifreliyse ve şifre girilmemişse, alt klasörlerin HTML'ini hiç yükleme (Tam Gizlilik!) --}}
                @if(!$needsPassword)
                    <ul class="list-group ms-3 border-start ps-2 mt-1 folder-children" style="border-left-style: dashed !important; border-color: #ccc;">
                        @include('qms::documents.partials._folder_item', [
                            'folders' => $folder->children, 
                            'canManage' => $canManage ?? false
                        ])
                    </ul>
                @endif
            @endif
        </li>
    @endif
@endforeach