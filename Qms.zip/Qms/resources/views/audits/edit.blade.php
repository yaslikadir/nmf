@extends('layouts.admin')
@section('title', 'Denetim Düzenle')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">Denetim Düzenle: <span class="text-primary">{{ $audit->code }}</span></h4>
        <a href="{{ route('admin.qms.audits.index') }}" class="btn btn-secondary shadow-sm">Geri Dön</a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <form action="{{ route('admin.qms.audits.update', $audit->id) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="fw-bold small">Denetim Başlığı</label>
                        <input type="text" name="title" class="form-control" value="{{ $audit->title }}" required>
                    </div>

                    <div class="col-md-6">
                        <label class="fw-bold small">Planlanan Tarih</label>
                        <input type="date" name="planned_date" class="form-control" value="{{ $audit->planned_date->format('Y-m-d') }}" required>
                    </div>

                    <div class="col-md-6">
                        <label class="fw-bold small">Baş Denetçi</label>
                        <select name="lead_auditor_id" class="form-select select2">
                            @foreach($users as $user)
                                <option value="{{ $user->id }}" {{ $audit->lead_auditor_id == $user->id ? 'selected' : '' }}>
                                    {{ $user->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="fw-bold small">Denetlenen Birim (İç Denetim ise)</label>
                        <select name="department_id" class="form-select select2">
                            <option value="">-- Seçiniz --</option>
                            @foreach($departments as $dept)
                                <option value="{{ $dept->id }}" {{ $audit->department_id == $dept->id ? 'selected' : '' }}>
                                    {{ $dept->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="fw-bold small">Kapsam / Notlar</label>
                        <textarea name="scope" class="form-control" rows="3">{{ $audit->scope }}</textarea>
                    </div>
                </div>

                <div class="mt-4 text-end">
                    <button type="submit" class="btn btn-warning fw-bold text-dark px-4">
                        <i class="fas fa-save me-2"></i> DEĞİŞİKLİKLERİ KAYDET
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection