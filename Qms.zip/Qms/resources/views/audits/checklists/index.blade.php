@extends('layouts.admin')
@section('title', 'Soru Listeleri')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800"><i class="fas fa-list-check me-2 text-warning"></i>Soru Listeleri (Checklists)</h4>
        <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#createChecklistModal">
            <i class="fas fa-plus me-1"></i> Yeni Liste
        </button>
    </div>

    <div class="row">
        @foreach($checklists as $list)
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm hover-shadow transition-all">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="fw-bold text-dark mb-0">{{ $list->name }}</h5>
                        @if($list->is_active) 
                            <i class="fas fa-check-circle text-success" title="Aktif"></i> 
                        @else 
                            <i class="fas fa-ban text-danger" title="Pasif"></i> 
                        @endif
                    </div>
                    <p class="text-muted small mb-3">{{ $list->type ?? 'Genel' }}</p>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="badge bg-light text-dark border">
                            <i class="fas fa-question-circle me-1"></i> {{ $list->questions_count }} Soru
                        </span>
                        <a href="{{ route('admin.qms.audits.checklists.show', $list->id) }}" class="btn btn-sm btn-outline-primary fw-bold">
                            SORULARI DÜZENLE <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>

{{-- YENİ LİSTE MODALI --}}
<div class="modal fade" id="createChecklistModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <form action="{{ route('admin.qms.audits.checklists.store') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title fw-bold">Yeni Soru Listesi</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold">Liste Adı</label>
                        <input type="text" name="name" class="form-control" placeholder="Örn: ISO 9001:2015 İç Denetim" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Tip</label>
                        <input type="text" name="type" class="form-control" placeholder="Örn: Kalite, Çevre, İSG">
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">OLUŞTUR</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection