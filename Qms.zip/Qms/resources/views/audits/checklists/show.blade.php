@extends('layouts.admin')
@section('title', $checklist->name)

@section('content')
<div class="container-fluid px-4 mt-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800">{{ $checklist->name }}</h4>
            <div class="text-muted small">Bu listeye bağlı soruları yönetin.</div>
        </div>
        <a href="{{ route('admin.qms.audits.checklists.index') }}" class="btn btn-secondary shadow-sm">Geri Dön</a>
    </div>

    <div class="row">
        {{-- SOL: YENİ SORU FORMU --}}
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-0 sticky-top" style="top: 20px; z-index: 1;">
                <div class="card-header bg-primary text-white fw-bold">
                    <i class="fas fa-plus me-1"></i> Yeni Soru Ekle
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.qms.audits.checklists.questions.store', $checklist->id) }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label class="fw-bold small">Soru / Kriter <span class="text-danger">*</span></label>
                            <textarea name="question" class="form-control" rows="4" required placeholder="Denetlenecek kriteri yazınız..."></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold small">Referans Standart (Opsiyonel)</label>
                            <input type="text" name="reference_standard" class="form-control" placeholder="Örn: ISO 9001 Madde 5.2">
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold small">Sıra No</label>
                            <input type="number" name="order" class="form-control" value="{{ $checklist->questions->count() + 1 }}">
                        </div>
                        <button type="submit" class="btn btn-primary w-100 fw-bold">LİSTEYE EKLE</button>
                    </form>
                </div>
            </div>
        </div>

        {{-- SAĞ: MEVCUT SORULAR --}}
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-light fw-bold">
                    <i class="fas fa-list-ol me-1"></i> Soru Listesi
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr class="text-muted small text-uppercase">
                                <th style="width: 50px;">Sıra</th>
                                <th>Soru</th>
                                <th>Referans</th>
                                <th class="text-end">İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($checklist->questions as $question)
                            <tr>
                                <td class="text-center fw-bold text-muted">{{ $question->order }}</td>
                                <td>{{ $question->question }}</td>
                                <td class="small text-muted">{{ $question->reference_standard ?? '-' }}</td>
                                <td class="text-end">
                                    <form action="{{ route('admin.qms.audits.questions.destroy', $question->id) }}" method="POST" onsubmit="return confirm('Silmek istediğinize emin misiniz?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-xs btn-outline-danger border-0">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="4" class="text-center py-5 text-muted">
                                    <i class="far fa-clipboard fa-3x mb-3 opacity-25"></i><br>
                                    Henüz soru eklenmemiş. Yandaki formdan ekleyebilirsiniz.
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection