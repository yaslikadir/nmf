@extends('layouts.admin')
@section('title', 'Denetim Analiz Paneli')

@section('content')
<div class="container-fluid px-4 mt-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800"><i class="fas fa-chart-pie me-2 text-primary"></i>Denetim Analiz & Trendler</h4>
            <div class="text-muted small">Denetim süreçlerinin performans göstergeleri ve sapma analizleri.</div>
        </div>
        <a href="{{ route('admin.qms.audits.index') }}" class="btn btn-outline-secondary btn-sm">Listeye Dön</a>
    </div>

    {{-- 1. KARTLAR (KPI) --}}
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card border-start-lg border-start-primary shadow-sm h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Toplam Denetim</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $totalAudits }}</div>
                        </div>
                        <div class="col-auto"><i class="fas fa-calendar fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-start-lg border-start-success shadow-sm h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Tamamlanan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $completedAudits }}</div>
                        </div>
                        <div class="col-auto"><i class="fas fa-check-circle fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-start-lg border-start-danger shadow-sm h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Tespit Edilen Uygunsuzluk</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $openFindings }}</div>
                        </div>
                        <div class="col-auto"><i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- 2. GRAFİKLER --}}
    <div class="row">
        
        {{-- Aylık Denetim Sayısı (Bar Chart) --}}
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Aylık Denetim Planı ({{ date('Y') }})</h6>
                </div>
                <div class="card-body">
                    <canvas id="monthlyAuditChart" height="100"></canvas>
                </div>
            </div>
        </div>

        {{-- Bulgu Türleri (Pie Chart) --}}
        <div class="col-lg-4 mb-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Bulgu Türü Dağılımı</h6>
                </div>
                <div class="card-body">
                    <canvas id="findingTypeChart" height="200"></canvas>
                </div>
            </div>
        </div>

        {{-- Departman Bazlı Hata Analizi (Horizontal Bar) --}}
        <div class="col-lg-6 mb-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white py-3 d-flex justify-content-between">
                    <h6 class="m-0 font-weight-bold text-danger">Departman Bazlı Uygunsuzluklar</h6>
                    <small class="text-muted">En çok hata çıkan birimler</small>
                </div>
                <div class="card-body">
                    <canvas id="deptFindingChart" height="150"></canvas>
                </div>
            </div>
        </div>

        {{-- En Son Eklenen Denetimler (Tablo) --}}
        <div class="col-lg-6 mb-4">
            <div class="card shadow-sm mb-4 h-100">
                <div class="card-header bg-white py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Son Denetimler</h6>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0 small">
                        <thead>
                            <tr>
                                <th>Kod</th>
                                <th>Başlık</th>
                                <th>Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach(\Modules\Qms\Models\QmsAudit::latest()->take(5)->get() as $lastAudit)
                            <tr>
                                <td>{{ $lastAudit->code }}</td>
                                <td>{{ Str::limit($lastAudit->title, 30) }}</td>
                                <td>
                                    @if($lastAudit->status == 'Completed') <span class="badge bg-success">Bitti</span>
                                    @elseif($lastAudit->status == 'In_Progress') <span class="badge bg-warning text-dark">Sürüyor</span>
                                    @else <span class="badge bg-secondary">Plan</span> @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // 1. AYLIK DENETİM GRAFİĞİ (Line/Bar)
    const ctxMonthly = document.getElementById('monthlyAuditChart').getContext('2d');
    new Chart(ctxMonthly, {
        type: 'bar',
        data: {
            labels: ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'],
            datasets: [{
                label: 'Denetim Sayısı',
                data: @json($monthlyCounts),
                backgroundColor: '#4e73df',
                hoverBackgroundColor: '#2e59d9',
                borderColor: '#4e73df',
                borderRadius: 5
            }]
        },
        options: {
            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
    });

    // 2. BULGU TÜRÜ (Pie)
    const ctxType = document.getElementById('findingTypeChart').getContext('2d');
    new Chart(ctxType, {
        type: 'doughnut',
        data: {
            labels: ['Uygunsuzluk (Hata)', 'Gözlem', 'Fırsat'],
            datasets: [{
                data: [
                    {{ $findingTypes['NonConformity'] ?? 0 }},
                    {{ $findingTypes['Observation'] ?? 0 }},
                    {{ $findingTypes['Opportunity'] ?? 0 }}
                ],
                backgroundColor: ['#dc3545', '#ffc107', '#198754'],
                hoverOffset: 4
            }]
        }
    });

    // 3. DEPARTMAN ANALİZİ (Yatay Bar)
    const ctxDept = document.getElementById('deptFindingChart').getContext('2d');
    new Chart(ctxDept, {
        type: 'bar',
        data: {
            labels: @json($findingsByDept->pluck('name')),
            datasets: [{
                label: 'Uygunsuzluk Sayısı',
                data: @json($findingsByDept->pluck('total')),
                backgroundColor: '#e74a3b',
                indexAxis: 'y', // Yatay bar yapar
            }]
        },
        options: {
            indexAxis: 'y',
            scales: { x: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
    });
</script>
@endpush