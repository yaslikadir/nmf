@extends('layouts.admin')
@section('title', 'Denetim Planları')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800"><i class="fas fa-calendar-alt me-2 text-primary"></i>Denetim Planları</h4>
        <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#createPlanModal">
            <i class="fas fa-plus me-1"></i> Yeni Plan Oluştur
        </button>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-muted small text-uppercase">
                        <tr>
                            <th>Plan Adı</th>
                            <th>Yıl</th>
                            <th class="text-center">Denetim Sayısı</th>
                            <th>Durum</th>
                            <th>Oluşturan</th>
                            <th class="text-end">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($plans as $plan)
                        <tr>
                            <td class="fw-bold text-primary">
                                <a href="{{ route('admin.qms.audits.plans.show', $plan->id) }}" class="text-decoration-none">
                                    {{ $plan->name }}
                                </a>
                            </td>
                            <td>{{ $plan->year }}</td>
                            <td class="text-center"><span class="badge bg-light text-dark border">{{ $plan->audits_count }}</span></td>
                            <td>
                                @if($plan->status == 'Draft') <span class="badge bg-secondary">Taslak</span>
                                @elseif($plan->status == 'Published') <span class="badge bg-success">Yayında</span>
                                @else <span class="badge bg-dark">Kapalı</span> @endif
                            </td>
                            <td class="small">{{ $plan->creator->name ?? '-' }}</td>
                            <td class="text-end">
                                <a href="{{ route('admin.qms.audits.plans.show', $plan->id) }}" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-eye"></i> Detay
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="6" class="text-center py-4 text-muted">Henüz plan oluşturulmamış.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white">{{ $plans->links() }}</div>
    </div>
</div>

{{-- YENİ PLAN MODALI --}}
<div class="modal fade" id="createPlanModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <form action="{{ route('admin.qms.audits.plans.store') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title fw-bold">Yeni Denetim Planı</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold">Plan Adı</label>
                        <input type="text" name="name" class="form-control" placeholder="Örn: 2026 İç Denetim Planı" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Yıl</label>
                        <input type="number" name="year" class="form-control" value="{{ date('Y') }}" required>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">OLUŞTUR</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection