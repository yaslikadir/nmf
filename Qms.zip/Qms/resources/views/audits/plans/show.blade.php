@extends('layouts.admin')
@section('title', $plan->name)

@push('css')
<style>
    /* Tablo Güzelleştirme (Ekran İçin) */
    .audit-plan-table th {
        background-color: #f8f9fa;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.75rem;
        border-bottom: 2px solid #dee2e6;
        vertical-align: middle;
    }
    .audit-plan-table td {
        vertical-align: middle;
        font-size: 0.85rem;
    }
    .audit-plan-table tr:hover {
        background-color: #f1f5f9;
    }

    /* --- YAZDIRMA AYARLARI (SIHİR BURADA) --- */
    @media print {
        /* 1. Gereksiz Her Şeyi Gizle */
        body * {
            visibility: hidden;
        }
        
        /* 2. Sadece Bizim Tablo Kartını ve İmza Alanını Göster */
        #printableArea, #printableArea * {
            visibility: visible;
        }

        /* 3. Pozisyonu Ayarla (Kağıdın tepesine yapıştır) */
        #printableArea {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 0;
            border: none !important;
            box-shadow: none !important;
        }

        /* 4. Butonları ve Linkleri Gizle (Tablo içindeki detay butonları vs) */
        .btn, .no-print {
            display: none !important;
        }

        /* 5. "İşlem" Sütununu Gizle (Kağıtta düzenle butonuna gerek yok) */
        .audit-plan-table th:last-child, 
        .audit-plan-table td:last-child {
            display: none !important;
        }

        /* 6. Arka Plan Renklerini Zorla (Tarayıcı ayarını ezmek için) */
        .badge {
            border: 1px solid #000;
            color: #000 !important;
            background-color: #fff !important;
        }
        
        /* 7. İmza Alanını Göster */
        .d-print-block {
            display: block !important;
        }

        /* Sayfa Kenar Boşluklarını Ayarla */
        @page {
            margin: 1cm;
            size: landscape; /* Tablo geniş olduğu için Yatay baskı önerilir */
        }
    }
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">
    
    {{-- ÜST BAŞLIK VE AKSİYONLAR --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800 mb-0">
                <i class="fas fa-calendar-alt me-2 text-primary"></i>{{ $plan->name }}
            </h4>
            <div class="text-muted small mt-1">
                <span class="badge bg-secondary">{{ $plan->year }}</span> 
                <span class="mx-1">•</span>
                Toplam {{ $plan->audits->count() }} Denetim Planlandı
            </div>
        </div>
        <div class="d-flex gap-2">
            <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addAuditModal">
                <i class="fas fa-plus-circle me-1"></i> Denetim Ekle
            </button>
            <button onclick="window.print()" class="btn btn-outline-dark shadow-sm">
                <i class="fas fa-print me-1"></i> Yazdır
            </button>
            <a href="{{ route('admin.qms.audits.plans.index') }}" class="btn btn-secondary shadow-sm">Geri</a>
        </div>
    </div>

    {{-- DENETİM PLANI TABLOSU (GÖRSELDEKİ FORMAT) --}}
    <div class="card shadow-sm border-0" id="printableArea">
        <div class="card-header bg-white py-3 border-bottom">
            <h6 class="m-0 fw-bold text-dark"><i class="fas fa-table me-2"></i>Denetim Planı Çizelgesi</h6>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered audit-plan-table mb-0">
                    <thead>
                        <tr>
                            <th style="width: 50px;" class="text-center">Sıra</th>
                            <th>Denetlenecek Süreç / Birim</th> {{-- Title --}}
                            <th>Kapsam (Standart Maddesi)</th>  {{-- Scope --}}
                            <th style="width: 120px;">Denetim Tarihi</th>
                            <th>Denetçi</th>
                            <th>Denetlenen</th>                 {{-- Dept/Supplier --}}
                            <th class="text-center" style="width: 100px;">Durum</th>
                            <th class="text-end" style="width: 120px;">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($plan->audits as $index => $audit)
                        <tr>
                            {{-- 1. SIRA --}}
                            <td class="text-center fw-bold text-muted">{{ $loop->iteration }}</td>

                            {{-- 2. SÜREÇ / BAŞLIK --}}
                            <td>
                                <div class="fw-bold text-dark">{{ $audit->title }}</div>
                                <div class="x-small text-muted font-monospace">{{ $audit->code }}</div>
                            </td>

                            {{-- 3. KAPSAM (ISO MADDESİ) --}}
                            <td>
                                @if($audit->scope)
                                    <span class="text-dark">{{ Str::limit($audit->scope, 50) }}</span>
                                @else
                                    <span class="text-muted fst-italic small">- Belirtilmedi -</span>
                                @endif
                            </td>

                            {{-- 4. TARİH --}}
                            <td>
                                <div class="fw-bold">{{ $audit->planned_date->format('d.m.Y') }}</div>
                                <small class="text-muted">{{ $audit->planned_date->locale('tr')->dayName }}</small>
                            </td>

                            {{-- 5. DENETÇİ --}}
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-xs bg-primary text-white rounded-circle me-2 d-flex justify-content-center align-items-center" style="width:24px; height:24px; font-size:10px;">
                                        {{ substr($audit->leadAuditor->name, 0, 1) }}
                                    </div>
                                    <span>{{ $audit->leadAuditor->name }}</span>
                                </div>
                            </td>

                            {{-- 6. DENETLENEN (BİRİM/FİRMA) --}}
                            <td>
                                @if($audit->department) 
                                    <span class="badge bg-light text-dark border"><i class="fas fa-building me-1"></i> {{ $audit->department->name }}</span>
                                @elseif($audit->supplier) 
                                    <span class="badge bg-light text-dark border"><i class="fas fa-truck me-1"></i> {{ $audit->supplier->name }}</span>
                                @else
                                    <span class="text-muted">-</span>
                                @endif
                            </td>

                            {{-- 7. DURUM --}}
                            <td class="text-center">
                                @if($audit->status == 'Planned') <span class="badge bg-secondary">Planlandı</span>
                                @elseif($audit->status == 'In_Progress') <span class="badge bg-warning text-dark">Sürüyor</span>
                                @elseif($audit->status == 'Completed') <span class="badge bg-success">Tamamlandı</span>
                                @else <span class="badge bg-danger">İptal</span> @endif
                            </td>

                            {{-- 8. İŞLEM --}}
                            <td class="text-end">
                                @if($audit->status != 'Completed')
                                    <a href="{{ route('admin.qms.audits.perform', $audit->id) }}" class="btn btn-sm btn-primary fw-bold" title="Denetimi Başlat">
                                        <i class="fas fa-play"></i>
                                    </a>
                                    <a href="{{ route('admin.qms.audits.edit', $audit->id) }}" class="btn btn-sm btn-outline-secondary" title="Düzenle">
                                        <i class="fas fa-pencil-alt"></i>
                                    </a>
                                @else
                                    <a href="{{ route('admin.qms.audits.report', $audit->id) }}" class="btn btn-sm btn-dark" target="_blank" title="Raporu Gör">
                                        <i class="fas fa-file-pdf"></i>
                                    </a>
                                @endif
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted bg-light">
                                <i class="fas fa-calendar-times fa-3x mb-3 opacity-25"></i><br>
                                Bu plana henüz denetim eklenmemiş. "Denetim Ekle" butonu ile başlayın.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        
        {{-- ONAY ALANI (Yazdırma sırasında görünür olması için) --}}
        <div class="card-footer bg-white border-top py-4 d-none d-print-block">
            <div class="row text-center mt-3">
                <div class="col-4">
                    <p class="fw-bold mb-4">Hazırlayan</p>
                    <div style="border-bottom: 1px solid #000; width: 80%; margin: 0 auto;"></div>
                </div>
                <div class="col-4">
                    <p class="fw-bold mb-4">Kontrol Eden</p>
                    <div style="border-bottom: 1px solid #000; width: 80%; margin: 0 auto;"></div>
                </div>
                <div class="col-4">
                    <p class="fw-bold mb-4">Onaylayan</p>
                    <div style="border-bottom: 1px solid #000; width: 80%; margin: 0 auto;"></div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- DENETİM EKLEME MODALI --}}
<div class="modal fade" id="addAuditModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.qms.audits.store') }}" method="POST">
            @csrf
            <input type="hidden" name="audit_plan_id" value="{{ $plan->id }}">
            
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h6 class="modal-title fw-bold"><i class="fas fa-plus-circle me-2"></i>Plana Yeni Denetim Ekle</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        {{-- BAŞLIK VE TÜR --}}
                        <div class="col-md-8">
                            <label class="fw-bold small">Denetlenecek Süreç / Başlık <span class="text-danger">*</span></label>
                            <input type="text" name="title" class="form-control" placeholder="Örn: İnsan Kaynakları Süreci" required>
                        </div>
                        <div class="col-md-4">
                            <label class="fw-bold small">Denetim Tipi <span class="text-danger">*</span></label>
                            <select name="type" class="form-select" id="auditTypeSelect" required onchange="toggleAuditeeType()">
                                <option value="Internal">İç Denetim</option>
                                <option value="Supplier">Tedarikçi Denetimi</option>
                                <option value="External">Dış Denetim</option>
                            </select>
                        </div>

                        {{-- TARİH --}}
                        <div class="col-md-6">
                            <label class="fw-bold small">Planlanan Tarih <span class="text-danger">*</span></label>
                            <input type="date" name="planned_date" class="form-control" required>
                        </div>

                        {{-- DENETLENEN (DİNAMİK) --}}
                        <div class="col-md-6" id="departmentDiv">
                            <label class="fw-bold small">Denetlenen Birim</label>
                            <select name="department_id" class="form-select select2" style="width:100%">
                                <option value="">-- Genel / Tüm Birimler --</option>
                                @foreach($departments as $dept)
                                    <option value="{{ $dept->id }}">{{ $dept->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        
                        {{-- TEDARİKÇİ (Başlangıçta Gizli) --}}
                        <div class="col-md-6" id="supplierDiv" style="display:none;">
                            <label class="fw-bold small">Denetlenen Tedarikçi</label>
                            <select name="supplier_id" class="form-select select2" style="width:100%">
                                <option value="">-- Seçiniz --</option>
                                {{-- Tedarikçiler buraya gelecek (Controller'dan gönderilmeli) --}}
                                {{-- Şimdilik boş bırakıyorum veya $suppliers varsa ekleyebilirsin --}}
                            </select>
                        </div>

                        {{-- KAPSAM (ISO MADDESİ) --}}
                        <div class="col-12">
                            <label class="fw-bold small text-primary">Kapsam / İlgili Standart Maddesi <span class="text-danger">*</span></label>
                            <input type="text" name="scope" class="form-control" placeholder="Örn: ISO 9001:2015 Madde 7.2 ve 7.3" required>
                            <div class="form-text x-small text-muted">Denetimin hangi standart maddelerini kapsadığını belirtin.</div>
                        </div>

                        {{-- SORUMLULAR --}}
                        <div class="col-md-6">
                            <label class="fw-bold small">Denetçi (Baş Denetçi) <span class="text-danger">*</span></label>
                            <select name="lead_auditor_id" class="form-select select2" required style="width:100%">
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="fw-bold small">Ek Denetçiler / Gözlemciler</label>
                            <select name="auditors[]" class="form-select select2" multiple style="width:100%">
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        {{-- SORU LİSTESİ --}}
                        <div class="col-12">
                            <label class="fw-bold small">Kullanılacak Soru Listeleri</label>
                            <div class="card p-2 bg-light border" style="max-height: 100px; overflow-y: auto;">
                                @foreach($checklists as $list)
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="checklist_ids[]" value="{{ $list->id }}" id="chk_{{ $list->id }}">
                                        <label class="form-check-label small" for="chk_{{ $list->id }}">
                                            {{ $list->name }}
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-success fw-bold">TABLOYA EKLE</button>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection

@push('scripts')
<script>
    function toggleAuditeeType() {
        var type = document.getElementById('auditTypeSelect').value;
        if(type === 'Supplier') {
            document.getElementById('departmentDiv').style.display = 'none';
            document.getElementById('supplierDiv').style.display = 'block';
        } else {
            document.getElementById('departmentDiv').style.display = 'block';
            document.getElementById('supplierDiv').style.display = 'none';
        }
    }
</script>
@endpush