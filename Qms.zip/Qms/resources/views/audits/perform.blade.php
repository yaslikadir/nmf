@extends('layouts.admin')

@section('title', 'Denetim Yürütme')

@push('css')
<style>
    .question-row { transition: all 0.3s; }
    .question-row:hover { background-color: #f8f9fa; }
    .status-btn { width: 100px; }
    
    /* Seçili Durumlar İçin Renklendirme */
    .row-success { border-left: 5px solid #198754; background-color: #f1fef5 !important; }
    .row-danger { border-left: 5px solid #dc3545; background-color: #fff5f5 !important; }
    .row-warning { border-left: 5px solid #ffc107; background-color: #fffdf5 !important; }
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">

    {{-- ÜST BİLGİ KARTI --}}
    <div class="card shadow-sm mb-4 border-top-lg border-primary">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h4 class="fw-bold text-primary mb-1">{{ $audit->title }}</h4>
                    <div class="text-muted small mb-2">
                        <span class="badge bg-secondary">{{ $audit->code }}</span>
                        <span class="mx-1">|</span>
                        <i class="far fa-calendar me-1"></i> Planlanan: {{ $audit->planned_date->format('d.m.Y') }}
                    </div>
                    <div class="small">
                        <strong>Baş Denetçi:</strong> {{ $audit->leadAuditor->name }} <br>
                        <strong>Denetlenen:</strong> 
                        @if($audit->department) {{ $audit->department->name }} (Departman)
                        @elseif($audit->supplier) {{ $audit->supplier->name }} (Tedarikçi)
                        @else Genel @endif
                    </div>
                </div>
                <div>
                    <button type="button" class="btn btn-success fw-bold shadow-sm" data-bs-toggle="modal" data-bs-target="#completeAuditModal">
                        <i class="fas fa-check-circle me-2"></i> DENETİMİ TAMAMLA
                    </button>
                </div>
            </div>
            
            @if($audit->scope)
                <div class="alert alert-light border mt-3 mb-0 small">
                    <strong><i class="fas fa-bullseye me-1"></i> Kapsam:</strong> {{ $audit->scope }}
                </div>
            @endif
        </div>
    </div>

    {{-- SORU LİSTELERİ VE SORULAR --}}
    <div class="row">
        <div class="col-12">
            @foreach($audit->checklists as $checklist)
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold text-uppercase d-flex justify-content-between">
                        <span><i class="fas fa-list-ol me-2"></i> {{ $checklist->name }}</span>
                        <span class="badge bg-white text-dark border">{{ $checklist->questions->count() }} Soru</span>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table align-middle mb-0">
                                <thead class="bg-white text-muted small text-uppercase">
                                    <tr>
                                        <th style="width: 5%">#</th>
                                        <th style="width: 50%">Soru / Kriter</th>
                                        <th style="width: 15%">Referans</th>
                                        <th style="width: 30%" class="text-center">Değerlendirme</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($checklist->questions as $index => $question)
                                        {{-- Daha önce cevaplanmış mı kontrol et --}}
                                        @php
                                            $existingFinding = $audit->findings->where('question_id', $question->id)->first();
                                            $rowClass = '';
                                            if($existingFinding) {
                                                if($existingFinding->type == 'Conformity') $rowClass = 'row-success';
                                                elseif($existingFinding->type == 'NonConformity') $rowClass = 'row-danger';
                                                else $rowClass = 'row-warning';
                                            }
                                        @endphp

                                        <tr class="question-row {{ $rowClass }}" id="row-{{ $question->id }}">
                                            <td class="text-center fw-bold text-muted">{{ $loop->iteration }}</td>
                                            <td>
                                                <div class="fw-bold">{{ $question->question }}</div>
                                                @if($existingFinding)
                                                    <div class="small text-muted mt-1 fst-italic">
                                                        <i class="fas fa-comment-alt me-1"></i> 
                                                        Not: {{ Str::limit($existingFinding->finding_details, 50) }}
                                                    </div>
                                                @endif
                                            </td>
                                            <td class="small text-muted">{{ $question->reference_standard ?? '-' }}</td>
                                            <td class="text-center">
                                                <div class="btn-group" role="group">
                                                    {{-- UYGUN BUTONU --}}
                                                    <button type="button" 
                                                            class="btn btn-sm {{ $existingFinding && $existingFinding->type == 'Conformity' ? 'btn-success' : 'btn-outline-success' }} status-btn"
                                                            onclick="openFindingModal({{ $question->id }}, 'Conformity')">
                                                        <i class="fas fa-check"></i> Uygun
                                                    </button>

                                                    {{-- UYGUNSUZLUK BUTONU --}}
                                                    <button type="button" 
                                                            class="btn btn-sm {{ $existingFinding && $existingFinding->type == 'NonConformity' ? 'btn-danger' : 'btn-outline-danger' }} status-btn"
                                                            onclick="openFindingModal({{ $question->id }}, 'NonConformity')">
                                                        <i class="fas fa-times"></i> Hata
                                                    </button>

                                                    {{-- DİĞER (Gözlem/Fırsat) --}}
                                                    <button type="button" 
                                                            class="btn btn-sm {{ $existingFinding && in_array($existingFinding->type, ['Observation', 'Opportunity']) ? 'btn-warning' : 'btn-outline-warning' }} status-btn"
                                                            onclick="openFindingModal({{ $question->id }}, 'Observation')">
                                                        <i class="fas fa-eye"></i> Diğer
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>

{{-- MODAL: BULGU GİRİŞİ --}}
<div class="modal fade" id="findingModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="findingForm" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="question_id" id="modalQuestionId">
            
            <div class="modal-content">
                <div class="modal-header" id="modalHeader">
                    <h5 class="modal-title fw-bold text-white" id="modalTitle">Bulgu Detayı</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    
                    {{-- Tip Seçimi (Hidden olarak tutulacak, JS ile doldurulacak) --}}
                    <input type="hidden" name="type" id="modalType">

                    {{-- 1. UYGUNSUZLUK DERECESİ (Sadece Hata ise görünür) --}}
                    <div class="mb-3" id="severityDiv" style="display:none;">
                        <label class="fw-bold small">Uygunsuzluk Derecesi <span class="text-danger">*</span></label>
                        <select name="severity" class="form-select">
                            <option value="Minor">Minör (Hafif)</option>
                            <option value="Major">Majör (Büyük)</option>
                            <option value="Critical">Kritik (Acil)</option>
                        </select>
                    </div>

                    {{-- 2. DETAY / NOT --}}
                    <div class="mb-3">
                        <label class="fw-bold small">Açıklama / Detay <span class="text-danger">*</span></label>
                        <textarea name="finding_details" class="form-control" rows="3" required placeholder="Gözleminizi veya bulguyu buraya yazınız..."></textarea>
                    </div>

                    {{-- 3. KANIT (TEXT) --}}
                    <div class="mb-3">
                        <label class="fw-bold small">Kanıt (Referans Belge/Gözlem)</label>
                        <input type="text" name="evidence" class="form-control" placeholder="Örn: PR-05 prosedürü, Fatma H. beyanı...">
                    </div>

                    {{-- 4. FOTOĞRAF / DOSYA YÜKLEME --}}
                    <div class="mb-3">
                        <label class="fw-bold small">Fotoğraf / Dosya Ekle (Opsiyonel)</label>
                        <input type="file" name="attachment" class="form-control">
                    </div>

                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary fw-bold" id="btnSaveFinding">KAYDET</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- MODAL: DENETİMİ TAMAMLA --}}
<div class="modal fade" id="completeAuditModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('admin.qms.audits.complete', $audit->id) }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title fw-bold"><i class="fas fa-check-double me-2"></i>Denetimi Tamamla</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Denetim sürecini sonlandırmak üzeresiniz. Bu işlemden sonra yeni bulgu eklenemez.</p>
                    <div class="mb-3">
                        <label class="fw-bold small">Yönetici Özeti / Genel Değerlendirme</label>
                        <textarea name="summary" class="form-control" rows="4" placeholder="Denetim genelinde gözlemlenen durumlar..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Vazgeç</button>
                    <button type="submit" class="btn btn-success fw-bold">ONAYLA VE RAPORLA</button>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection

@push('scripts')
<script>
    // 1. MODAL AÇMA FONKSİYONU
    function openFindingModal(questionId, type) {
        // Formu temizle
        document.getElementById('findingForm').reset();
        
        // ID ve Tipi Set Et
        document.getElementById('modalQuestionId').value = questionId;
        document.getElementById('modalType').value = type;

        // Modalin Rengini ve Başlığını Ayarla
        const header = document.getElementById('modalHeader');
        const title = document.getElementById('modalTitle');
        const severityDiv = document.getElementById('severityDiv');

        if(type === 'Conformity') {
            header.className = 'modal-header bg-success';
            title.innerText = 'Uygunluk Kaydı';
            severityDiv.style.display = 'none';
        } else if(type === 'NonConformity') {
            header.className = 'modal-header bg-danger';
            title.innerText = 'Uygunsuzluk (Hata) Kaydı';
            severityDiv.style.display = 'block'; // Derece seçimi aktif
        } else {
            header.className = 'modal-header bg-warning text-dark';
            title.innerText = 'Gözlem / Fırsat Kaydı';
            severityDiv.style.display = 'none';
        }

        // Modalı Göster
        new bootstrap.Modal(document.getElementById('findingModal')).show();
    }

    // 2. AJAX İLE KAYDETME
    $('#findingForm').on('submit', function(e) {
        e.preventDefault();
        
        let formData = new FormData(this);
        let btn = $('#btnSaveFinding');
        let originalText = btn.text();
        
        btn.prop('disabled', true).text('Kaydediliyor...');

        $.ajax({
            url: "{{ route('admin.qms.audits.findings.store', $audit->id) }}",
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                // Modalı Kapat
                bootstrap.Modal.getInstance(document.getElementById('findingModal')).hide();
                
                // Satırı Güncelle (Görsel Geri Bildirim)
                let qId = formData.get('question_id');
                let type = formData.get('type');
                let row = $('#row-' + qId);

                // Önceki sınıfları temizle
                row.removeClass('row-success row-danger row-warning');

                // Yeni sınıfı ekle ve butonları güncelle
                if(type === 'Conformity') {
                    row.addClass('row-success');
                    // Buton stillerini güncelleme (basitçe sayfayı yenilemeden class değiştirilebilir ama şimdilik renk yeterli)
                } else if(type === 'NonConformity') {
                    row.addClass('row-danger');
                } else {
                    row.addClass('row-warning');
                }

                // SweetAlert ile başarı mesajı
                Swal.fire({
                    icon: 'success',
                    title: 'Kaydedildi',
                    text: 'Bulgu sisteme işlendi.',
                    timer: 1500,
                    showConfirmButton: false
                });

                btn.prop('disabled', false).text(originalText);
            },
            error: function(xhr) {
                alert('Hata oluştu: ' + xhr.responseText);
                btn.prop('disabled', false).text(originalText);
            }
        });
    });
</script>
@endpush