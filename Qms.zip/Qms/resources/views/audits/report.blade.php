<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <title>Denetim Raporu - {{ $audit->code }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    {{-- Font Awesome (İkonlar için) --}}
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 13px; color: #333; }
        .report-header { border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
        .table-bordered th, .table-bordered td { border-color: #dee2e6; padding: 8px; vertical-align: middle; }
        .section-title { background-color: #f8f9fa; padding: 8px; font-weight: bold; border: 1px solid #dee2e6; margin-top: 20px; }
        
        /* Yazdırma Ayarları */
        @media print {
            .no-print { display: none !important; }
            body { font-size: 11px; }
            .section-title { background-color: #eee !important; -webkit-print-color-adjust: exact; }
            .table-danger { background-color: #ffeaea !important; -webkit-print-color-adjust: exact; }
            .table-success { background-color: #eaffea !important; -webkit-print-color-adjust: exact; }
            a { text-decoration: none; color: #000; }
        }
    </style>
</head>
<body class="p-4">

    {{-- YAZDIR BUTONU --}}
    <div class="no-print mb-4 text-end">
        <button onclick="window.print()" class="btn btn-primary fw-bold">
            <i class="fas fa-print me-1"></i> YAZDIR / PDF KAYDET
        </button>
        <a href="{{ route('admin.qms.audits.index') }}" class="btn btn-secondary">Kapat</a>
    </div>

    {{-- RAPOR BAŞLIĞI --}}
    <div class="report-header d-flex justify-content-between align-items-center">
        <div style="font-size: 24px; font-weight: bold; color: #0d6efd;">
    {{ \App\Models\Setting::get('company_name', config('app.name')) }}
</div>
        <div class="text-end">
            <h3 class="mb-0">DENETİM RAPORU</h3>
            <small class="text-muted">Rapor No: {{ $audit->code }}</small>
        </div>
    </div>

    {{-- 1. DENETİM BİLGİLERİ --}}
    <div class="section-title">1. DENETİM BİLGİLERİ</div>
    <table class="table table-bordered mb-0">
        <tr>
            <th width="20%">Denetim Konusu</th>
            <td width="30%">{{ $audit->title }}</td>
            <th width="20%">Tarih</th>
            <td width="30%">{{ $audit->performed_date ? $audit->performed_date->format('d.m.Y') : '-' }}</td>
        </tr>
        <tr>
            <th>Denetim Tipi</th>
            <td>{{ $audit->type }}</td>
            <th>Denetlenen Birim</th>
            <td>{{ $audit->department->name ?? ($audit->supplier->name ?? '-') }}</td>
        </tr>
        <tr>
            <th>Baş Denetçi</th>
            <td>{{ $audit->leadAuditor->name }}</td>
            <th>Kapsam</th>
            <td>{{ $audit->scope ?? 'Belirtilmedi' }}</td>
        </tr>
    </table>

    {{-- 2. DENETİM ÖZETİ --}}
    <div class="section-title">2. YÖNETİCİ ÖZETİ</div>
    <div class="border p-3 mb-3 bg-light">
        {!! nl2br(e($audit->summary ?? 'Özet bilgi girilmemiş.')) !!}
    </div>

    {{-- 3. BULGULAR VE UYGUNSUZLUKLAR --}}
    <div class="section-title">3. BULGULAR VE UYGUNSUZLUKLAR</div>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th width="5%">#</th>
                <th width="35%">İlgili Soru / Kriter</th>
                <th width="10%" class="text-center">Tip</th>
                <th width="40%">Bulgu Detayı</th>
                <th width="10%">Derece</th>
            </tr>
        </thead>
        <tbody>
            @php $count = 0; @endphp
            @foreach($audit->findings as $finding)
                {{-- Sadece uygunsuzlukları ve gözlemleri göster (Uygunları raporda kalabalık etmesin) --}}
                @if($finding->type != 'Conformity')
                    @php $count++; @endphp
                    <tr>
                        <td class="text-center">{{ $count }}</td>
                        <td>{{ $finding->question->question ?? 'Genel Bulgu' }}</td>
                        <td class="text-center">
                            @if($finding->type == 'NonConformity') 
                                <span class="fw-bold text-danger">UYGUNSUZLUK</span>
                            @else 
                                <span class="fw-bold text-warning">GÖZLEM</span>
                            @endif
                        </td>
                        <td>
                            {{ $finding->finding_details }}
                            @if($finding->evidence)
                                <br><small class="text-muted">Kanıt: {{ $finding->evidence }}</small>
                            @endif

                            {{-- [YENİ] DÖF BAŞLATMA ALANI --}}
                            @if($finding->type == 'NonConformity')
                                <div class="mt-2 no-print">
                                    @php
                                        // Bu bulguya ait CAPA var mı kontrol et
                                        $existingCapa = \Modules\Qms\Models\QmsCapa::where('audit_finding_id', $finding->id)->first();
                                    @endphp

                                    @if($existingCapa)
                                        <a href="{{ route('admin.qms.capas.show', $existingCapa->id) }}" class="btn btn-sm btn-outline-success text-decoration-none" target="_blank">
                                            <i class="fas fa-link me-1"></i> DÖF: {{ $existingCapa->code }}
                                        </a>
                                    @else
                                        <a href="{{ route('admin.qms.capas.create', ['finding_id' => $finding->id]) }}" class="btn btn-sm btn-danger text-decoration-none" target="_blank">
                                            <i class="fas fa-tools me-1"></i> DÖF Başlat
                                        </a>
                                    @endif
                                </div>
                            @endif
                            {{-- [BİTİŞ] DÖF ALANI --}}

                        </td>
                        <td class="text-center">{{ $finding->severity ?? '-' }}</td>
                    </tr>
                @endif
            @endforeach

            @if($count == 0)
                <tr>
                    <td colspan="5" class="text-center py-3 text-success fw-bold">
                        Bu denetimde herhangi bir uygunsuzluk tespit edilmemiştir.
                    </td>
                </tr>
            @endif
        </tbody>
    </table>

    {{-- 4. ONAY VE İMZA --}}
    <div class="row mt-5">
        <div class="col-6 text-center">
            <p class="fw-bold">Baş Denetçi</p>
            <p>{{ $audit->leadAuditor->name }}</p>
            <div style="height: 60px; border-bottom: 1px dashed #ccc;"></div>
            <small>İmza</small>
        </div>
        <div class="col-6 text-center">
            <p class="fw-bold">Birim Yöneticisi / Temsilci</p>
            <p>.......................................</p>
            <div style="height: 60px; border-bottom: 1px dashed #ccc;"></div>
            <small>İmza</small>
        </div>
    </div>

    <div class="text-center mt-5 text-muted x-small">
        Bu rapor {{ \App\Models\Setting::get('company_name', config('app.name')) }} sistemi tarafından {{ now()->format('d.m.Y H:i') }} tarihinde oluşturulmuştur.
    </div>

</body>
</html>