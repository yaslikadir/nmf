<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Memnuniyet Formu - {{ $feedback->tracking_code }}</title>
    <style>
        @page { size: A4; margin: 10mm; }
        body { font-family: 'Times New Roman', serif; font-size: 10pt; line-height: 1.2; color: #000; }
        
        table { width: 100%; border-collapse: collapse; margin-bottom: 5px; }
        th, td { border: 1px solid #000; padding: 4px 6px; vertical-align: middle; }
        
        .header-logo { width: 150px; text-align: center; }
        .header-title { text-align: center; font-weight: bold; font-size: 14pt; background: #fff; }
        .bg-gray { background-color: #e0e0e0; font-weight: bold; }
        
        .center { text-align: center; }
        .bold { font-weight: bold; }
        
        .check-box { display: inline-block; width: 12px; height: 12px; border: 1px solid #000; margin-right: 3px; vertical-align: middle; }
        .checked { background-color: #000; } 
        
        /* Puanlama Tablosu İçin */
        .rating-cell { text-align: center; font-weight: bold; width: 40px; }

        @media print { .no-print { display: none; } }
        .print-btn { 
            position: fixed; top: 20px; right: 20px; 
            background: #28a745; color: white; padding: 10px 20px; 
            text-decoration: none; font-family: sans-serif; border-radius: 5px; cursor: pointer;
        }
    </style>
</head>
<body onload="window.print()">

    <a href="javascript:window.print()" class="no-print print-btn">YAZDIR / PDF KAYDET</a>

    {{-- 1. BAŞLIK BÖLÜMÜ --}}
    <table>
        <tr>
            <td class="header-logo" rowspan="3">
                {{-- LOGO ALANI --}}
                <div style="font-size:20px; font-weight:bold; padding:15px;">LOGO</div>
            </td>
            <td class="header-title" rowspan="3">
                MÜŞTERİ MEMNUNİYETİ<br>VE<br>ÖNERİ FORMU
            </td>
            <td width="15%" class="bold">Doküman No</td>
            <td width="15%">FR-08-02</td>
        </tr>
        <tr>
            <td class="bold">Yayın Tarihi</td>
            <td>31.01.2019</td>
        </tr>
        <tr>
            <td class="bold">Rev. No/Tarih</td>
            <td>00 / --</td>
        </tr>
    </table>

    <div style="margin-bottom: 10px; font-size: 9pt; text-align: justify;">
        <strong>Sayın Yetkili;</strong><br>
        Kaliteli hizmet sunmayı hedefleyen kuruluşumuzun bundan sonraki çalışmalarında yol gösterici olması açısından, geçmişte yaptığımız çalışmaları sizin gözünüzle değerlendirmek ve kalite politikamız olan sürekli gelişme amacıyla görüşlerinize ihtiyacımız vardır. Bu anketi doldurarak görüşlerinizi bizimle paylaşmanızı rica ederiz.<br>
        <strong>İlginize teşekkür ederiz.</strong>
    </div>

    {{-- 2. FİRMA BİLGİLERİ --}}
    <table>
        <tr>
            <td width="20%" class="bg-gray">Firma Adı / İli</td>
            <td colspan="3">{{ $feedback->data['company_city'] ?? $feedback->guest_name }}</td>
        </tr>
        <tr>
            <td class="bg-gray">Formu Dolduran</td>
            <td colspan="3">{{ $feedback->data['fullname'] ?? $feedback->guest_name }}</td>
        </tr>
        <tr>
            <td class="bg-gray">E-Mail / Telefon</td>
            <td>{{ $feedback->data['email'] ?? $feedback->guest_email }} / {{ $feedback->data['phone'] ?? $feedback->guest_phone }}</td>
            <td width="20%" class="bg-gray">Form Tarihi</td>
            <td width="20%">{{ $feedback->created_at->format('d.m.Y') }}</td>
        </tr>
    </table>

    {{-- 3. HİZMET DETAYLARI --}}
    @php
        $services = $feedback->data['service_scope'] ?? [];
        if(is_string($services)) $services = [$services]; 
        
        $source = $feedback->data['hear_source'] ?? '';
        // Recommendation aşağıda özel olarak işlenecek
        $recRaw = $feedback->data['recommendation'] ?? '';
    @endphp

    <table>
        <tr class="bg-gray center">
            <td width="33%">Alınan Hizmet Kapsamı</td>
            <td width="33%">Gelecekte bizimle çalışmak ister misiniz?</td>
            <td width="33%">Bizden nasıl haberdar oldunuz?</td>
        </tr>
        <tr style="vertical-align: top;">
            <td>
                <span class="check-box {{ in_array('Analiz Hizmeti', $services) ? 'checked' : '' }}"></span> Analiz Hizmeti<br>
                <span class="check-box {{ in_array('Numune Alma', $services) ? 'checked' : '' }}"></span> Numune Alma<br>
                <span class="check-box {{ in_array('Danışmanlık', $services) ? 'checked' : '' }}"></span> Danışmanlık<br>
                <span class="check-box {{ in_array('Diğer', $services) ? 'checked' : '' }}"></span> Diğer
            </td>
            <td>
                {{-- Tavsiye Checkbox Kontrolü (Raw veri string ise çalışır) --}}
                @php 
                    // Eğer array gelirse ilk elemanı alalım ki checkbox mantığı bozulmasın
                    $recCheck = is_array($recRaw) ? ($recRaw[0] ?? '') : $recRaw;
                @endphp
                <span class="check-box {{ ($recCheck == 'Evet' || $recCheck == 'Kesinlikle') ? 'checked' : '' }}"></span> Evet<br>
                <span class="check-box {{ ($recCheck == 'Hayır') ? 'checked' : '' }}"></span> Hayır<br>
                <span class="check-box {{ ($recCheck == 'Kısmen') ? 'checked' : '' }}"></span> Kararsızım
            </td>
            <td>
                <span class="check-box {{ $source == 'Web Sitemiz' ? 'checked' : '' }}"></span> Web Sitemiz<br>
                <span class="check-box {{ $source == 'Referans' ? 'checked' : '' }}"></span> Referans<br>
                <span class="check-box {{ $source == 'Ziyaret' ? 'checked' : '' }}"></span> Ziyaret<br>
                <span class="check-box {{ $source == 'Diğer' ? 'checked' : '' }}"></span> Diğer
            </td>
        </tr>
    </table>

    {{-- 4. PUANLAMA TABLOSU --}}
    <table>
        <tr class="bg-gray center">
            <td style="text-align: left;">DEĞERLENDİRME KRİTERLERİ</td>
            <td class="rating-cell">1</td>
            <td class="rating-cell">2</td>
            <td class="rating-cell">3</td>
            <td class="rating-cell">4</td>
            <td class="rating-cell">5</td>
        </tr>

        @php
            $questions = [
                'q1_staff_politeness' => 'Personelin nezaketi ve ilgisi',
                'q2_sample_staff' => 'Numune kabul personelinin yeterliliği',
                'q3_reliability' => 'Analiz sonuçlarının güvenilirliği',
                'q4_timing' => 'Raporların zamanında teslim edilmesi',
                'q5_report_format' => 'Rapor formatının anlaşılırlığı',
                'q6_feedback_speed' => 'Talep ve sorulara dönüş hızı',
            ];
        @endphp

        @foreach($questions as $key => $label)
            @php 
                $score = $feedback->data[$key] ?? 0;
                // Eğer puan yanlışlıkla array gelirse ilkini al
                if(is_array($score)) $score = $score[0] ?? 0;
            @endphp
            <tr>
                <td>{{ $label }}</td>
                <td class="rating-cell center">{{ $score == 1 ? 'X' : '' }}</td>
                <td class="rating-cell center">{{ $score == 2 ? 'X' : '' }}</td>
                <td class="rating-cell center">{{ $score == 3 ? 'X' : '' }}</td>
                <td class="rating-cell center">{{ $score == 4 ? 'X' : '' }}</td>
                <td class="rating-cell center">{{ $score == 5 ? 'X' : '' }}</td>
            </tr>
        @endforeach
    </table>

    {{-- 5. GENEL GÖRÜŞLER (DÜZELTİLDİ) --}}
    <table>
        <tr class="bg-gray">
            <td>Genel olarak bizi tavsiye eder misiniz?</td>
            <td width="15%" class="center">
                {{-- DÜZELTME 1: RECOMMENDATION --}}
                @php
                    $recValue = $feedback->data['recommendation'] ?? '-';
                @endphp
                {{ is_array($recValue) ? implode(' / ', $recValue) : $recValue }}
            </td>
        </tr>
        <tr>
            <td colspan="2" class="bg-gray">Öncelikle iyileştirmemizi istediğiniz konu veya konuları bildiriniz:</td>
        </tr>
        <tr>
            <td colspan="2" style="height: 60px; vertical-align: top;">
                {{-- DÜZELTME 2: SUGGESTIONS --}}
                @php
                    $suggestions = $feedback->data['suggestions'] ?? null;
                @endphp
                @if(is_array($suggestions))
                    {{ implode(' / ', $suggestions) }}
                @elseif(!empty($suggestions))
                    {{ $suggestions }}
                @else
                    Belirtilmemiş.
                @endif
            </td>
        </tr>
        <tr>
            <td colspan="2" class="bg-gray">Kuruluşumuzun güçlü olduğunu düşündüğünüz konu veya konuları bildiriniz:</td>
        </tr>
        <tr>
            <td colspan="2" style="height: 60px; vertical-align: top;">
                {{-- DÜZELTME 3: STRONG POINTS --}}
                @php
                    $strongPoints = $feedback->data['strong_points'] ?? null;
                @endphp
                @if(is_array($strongPoints))
                    {{ implode(' / ', $strongPoints) }}
                @elseif(!empty($strongPoints))
                    {{ $strongPoints }}
                @else
                    Belirtilmemiş.
                @endif
            </td>
        </tr>
    </table>

    {{-- 6. ONAY KISMI --}}
    <table>
        <tr class="bg-gray">
            <td width="33%">Hazırlayan</td>
            <td width="33%">Gözden Geçiren</td>
            <td width="33%">Onaylayan</td>
        </tr>
        <tr class="center">
            <td style="height: 50px;">
                Kalite Yönetim Temsilcisi<br>
                <strong>Gözde Kaplan</strong>
            </td>
            <td>
                Kalite Yönetim Temsilcisi<br>
                <strong>Gözde Kaplan</strong>
            </td>
            <td>
                Lab. Müdürü<br>
                <strong>Engin Katırağ</strong>
            </td>
        </tr>
    </table>
    
    <div style="font-size: 8pt; text-align: right; margin-top: 5px;">
        Referans: {{ $feedback->tracking_code }} | {{ date('d.m.Y H:i') }}
    </div>

</body>
</html>