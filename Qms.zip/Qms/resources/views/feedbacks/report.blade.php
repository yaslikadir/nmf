@extends('layouts.admin')
@section('title', 'Memnuniyet Analizi')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800"><i class="fas fa-chart-pie me-2 text-success"></i>Müşteri Memnuniyet Analizi</h4>
        <a href="{{ route('admin.qms.feedbacks.index') }}" class="btn btn-secondary btn-sm">Geri Dön</a>
    </div>

    <div class="row">
        {{-- ÖZET KART --}}
        <div class="col-md-12 mb-4">
            <div class="card bg-gradient-success text-white shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small text-white-50">Toplam Anket Katılımı</div>
                            <div class="display-4 fw-bold">{{ $totalCount }}</div>
                        </div>
                        <i class="fas fa-poll fa-4x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>

        {{-- GRAFİK / PUANLAR --}}
        <div class="col-lg-8">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Kriter Bazlı Ortalama Puanlar (5 Üzerinden)</div>
                <div class="card-body">
                    @foreach($stats as $label => $score)
                    <div class="mb-4">
                        <div class="d-flex justify-content-between mb-1">
                            <span class="fw-bold text-dark">{{ $label }}</span>
                            <span class="fw-bold {{ $score >= 4 ? 'text-success' : ($score >= 3 ? 'text-warning' : 'text-danger') }}">
                                {{ $score }} / 5
                            </span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar {{ $score >= 4 ? 'bg-success' : ($score >= 3 ? 'bg-warning' : 'bg-danger') }}" 
                                 role="progressbar" style="width: {{ ($score/5)*100 }}%"></div>
                        </div>
                    </div>
                    @endforeach
                    
                    @if($totalCount == 0)
                        <div class="text-center text-muted py-5">Henüz veri yok.</div>
                    @endif
                </div>
            </div>
        </div>

        {{-- SON YORUMLAR --}}
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-bold">Son Müşteri Yorumları</div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        @foreach($surveys->take(5) as $survey)
                            @if(isset($survey->data['suggestions']) && !empty($survey->data['suggestions']))
                            <li class="list-group-item">
                                <p class="mb-1 small fst-italic text-muted">"{{ $survey->data['suggestions'] }}"</p>
                                <div class="d-flex justify-content-between">
                                    <small class="fw-bold text-dark">{{ $survey->guest_name ?? 'Anonim' }}</small>
                                    <small class="text-muted" style="font-size:10px">{{ $survey->created_at->diffForHumans() }}</small>
                                </div>
                            </li>
                            @endif
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection