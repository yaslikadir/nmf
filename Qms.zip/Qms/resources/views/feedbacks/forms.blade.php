@extends('layouts.admin')
@section('title', 'Form Linkleri')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800"><i class="fas fa-link me-2 text-primary"></i>Form Linkleri & Ayarlar</h4>
            <div class="text-muted small">Müşterilerinizle paylaşabileceğiniz form bağlantıları.</div>
        </div>
        <a href="{{ route('admin.qms.feedbacks.index') }}" class="btn btn-secondary btn-sm">Geri Dön</a>
    </div>

    <div class="row">
        @foreach($forms as $form)
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card h-100 shadow-sm border-0 border-top-lg {{ $form->type == 'Complaint' ? 'border-danger' : 'border-success' }}">
                <div class="card-body">
                    {{-- Başlık ve Durum --}}
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h5 class="fw-bold text-dark mb-1">{{ $form->title }}</h5>
                            <span class="badge {{ $form->type == 'Complaint' ? 'bg-danger' : 'bg-success' }} bg-opacity-10 text-dark">
                                {{ $form->type == 'Complaint' ? 'Şikayet Formu' : 'Anket Formu' }}
                            </span>
                        </div>
                        <div class="form-check form-switch">
                            {{-- Aktif/Pasif (Görseldir, işlevi için AJAX gerekir ama şimdilik dursun) --}}
                            <input class="form-check-input" type="checkbox" checked disabled>
                        </div>
                    </div>

                    <p class="text-muted small mb-4" style="min-height: 40px;">
                        {{ Str::limit($form->description, 80) }}
                    </p>

                    {{-- İstatistik --}}
                    <div class="d-flex align-items-center justify-content-between bg-light p-2 rounded mb-3">
                        <small class="fw-bold text-secondary">Toplam Başvuru:</small>
                        <span class="fw-bold text-primary">{{ $form->feedbacks_count }}</span>
                    </div>

                    {{-- Link Alanı --}}
                    <label class="small text-muted fw-bold mb-1">Paylaşım Linki</label>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control form-control-sm bg-white" 
                               id="link-{{ $form->id }}" 
                               value="{{ route('public.feedback.show', $form->slug) }}" readonly>
                        <button class="btn btn-outline-primary btn-sm" type="button" onclick="copyLink('link-{{ $form->id }}')">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>

                    <div class="d-grid gap-2">
                        <a href="{{ route('public.feedback.show', $form->slug) }}" target="_blank" class="btn btn-light btn-sm text-primary fw-bold">
                            <i class="fas fa-external-link-alt me-1"></i> Formu Görüntüle
                        </a>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>

{{-- Kopyalama Scripti --}}
<script>
    function copyLink(elementId) {
        var copyText = document.getElementById(elementId);
        copyText.select();
        copyText.setSelectionRange(0, 99999); // Mobil uyumluluk
        navigator.clipboard.writeText(copyText.value);
        
        // Basit bir uyarı (Toast mantığı eklenebilir)
        alert("Link kopyalandı: " + copyText.value);
    }
</script>
@endsection