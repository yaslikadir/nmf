@extends('layouts.admin')
@section('title', 'Geri Bildirim Havuzu')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800"><i class="fas fa-inbox me-2 text-primary"></i>Geri Bildirim Havuzu</h4>
            <div class="text-muted small">Müşteri şikayetleri ve memnuniyet anketleri.</div>
        </div>
    </div>

    {{-- FİLTRELER --}}
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body py-2">
            <form action="" method="GET" class="row g-2 align-items-center">
                <div class="col-md-3">
                    <select name="type" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="all">Tüm Form Tipleri</option>
                        <option value="Complaint" {{ request('type') == 'Complaint' ? 'selected' : '' }}>Şikayetler</option>
                        <option value="Satisfaction" {{ request('type') == 'Satisfaction' ? 'selected' : '' }}>Anketler</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="all">Tüm Durumlar</option>
                        <option value="Pending" {{ request('status') == 'Pending' ? 'selected' : '' }}>Bekleyenler</option>
                        <option value="Reviewing" {{ request('status') == 'Reviewing' ? 'selected' : '' }}>İncelenenler</option>
                        <option value="Resolved" {{ request('status') == 'Resolved' ? 'selected' : '' }}>Çözülenler</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    {{-- LİSTE --}}
    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-muted small">
                        <tr>
                            <th>Kod</th>
                            <th>Form Tipi</th>
                            <th>Gönderen</th>
                            <th>Öncelik</th>
                            <th>Durum</th>
                            <th>Atanan</th>
                            <th>Tarih</th>
                            <th class="text-end">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($feedbacks as $fb)
                        <tr>
                            <td>
                                <a href="{{ route('admin.qms.feedbacks.show', $fb->id) }}" class="fw-bold text-primary text-decoration-none">
                                    {{ $fb->tracking_code }}
                                </a>
                            </td>
                            <td>
                                @if($fb->form->type == 'Complaint')
                                    <span class="badge bg-danger bg-opacity-10 text-danger"><i class="fas fa-exclamation-circle me-1"></i>Şikayet</span>
                                @else
                                    <span class="badge bg-success bg-opacity-10 text-success"><i class="fas fa-smile me-1"></i>Anket</span>
                                @endif
                                <div class="small text-muted">{{ Str::limit($fb->form->title, 20) }}</div>
                            </td>
                            <td>
                                <div class="fw-bold text-dark">{{ $fb->guest_name ?? 'Anonim' }}</div>
                                <div class="small text-muted">{{ $fb->guest_email ?? '-' }}</div>
                            </td>
                            <td>
                                @if($fb->priority == 'High' || $fb->priority == 'Critical')
                                    <span class="badge bg-danger">Yüksek</span>
                                @elseif($fb->priority == 'Normal')
                                    <span class="badge bg-primary">Normal</span>
                                @else
                                    <span class="badge bg-secondary">Düşük</span>
                                @endif
                            </td>
                            <td>
                                @if($fb->status == 'Pending') <span class="badge bg-warning text-dark">Bekliyor</span>
                                @elseif($fb->status == 'Reviewing') <span class="badge bg-info text-dark">İnceleniyor</span>
                                @elseif($fb->status == 'Resolved') <span class="badge bg-success">Çözüldü</span>
                                @else <span class="badge bg-secondary">İptal</span> @endif
                            </td>
                            <td>
                                @if($fb->assignedUser)
                                    <div class="d-flex align-items-center">
                                        <div class="bg-light rounded-circle text-center me-2" style="width:25px; height:25px; line-height:25px; font-size:10px;">
                                            {{ substr($fb->assignedUser->name, 0, 1) }}
                                        </div>
                                        <span class="small">{{ $fb->assignedUser->name }}</span>
                                    </div>
                                @else
                                    <span class="text-muted small fst-italic">-Atanmadı-</span>
                                @endif
                            </td>
                            <td class="small text-muted">{{ $fb->created_at->format('d.m.Y H:i') }}</td>
                            <td class="text-end">
                                <a href="{{ route('admin.qms.feedbacks.show', $fb->id) }}" class="btn btn-sm btn-outline-primary">
                                    Yönet <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="8" class="text-center py-4 text-muted">Kayıt bulunamadı.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-2">
            {{ $feedbacks->links() }}
        </div>
    </div>
</div>
@endsection