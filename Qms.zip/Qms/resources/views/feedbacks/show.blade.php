@extends('layouts.admin')
@section('title', 'Geri Bildirim Detayı')

@section('content')
<div class="container-fluid px-4 mt-4">
    
    {{-- BAŞLIK --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800 mb-0">
                <span class="text-primary me-2">{{ $feedback->tracking_code }}</span> Detayı
            </h4>
            <div class="text-muted small">
                {{ $feedback->form->title }} | Gönderim: {{ $feedback->created_at->format('d.m.Y H:i') }}
            </div>
        </div>
        {{-- BUTONLAR --}}
        <div>
            <a href="{{ route('admin.qms.feedbacks.print', $feedback->id) }}" target="_blank" class="btn btn-dark btn-sm shadow-sm me-2">
                <i class="fas fa-print me-1"></i> Formu Yazdır
            </a>
            <a href="{{ route('admin.qms.feedbacks.index') }}" class="btn btn-secondary btn-sm shadow-sm">
                <i class="fas fa-arrow-left me-1"></i> Listeye Dön
            </a>
        </div>
    </div>

    <div class="row">
        
        {{-- SOL KOLON: FORM İÇERİĞİ (GELEN CEVAPLAR) --}}
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm border-0 border-top-lg border-primary mb-4">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-file-alt me-2 text-primary"></i>Müşteri Beyanı / Form İçeriği
                </div>
                <div class="card-body">
                    
                    {{-- 1. Müşteri Bilgileri --}}
                    <div class="alert alert-light border d-flex justify-content-between align-items-center p-3 mb-4">
                        <div><strong class="text-muted small d-block">Adı Soyadı</strong> {{ $feedback->guest_name ?? 'Belirtilmemiş' }}</div>
                        <div><strong class="text-muted small d-block">E-Posta</strong> {{ $feedback->guest_email ?? '-' }}</div>
                        <div><strong class="text-muted small d-block">Telefon</strong> {{ $feedback->guest_phone ?? '-' }}</div>
                    </div>

                    {{-- 2. Dinamik Soru ve Cevaplar --}}
                    <h6 class="fw-bold border-bottom pb-2 mb-3">Verilen Cevaplar</h6>
                    
                    @foreach($feedback->form->fields as $field)
                        <div class="mb-3">
                            <label class="small text-muted fw-bold text-uppercase">{{ $field->label }}</label>
                            <div class="p-2 bg-light rounded border-start border-4 border-info text-dark">
                                @php 
                                    $answer = $feedback->data[$field->name] ?? '-';
                                @endphp

                                {{-- Eğer Dosya ise İndirme Linki Göster --}}
                                @if($field->type == 'file' && $answer != '-')
                                    <a href="{{ asset('storage/'.$answer) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-download me-1"></i> Dosyayı Görüntüle
                                    </a>
                                
                                {{-- Eğer Puanlama (Yıldız) ise --}}
                                @elseif($field->type == 'rating')
                                    <div class="text-warning">
                                        @php $score = is_numeric($answer) ? $answer : 0; @endphp
                                        @for($i=1; $i<=5; $i++)
                                            <i class="fas fa-star {{ $i <= $score ? '' : 'text-gray-300' }}"></i>
                                        @endfor
                                        <span class="text-dark ms-2 fw-bold">({{ $score }}/5)</span>
                                    </div>

                                {{-- DİĞER TÜRLER (TEXT, CHECKBOX VS) --}}
                                @else
                                    {{-- İŞTE DÜZELTME BURADA: Array ise virgülle birleştir, değilse yaz --}}
                                    @if(is_array($answer))
                                        {{ implode(', ', $answer) }}
                                    @else
                                        {{ $answer }}
                                    @endif
                                @endif
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>

            {{-- LOGLAR / TARİHÇE --}}
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-history me-2 text-info"></i>İşlem Tarihçesi
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        @forelse($feedback->activities as $activity)
                            <li class="list-group-item">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <span class="fw-bold text-dark">{{ $activity->action }}</span>
                                        <br>
                                        <small class="text-muted">{{ $activity->description }}</small>
                                    </div>
                                    <div class="text-end">
                                        <small class="d-block text-dark fw-bold">{{ $activity->user->name ?? 'Sistem' }}</small>
                                        <small class="text-muted" style="font-size: 11px;">{{ $activity->created_at->format('d.m.Y H:i') }}</small>
                                    </div>
                                </div>
                            </li>
                        @empty
                            <li class="list-group-item text-center text-muted py-3">Henüz işlem geçmişi yok.</li>
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

        {{-- SAĞ KOLON: YÖNETİM PANELİ --}}
        <div class="col-lg-4">
            <div class="card shadow-sm border-0 bg-light">
                <div class="card-header bg-white fw-bold border-bottom">
                    <i class="fas fa-cogs me-2 text-secondary"></i>Yönetim Paneli
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.qms.feedbacks.update', $feedback->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        {{-- DURUM GÜNCELLEME --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Süreç Durumu</label>
                            <select name="status" class="form-select">
                                <option value="Pending" {{ $feedback->status == 'Pending' ? 'selected' : '' }}>🟡 Bekliyor</option>
                                <option value="Reviewing" {{ $feedback->status == 'Reviewing' ? 'selected' : '' }}>🔵 İnceleniyor</option>
                                <option value="Investigating" {{ $feedback->status == 'Investigating' ? 'selected' : '' }}>🟣 Kök Neden Analizinde</option>
                                <option value="Resolved" {{ $feedback->status == 'Resolved' ? 'selected' : '' }}>🟢 Çözüldü / Kapandı</option>
                                <option value="Cancelled" {{ $feedback->status == 'Cancelled' ? 'selected' : '' }}>⚪ İptal / Geçersiz</option>
                            </select>
                        </div>

                        {{-- ÖNCELİK --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Öncelik Seviyesi</label>
                            <select name="priority" class="form-select">
                                <option value="Low" {{ $feedback->priority == 'Low' ? 'selected' : '' }}>Düşük</option>
                                <option value="Normal" {{ $feedback->priority == 'Normal' ? 'selected' : '' }}>Normal</option>
                                <option value="High" {{ $feedback->priority == 'High' ? 'selected' : '' }}>Yüksek</option>
                                <option value="Critical" {{ $feedback->priority == 'Critical' ? 'selected' : '' }}>KRİTİK</option>
                            </select>
                        </div>

                        {{-- SORUMLU ATAMA --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Sorumlu Personel</label>
                            <select name="assigned_user_id" class="form-select">
                                <option value="">-- Atanmadı --</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" {{ $feedback->assigned_user_id == $user->id ? 'selected' : '' }}>
                                        {{ $user->name }} ({{ $user->department->name ?? '-' }})
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 fw-bold">
                            <i class="fas fa-save me-1"></i> Değişiklikleri Kaydet
                        </button>
                    </form>
                </div>
            </div>

            {{-- KÖK NEDEN VE DÖF BUTONU --}}
            @if($feedback->form->type == 'Complaint')
            <div class="card shadow-sm border-0 mt-3 border-start border-4 border-danger">
                <div class="card-body">
                    <h6 class="fw-bold text-danger">ISO 17025 Aksiyonu</h6>
                    <p class="small text-muted mb-3">Bu şikayet sistemsel bir hata içeriyorsa DÖF başlatılmalıdır.</p>
                    
                    <a href="{{ route('admin.qms.capas.create', ['feedback_id' => $feedback->id]) }}" class="btn btn-outline-danger w-100 btn-sm">
                        <i class="fas fa-virus me-1"></i> DÖF / Kök Neden Analizi Başlat
                    </a>
                </div>
            </div>
            @endif

        </div>
    </div>
</div>
@endsection