<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Şikayet Formu - {{ $feedback->tracking_code }}</title>
    <style>
        @page { size: A4; margin: 10mm; }
        body { font-family: 'Times New Roman', serif; font-size: 11pt; line-height: 1.3; color: #000; }
        
        table { width: 100%; border-collapse: collapse; margin-bottom: 5px; }
        th, td { border: 1px solid #000; padding: 4px 6px; vertical-align: top; }
        
        .header-logo { width: 150px; text-align: center; }
        .header-title { text-align: center; font-weight: bold; font-size: 14pt; background: #fff; }
        .bg-gray { background-color: #e0e0e0; font-weight: bold; font-size: 10pt; }
        
        .no-border-top { border-top: none !important; }
        .no-border-bottom { border-bottom: none !important; }
        .h-100 { height: 100px; }
        .h-50 { height: 50px; }
        
        .check-box { display: inline-block; width: 12px; height: 12px; border: 1px solid #000; margin-right: 3px; }
        .checked { background-color: #000; } /* İşaretli kutu içi dolu olsun */

        /* Yazdırma Butonu */
        @media print { .no-print { display: none; } }
        .print-btn { 
            position: fixed; top: 20px; right: 20px; 
            background: #dc3545; color: white; padding: 10px 20px; 
            text-decoration: none; font-family: sans-serif; border-radius: 5px; cursor: pointer;
        }
    </style>
</head>
<body onload="window.print()">

    <a href="javascript:window.print()" class="no-print print-btn">YAZDIR / PDF KAYDET</a>

    {{-- BAŞLIK BÖLÜMÜ --}}
    <table>
        <tr>
            <td class="header-logo" rowspan="3">
                {{-- LOGO YERİ --}}
                <div style="font-size:20px; font-weight:bold; padding:15px;">LOGO</div>
            </td>
            <td class="header-title" rowspan="3">
                MÜŞTERİ ŞİKAYETİ<br>KAYIT ve DEĞERLENDİRME FORMU
            </td>
            <td width="15%"><strong>Doküman No</strong></td>
            <td width="15%">FR-08-03</td>
        </tr>
        <tr>
            <td><strong>Yayın Tarihi</strong></td>
            <td>31.01.2019</td>
        </tr>
        <tr>
            <td><strong>Rev. No/Tarih</strong></td>
            <td>00 / --</td>
        </tr>
    </table>

    {{-- ŞİKAYETÇİ BİLGİLERİ --}}
    <table>
        <tr>
            <td colspan="4" class="bg-gray">Şikayetçi Bilgileri</td>
        </tr>
        <tr>
            <td width="20%"><strong>Müşteri Unvanı</strong></td>
            <td colspan="3">{{ $feedback->guest_name ?? 'Belirtilmemiş' }}</td>
        </tr>
        <tr>
            <td><strong>Adres</strong></td>
            <td colspan="3">-</td> {{-- Adres alanı formda yoksa tire --}}
        </tr>
        <tr>
            <td><strong>Tel / E-mail</strong></td>
            <td>{{ $feedback->guest_phone }} / {{ $feedback->guest_email }}</td>
            <td width="15%"><strong>Şikayet Tarihi</strong></td>
            <td width="15%">{{ $feedback->created_at->format('d.m.Y') }}</td>
        </tr>
    </table>

    {{-- ŞİKAYET KONUSU --}}
    <table>
        <tr>
            <td colspan="2" class="bg-gray">Şikayete Konu Olan Hizmet/Hizmetler ve Şikayetin Açıklaması</td>
        </tr>
        <tr>
            <td width="20%"><strong>Referans No</strong></td>
            <td>{{ $feedback->tracking_code }}</td>
        </tr>
        <tr>
            <td colspan="2" class="bg-gray">Laboratuvarımıza nasıl ulaştınız?</td>
        </tr>
        <tr>
            <td colspan="2">
                <span class="check-box checked"></span> Web Sayfası &nbsp;&nbsp;&nbsp;
                <span class="check-box"></span> Referans &nbsp;&nbsp;&nbsp;
                <span class="check-box"></span> Diğer
            </td>
        </tr>
    </table>

    {{-- ŞİKAYET AÇIKLAMASI --}}
    <table>
        <tr>
            <td class="bg-gray">Şikayet Açıklaması (Müşteri Beyanı)</td>
        </tr>
        <tr>
            <td class="h-100">
                <strong>Konu:</strong> {{ $feedback->data['subject'] ?? 'Genel' }} <br><br>
                {{ $feedback->data['message'] ?? '-' }}
            </td>
        </tr>
    </table>

    {{-- İLETİŞİM TERCİHİ --}}
    <table>
        <tr>
            <td width="50%" class="bg-gray">Gelecekte bizimle çalışmak ister misiniz?</td>
            <td class="bg-gray">Önerileriniz</td>
        </tr>
        <tr>
            <td>
                <span class="check-box"></span> Kararsızım <br>
                <span class="check-box checked"></span> Evet <br>
                <span class="check-box"></span> Hayır
            </td>
            <td>
                {{-- Varsa öneri buraya --}}
            </td>
        </tr>
    </table>

    {{-- DOLDURAN KİŞİ --}}
    <table>
        <tr>
            <td colspan="3" class="bg-gray">> Laboratuvar Tarafından Doldurulacaktır.</td>
        </tr>
        <tr>
            <td><strong>Şikayetin Alınma Şekli:</strong> <br> Web Portalı (Online)</td>
            <td><strong>Formu Dolduran:</strong> <br> {{ $feedback->assignedUser->name ?? 'Sistem Otomatiği' }}</td>
        </tr>
    </table>

    {{-- DEĞERLENDİRME --}}
    <table>
        <tr>
            <td class="bg-gray">Şikayetin Değerlendirilmesi ve Muhtemel Sebepleri</td>
        </tr>
        <tr>
            <td class="h-50">
                {{-- Yönetici paneline "Değerlendirme Notu" alanı eklersek buraya basarız. Şimdilik activity logdan son notu alalım --}}
                @php
                    $lastNote = $feedback->activities->where('action', '!=', 'Durum Değişti')->last();
                @endphp
                {{ $lastNote ? $lastNote->description : 'Ön inceleme yapıldı.' }}
            </td>
        </tr>
    </table>

    {{-- SONUÇ VE DÖF --}}
    @php
        $isAccepted = $feedback->status != 'Cancelled';
        $dof = \Modules\Qms\Models\QmsCapa::where('feedback_id', $feedback->id)->first();
    @endphp

    <table>
        <tr>
            <td colspan="2" class="bg-gray">Değerlendirme Sonucu &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Şikayet No: {{ $feedback->tracking_code }}</td>
        </tr>
        <tr>
            <td width="50%">
                <span class="check-box {{ !$isAccepted ? 'checked' : '' }}"></span> Şikayet Kabul Edilmedi.
            </td>
            <td>
                <span class="check-box {{ $isAccepted ? 'checked' : '' }}"></span> Şikayet Kabul Edildi. <br>
                &nbsp;&nbsp;&nbsp; <span class="check-box {{ ($isAccepted && !$dof) ? 'checked' : '' }}"></span> Düzeltici Faaliyet gerekli değil. <br>
                &nbsp;&nbsp;&nbsp; <span class="check-box {{ $dof ? 'checked' : '' }}"></span> Düzeltici Faaliyet (DÖF No: <strong>{{ $dof ? $dof->code : '..........' }}</strong>)
            </td>
        </tr>
    </table>

    {{-- YAPILAN İŞLEMLER --}}
    <table>
        <tr>
            <td class="bg-gray">Şikayetin Giderilmesi için Yapılan İşlemler</td>
        </tr>
        <tr>
            <td class="h-50">
                @if($dof)
                    Düzeltici faaliyet başlatıldı. Aksiyonlar DÖF formunda takip edilmektedir.
                @else
                    Müşteri ile iletişime geçildi, bilgilendirme yapıldı.
                @endif
            </td>
        </tr>
    </table>

    {{-- ONAY KISMI --}}
    <table>
        <tr>
            <td width="50%" class="bg-gray">Kalite Birimi</td>
            <td width="50%" class="bg-gray">Laboratuvar Müdürü</td>
        </tr>
        <tr>
            <td class="h-50">
                <strong>Ad-Soyad:</strong> Gözde Kaplan <br>
                <strong>Tarih/İmza:</strong>
            </td>
            <td class="h-50">
                <strong>Ad-Soyad:</strong> Engin Katırağ <br>
                <strong>Tarih/İmza:</strong>
            </td>
        </tr>
    </table>

    <div style="font-size: 8pt; text-align: right; margin-top: 5px;">
        Sistem tarafından {{ date('d.m.Y H:i') }} tarihinde oluşturulmuştur.
    </div>

</body>
</html>