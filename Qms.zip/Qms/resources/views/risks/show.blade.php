@extends('layouts.admin')
@section('title', 'Risk Detayı - ' . $risk->code)

@section('content')
<div class="container-fluid px-4 mt-4">

    {{-- ÜST BAŞLIK VE BUTONLAR --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800 mb-0">
                <span class="text-primary me-2">{{ $risk->code }}</span> Detayı
            </h4>
            <div class="text-muted small">
                {{ $risk->category }} | 
                <span class="badge bg-{{ $risk->type == 'Risk' ? 'danger' : 'success' }}">{{ $risk->type == 'Risk' ? 'Risk (Tehdit)' : 'Fırsat' }}</span>
            </div>
        </div>
        <div>
            <a href="{{ route('admin.qms.risks.index') }}" class="btn btn-secondary btn-sm shadow-sm">
                <i class="fas fa-arrow-left me-1"></i> Listeye Dön
            </a>
            
            <form action="{{ route('admin.qms.risks.destroy', $risk->id) }}" method="POST" class="d-inline-block ms-2" onsubmit="return confirm('Bu risk kaydını silmek istediğinize emin misiniz?');">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-outline-danger btn-sm">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </form>
        </div>
    </div>

    <div class="row">
        
        {{-- SOL KOLON: RİSK DETAYLARI VE DÖF LİSTESİ --}}
        <div class="col-lg-8">
            
            {{-- 1. RİSK KİMLİK KARTI --}}
            <div class="card shadow-sm border-0 border-top-lg border-primary mb-4">
                <div class="card-body">
                    <h5 class="fw-bold text-dark border-bottom pb-2 mb-3">Risk / Fırsat Tanımı</h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-12 mb-3">
                            <label class="small text-muted fw-bold text-uppercase">Tanım</label>
                            <div class="bg-light p-3 rounded border text-dark">
                                {{ $risk->description }}
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="small text-muted fw-bold text-uppercase">Riskin Kaynağı</label>
                            <div class="text-dark">{{ $risk->source ?? 'Belirtilmemiş' }}</div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="small text-muted fw-bold text-uppercase">Olası Etki (Laboratuvara)</label>
                            <div class="text-danger fw-bold">{{ $risk->potential_impact ?? 'Belirtilmemiş' }}</div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <label class="small text-muted fw-bold text-uppercase">İlgili Departman</label>
                            <div><i class="fas fa-building me-1 text-secondary"></i> {{ $risk->department->name ?? '-' }}</div>
                        </div>
                        <div class="col-md-4">
                            <label class="small text-muted fw-bold text-uppercase">Risk Sahibi</label>
                            <div><i class="fas fa-user-tie me-1 text-secondary"></i> {{ $risk->owner->name ?? '-' }}</div>
                        </div>
                        <div class="col-md-4">
                            <label class="small text-muted fw-bold text-uppercase">Gözden Geçirme Tarihi</label>
                            <div>
                                <i class="fas fa-calendar-alt me-1 text-secondary"></i> 
                                {{ $risk->review_date ? \Carbon\Carbon::parse($risk->review_date)->format('d.m.Y') : 'Planlanmadı' }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- 2. İLİŞKİLİ DÖF'LER --}}
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-clipboard-check me-2 text-info"></i>İlişkili DÖF / Önleyici Faaliyetler</span>
                    
                    <a href="{{ route('admin.qms.capas.create', ['risk_id' => $risk->id]) }}" class="btn btn-sm btn-outline-danger fw-bold">
                        <i class="fas fa-plus-circle me-1"></i> DÖF Başlat
                    </a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>DÖF Konusu</th>
                                    <th>Sorumlu</th>
                                    <th>Durum</th>
                                    <th>Hedef Tarih</th>
                                    <th class="text-end">İşlem</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($risk->capas as $capa)
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="me-2">
                                                    <span class="badge bg-light text-dark border">{{ $capa->code }}</span>
                                                </div>
                                                <div>
                                                    <a href="{{ route('admin.qms.capas.show', $capa->id) }}" class="fw-bold text-dark text-decoration-none">
                                                        {{ $capa->subject }}
                                                    </a>
                                                    <div class="small text-muted" title="{{ $capa->description }}">
                                                        {{ Str::limit($capa->description, 50) }}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="small"><i class="fas fa-user me-1 text-secondary"></i>{{ $capa->lead->name ?? '-' }}</div>
                                        </td>
                                        <td>
                                            @php
                                                $capaStatuses = [
                                                    'Pending' => ['text' => 'Bekliyor', 'color' => 'secondary'],
                                                    'Root_Cause_Analysis' => ['text' => 'Kök Neden Analizi', 'color' => 'warning text-dark'],
                                                    'Action_Planning' => ['text' => 'Aksiyon Planlama', 'color' => 'info text-dark'],
                                                    'Implementation' => ['text' => 'Uygulama', 'color' => 'primary'],
                                                    'Verification' => ['text' => 'Doğrulama', 'color' => 'info'],
                                                    'Closed' => ['text' => 'Kapandı', 'color' => 'success'],
                                                    'Cancelled' => ['text' => 'İptal', 'color' => 'dark'],
                                                ];
                                                $statusInfo = $capaStatuses[$capa->status] ?? ['text' => $capa->status, 'color' => 'secondary'];
                                            @endphp
                                            <span class="badge bg-{{ $statusInfo['color'] }}">
                                                {{ $statusInfo['text'] }}
                                            </span>
                                        </td>
                                        <td>
                                            <div class="small">{{ $capa->target_date ? \Carbon\Carbon::parse($capa->target_date)->format('d.m.Y') : '-' }}</div>
                                        </td>
                                        <td class="text-end">
                                            <a href="{{ route('admin.qms.capas.show', $capa->id) }}" class="btn btn-sm btn-light border" title="Detay">
                                                <i class="fas fa-chevron-right"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            <div class="mb-2"><i class="fas fa-folder-open fa-2x text-gray-300"></i></div>
                                            Bu risk için henüz bir DÖF (Aksiyon) başlatılmamış.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

        {{-- SAĞ KOLON: RİSK SKORU, DURUM VE TARIHÇE (TIMELINE) --}}
        <div class="col-lg-4">
            
            {{-- 1. RİSK SKORU GÖRSELİ VE GÜNCELLEME FORMU --}}
            <div class="card shadow-sm border-0 mb-4 text-center">
                <div class="card-header bg-white fw-bold">
                    Risk Analiz ve Güncelleme
                </div>
                <div class="card-body">
                    @php
                        $score = $risk->risk_score;
                        $colorClass = 'success';
                        $levelText = 'DÜŞÜK';
                        if($score >= 15) { $colorClass = 'danger'; $levelText = 'KRİTİK'; }
                        elseif($score >= 8) { $colorClass = 'warning'; $levelText = 'YÜKSEK'; }
                        elseif($score >= 4) { $colorClass = 'info'; $levelText = 'ORTA'; }
                    @endphp

                    {{-- SKOR DAİRESİ --}}
                    <div class="position-relative d-inline-block mb-3">
                        <div class="rounded-circle d-flex align-items-center justify-content-center border border-4 border-{{ $colorClass }}" 
                             style="width: 120px; height: 120px; background-color: rgba(var(--bs-{{ $colorClass }}-rgb), 0.1);">
                            <div>
                                <div class="display-4 fw-bold text-{{ $colorClass }}">{{ $score }}</div>
                                <div class="small text-muted" style="font-size: 0.7rem;">RİSK SKORU</div>
                            </div>
                        </div>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-{{ $colorClass }}">
                            {{ $levelText }}
                        </span>
                    </div>
                    
                    <hr>

                    {{-- GÜNCELLEME FORMU --}}
                    <form action="{{ route('admin.qms.risks.update', $risk->id) }}" method="POST">
                        @csrf
                        @method('PUT')
                        
                        {{-- GİZLİ ALANLAR (Değişmeyecek olanlar) --}}
                        <input type="hidden" name="owner_id" value="{{ $risk->owner_id }}">
                        
                        <div class="row g-2 mb-3 text-start">
                            {{-- MANUEL PUAN GÜNCELLEME ALANI --}}
                            <div class="col-6">
                                <label class="form-label small fw-bold text-muted">Olasılık (P)</label>
                                <select name="probability" class="form-select form-select-sm">
                                    @for($i=1; $i<=5; $i++)
                                        <option value="{{ $i }}" {{ $risk->probability == $i ? 'selected' : '' }}>{{ $i }}</option>
                                    @endfor
                                </select>
                            </div>
                            <div class="col-6">
                                <label class="form-label small fw-bold text-muted">Etki (I)</label>
                                <select name="impact" class="form-select form-select-sm">
                                    @for($i=1; $i<=5; $i++)
                                        <option value="{{ $i }}" {{ $risk->impact == $i ? 'selected' : '' }}>{{ $i }}</option>
                                    @endfor
                                </select>
                            </div>
                            
                            {{-- DURUM GÜNCELLEME --}}
                            <div class="col-12 mt-2">
                                <label class="form-label small fw-bold text-muted">Risk Durumu</label>
                                <select name="status" class="form-select form-select-sm">
                                    <option value="Open" {{ $risk->status == 'Open' ? 'selected' : '' }}>Açık</option>
                                    <option value="In_Progress" {{ $risk->status == 'In_Progress' ? 'selected' : '' }}>İşlemde</option>
                                    <option value="Monitoring" {{ $risk->status == 'Monitoring' ? 'selected' : '' }}>İzleniyor</option>
                                    <option value="Closed" {{ $risk->status == 'Closed' ? 'selected' : '' }}>Kapalı</option>
                                </select>
                            </div>
                        </div>

                        <div class="d-grid">
                            <button class="btn btn-primary btn-sm fw-bold" type="submit">
                                <i class="fas fa-save me-1"></i> Değişiklikleri Kaydet
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            {{-- 2. RİSK TARİHÇESİ (TIMELINE) --}}
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-history me-2 text-primary"></i>Tarihçe ve İzlenebilirlik
                </div>
                <div class="card-body p-3 bg-light" style="max-height: 400px; overflow-y: auto;">
                    
                    <div class="timeline">
                        @forelse($risk->histories()->orderBy('created_at', 'desc')->get() as $history)
                            {{-- ÇEVİRİ MANTIĞI --}}
                            @php
                                // Eylem Çevirisi
                                $actionMap = [
                                    'created' => 'Oluşturuldu', 
                                    'updated' => 'Güncellendi',
                                    'Oluşturuldu' => 'Oluşturuldu',
                                    'Güncellendi' => 'Güncellendi'
                                ];
                                $actionText = $actionMap[$history->action] ?? $history->action;

                                // Alan Adı Çevirisi
                                $fieldMap = [
                                    'probability' => 'Olasılık',
                                    'impact' => 'Etki (Şiddet)',
                                    'risk_score' => 'Risk Skoru',
                                    'status' => 'Durum',
                                    'title' => 'Başlık',
                                    'description' => 'Açıklama',
                                    'risk_level' => 'Risk Seviyesi'
                                ];

                                // Değer Çevirisi (YENİ EKLENDİ)
                                $valueMap = [
                                    // Durumlar
                                    'Open' => 'Açık',
                                    'In_Progress' => 'İşlemde',
                                    'Monitoring' => 'İzleniyor',
                                    'Closed' => 'Kapalı',
                                    // Seviyeler
                                    'Low' => 'Düşük',
                                    'Medium' => 'Orta',
                                    'High' => 'Yüksek',
                                    'Critical' => 'Kritik',
                                    // Puanlar (İsteğe bağlı)
                                    '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5'
                                ];
                            @endphp

                            <div class="timeline-item">
                                <div class="timeline-marker {{ $actionText == 'Oluşturuldu' ? 'bg-success' : 'bg-primary' }}"></div>
                                <div class="timeline-content shadow-sm bg-white p-3 rounded">
                                    <div class="d-flex justify-content-between mb-1">
                                        <h6 class="fw-bold mb-0 text-dark" style="font-size: 0.9rem;">{{ $actionText }}</h6>
                                        <small class="text-muted" style="font-size: 0.75rem;">{{ $history->created_at->format('d.m.Y H:i') }}</small>
                                    </div>
                                    
                                    <div class="small text-muted mb-2 border-bottom pb-1">
                                        <i class="fas fa-user-circle me-1"></i> {{ $history->user->name ?? 'Sistem' }}
                                    </div>

                                    @if($history->changes)
                                        <ul class="list-unstyled mb-0 small ps-1">
                                            @foreach($history->changes as $change)
                                                @php 
                                                    // Alan adını çevir
                                                    $fieldName = $fieldMap[$change['field']] ?? ($change['field'] ?? '-'); 
                                                    
                                                    // Değerleri çevir (Eğer harita da varsa kullan, yoksa orijinali)
                                                    $oldVal = $valueMap[$change['old']] ?? $change['old'];
                                                    $newVal = $valueMap[$change['new']] ?? $change['new'];
                                                @endphp
                                                <li class="mb-1">
                                                    <span class="fw-bold text-secondary">{{ $fieldName }}:</span> 
                                                    <span class="text-danger text-decoration-line-through mx-1">{{ $oldVal }}</span> 
                                                    <i class="fas fa-arrow-right text-muted" style="font-size: 0.7em;"></i> 
                                                    <span class="text-success fw-bold mx-1">{{ $newVal }}</span>
                                                </li>
                                            @endforeach
                                        </ul>
                                    @else
                                        <p class="text-muted small mb-0 fst-italic">{{ $history->comment }}</p>
                                    @endif
                                </div>
                            </div>
                        @empty
                            <div class="text-center text-muted small py-3">Henüz tarihçe kaydı yok.</div>
                        @endforelse
                    </div>

                </div>
            </div>
            
            {{-- BİLGİ NOTU --}}
            <div class="alert alert-info border-0 small text-dark d-flex align-items-center">
                <i class="fas fa-info-circle me-3 fa-2x text-info"></i>
                <div>
                    DÖF aksiyonları tamamlandıktan sonra, yukarıdaki panelden <strong>Olasılık</strong> ve <strong>Etki</strong> değerlerini düşürerek risk puanını güncelleyebilirsiniz.
                </div>
            </div>

        </div>
    </div>
</div>

<style>
    /* TIMELINE STYLES */
    .timeline {
        position: relative;
        padding-left: 1.5rem;
        border-left: 2px solid #e9ecef;
        margin-left: 0.5rem;
        padding-top: 0.5rem;
        padding-bottom: 0.5rem;
    }
    .timeline-item {
        position: relative;
        margin-bottom: 1.5rem;
    }
    .timeline-item:last-child {
        margin-bottom: 0;
    }
    .timeline-marker {
        position: absolute;
        top: 15px;
        left: -1.95rem;
        width: 14px;
        height: 14px;
        border-radius: 50%;
        border: 3px solid #fff;
        box-shadow: 0 0 0 2px #cbd5e1;
        z-index: 1;
    }
    .timeline-content {
        position: relative;
        border: 1px solid rgba(0,0,0,0.05);
    }
    .timeline-content::before {
        content: '';
        position: absolute;
        top: 18px;
        left: -6px;
        width: 10px;
        height: 10px;
        background: #fff;
        border-left: 1px solid rgba(0,0,0,0.05);
        border-bottom: 1px solid rgba(0,0,0,0.05);
        transform: rotate(45deg);
    }
</style>
@endsection