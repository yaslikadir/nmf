@extends('layouts.admin')
@section('title', 'Risk Yönetim Paneli')

@section('content')
<style>
    /* ═══════════════════════════════════════════════════════════════
       2026 CREATIVE RISK MANAGEMENT DASHBOARD - DARK THEME
       ═══════════════════════════════════════════════════════════════ */
    
    :root {
        --bg-primary: #0a0e1a;
        --bg-secondary: #111827;
        --bg-card: rgba(17, 24, 39, 0.7);
        --bg-card-hover: rgba(30, 41, 59, 0.8);
        --border-color: rgba(99, 102, 241, 0.2);
        --border-glow: rgba(99, 102, 241, 0.5);
        --text-primary: #f1f5f9;
        --text-secondary: #94a3b8;
        --text-muted: #64748b;
        --accent-blue: #6366f1;
        --accent-cyan: #22d3ee;
        --accent-emerald: #10b981;
        --risk-critical: #ef4444;
        --risk-high: #f97316;
        --risk-medium: #eab308;
        --risk-low: #22c55e;
        --gradient-1: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        --gradient-2: linear-gradient(135deg, #ef4444 0%, #f97316 100%);
        --gradient-3: linear-gradient(135deg, #f97316 0%, #eab308 100%);
        --gradient-4: linear-gradient(135deg, #10b981 0%, #22d3ee 100%);
    }

    .risk-dashboard {
        min-height: 100vh;
        background: var(--bg-primary);
        background-image: 
            radial-gradient(ellipse at 20% 0%, rgba(99, 102, 241, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 100%, rgba(139, 92, 246, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse at 50% 50%, rgba(34, 211, 238, 0.05) 0%, transparent 70%);
        padding: 2rem;
        position: relative;
        overflow: hidden;
    }

    .risk-dashboard::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%236366f1' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        pointer-events: none;
    }

    /* Header */
    .dashboard-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        position: relative;
        z-index: 1;
    }

    .dashboard-title {
        font-size: 2rem;
        font-weight: 800;
        background: linear-gradient(135deg, #f1f5f9 0%, #6366f1 50%, #22d3ee 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        letter-spacing: -0.02em;
        margin-bottom: 0.25rem;
    }

    .dashboard-subtitle {
        color: var(--text-muted);
        font-size: 0.875rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .dashboard-subtitle::before {
        content: '';
        width: 8px;
        height: 8px;
        background: var(--accent-emerald);
        border-radius: 50%;
        animation: pulse-glow 2s ease-in-out infinite;
    }

    @keyframes pulse-glow {
        0%, 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4); }
        50% { box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
    }

    .header-actions {
        display: flex;
        gap: 0.75rem;
    }

    .btn-glass {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.625rem 1.25rem;
        font-size: 0.875rem;
        font-weight: 500;
        border-radius: 12px;
        border: 1px solid var(--border-color);
        background: var(--bg-card);
        color: var(--text-primary);
        backdrop-filter: blur(12px);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        text-decoration: none;
        cursor: pointer;
    }

    .btn-glass:hover {
        background: var(--bg-card-hover);
        border-color: var(--border-glow);
        box-shadow: 0 0 20px rgba(99, 102, 241, 0.3);
        transform: translateY(-2px);
        color: var(--text-primary);
    }

    .btn-glass.btn-danger {
        border-color: rgba(239, 68, 68, 0.3);
    }

    .btn-glass.btn-danger:hover {
        border-color: rgba(239, 68, 68, 0.6);
        box-shadow: 0 0 20px rgba(239, 68, 68, 0.3);
    }

    /* Summary Cards */
    .summary-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.5rem;
        margin-bottom: 2rem;
        position: relative;
        z-index: 1;
    }

    @media (max-width: 1200px) {
        .summary-grid { grid-template-columns: repeat(2, 1fr); }
    }

    @media (max-width: 640px) {
        .summary-grid { grid-template-columns: 1fr; }
    }

    .summary-card {
        position: relative;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 20px;
        padding: 1.5rem;
        backdrop-filter: blur(12px);
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .summary-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: var(--card-accent);
        opacity: 0.8;
    }

    .summary-card::after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 120px;
        height: 120px;
        background: var(--card-accent);
        opacity: 0.05;
        border-radius: 50%;
        transform: translate(30%, -30%);
        transition: all 0.4s ease;
    }

    .summary-card:hover {
        transform: translateY(-4px);
        border-color: var(--border-glow);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3), 0 0 30px var(--card-glow);
    }

    .summary-card:hover::after {
        transform: translate(20%, -20%) scale(1.2);
        opacity: 0.1;
    }

    .summary-card.primary { --card-accent: var(--accent-blue); --card-glow: rgba(99, 102, 241, 0.2); }
    .summary-card.danger { --card-accent: var(--risk-critical); --card-glow: rgba(239, 68, 68, 0.2); }
    .summary-card.warning { --card-accent: var(--risk-high); --card-glow: rgba(249, 115, 22, 0.2); }
    .summary-card.success { --card-accent: var(--accent-emerald); --card-glow: rgba(16, 185, 129, 0.2); }

    .card-label {
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: var(--card-accent);
        margin-bottom: 0.75rem;
    }

    .card-value {
        font-size: 3rem;
        font-weight: 800;
        color: var(--text-primary);
        line-height: 1;
        margin-bottom: 0.5rem;
        font-variant-numeric: tabular-nums;
    }

    .card-description {
        font-size: 0.8rem;
        color: var(--text-muted);
    }

    /* Main Content Grid */
    .content-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.5rem;
        position: relative;
        z-index: 1;
    }

    @media (max-width: 1024px) {
        .content-grid { grid-template-columns: 1fr; }
    }

    /* Glass Card */
    .glass-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 20px;
        backdrop-filter: blur(12px);
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .glass-card:hover {
        border-color: var(--border-glow);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }

    .card-header {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid var(--border-color);
    }

    .card-header-icon {
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        font-size: 1rem;
    }

    .card-header-icon.blue { background: rgba(99, 102, 241, 0.2); color: var(--accent-blue); }
    .card-header-icon.cyan { background: rgba(34, 211, 238, 0.2); color: var(--accent-cyan); }
    .card-header-icon.orange { background: rgba(249, 115, 22, 0.2); color: var(--risk-high); }

    .card-header-title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--text-primary);
    }

    .card-body {
        padding: 1.5rem;
    }

    /* Heatmap */
    .heatmap-wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 1rem;
        width: 100%;
    }

    .heatmap-container {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .heatmap-grid {
        display: grid;
        grid-template-columns: repeat(5, 100px);
        grid-template-rows: repeat(5, 100px);
        gap: 10px;
    }

    .heatmap-y-labels {
        display: flex;
        flex-direction: column;
        gap: 10px;
        justify-content: center;
    }

    .heatmap-y-labels .axis-label {
        height: 100px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .heatmap-x-labels {
        display: grid;
        grid-template-columns: repeat(5, 100px);
        gap: 10px;
        margin-left: calc(50px + 1rem);
        margin-top: 0.5rem;
    }

    .heatmap-cell {
        width: 100px;
        height: 100px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
        color: #ffffff;
        cursor: default;
        transition: all 0.25s ease;
        position: relative;
        border: 2px solid transparent;
        padding: 8px;
        gap: 4px;
    }

    .heatmap-cell:hover {
        transform: scale(1.08);
        z-index: 10;
        border-color: rgba(255, 255, 255, 0.5);
    }

    .heatmap-cell.low { 
        background: linear-gradient(145deg, #22c55e 0%, #16a34a 100%);
        box-shadow: 0 6px 20px rgba(34, 197, 94, 0.35);
    }
    .heatmap-cell.medium { 
        background: linear-gradient(145deg, #eab308 0%, #ca8a04 100%);
        color: #1a1a2e;
        box-shadow: 0 6px 20px rgba(234, 179, 8, 0.35);
    }
    .heatmap-cell.high { 
        background: linear-gradient(145deg, #f97316 0%, #ea580c 100%);
        box-shadow: 0 6px 20px rgba(249, 115, 22, 0.35);
    }
    .heatmap-cell.critical { 
        background: linear-gradient(145deg, #ef4444 0%, #dc2626 100%);
        box-shadow: 0 6px 20px rgba(239, 68, 68, 0.35);
    }

    .heatmap-cell.empty {
        opacity: 0.3;
        box-shadow: none;
    }

    .heatmap-cell .cell-formula {
        font-size: 0.65rem;
        font-weight: 500;
        opacity: 0.8;
        letter-spacing: 0.02em;
    }

    .heatmap-cell .cell-count {
        font-size: 1.75rem;
        font-weight: 800;
        line-height: 1;
    }

    .heatmap-cell .cell-count-label {
        font-size: 0.6rem;
        font-weight: 500;
        opacity: 0.75;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .heatmap-cell .cell-score {
        font-size: 0.75rem;
        font-weight: 700;
        padding: 2px 8px;
        background: rgba(0,0,0,0.2);
        border-radius: 4px;
    }

    .heatmap-cell.medium .cell-score {
        background: rgba(0,0,0,0.15);
    }

    .axis-label {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        font-size: 1rem;
        font-weight: 700;
        color: var(--text-secondary);
    }

    .axis-title {
        font-size: 0.8rem;
        font-weight: 700;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.15em;
        text-align: center;
    }

    .axis-title.y-axis {
        writing-mode: vertical-rl;
        transform: rotate(180deg);
    }

    /* Charts */
    .chart-container {
        height: 180px;
        position: relative;
    }

    .charts-stack {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    /* Pie Chart Section */
    .pie-section {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.5rem;
        align-items: center;
    }

    @media (max-width: 640px) {
        .pie-section { grid-template-columns: 1fr; }
    }

    .pie-canvas-wrapper {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .legend-list {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    .legend-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0.75rem 1rem;
        background: rgba(255, 255, 255, 0.03);
        border-radius: 10px;
        border: 1px solid transparent;
        transition: all 0.3s ease;
    }

    .legend-item:hover {
        background: rgba(255, 255, 255, 0.06);
        border-color: var(--border-color);
    }

    .legend-item-left {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .legend-dot {
        width: 12px;
        height: 12px;
        border-radius: 4px;
    }

    .legend-dot.critical { background: var(--risk-critical); box-shadow: 0 0 10px rgba(239, 68, 68, 0.5); }
    .legend-dot.high { background: var(--risk-high); box-shadow: 0 0 10px rgba(249, 115, 22, 0.5); }
    .legend-dot.medium { background: var(--risk-medium); box-shadow: 0 0 10px rgba(234, 179, 8, 0.5); }
    .legend-dot.low { background: var(--risk-low); box-shadow: 0 0 10px rgba(34, 197, 94, 0.5); }

    .legend-label {
        font-size: 0.875rem;
        color: var(--text-secondary);
    }

    .legend-value {
        font-size: 1rem;
        font-weight: 700;
        color: var(--text-primary);
        font-variant-numeric: tabular-nums;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .risk-dashboard {
            padding: 1rem;
        }
        
        .dashboard-header {
            flex-direction: column;
            gap: 1rem;
            align-items: flex-start;
        }
        
        .dashboard-title {
            font-size: 1.5rem;
        }
        
        .card-value {
            font-size: 2.25rem;
        }
    }

    /* Animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .summary-card, .glass-card {
        animation: fadeInUp 0.6s ease forwards;
    }

    .summary-card:nth-child(1) { animation-delay: 0.1s; }
    .summary-card:nth-child(2) { animation-delay: 0.2s; }
    .summary-card:nth-child(3) { animation-delay: 0.3s; }
    .summary-card:nth-child(4) { animation-delay: 0.4s; }

    .content-grid .glass-card:nth-child(1) { animation-delay: 0.5s; }
    .content-grid .glass-card:nth-child(2) { animation-delay: 0.6s; }
</style>

<div class="risk-dashboard">
    {{-- HEADER --}}
    <div class="dashboard-header">
        <div>
            <h1 class="dashboard-title">Risk Yonetim Paneli</h1>
            <div class="dashboard-subtitle">ISO 17025 Madde 8.5 - Risk ve Firsatlar Analizi</div>
        </div>
        <div class="header-actions">
            <a href="{{ route('admin.qms.risks.general-report') }}" target="_blank" class="btn btn-dark btn-sm">
    <i class="fas fa-print me-1"></i> Genel Rapor Oluştur
</a>

            <a href="{{ route('admin.qms.risks.index') }}" class="btn-glass">
                <i class="fas fa-list"></i> Risk Listesi
            </a>
            <a href="{{ route('admin.qms.emergency-plans.index') }}" class="btn-glass btn-danger">
                <i class="fas fa-fire-extinguisher"></i> Acil Durum Planlari
            </a>
        </div>
    </div>

    {{-- SUMMARY CARDS --}}
    <div class="summary-grid">
        <div class="summary-card primary">
            <div class="card-label">Toplam Risk</div>
            <div class="card-value">{{ $totalRisks }}</div>
            <div class="card-description">Sistemde tanimli</div>
        </div>
        <div class="summary-card danger">
            <div class="card-label">Kritik Seviye</div>
            <div class="card-value">{{ $riskLevels['kritik'] }}</div>
            <div class="card-description">Acil aksiyon gerekli</div>
        </div>
        <div class="summary-card warning">
            <div class="card-label">Yuksek Seviye</div>
            <div class="card-value">{{ $riskLevels['yuksek'] }}</div>
            <div class="card-description">Izlenmesi gereken</div>
        </div>
        <div class="summary-card success">
            <div class="card-label">Tamamlanan Tatbikat</div>
            <div class="card-value">{{ $totalDrills }}</div>
            <div class="card-description">Ort. Sure: {{ number_format($avgDrillDuration, 1) }} dk</div>
        </div>
    </div>

    {{-- MAIN CONTENT --}}
    <div class="content-grid">
        {{-- HEATMAP --}}
        <div class="glass-card">
            <div class="card-header">
                <div class="card-header-icon blue">
                    <i class="fas fa-th"></i>
                </div>
                <span class="card-header-title">Risk Isi Haritasi (Heatmap)</span>
            </div>
            <div class="card-body">
                <div class="heatmap-wrapper">
                    <div class="heatmap-container">
                        <span class="axis-title y-axis">OLASILIK (P)</span>
                        <div class="heatmap-y-labels">
                            @for($p = 5; $p >= 1; $p--)
                                <div class="axis-label">{{ $p }}</div>
                            @endfor
                        </div>
                        <div class="heatmap-grid">
                            @for($p = 5; $p >= 1; $p--)
                                @for($i = 1; $i <= 5; $i++)
                                    @php
                                        $score = $p * $i;
                                        $count = $matrix[$p][$i] ?? 0;
                                        
                                        $levelClass = 'low';
                                        if($score >= 5 && $score <= 9) $levelClass = 'medium';
                                        if($score >= 10 && $score <= 15) $levelClass = 'high';
                                        if($score >= 16) $levelClass = 'critical';
                                        
                                        $emptyClass = $count == 0 ? 'empty' : '';
                                    @endphp
                                    <div class="heatmap-cell {{ $levelClass }} {{ $emptyClass }}" title="P:{{$p}} x I:{{$i}} = Skor:{{$score}}">
                                        <span class="cell-formula">{{ $p }} x {{ $i }}</span>
                                        <span class="cell-count">{{ $count }}</span>
                                        <span class="cell-count-label">Risk</span>
                                        <span class="cell-score">Skor: {{ $score }}</span>
                                    </div>
                                @endfor
                            @endfor
                        </div>
                    </div>
                    <div class="heatmap-x-labels">
                        @for($i = 1; $i <= 5; $i++)
                            <div class="axis-label">{{ $i }}</div>
                        @endfor
                    </div>
                    <span class="axis-title">SIDDET / ETKI (I)</span>
                </div>
            </div>
        </div>

        {{-- CHARTS --}}
        <div class="charts-stack">
            {{-- TREND CHART --}}
            <div class="glass-card">
                <div class="card-header">
                    <div class="card-header-icon cyan">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <span class="card-header-title">Risk Trend Analizi (Son 6 Ay)</span>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="trendChart"></canvas>
                    </div>
                </div>
            </div>

            {{-- PIE CHART --}}
            <div class="glass-card">
                <div class="card-header">
                    <div class="card-header-icon orange">
                        <i class="fas fa-chart-pie"></i>
                    </div>
                    <span class="card-header-title">Risk Seviye Dagilimi</span>
                </div>
                <div class="card-body">
                    <div class="pie-section">
                        <div class="pie-canvas-wrapper">
                            <canvas id="pieChart" width="180" height="180"></canvas>
                        </div>
                        <div class="legend-list">
                            <div class="legend-item">
                                <div class="legend-item-left">
                                    <span class="legend-dot critical"></span>
                                    <span class="legend-label">Kritik (16-25)</span>
                                </div>
                                <span class="legend-value">{{ $riskLevels['kritik'] }}</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-item-left">
                                    <span class="legend-dot high"></span>
                                    <span class="legend-label">Yuksek (10-15)</span>
                                </div>
                                <span class="legend-value">{{ $riskLevels['yuksek'] }}</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-item-left">
                                    <span class="legend-dot medium"></span>
                                    <span class="legend-label">Orta (5-9)</span>
                                </div>
                                <span class="legend-value">{{ $riskLevels['orta'] }}</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-item-left">
                                    <span class="legend-dot low"></span>
                                    <span class="legend-label">Dusuk (1-4)</span>
                                </div>
                                <span class="legend-value">{{ $riskLevels['dusuk'] }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- CHART.JS --}}
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Trend Chart
    const ctxTrend = document.getElementById('trendChart').getContext('2d');
    const gradientTrend = ctxTrend.createLinearGradient(0, 0, 0, 180);
    gradientTrend.addColorStop(0, 'rgba(99, 102, 241, 0.4)');
    gradientTrend.addColorStop(1, 'rgba(99, 102, 241, 0)');

    new Chart(ctxTrend, {
        type: 'line',
        data: {
            labels: {!! json_encode($trendLabels) !!},
            datasets: [{
                label: 'Yeni Tespit Edilen Riskler',
                data: {!! json_encode($trendValues) !!},
                borderColor: '#6366f1',
                backgroundColor: gradientTrend,
                pointBackgroundColor: '#6366f1',
                pointBorderColor: '#1a1a2e',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 8,
                pointHoverBackgroundColor: '#22d3ee',
                pointHoverBorderColor: '#fff',
                fill: true,
                tension: 0.4,
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(17, 24, 39, 0.95)',
                    titleColor: '#f1f5f9',
                    bodyColor: '#94a3b8',
                    borderColor: 'rgba(99, 102, 241, 0.3)',
                    borderWidth: 1,
                    cornerRadius: 8,
                    padding: 12,
                    displayColors: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        color: '#64748b',
                        font: { size: 11 }
                    },
                    grid: {
                        color: 'rgba(99, 102, 241, 0.1)',
                        drawBorder: false
                    }
                },
                x: {
                    ticks: {
                        color: '#64748b',
                        font: { size: 11 }
                    },
                    grid: { display: false }
                }
            }
        }
    });

    // Pie Chart
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: ['Dusuk', 'Orta', 'Yuksek', 'Kritik'],
            datasets: [{
                data: [
                    {{ $riskLevels['dusuk'] }},
                    {{ $riskLevels['orta'] }},
                    {{ $riskLevels['yuksek'] }},
                    {{ $riskLevels['kritik'] }}
                ],
                backgroundColor: ['#22c55e', '#eab308', '#f97316', '#ef4444'],
                borderColor: '#111827',
                borderWidth: 3,
                hoverBorderColor: '#1e293b',
                hoverBorderWidth: 4,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            cutout: '65%',
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(17, 24, 39, 0.95)',
                    titleColor: '#f1f5f9',
                    bodyColor: '#94a3b8',
                    borderColor: 'rgba(99, 102, 241, 0.3)',
                    borderWidth: 1,
                    cornerRadius: 8,
                    padding: 12,
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            let value = context.raw;
                            let total = context.chart._metasets[context.datasetIndex].total;
                            let percentage = Math.round((value / total) * 100) + '%';
                            return label + ': ' + value + ' (' + percentage + ')';
                        }
                    }
                }
            }
        }
    });
});
</script>
@endsection
