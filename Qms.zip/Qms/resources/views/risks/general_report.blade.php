<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Yönetim Risk Analiz Raporu - {{ date('Y') }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');

        body { font-family: 'Inter', sans-serif; background: #525659; padding: 20px; }
        
        /* A4 Page Setup */
        .page {
            background: white;
            width: 210mm;
            min-height: 297mm;
            margin: 0 auto;
            padding: 15mm;
            position: relative;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        /* Header Table */
        .header-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; border: 2px solid #000; }
        .header-table td { border: 1px solid #000; padding: 10px; vertical-align: middle; text-align: center; }
        .logo-img { max-height: 60px; }

        /* Titles */
        .section-title {
            background: #1e293b; color: white;
            padding: 8px 15px; font-weight: 700;
            text-transform: uppercase; font-size: 0.9rem;
            margin-top: 25px; margin-bottom: 15px;
            border-left: 5px solid #ef4444;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        /* Summary Boxes */
        .summary-box {
            border: 1px solid #ddd; padding: 15px; text-align: center; border-radius: 8px;
            background: #f8fafc;
        }
        .summary-val { font-size: 1.8rem; font-weight: 800; color: #1e293b; display: block; line-height: 1; }
        .summary-label { font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 600; margin-top: 5px; }

        /* --- HEATMAP TABLE FIX (YENİ DÜZEN) --- */
        .heatmap-table {
            border-collapse: separate;
            border-spacing: 4px; /* Hücreler arası boşluk */
            margin: 0 auto;
        }
        .heatmap-table td {
            text-align: center;
            vertical-align: middle;
            padding: 0;
        }
        
        /* Eksen Etiketleri */
        .axis-y-text {
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            font-weight: bold;
            font-size: 0.8rem;
            color: #64748b;
            height: 150px;
            text-align: center;
        }
        .axis-x-text {
            font-weight: bold;
            font-size: 0.8rem;
            color: #64748b;
            padding-top: 10px !important;
        }
        .axis-num {
            font-weight: bold;
            color: #64748b;
            font-size: 0.9rem;
            width: 20px;
        }

        /* Hücre Tasarımı */
        .h-cell {
            width: 55px; height: 55px;
            border: 1px solid #e2e8f0;
            border-radius: 4px;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            position: relative;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        .h-cell span {
            display: block;
            font-size: 0.55rem;
            font-weight: normal;
            opacity: 0.9;
            margin-top: -2px;
        }

        /* Renkler */
        .bg-low { background-color: #22c55e !important; border-color: #16a34a !important; }
        .bg-med { background-color: #eab308 !important; color: #fff !important; border-color: #ca8a04 !important; }
        .bg-high { background-color: #f97316 !important; border-color: #ea580c !important; }
        .bg-crit { background-color: #ef4444 !important; border-color: #dc2626 !important; }
        .bg-empty { background-color: #f1f5f9 !important; border: 1px dashed #cbd5e1 !important; color: transparent !important; }

        /* Risk Table */
        .risk-table { width: 100%; font-size: 0.75rem; border-collapse: collapse; }
        .risk-table th { background: #f1f5f9; font-weight: 700; text-transform: uppercase; padding: 8px; border: 1px solid #cbd5e1; -webkit-print-color-adjust: exact; }
        .risk-table td { padding: 6px; border: 1px solid #e2e8f0; vertical-align: top; }
        
        /* Print Settings */
        @media print {
            body { background: none; padding: 0; }
            .page { margin: 0; width: 100%; box-shadow: none; border: none; padding: 0; }
            .no-print { display: none !important; }
            .page-break { page-break-after: always; }
            canvas { max-width: 100% !important; max-height: 250px !important; }
        }
    </style>
</head>
<body>

    <div class="text-center mb-4 no-print">
        <button onclick="window.print()" class="btn btn-primary btn-lg shadow">
            <i class="fa-solid fa-print me-2"></i> Raporu Yazdır / PDF İndir
        </button>
        <button onclick="window.close()" class="btn btn-secondary btn-lg shadow ms-2">Kapat</button>
    </div>

    <div class="page">
        
        <table class="header-table">
            <tr>
                <td width="20%">
                    <img src="{{ asset('assets/img/logo.png') }}" class="logo-img" alt="Logo">
                    <br><strong>LABORATUVAR A.Ş.</strong>
                </td>
                <td width="60%">
                    <h3 class="m-0 fw-bold">RİSK DEĞERLENDİRME VE ANALİZ RAPORU</h3>
                    <small>ISO/IEC 17025:2017 - Madde 8.5 Risk ve Fırsatlar</small>
                </td>
                <td width="20%" class="text-start fs-6" style="font-size: 0.7rem !important;">
                    <div><strong>Dok. No:</strong> FR-RISK-01</div>
                    <div><strong>Yayın T.:</strong> 01.01.2024</div>
                    <div><strong>Rev. No:</strong> 03</div>
                    <div><strong>Sayfa:</strong> 1 / 2</div>
                </td>
            </tr>
        </table>

        <div class="section-title">1. Yönetici Özeti ve İstatistikler</div>
        <div class="row g-2 mb-4">
            <div class="col-3">
                <div class="summary-box" style="border-top: 3px solid #6366f1;">
                    <span class="summary-val">{{ $stats['total'] }}</span>
                    <span class="summary-label">Toplam Risk</span>
                </div>
            </div>
            <div class="col-3">
                <div class="summary-box" style="border-top: 3px solid #ef4444;">
                    <span class="summary-val text-danger">{{ $stats['critical'] }}</span>
                    <span class="summary-label text-danger">Kritik Seviye</span>
                </div>
            </div>
            <div class="col-3">
                <div class="summary-box" style="border-top: 3px solid #f97316;">
                    <span class="summary-val text-warning">{{ $stats['high'] }}</span>
                    <span class="summary-label text-warning">Yüksek Seviye</span>
                </div>
            </div>
            <div class="col-3">
                <div class="summary-box" style="border-top: 3px solid #22c55e;">
                    <span class="summary-val text-success">{{ $stats['open'] }}</span>
                    <span class="summary-label text-success">Aktif/Açık Risk</span>
                </div>
            </div>
        </div>

        <div class="section-title">2. Risk Dağılımı ve Trend Analizi</div>
        
        <div class="row align-items-center">
            
            <div class="col-6 text-center border-end">
                <h6 class="fw-bold mb-3 text-muted">Risk Isı Haritası (Olasılık x Etki)</h6>
                
                <table class="heatmap-table">
                    @for($p = 5; $p >= 1; $p--)
                        <tr>
                            @if($p == 5)
                                <td rowspan="6" class="axis-y-text">OLASILIK</td>
                            @endif
                            
                            <td class="axis-num">{{ $p }}</td>
                            
                            @for($i = 1; $i <= 5; $i++)
                                @php
                                    $score = $p * $i;
                                    $count = $matrix[$p][$i] ?? 0;
                                    $bg = 'bg-empty';
                                    if ($count > 0) {
                                        if ($score >= 16) $bg = 'bg-crit';
                                        elseif ($score >= 10) $bg = 'bg-high';
                                        elseif ($score >= 5) $bg = 'bg-med';
                                        else $bg = 'bg-low';
                                    }
                                @endphp
                                <td class="h-cell {{ $bg }}">
                                    @if($count > 0)
                                        {{ $count }}
                                        <span>(Skor:{{ $score }})</span>
                                    @endif
                                </td>
                            @endfor
                        </tr>
                    @endfor

                    <tr>
                        <td></td> <td class="axis-num">1</td>
                        <td class="axis-num">2</td>
                        <td class="axis-num">3</td>
                        <td class="axis-num">4</td>
                        <td class="axis-num">5</td>
                    </tr>
                    
                    <tr>
                        <td></td>
                        <td colspan="6" class="axis-x-text">ŞİDDET / ETKİ</td>
                    </tr>
                </table>

            </div>

            <div class="col-6">
                <h6 class="fw-bold mb-3 text-muted text-center">Son 6 Aylık Risk Tespit Trendi</h6>
                <div style="height: 200px; width: 100%;">
                    <canvas id="reportTrendChart"></canvas>
                </div>
            </div>
        </div>

        <div class="section-title mt-4">3. Yönetim Değerlendirmesi ve Karar</div>
        <div class="border p-3 rounded" style="height: 120px; border-style: dashed !important; border-color: #cbd5e1;">
            <p class="text-muted small mb-0">
                Bu alana Kalite Yönetim Temsilcisi veya Laboratuvar Müdürü tarafından risk analizi sonucuna dair genel değerlendirme notları el ile yazılacaktır.
                <br><br>
                <strong>Karar:</strong> .........................................................................................................................................
            </p>
        </div>

        <div class="mt-5 pt-3 border-top d-flex justify-content-between text-center">
            <div style="width: 30%">
                <strong>Hazırlayan</strong><br>
                Kalite Yön. Temsilcisi<br>
                <br>İmza
            </div>
            <div style="width: 30%">
                <strong>Kontrol Eden</strong><br>
                Laboratuvar Müdürü<br>
                <br>İmza
            </div>
            <div style="width: 30%">
                <strong>Onaylayan</strong><br>
                Genel Müdür<br>
                <br>İmza
            </div>
        </div>
    </div>

    <div class="page page-break">
        
        <table class="header-table">
            <tr>
                <td width="20%"><strong>LABORATUVAR A.Ş.</strong></td>
                <td width="60%"><strong>RİSK ENVANTER LİSTESİ</strong></td>
                <td width="20%" style="font-size: 0.7rem;">Sayfa: 2 / 2</td>
            </tr>
        </table>

        <div class="section-title mt-0">4. Risk Envanteri ve Mevcut Durum</div>

        <table class="risk-table">
            <thead>
                <tr>
                    <th width="8%">KOD</th>
                    <th width="25%">RİSK TANIMI</th>
                    <th width="15%">KATEGORİ & KAYNAK</th>
                    <th width="12%">DEPARTMAN</th>
                    <th width="8%" class="text-center">İLK<br>SKOR</th>
                    <th width="8%" class="text-center">MEVCUT<br>SKOR</th>
                    <th width="10%">DURUM</th>
                    <th width="14%">ALINAN AKSİYON</th>
                </tr>
            </thead>
            <tbody>
                @foreach($risks as $risk)
                    <tr>
                        <td><strong>{{ $risk->code }}</strong></td>
                        <td>{{ $risk->description }}</td>
                        <td>
                            <div class="fw-bold">{{ $risk->category }}</div>
                            <small class="text-muted">{{ Str::limit($risk->source, 20) }}</small>
                        </td>
                        <td>{{ $risk->department->name ?? 'Genel' }}</td>
                        
                        {{-- SKOR RENKLENDİRME --}}
                        @php
                            $score = $risk->risk_score;
                            $color = 'text-dark';
                            if($score >= 16) $color = 'text-danger fw-bold';
                            elseif($score >= 10) $color = 'text-warning fw-bold';
                        @endphp

                        <td class="text-center bg-light">{{ $score }}</td>
                        <td class="text-center {{ $color }}" style="font-size: 1.1em;">{{ $score }}</td>
                        
                        <td>
                            @if($risk->status == 'Closed') <span class="badge bg-success text-white border-0">KAPALI</span>
                            @elseif($risk->status == 'Open') <span class="badge bg-danger text-white border-0">AÇIK</span>
                            @else <span class="badge bg-warning text-dark border-0">İŞLEMDE</span>
                            @endif
                        </td>
                        <td>
                            @if($risk->capas->count() > 0)
                                {{ $risk->capas->first()->code }} - DÖF
                            @else
                                -
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="mt-4 small text-muted">
            * <strong>İlk Skor:</strong> Riskin tespit edildiği andaki ham skoru.<br>
            * <strong>Mevcut Skor:</strong> Alınan önleyici faaliyetler (DÖF) sonrası düşürülen güncel skor.
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const ctx = document.getElementById('reportTrendChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: {!! json_encode($trendLabels) !!},
                    datasets: [{
                        label: 'Risk Kaydı',
                        data: {!! json_encode($trendValues) !!},
                        borderColor: '#1e293b',
                        backgroundColor: 'rgba(30, 41, 59, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.3,
                        pointRadius: 3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    animation: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { beginAtZero: true, ticks: { stepSize: 1 } },
                        x: { grid: { display: false } }
                    }
                }
            });
        });
    </script>

</body>
</html>