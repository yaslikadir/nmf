@extends('layouts.admin')
@section('title', 'Risk ve Fırsat Yönetimi')

@section('content')
<div class="container-fluid px-4 mt-4">

    {{-- ÜST İSTATİSTİK KARTLARI --}}
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="small text-white-50">Toplam Kayıt</div>
                        <div class="fs-4 fw-bold">{{ $stats['total'] }}</div>
                    </div>
                    <i class="fas fa-list fa-2x text-white-50"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-danger text-white mb-4 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="small text-white-50">Kritik Riskler</div>
                        <div class="fs-4 fw-bold">{{ $stats['critical'] }}</div>
                    </div>
                    <i class="fas fa-exclamation-triangle fa-2x text-white-50"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="small text-white-50">Fırsatlar</div>
                        <div class="fs-4 fw-bold">{{ $stats['opportunities'] }}</div>
                    </div>
                    <i class="fas fa-lightbulb fa-2x text-white-50"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="small text-white-50">Yeni Kayıt</div>
                        <a href="{{ route('admin.qms.risks.create') }}" class="btn btn-sm btn-light text-dark fw-bold stretched-link">Risk Tanımla</a>
                    </div>
                    <i class="fas fa-plus-circle fa-2x text-white-50"></i>
                </div>
            </div>
        </div>
    </div>

    {{-- FİLTRELEME VE LİSTE --}}
    <div class="card mb-4 shadow-sm border-0 border-top-lg border-primary">
        <div class="card-header bg-white">
            <i class="fas fa-table me-1"></i>Risk ve Fırsat Kayıtları
        </div>
        <div class="card-body">
            
            {{-- Filtre Formu --}}
            <form method="GET" action="{{ route('admin.qms.risks.index') }}" class="row g-3 mb-4 p-3 bg-light rounded">
                <div class="col-md-3">
                    <label class="form-label small fw-bold">Kayıt Türü</label>
                    <select name="type" class="form-select form-select-sm">
                        <option value="">Tümü</option>
                        <option value="Risk" {{ request('type') == 'Risk' ? 'selected' : '' }}>Risk</option>
                        <option value="Opportunity" {{ request('type') == 'Opportunity' ? 'selected' : '' }}>Fırsat</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold">Risk Seviyesi</label>
                    <select name="risk_level" class="form-select form-select-sm">
                        <option value="">Tümü</option>
                        <option value="Critical" {{ request('risk_level') == 'Critical' ? 'selected' : '' }}>🔴 Kritik</option>
                        <option value="High" {{ request('risk_level') == 'High' ? 'selected' : '' }}>🟠 Yüksek</option>
                        <option value="Medium" {{ request('risk_level') == 'Medium' ? 'selected' : '' }}>🟡 Orta</option>
                        <option value="Low" {{ request('risk_level') == 'Low' ? 'selected' : '' }}>🟢 Düşük</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold">Departman</label>
                    <select name="department_id" class="form-select form-select-sm">
                        <option value="">Tümü</option>
                        @foreach($departments as $dept)
                            <option value="{{ $dept->id }}" {{ request('department_id') == $dept->id ? 'selected' : '' }}>{{ $dept->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-filter me-1"></i> Filtrele</button>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Kod</th>
                            <th>Tür</th>
                            <th>Kategori / Tanım</th>
                            <th>Departman</th>
                            <th class="text-center">P x Ş = Skor</th>
                            <th class="text-center">Seviye</th>
                            <th>Sorumlu</th>
                            <th>Durum</th>
                            <th width="100">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($risks as $risk)
                            <tr>
                                <td class="fw-bold text-primary small">{{ $risk->code }}</td>
                                <td>
                                    @if($risk->type == 'Risk')
                                        <span class="badge bg-danger">Risk</span>
                                    @else
                                        <span class="badge bg-success">Fırsat</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="fw-bold">{{ $risk->category }}</div>
                                    <div class="small text-muted text-truncate" style="max-width: 250px;">{{ $risk->description }}</div>
                                </td>
                                <td><span class="badge bg-light text-dark border">{{ $risk->department->name ?? '-' }}</span></td>
                                <td class="text-center fw-bold text-dark">
                                    {{ $risk->probability }} x {{ $risk->impact }} = {{ $risk->risk_score }}
                                </td>
                                <td class="text-center">
                                    @php
                                        $colors = [
                                            'Critical' => 'danger',
                                            'High' => 'warning text-dark',
                                            'Medium' => 'info text-dark',
                                            'Low' => 'success'
                                        ];
                                        $labels = [
                                            'Critical' => 'KRİTİK',
                                            'High' => 'YÜKSEK',
                                            'Medium' => 'ORTA',
                                            'Low' => 'DÜŞÜK'
                                        ];
                                    @endphp
                                    <span class="badge bg-{{ $colors[$risk->risk_level] ?? 'secondary' }}">
                                        {{ $labels[$risk->risk_level] ?? $risk->risk_level }}
                                    </span>
                                </td>
                                <td class="small">
                                    <i class="fas fa-user-circle me-1 text-muted"></i>{{ $risk->owner->name ?? '-' }}
                                </td>
                                <td>
    @php
        $statusLabels = [
            'Open' => 'Açık',
            'In_Progress' => 'İşlemde',
            'Monitoring' => 'İzleniyor',
            'Closed' => 'Kapalı',
            'Cancelled' => 'İptal'
        ];
        $statusColors = [
            'Open' => 'primary',
            'In_Progress' => 'warning text-dark',
            'Monitoring' => 'info text-dark',
            'Closed' => 'secondary',
            'Cancelled' => 'dark'
        ];
    @endphp
    <span class="badge rounded-pill bg-{{ $statusColors[$risk->status] ?? 'secondary' }}">
        {{ $statusLabels[$risk->status] ?? $risk->status }}
    </span>
</td>
                                <td>
                                    <a href="{{ route('admin.qms.risks.show', $risk->id) }}" class="btn btn-sm btn-outline-dark w-100">
                                        <i class="fas fa-eye"></i> İncele
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="9" class="text-center py-4 text-muted">Kayıt bulunamadı.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            <div class="mt-3">
                {{ $risks->withQueryString()->links() }}
            </div>
        </div>
    </div>
</div>
@endsection