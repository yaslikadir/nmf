@extends('layouts.admin')
@section('title', 'Yeni Risk / Fırsat Tanımla')

@section('content')
<div class="container-fluid px-4 mt-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">
            <span class="text-primary"><i class="fas fa-plus-circle me-2"></i>Yeni Risk / Fırsat</span> Tanımla
        </h4>
        <a href="{{ route('admin.qms.risks.index') }}" class="btn btn-secondary btn-sm shadow-sm">
            <i class="fas fa-arrow-left me-1"></i> Listeye Dön
        </a>
    </div>

    <form action="{{ route('admin.qms.risks.store') }}" method="POST">
        @csrf
        <div class="row">
            {{-- SOL TARAFA: TEMEL BİLGİLER --}}
            <div class="col-lg-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-white fw-bold">
                        <i class="fas fa-info-circle me-2 text-info"></i>Risk Kimliği ve Tanımı
                    </div>
                    <div class="card-body">
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold small required">Kayıt Türü</label>
                                <select name="type" class="form-select bg-light" required>
                                    <option value="Risk">🔴 Risk (Tehdit)</option>
                                    <option value="Opportunity">🟢 Fırsat (Gelişim)</option>
                                </select>
                                <small class="text-muted">Olumsuz durumlar için Risk, iyileştirmeler için Fırsat seçiniz.</small>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small required">Kategori</label>
                                <select name="category" class="form-select" required>
                                    <option value="">Seçiniz...</option>
                                    <option value="Process">Süreç / Operasyonel</option>
                                    <option value="Equipment">Cihaz / Ekipman</option>
                                    <option value="Personnel">Personel / Yetkinlik</option>
                                    <option value="Impartiality">Tarafsızlık / Gizlilik</option>
                                    <option value="Environmental">Çevresel Şartlar</option>
                                    <option value="OHS">İş Sağlığı ve Güvenliği</option>
                                    <option value="Financial">Finansal / İtibar</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small required">Risk / Fırsat Tanımı</label>
                            <textarea name="description" class="form-control" rows="3" placeholder="Örn: Cihaz kalibrasyonunun zamanında yapılmaması sonucu hatalı raporlama..." required></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small">Riskin Kaynağı / Kök Neden</label>
                            <textarea name="source" class="form-control" rows="2" placeholder="Örn: Yedek parça tedarik süresinin uzun olması..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small required">Olası Etki / Sonuç</label>
                            <textarea name="potential_impact" class="form-control" rows="2" placeholder="Örn: Analiz raporlarının geçersiz sayılması, müşteri güven kaybı..." required></textarea>
                            <small class="text-muted">Bu risk gerçekleşirse laboratuvara etkisi ne olur?</small>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label fw-bold small required">İlgili Departman</label>
                                <select name="department_id" class="form-select" required>
                                    <option value="">Seçiniz...</option>
                                    @foreach($departments as $dept)
                                        <option value="{{ $dept->id }}">{{ $dept->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small required">Risk Sahibi / Sorumlu</label>
                                <select name="owner_id" class="form-select" required>
                                    <option value="">Seçiniz...</option>
                                    @foreach($users as $user)
                                        <option value="{{ $user->id }}">{{ $user->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            {{-- SAĞ TARAF: PUANLAMA --}}
            <div class="col-lg-4">
                <div class="card shadow-sm mb-4 border-start border-4 border-warning">
                    <div class="card-header bg-white fw-bold">
                        <i class="fas fa-calculator me-2 text-warning"></i>Risk Değerlendirme (5x5)
                    </div>
                    <div class="card-body">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold small required">Olasılık (P)</label>
                            <select name="probability" id="probability" class="form-select" required onchange="calculateScore()">
                                <option value="1">1 - Çok Düşük (Yılda bir)</option>
                                <option value="2">2 - Düşük (3-6 ayda bir)</option>
                                <option value="3">3 - Orta (Ayda bir)</option>
                                <option value="4">4 - Yüksek (Haftada bir)</option>
                                <option value="5">5 - Çok Yüksek (Her gün)</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small required">Etki / Şiddet (I)</label>
                            <select name="impact" id="impact" class="form-select" required onchange="calculateScore()">
                                <option value="1">1 - Çok Düşük (Hissedilmez)</option>
                                <option value="2">2 - Düşük (Küçük kayıp)</option>
                                <option value="3">3 - Orta (Süreç aksaması)</option>
                                <option value="4">4 - Yüksek (Müşteri kaybı)</option>
                                <option value="5">5 - Çok Yüksek (Yasal ceza/Kapanma)</option>
                            </select>
                        </div>

                        <hr>

                        <div class="text-center p-3 rounded bg-light border">
                            <div class="small text-muted mb-1">Hesaplanan Risk Skoru</div>
                            <h2 class="fw-bold m-0" id="scoreDisplay">1</h2>
                            <div id="riskLevelBadge" class="badge bg-success mt-2">DÜŞÜK SEVİYE</div>
                        </div>

                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary fw-bold p-3">
                        <i class="fas fa-save me-1"></i> KAYDET VE ANALİZ ET
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
    function calculateScore() {
        var p = document.getElementById('probability').value;
        var i = document.getElementById('impact').value;
        var score = p * i;
        
        document.getElementById('scoreDisplay').innerText = score;

        var badge = document.getElementById('riskLevelBadge');
        
        // 17025 Standardına uygun basit risk matrisi mantığı
        if(score >= 15) {
            badge.className = 'badge bg-danger mt-2';
            badge.innerText = 'KRİTİK SEVİYE (ACİL ÖNLEM)';
        } else if (score >= 8) {
            badge.className = 'badge bg-warning text-dark mt-2';
            badge.innerText = 'YÜKSEK SEVİYE (PLANLI ÖNLEM)';
        } else if (score >= 4) {
            badge.className = 'badge bg-info text-dark mt-2';
            badge.innerText = 'ORTA SEVİYE (İZLEME)';
        } else {
            badge.className = 'badge bg-success mt-2';
            badge.innerText = 'DÜŞÜK SEVİYE (KABUL EDİLEBİLİR)';
        }
    }
</script>
@endsection