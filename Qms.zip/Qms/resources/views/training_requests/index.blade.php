@extends('layouts.admin')
@section('title', 'Eğitim Talepleri')

@section('content')
<div class="container-fluid px-4 mt-4">
    <h4 class="fw-bold text-gray-800 mb-4"><i class="fas fa-inbox me-2 text-primary"></i>Personel Eğitim Talepleri</h4>

    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-white">
            <h6 class="m-0 font-weight-bold text-primary">Talep Havuzu</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Tarih</th>
                            <th>Personel</th>
                            <th>Talep Edilen Konu</th>
                            <th>Öncelik</th>
                            <th>Durum</th>
                            <th style="width: 180px;">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($requests as $req)
                        <tr class="{{ $req->status == 'Pending' ? 'table-warning' : '' }}">
                            <td>{{ $req->created_at->format('d.m.Y') }}</td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 35px; height: 35px;">
                                        {{ substr($req->user->name, 0, 1) }}
                                    </div>
                                    <div>
                                        <div class="fw-bold">{{ $req->user->name }}</div>
                                        <div class="small text-muted">{{ $req->user->department->name ?? 'Departman Yok' }}</div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="fw-bold text-dark">{{ $req->subject }}</span>
                                @if($req->description)
                                    <div class="small text-muted mt-1"><i class="fas fa-quote-left me-1"></i>{{ $req->description }}</div>
                                @endif
                            </td>
                            <td>
                                @if($req->priority == 'Acil')
                                    <span class="badge bg-danger"><i class="fas fa-exclamation-circle me-1"></i>ACİL</span>
                                @else
                                    <span class="badge bg-secondary">Normal</span>
                                @endif
                            </td>
                            <td>
                                @if($req->status == 'Pending')
                                    <span class="badge bg-warning text-dark">Bekliyor</span>
                                @elseif($req->status == 'Approved')
                                    <span class="badge bg-info">Onaylandı</span>
                                @elseif($req->status == 'Planned')
                                    <span class="badge bg-success">Planlandı</span>
                                @else
                                    <span class="badge bg-secondary">Reddedildi</span>
                                @endif
                            </td>
                            <td>
                                {{-- AKSİYON BUTONLARI --}}
                                @if($req->status == 'Pending')
                                    <div class="btn-group w-100">
                                        {{-- PLANLA BUTONU: Mevcut Plan Oluşturma Sayfasına Veri Taşıyacak --}}
                                        <a href="{{ route('admin.qms.plans.create', ['request_id' => $req->id, 'user_id' => $req->user_id, 'subject' => $req->subject]) }}" 
                                           class="btn btn-sm btn-success" title="Direkt Plan Oluştur">
                                            <i class="fas fa-calendar-plus"></i> Planla
                                        </a>

                                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal{{ $req->id }}" title="Reddet">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                @elseif($req->status == 'Planned')
                                    <button class="btn btn-sm btn-outline-success w-100" disabled><i class="fas fa-check-double me-1"></i>İşlem Tamam</button>
                                @else
                                    <span class="text-muted small">İşlem yapıldı</span>
                                @endif
                            </td>
                        </tr>

                        {{-- REDDETME MODALI --}}
                        <div class="modal fade" id="rejectModal{{ $req->id }}" tabindex="-1">
                            <div class="modal-dialog">
                                <form action="{{ route('admin.qms.requests.update', $req->id) }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="status" value="Rejected">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Talebi Reddet</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p><strong>{{ $req->user->name }}</strong> kişisinin <strong>{{ $req->subject }}</strong> eğitim talebini reddetmek üzeresiniz.</p>
                                            <div class="mb-3">
                                                <label>Red Sebebi (Opsiyonel)</label>
                                                <textarea name="admin_note" class="form-control" rows="2"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                                            <button type="submit" class="btn btn-danger">Reddet</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        @empty
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">
                                <i class="fas fa-inbox fa-3x mb-3 text-gray-300"></i><br>
                                Henüz bekleyen bir eğitim talebi yok.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection