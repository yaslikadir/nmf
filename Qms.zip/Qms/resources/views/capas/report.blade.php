<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <title>DÖF Formu - {{ $capa->code }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 12px; color: #000; }
        .report-header { border: 2px solid #000; padding: 15px; margin-bottom: 20px; }
        .section-box { border: 1px solid #000; padding: 10px; margin-bottom: 15px; page-break-inside: avoid; }
        .section-title { font-weight: bold; background-color: #eee; padding: 5px; border-bottom: 1px solid #000; margin: -10px -10px 10px -10px; display: block; }
        .table-bordered th, .table-bordered td { border-color: #000 !important; }
        
        @media print {
            .no-print { display: none !important; }
            body { font-size: 11px; }
            .section-title { background-color: #ddd !important; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body class="p-4">

    {{-- YAZDIR BUTONU --}}
    <div class="no-print mb-4 text-end">
        <button onclick="window.print()" class="btn btn-dark fw-bold">
            <i class="fas fa-print me-1"></i> YAZDIR
        </button>
        <button onclick="window.close()" class="btn btn-secondary">Kapat</button>
    </div>

    {{-- BAŞLIK --}}
    <table class="table table-bordered mb-4" style="border-color: #000;">
        <tr>
            <td width="20%" class="text-center align-middle fw-bold">
                {{ config('app.name') }}
            </td>
            <td width="60%" class="text-center align-middle">
                <h4 class="mb-0 fw-bold">DÜZELTİCİ ÖNLEYİCİ FAALİYET (DÖF) FORMU</h4>
            </td>
            <td width="20%" class="small">
                <div><strong>Form No:</strong> FR-QMS-05</div>
                <div><strong>Yayın Tarihi:</strong> {{ now()->format('d.m.Y') }}</div>
                <div><strong>DÖF No:</strong> {{ $capa->code }}</div>
            </td>
        </tr>
    </table>

    {{-- BÖLÜM 1: UYGUNSUZLUK TANIMI --}}
    <div class="section-box">
        <span class="section-title">1. UYGUNSUZLUK TANIMI VE KAYNAĞI</span>
        <table class="table table-borderless mb-0 small">
            <tr>
                <td width="15%" class="fw-bold">Kaynak:</td>
                <td width="35%">{{ $capa->source_label }}</td>
                <td width="15%" class="fw-bold">İlgili Birim:</td>
                <td width="35%">{{ $capa->department->name ?? 'Genel' }}</td>
            </tr>
            <tr>
                <td class="fw-bold">Tespit Tarihi:</td>
                <td>{{ $capa->created_at->format('d.m.Y') }}</td>
                <td class="fw-bold">Sorumlu:</td>
                <td>{{ $capa->lead->name }}</td>
            </tr>
            <tr>
                <td colspan="4"><hr class="my-1"></td>
            </tr>
            <tr>
                <td class="fw-bold">Konu:</td>
                <td colspan="3">{{ $capa->subject }}</td>
            </tr>
            <tr>
                <td class="fw-bold">Detaylı Açıklama:</td>
                <td colspan="3">{!! nl2br(e($capa->description)) !!}</td>
            </tr>
        </table>
    </div>

    {{-- BÖLÜM 2: KÖK NEDEN ANALİZİ --}}
    <div class="section-box">
        <span class="section-title">2. KÖK NEDEN ANALİZİ</span>
        <div class="mb-2">
            <strong>Acil Önlem:</strong> {{ $capa->immediate_action ?? 'Belirtilmedi.' }}
        </div>
        <div>
            <strong>Kök Neden:</strong>
            <p class="mt-1 mb-0">{!! nl2br(e($capa->root_cause ?? 'Henüz analiz yapılmadı.')) !!}</p>
        </div>
    </div>

    {{-- BÖLÜM 3: AKSİYONLAR --}}
    <div class="section-box">
        <span class="section-title">3. PLANLANAN FAALİYETLER (AKSİYONLAR)</span>
        <table class="table table-bordered table-sm mb-0 text-center">
            <thead>
                <tr style="background-color: #f8f9fa;">
                    <th>Yapılacak İş</th>
                    <th>Sorumlu</th>
                    <th>Termin</th>
                    <th>Tamamlanma Tarihi</th>
                    <th>Sonuç / Kanıt</th>
                </tr>
            </thead>
            <tbody>
                @forelse($capa->actions as $action)
                <tr>
                    <td class="text-start">{{ $action->action_description }}</td>
                    <td>{{ $action->responsible->name }}</td>
                    <td>{{ $action->due_date->format('d.m.Y') }}</td>
                    <td>{{ $action->completed_at ? $action->completed_at->format('d.m.Y') : '-' }}</td>
                    <td class="text-start small">{{ $action->completion_note ?? '-' }}</td>
                </tr>
                @empty
                <tr><td colspan="5">Aksiyon bulunamadı.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- BÖLÜM 4: KAPATMA VE ONAY --}}
    <div class="section-box" style="page-break-inside: avoid;">
        <span class="section-title">4. DOĞRULAMA VE KAPATMA</span>
        
        <table class="table table-bordered mb-0 text-center" style="border-color: #000;">
            <tr>
                <td width="33%" style="height: 100px; vertical-align: top;">
                    <div class="fw-bold mb-4">DÖF Sorumlusu</div>
                    <div>{{ $capa->lead->name }}</div>
                    <div class="small text-muted mt-4">İmza</div>
                </td>
                <td width="33%" style="height: 100px; vertical-align: top;">
                    <div class="fw-bold mb-4">Birim Yöneticisi</div>
                    <div>.............................</div>
                    <div class="small text-muted mt-4">İmza</div>
                </td>
                <td width="33%" style="height: 100px; vertical-align: top;">
                    <div class="fw-bold mb-4">Kalite Yöneticisi</div>
                    @if($capa->status == 'Closed')
                        <div class="text-success fw-bold">ONAYLANDI</div>
                        <div>{{ $capa->closed_date->format('d.m.Y') }}</div>
                    @else
                        <div>.............................</div>
                    @endif
                    <div class="small text-muted mt-2">İmza</div>
                </td>
            </tr>
        </table>
        
        <div class="mt-2 small">
            <strong>Sonuç:</strong> 
            @if($capa->status == 'Closed')
                Faaliyetler etkin bir şekilde uygulanmış ve uygunsuzluk giderilmiştir.
            @else
                Süreç devam etmektedir.
            @endif
        </div>
    </div>

</body>
</html>