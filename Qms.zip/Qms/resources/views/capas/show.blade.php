@extends('layouts.admin')
@section('title', $capa->code . ' Detayı')

@section('content')
<div class="container-fluid px-4 mt-4">

    {{-- ÜST BAŞLIK VE DURUM --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800 mb-0">
                <i class="fas fa-tools me-2 text-danger"></i>{{ $capa->code }}
            </h4>
            <div class="text-muted small mt-1">
                {{ $capa->subject }}
            </div>
        </div>
        <div>
            {{-- DURUM ROZETİ --}}
            <span class="badge {{ $capa->status_label['class'] }} fs-6 shadow-sm">
                {{ $capa->status_label['text'] }}
            </span>
            
            {{-- RAPOR YAZDIR BUTONU --}}
            <a href="{{ route('admin.qms.capas.report', $capa->id) }}" target="_blank" class="btn btn-dark btn-sm ms-2 shadow-sm">
                <i class="fas fa-print me-1"></i> Formu Yazdır
            </a>

            <a href="{{ route('admin.qms.capas.index') }}" class="btn btn-secondary btn-sm ms-2 shadow-sm">Geri Dön</a>
        </div>
    </div>

    <div class="row">
        
        {{-- SOL KOLON: BİLGİLER VE ANALİZ --}}
        <div class="col-lg-8">
            
            {{-- 1. TANIMLAMA KARTI --}}
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light fw-bold text-dark">
                    <i class="fas fa-info-circle me-2"></i>1. Uygunsuzluk Tanımı
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="small fw-bold text-muted">Kaynak</label>
                            <div class="fw-bold">{{ $capa->source_label }}</div>
                            
                            @if($capa->auditFinding)
                                <a href="{{ route('admin.qms.audits.perform', $capa->auditFinding->audit_id) }}" class="badge bg-warning text-dark text-decoration-none mt-1">
                                    <i class="fas fa-link me-1"></i> Denetim Kaydına Git
                                </a>
                            @endif
                        </div>
                        <div class="col-md-6">
                            <label class="small fw-bold text-muted">İlgili Departman</label>
                            <div>{{ $capa->department->name ?? 'Genel' }}</div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold text-muted">Detaylı Açıklama</label>
                        <div class="bg-light p-3 rounded border">
                            {!! nl2br(e($capa->description)) !!}
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="small fw-bold text-muted">Sorumlu (Lider)</label>
                            <div class="d-flex align-items-center">
                                <div class="avatar avatar-xs bg-primary text-white rounded-circle me-2 d-flex justify-content-center align-items-center" style="width:24px; height:24px;">
                                    {{ substr($capa->lead->name, 0, 1) }}
                                </div>
                                {{ $capa->lead->name }}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="small fw-bold text-muted">Hedef Tarih</label>
                            <div class="fw-bold {{ $capa->target_date < now() && $capa->status != 'Closed' ? 'text-danger' : 'text-dark' }}">
                                <i class="far fa-calendar-alt me-1"></i> {{ $capa->target_date ? $capa->target_date->format('d.m.Y') : '-' }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- 2. KÖK NEDEN ANALİZİ --}}
            <div class="card shadow-sm mb-4 border-top-lg border-warning">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-microscope me-2 text-warning"></i>2. Kök Neden Analizi & Acil Önlem</span>
                    @if($capa->status == 'Root_Cause_Analysis')
                        <span class="badge bg-warning text-dark">Bekleniyor</span>
                    @else
                        <span class="badge bg-success"><i class="fas fa-check me-1"></i>Tamamlandı</span>
                    @endif
                </div>
                <div class="card-body">
                    @if($capa->status == 'Root_Cause_Analysis')
                        {{-- ANALİZ FORM MODU --}}
                        <form action="{{ route('admin.qms.capas.save-root-cause', $capa->id) }}" method="POST">
                            @csrf
                            <div class="alert alert-warning small">
                                <i class="fas fa-exclamation-triangle me-1"></i> Lütfen kök neden analizini yapıp kaydedin. Kaydettikten sonra aksiyon planlama aşamasına geçilecektir.
                            </div>
                            <div class="mb-3">
                                <label class="fw-bold small">Acil Önlem (Immediate Action)</label>
                                <textarea name="immediate_action" class="form-control" rows="2" placeholder="Sorunun büyümemesi için anlık ne yapıldı?"></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="fw-bold small">Kök Neden (Root Cause) <span class="text-danger">*</span></label>
                                <textarea name="root_cause" class="form-control" rows="4" required placeholder="Sorunun asıl kaynağı nedir? (5 Neden, Balık Kılçığı vb.)"></textarea>
                            </div>
                            <div class="text-end">
                                <button type="submit" class="btn btn-warning fw-bold text-dark">
                                    <i class="fas fa-save me-1"></i> ANALİZİ KAYDET VE İLERLE
                                </button>
                            </div>
                        </form>
                    @else
                        {{-- ANALİZ OKUMA MODU --}}
                        <div class="mb-3">
                            <label class="small fw-bold text-muted">Acil Önlem</label>
                            <p class="mb-1">{{ $capa->immediate_action ?? '-' }}</p>
                        </div>
                        <div class="mb-0">
                            <label class="small fw-bold text-muted">Tespit Edilen Kök Neden</label>
                            <div class="alert alert-light border border-warning text-dark mb-0">
                                {!! nl2br(e($capa->root_cause)) !!}
                            </div>
                        </div>
                    @endif
                </div>
            </div>

            {{-- 3. AKSİYON PLANLAMA (GÖREVLER) --}}
            @if($capa->status != 'Root_Cause_Analysis' && $capa->status != 'Opened')
            <div class="card shadow-sm mb-4 border-top-lg border-info">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-tasks me-2 text-info"></i>3. Düzeltici Faaliyetler (Aksiyonlar)</span>
                    @if($capa->status != 'Closed')
                        <button class="btn btn-sm btn-info text-white fw-bold" data-bs-toggle="modal" data-bs-target="#addActionModal">
                            <i class="fas fa-plus me-1"></i> Aksiyon Ekle
                        </button>
                    @endif
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light small text-muted">
                                <tr>
                                    <th>Yapılacak İş</th>
                                    <th>Sorumlu</th>
                                    <th>Son Tarih</th>
                                    <th>Durum</th>
                                    <th class="text-end" style="min-width: 100px;">İşlem</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($capa->actions as $action)
                                <tr>
                                    <td>{{ Str::limit($action->action_description, 50) }}</td>
                                    <td>
                                        <span class="badge bg-light text-dark border">{{ $action->responsible->name }}</span>
                                    </td>
                                    <td>
                                        <span class="{{ $action->due_date < now() && $action->status != 'Completed' ? 'text-danger fw-bold' : '' }}">
                                            {{ $action->due_date->format('d.m.Y') }}
                                        </span>
                                    </td>
                                    <td>
                                        @if($action->status == 'Completed')
                                            <span class="badge bg-success"><i class="fas fa-check me-1"></i>Tamam</span>
                                        @else
                                            <span class="badge bg-secondary">Bekliyor</span>
                                        @endif
                                    </td>
                                    <td class="text-end">
                                        {{-- 1. TAMAMLAMA BUTONU --}}
                                        @if($action->status != 'Completed' && $capa->status != 'Closed')
                                            <button class="btn btn-sm btn-outline-success me-1" onclick="openCompleteModal({{ $action->id }})" title="Tamamla">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        @endif

                                        {{-- 2. DETAY GÖRME BUTONU (DÜZELTİLDİ) --}}
                                        {{-- Verileri data- attribute olarak veriyoruz ki JS hatası olmasın --}}
                                        <button class="btn btn-sm btn-outline-primary" 
                                                data-desc="{{ $action->action_description }}"
                                                data-note="{{ $action->completion_note }}"
                                                data-status="{{ $action->status }}"
                                                data-date="{{ $action->completed_at ? $action->completed_at->format('d.m.Y') : '-' }}"
                                                onclick="openDetailModal(this)"
                                                title="Detay Gör">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="5" class="text-center py-3 text-muted">Henüz aksiyon planlanmamış.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            @endif

        </div>

        {{-- SAĞ KOLON: KAPATMA VE ÖZET --}}
        <div class="col-lg-4">
            
            {{-- 4. KAPATMA VE DOĞRULAMA KARTI --}}
            <div class="card shadow-sm mb-4 border-top-lg border-success">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-clipboard-check me-2 text-success"></i>4. Doğrulama & Kapatma
                </div>
                <div class="card-body">
                    @if($capa->status == 'Closed')
                        <div class="text-center py-4">
                            <div class="display-1 text-success mb-3"><i class="fas fa-check-circle"></i></div>
                            <h5 class="fw-bold text-success">DÖF KAPATILDI</h5>
                            <p class="text-muted small">
                                Kapatma Tarihi: {{ $capa->closed_date->format('d.m.Y') }}
                            </p>
                        </div>
                    @else
                        {{-- Kapatma Şartları --}}
                        <ul class="list-group list-group-flush small mb-3">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Kök Neden Analizi Yapıldı mı?
                                @if($capa->root_cause) <i class="fas fa-check text-success"></i> @else <i class="fas fa-times text-danger"></i> @endif
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Aksiyonlar Tamamlandı mı?
                                @php 
                                    $allActionsCompleted = $capa->actions->count() > 0 && $capa->actions->where('status', '!=', 'Completed')->count() == 0;
                                @endphp
                                @if($allActionsCompleted) <i class="fas fa-check text-success"></i> @else <i class="fas fa-times text-danger"></i> @endif
                            </li>
                        </ul>

                        @if($allActionsCompleted && $capa->root_cause)
                            <form action="{{ route('admin.qms.capas.close', $capa->id) }}" method="POST" onsubmit="return confirm('DÖF kaydını kapatmak ve doğrulamak üzeresiniz. Emin misiniz?');">
                                @csrf
                                <div class="alert alert-success small">
                                    <i class="fas fa-check-circle me-1"></i> Tüm şartlar sağlandı. DÖF kapatılabilir.
                                </div>
                                <button class="btn btn-success w-100 fw-bold py-2">
                                    DÖF'Ü KAPAT VE DOĞRULA
                                </button>
                            </form>
                        @else
                            <div class="alert alert-secondary small text-center">
                                DÖF'ü kapatmak için önce analiz yapılmalı ve tüm aksiyonlar tamamlanmalıdır.
                            </div>
                            <button class="btn btn-secondary w-100" disabled>Kapatılamaz</button>
                        @endif
                    @endif
                </div>
            </div>

            {{-- ZAMAN ÇİZELGESİ (Timeline) --}}
            <div class="card shadow-sm">
                <div class="card-header bg-light fw-bold small">Süreç Durumu</div>
                <div class="card-body">
                    <div class="d-flex flex-column gap-3">
                        <div class="d-flex align-items-center text-success">
                            <i class="fas fa-dot-circle me-2"></i> Tanımlama ({{ $capa->created_at->format('d.m.Y') }})
                        </div>
                        <div class="d-flex align-items-center {{ $capa->root_cause ? 'text-success' : 'text-muted' }}">
                            <i class="fas {{ $capa->root_cause ? 'fa-dot-circle' : 'fa-circle' }} me-2"></i> Kök Neden Analizi
                        </div>
                        <div class="d-flex align-items-center {{ $capa->actions->count() > 0 ? 'text-success' : 'text-muted' }}">
                            <i class="fas {{ $capa->actions->count() > 0 ? 'fa-dot-circle' : 'fa-circle' }} me-2"></i> Aksiyon Planlama
                        </div>
                        <div class="d-flex align-items-center {{ $capa->status == 'Closed' ? 'text-success' : 'text-muted' }}">
                            <i class="fas {{ $capa->status == 'Closed' ? 'fa-check-circle' : 'fa-circle' }} me-2"></i> Kapatma
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

{{-- MODAL: AKSİYON EKLEME --}}
<div class="modal fade" id="addActionModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('admin.qms.capas.add-action', $capa->id) }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h6 class="modal-title fw-bold">Yeni Aksiyon / Görev Ekle</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="fw-bold small">Yapılacak İş Tanımı</label>
                        <textarea name="action_description" class="form-control" rows="3" required placeholder="Örn: Personel eğitimi verilecek..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold small">Sorumlu Personel</label>
                        <select name="responsible_user_id" class="form-select" required>
                            @foreach($users as $user)
                                <option value="{{ $user->id }}">{{ $user->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold small">Son Tarih (Termin)</label>
                        <input type="date" name="due_date" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-info text-white fw-bold">KAYDET</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- MODAL: AKSİYON TAMAMLAMA --}}
<div class="modal fade" id="completeActionModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="completeActionForm" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h6 class="modal-title fw-bold">Aksiyonu Tamamla</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Bu görevi tamamlandı olarak işaretliyorsunuz.</p>
                    <div class="mb-3">
                        <label class="fw-bold small">Tamamlama Notu / Kanıt</label>
                        <textarea name="completion_note" class="form-control" rows="3" placeholder="Örn: Eğitim kayıtları ektedir..."></textarea>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-success fw-bold">ONAYLA</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- [YENİ] MODAL: AKSİYON DETAYI GÖRÜNTÜLEME --}}
<div class="modal fade" id="viewActionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h6 class="modal-title fw-bold"><i class="fas fa-info-circle me-2"></i>Aksiyon Detayı</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="small fw-bold text-muted">Yapılacak İş</label>
                    <div class="p-2 bg-light border rounded" id="modalActionDesc"></div>
                </div>
                
                {{-- Tamamlandıysa Görünecek --}}
                <div id="modalCompletionSection" style="display: none;">
                    <hr>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <label class="small fw-bold text-success"><i class="fas fa-check-circle me-1"></i>Tamamlanma Bilgisi</label>
                        <span class="badge bg-success" id="modalCompletedDate"></span>
                    </div>
                    <div class="mb-2">
                        <label class="small fw-bold text-muted">Tamamlama Notu / Kanıt:</label>
                        <div class="p-2 bg-success bg-opacity-10 border border-success rounded text-dark" id="modalActionNote"></div>
                    </div>
                </div>

                {{-- Bekliyorsa Görünecek --}}
                <div id="modalPendingSection">
                    <hr>
                    <span class="badge bg-secondary">Henüz tamamlanmadı</span>
                </div>
            </div>
            <div class="modal-footer py-1">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    // Tamamlama Modalını Aç
    function openCompleteModal(actionId) {
        let url = "{{ route('admin.qms.capas.actions.complete', ':id') }}";
        url = url.replace(':id', actionId);
        document.getElementById('completeActionForm').action = url;
        new bootstrap.Modal(document.getElementById('completeActionModal')).show();
    }

    // [DÜZELTİLDİ] Detay Modalını Aç
    // Artık parametreleri argüman olarak değil, butonun data attribute'larından okuyoruz.
    // Bu sayede satır sonu, tırnak işareti vb. JS hataları oluşmaz.
    function openDetailModal(button) {
        // Verileri butondan oku
        let desc = button.getAttribute('data-desc');
        let note = button.getAttribute('data-note');
        let status = button.getAttribute('data-status');
        let date = button.getAttribute('data-date');

        // Modal Alanlarını Doldur
        document.getElementById('modalActionDesc').innerText = desc;
        
        // Tamamlandı mı kontrol et
        if(status === 'Completed') {
            document.getElementById('modalCompletionSection').style.display = 'block';
            document.getElementById('modalPendingSection').style.display = 'none';
            
            // Not boşsa uyarı yaz
            document.getElementById('modalActionNote').innerText = note ? note : 'Not girilmemiş.';
            document.getElementById('modalCompletedDate').innerText = date;
        } else {
            document.getElementById('modalCompletionSection').style.display = 'none';
            document.getElementById('modalPendingSection').style.display = 'block';
        }

        new bootstrap.Modal(document.getElementById('viewActionModal')).show();
    }
</script>
@endpush