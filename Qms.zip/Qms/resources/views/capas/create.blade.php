@extends('layouts.admin')
@section('title', 'Yeni DÖF')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">Yeni Düzeltici Faaliyet Başlat</h4>
        <a href="{{ route('admin.qms.capas.index') }}" class="btn btn-secondary shadow-sm">Geri</a>
    </div>

    {{-- BİLGİ NOTU: Kaynak Gösterimi --}}
    @if(isset($prefilled['source']))
        <div class="alert alert-info border-left-primary shadow-sm mb-4">
            @if($prefilled['source'] == 'Audit')
                <i class="fas fa-clipboard-check me-2"></i> Bu DÖF, bir <strong>Denetim Bulgusu</strong> üzerinden oluşturuluyor. Bilgiler otomatik aktarıldı.
            @elseif($prefilled['source'] == 'Complaint')
                <i class="fas fa-comment-dots me-2"></i> Bu DÖF, <strong>Müşteri Şikayeti</strong> üzerine başlatılıyor. Müşteri beyanı aşağıya aktarıldı.
            @elseif($prefilled['source'] == 'Risk')
                <i class="fas fa-exclamation-triangle me-2"></i> Bu DÖF, <strong>Risk Analizi</strong> sonucu önleyici tedbir olarak başlatılıyor. Risk detayları aşağıya aktarıldı.
            @endif
        </div>
    @endif

    <div class="card shadow-sm">
        <div class="card-body">
            <form action="{{ route('admin.qms.capas.store') }}" method="POST">
                @csrf
                
                {{-- GİZLİ INPUTLAR (Bağlantı ID'leri) --}}
                @if(isset($prefilled['audit_finding_id']))
                    <input type="hidden" name="audit_finding_id" value="{{ $prefilled['audit_finding_id'] }}">
                @endif

                @if(isset($prefilled['feedback_id']))
                    <input type="hidden" name="feedback_id" value="{{ $prefilled['feedback_id'] }}">
                @endif

                {{-- YENİ: Risk ID --}}
                @if(isset($prefilled['risk_id']))
                    <input type="hidden" name="risk_id" value="{{ $prefilled['risk_id'] }}">
                @endif

                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="fw-bold small">DÖF Konusu / Başlık <span class="text-danger">*</span></label>
                        <input type="text" name="subject" class="form-control" 
                               placeholder="Örn: Üretim Hattı Etiketleme Hatası" 
                               value="{{ $prefilled['subject'] ?? old('subject') }}" required>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="fw-bold small">Kaynak <span class="text-danger">*</span></label>
                        <select name="source" class="form-select" required>
                            {{-- Controllerdan gelen 'source' verisine göre otomatik seç --}}
                            <option value="Audit" {{ (isset($prefilled['source']) && $prefilled['source'] == 'Audit') ? 'selected' : '' }}>Denetim Bulgusu</option>
                            <option value="Complaint" {{ (isset($prefilled['source']) && $prefilled['source'] == 'Complaint') ? 'selected' : '' }}>Müşteri Şikayeti</option>
                            <option value="Risk" {{ (isset($prefilled['source']) && $prefilled['source'] == 'Risk') ? 'selected' : '' }}>Risk Analizi</option>
                            
                            {{-- Manuel seçimler için old() kontrolü --}}
                            <option value="Incident" {{ (old('source') == 'Incident') ? 'selected' : '' }}>Olay / Kaza</option>
                            <option value="Other" {{ (old('source') == 'Other') ? 'selected' : '' }}>Diğer</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="fw-bold small">Uygunsuzluk Tanımı (Detaylı Açıklama) <span class="text-danger">*</span></label>
                        <textarea name="description" class="form-control" rows="6" required placeholder="Sorun nedir? Nerede ve ne zaman tespit edildi?">{{ $prefilled['description'] ?? old('description') }}</textarea>
                        
                        {{-- Kaynağa göre bilgilendirme metinleri --}}
                        @if(isset($prefilled['source']))
                            @if($prefilled['source'] == 'Complaint')
                                <div class="form-text small text-muted fst-italic">
                                    <i class="fas fa-info-circle me-1"></i> Şikayet detayları ve müşteri bilgileri buraya otomatik aktarılmıştır. Teknik inceleme notlarınızı altına ekleyebilirsiniz.
                                </div>
                            @elseif($prefilled['source'] == 'Risk')
                                <div class="form-text small text-muted fst-italic">
                                    <i class="fas fa-info-circle me-1"></i> Risk analizi detayları (Olasılık, Etki vb.) otomatik aktarıldı. Alınacak önlemin kapsamını buraya ekleyebilirsiniz.
                                </div>
                            @endif
                        @endif
                    </div>

                    <div class="col-md-6">
                        <label class="fw-bold small">İlgili Departman</label>
                        <select name="department_id" class="form-select select2">
                            <option value="">-- Seçiniz --</option>
                            @foreach($departments as $dept)
                                <option value="{{ $dept->id }}" {{ (isset($prefilled['department_id']) && $prefilled['department_id'] == $dept->id) ? 'selected' : '' }}>
                                    {{ $dept->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="fw-bold small">DÖF Sorumlusu (Lider) <span class="text-danger">*</span></label>
                        <select name="lead_user_id" class="form-select select2" required>
                            <option value="">-- Seçiniz --</option>
                            @foreach($users as $user)
                                <option value="{{ $user->id }}" {{ old('lead_user_id') == $user->id ? 'selected' : '' }}>
                                    {{ $user->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="fw-bold small">Öncelik</label>
                        <select name="priority" class="form-select">
                            <option value="Low" {{ old('priority') == 'Low' ? 'selected' : '' }}>Düşük</option>
                            <option value="Medium" {{ old('priority') == 'Medium' ? 'selected' : 'selected' }}>Orta</option>
                            <option value="High" {{ old('priority') == 'High' ? 'selected' : '' }}>Yüksek</option>
                            <option value="Critical" {{ old('priority') == 'Critical' ? 'selected' : '' }}>Kritik</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="fw-bold small">Hedef Kapanış Tarihi</label>
                        <input type="date" name="target_date" class="form-control" value="{{ old('target_date') }}">
                    </div>
                </div>

                <div class="text-end mt-4">
                    <button type="submit" class="btn btn-danger fw-bold px-4">
                        <i class="fas fa-save me-1"></i> KAYDET VE BAŞLAT
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection