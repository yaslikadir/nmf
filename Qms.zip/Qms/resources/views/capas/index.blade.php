@extends('layouts.admin')
@section('title', 'DÖF Listesi')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800"><i class="fas fa-tools me-2 text-danger"></i>Düzeltici Önleyici Faaliyetler (DÖF)</h4>
        <a href="{{ route('admin.qms.capas.create') }}" class="btn btn-danger shadow-sm">
            <i class="fas fa-plus me-1"></i> Yeni DÖF Başlat
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th>Kod</th>
                        <th>Konu / Kaynak</th>
                        <th>Sorumlu</th>
                        <th>Durum</th>
                        <th>Hedef Tarih</th>
                        <th class="text-end">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($capas as $capa)
                    {{-- ÇEVİRİ MANTIĞI --}}
                    @php
                        $sourceMap = [
                            'Audit' => 'Denetim Bulgusu',
                            'Complaint' => 'Müşteri Şikayeti',
                            'Risk' => 'Risk Analizi',
                            'Incident' => 'Olay / Kaza',
                            'Other' => 'Diğer'
                        ];

                        $statusMap = [
                            'Opened' => ['label' => 'Yeni / Açık', 'class' => 'bg-secondary'],
                            'Root_Cause_Analysis' => ['label' => 'Kök Neden Analizi', 'class' => 'bg-warning text-dark'],
                            'Action_Planning' => ['label' => 'Aksiyon Planlama', 'class' => 'bg-info text-dark'],
                            'Verification' => ['label' => 'Doğrulama', 'class' => 'bg-primary'],
                            'Closed' => ['label' => 'Kapalı', 'class' => 'bg-success'],
                            'Cancelled' => ['label' => 'İptal', 'class' => 'bg-dark']
                        ];
                        
                        $status = $statusMap[$capa->status] ?? ['label' => $capa->status, 'class' => 'bg-secondary'];
                    @endphp

                    <tr>
                        <td class="fw-bold text-danger font-monospace">{{ $capa->code }}</td>
                        <td>
                            <div class="fw-bold text-dark">{{ $capa->subject }}</div>
                            {{-- BURASI DÜZELDİ: İngilizce enum yerine Türkçe karşılığı --}}
                            <small class="text-muted">
                                <i class="fas fa-info-circle me-1"></i> {{ $sourceMap[$capa->source] ?? $capa->source }}
                            </small>
                        </td>
                        <td>
                            @if($capa->lead)
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-xs bg-secondary text-white rounded-circle me-2 d-flex justify-content-center align-items-center" style="width:24px; height:24px; font-size:10px;">
                                        {{ substr($capa->lead->name, 0, 1) }}
                                    </div>
                                    <span class="small">{{ $capa->lead->name }}</span>
                                </div>
                            @else - @endif
                        </td>
                        <td>
                            <span class="badge {{ $status['class'] }}">{{ $status['label'] }}</span>
                        </td>
                        <td>
                            @if($capa->target_date)
                                {{ $capa->target_date->format('d.m.Y') }}
                            @else - @endif
                        </td>
                        <td class="text-end">
                            <a href="{{ route('admin.qms.capas.show', $capa->id) }}" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye me-1"></i> Yönet
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="6" class="text-center py-4 text-muted">Kayıt bulunamadı.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection