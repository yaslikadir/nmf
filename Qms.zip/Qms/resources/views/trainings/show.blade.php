@extends('layouts.admin')
@section('title', $training->code . ' Yönetimi')

@section('content')
<div class="container-fluid px-4 mt-4">

    {{-- ÜST BİLGİ --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800 mb-0">
                <i class="fas fa-graduation-cap me-2 text-success"></i>{{ $training->title }}
            </h4>
            <div class="text-muted small mt-1">{{ $training->code }} | {{ $training->type }}</div>
        </div>
        <a href="{{ route('admin.qms.trainings.index') }}" class="btn btn-secondary btn-sm shadow-sm">Geri</a>
    </div>

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-white fw-bold">Eğitim Tanımını Düzenle</div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.qms.trainings.update', $training->id) }}">
                @csrf
                @method('PUT')
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Eğitim Başlığı</label>
                        <input type="text" name="title" class="form-control" value="{{ old('title', $training->title) }}" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Eğitim Türü</label>
                        <select name="type" class="form-select" required>
                            <option value="Internal" @selected(old('type', $training->type) === 'Internal')>İç Eğitim</option>
                            <option value="External" @selected(old('type', $training->type) === 'External')>Dış Kaynaklı</option>
                            <option value="Online" @selected(old('type', $training->type) === 'Online')>Online / Video</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Personel Dosyası Kategorisi</label>
                        <select name="profile_category" class="form-select" required>
                            <option value="general" @selected(old('profile_category', $training->profile_category ?? 'general') === 'general')>Genel Eğitim</option>
                            <option value="orientation" @selected(old('profile_category', $training->profile_category ?? 'general') === 'orientation')>Oryantasyon</option>
                            <option value="authorization_training" @selected(old('profile_category', $training->profile_category ?? 'general') === 'authorization_training')>Yetkilendirme Eğitimi</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-bold">Açıklama</label>
                        <textarea name="description" class="form-control" rows="2">{{ old('description', $training->description) }}</textarea>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Geçerlilik (Ay)</label>
                        <input type="number" name="validity_months" class="form-control" min="1" value="{{ old('validity_months', $training->validity_months) }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Geçme Notu</label>
                        <input type="number" name="passing_score" class="form-control" min="0" max="100" value="{{ old('passing_score', $training->passing_score ?? 70) }}">
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <div class="form-check mb-2">
                            <input type="checkbox" class="form-check-input" id="editHasExam" name="has_exam" value="1" @checked(old('has_exam', $training->has_exam))>
                            <label for="editHasExam" class="form-check-label">Sınav uygulanır</label>
                        </div>
                    </div>
                    <div class="col-md-3 text-end align-self-end">
                        <button type="submit" class="btn btn-primary">Eğitim Tanımını Kaydet</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="row">
        
        {{-- SOL TARAF: MATERYALLER --}}
        <div class="col-lg-6 mb-4">
            <div class="card shadow-sm h-100 border-top-lg border-primary">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-file-alt me-2 text-primary"></i>Eğitim Materyalleri</span>
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#uploadModal">
                        <i class="fas fa-upload me-1"></i> Dosya Yükle
                    </button>
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light small">
                            <tr>
                                <th>Başlık / Dosya Adı</th>
                                <th>Tip</th>
                                <th class="text-end">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="small align-middle">
                            @forelse($training->materials as $material)
                            @php
                                $mExt = strtolower(pathinfo($material->file_path, PATHINFO_EXTENSION) ?: $material->file_type);
                                $mViewUrl = route('admin.qms.my-trainings.material.view', $material->id);
                                $mDirectUrl = asset('storage/'.$material->file_path);
                            @endphp
                            <tr>
                                <td>
                                    <a href="javascript:void(0)"
                                       class="fw-bold text-decoration-none open-material-modal"
                                       data-title="{{ $material->title }}"
                                       data-ext="{{ $mExt }}"
                                       data-url="{{ $mViewUrl }}"
                                       data-direct-url="{{ $mDirectUrl }}">
                                        <i class="fas {{ in_array($mExt, ['mp4','webm','ogg','mov']) ? 'fa-play-circle text-danger' : (in_array($mExt, ['ppt','pptx']) ? 'fa-file-powerpoint text-warning' : 'fa-file-pdf text-danger') }} me-1"></i>
                                        {{ $material->title }}
                                    </a>
                                </td>
                                <td><span class="badge bg-light text-dark border">{{ strtoupper($mExt ?: $material->file_type) }}</span></td>
                                <td class="text-end text-nowrap">
                                    <button type="button"
                                            class="btn btn-xs btn-outline-primary me-1 open-material-modal"
                                            data-title="{{ $material->title }}"
                                            data-ext="{{ $mExt }}"
                                            data-url="{{ $mViewUrl }}"
                                            data-direct-url="{{ $mDirectUrl }}"
                                            title="Sistem İçi Önizle">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <form action="{{ route('admin.qms.trainings.delete-material', $material->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Silinsin mi?')">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-xs btn-outline-danger"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="3" class="text-center text-muted py-3">Henüz materyal yüklenmemiş.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {{-- SAĞ TARAF: SORU BANKASI (Eğer Sınavlıysa) --}}
        @if($training->has_exam)
        <div class="col-lg-6 mb-4">
            <div class="card shadow-sm h-100 border-top-lg border-warning">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-question-circle me-2 text-warning"></i>Online Sınav Soruları</span>
                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#addQuestionModal">
                        <i class="fas fa-plus me-1"></i> Soru Ekle
                    </button>
                </div>
                <div class="card-body p-0">
                    <div class="alert alert-light border-bottom mb-0 small text-center">
                        <span class="fw-bold text-dark">Toplam Soru: {{ $training->questions->count() }}</span> | 
                        Geçme Notu: <span class="badge bg-success">{{ $training->passing_score }}</span>
                    </div>
                    <div class="accordion accordion-flush" id="questionsAccordion">
                        @forelse($training->questions as $index => $question)
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-heading{{ $question->id }}">
                                    <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse{{ $question->id }}">
                                        <span class="fw-bold me-2">{{ $index + 1 }}.</span> {{ Str::limit($question->question_text, 40) }}
                                    </button>
                                </h2>
                                <div id="flush-collapse{{ $question->id }}" class="accordion-collapse collapse" data-bs-parent="#questionsAccordion">
                                    <div class="accordion-body bg-light p-2 small">
                                        <div class="mb-2 fw-bold text-dark">{{ $question->question_text }}</div>
                                        <ul class="list-group list-group-flush mb-2">
                                            @foreach($question->options as $opt)
                                                <li class="list-group-item bg-transparent py-1 {{ $opt->is_correct ? 'text-success fw-bold' : '' }}">
                                                    @if($opt->is_correct) <i class="fas fa-check me-1"></i> @else <i class="far fa-circle me-1 text-muted"></i> @endif
                                                    {{ $opt->option_text }}
                                                </li>
                                            @endforeach
                                        </ul>
                                        <div class="text-end">
                                            <form action="{{ route('admin.qms.trainings.questions.destroy', $question->id) }}" method="POST" onsubmit="return confirm('Bu soruyu silmek istediğinize emin misiniz?')">
                                                @csrf @method('DELETE')
                                                <button class="btn btn-xs btn-danger">Soruyu Sil</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="text-center text-muted py-4 small">Henüz soru eklenmemiş.</div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
        @else
        <div class="col-lg-6 mb-4">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> Bu eğitim için sınav özelliği kapalıdır.
            </div>
        </div>
        @endif

    </div>
</div>

{{-- YENİ EKLENEN BÖLÜM: EĞİTİM DEĞERLENDİRME RAPORU --}}
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow-sm border-0 border-top-lg border-info">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-comments me-2 text-info"></i>Katılımcı Değerlendirmeleri ve Puanlar</span>
                    
                    @php
                        $stats = $training->rating_stats;
                    @endphp
                    @if($stats['count'] > 0)
                        <div class="badge bg-light text-dark border p-2">
                            <span class="text-muted small me-2">Ortalama:</span>
                            <span class="fw-bold fs-6 text-warning">{{ $stats['average'] }} <i class="fas fa-star"></i></span>
                            <span class="text-muted small ms-2">({{ $stats['count'] }} Kişi)</span>
                        </div>
                    @endif
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light small text-muted">
                                <tr>
                                    <th>Personel</th>
                                    <th>Tarih</th>
                                    <th class="text-center">Puan</th>
                                    <th>Yorum / Geri Bildirim</th>
                                </tr>
                            </thead>
                            <tbody>
                                {{-- İlişkiler zinciriyle değerlendirmeleri çekiyoruz --}}
                                @php
                                    $evaluations = \App\Models\TrainingEvaluation::whereHas('record.plan', function($q) use ($training) {
                                        $q->where('training_id', $training->id);
                                    })->with('record.user')->latest()->limit(10)->get();
                                @endphp

                                @forelse($evaluations as $eval)
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2 small" style="width: 30px; height: 30px;">
                                                    {{ substr($eval->record->user->name, 0, 1) }}
                                                </div>
                                                <div>
                                                    <div class="fw-bold small">{{ $eval->record->user->name }}</div>
                                                    <div class="text-muted" style="font-size: 10px;">{{ $eval->record->user->department->name ?? '-' }}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="small text-muted">{{ $eval->created_at->format('d.m.Y H:i') }}</td>
                                        <td class="text-center">
                                            <div class="text-warning">
                                                @for($i=1; $i<=5; $i++)
                                                    <i class="fas fa-star {{ $i <= $eval->rating ? '' : 'text-gray-200' }}"></i>
                                                @endfor
                                            </div>
                                            <div class="fw-bold small text-dark">{{ $eval->rating }}/5</div>
                                        </td>
                                        <td>
                                            @if($eval->comment)
                                                <span class="small text-dark fst-italic">"{{ Str::limit($eval->comment, 80) }}"</span>
                                            @else
                                                <span class="text-muted small">-</span>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center py-4 text-muted small">
                                            <i class="fas fa-comment-slash fa-2x mb-2 text-gray-300"></i><br>
                                            Henüz bu eğitim için bir değerlendirme yapılmamış.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if($evaluations->count() > 0)
                    <div class="card-footer bg-white text-center py-2">
                        <small class="text-muted">Son 10 değerlendirme listelenmektedir.</small>
                    </div>
                @endif
            </div>
        </div>
    </div>

{{-- MODALLAR --}}

{{-- 1. DOSYA YÜKLEME MODALI --}}
<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('admin.qms.trainings.upload-material', $training->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title fw-bold">Materyal Yükle</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold">Doküman Başlığı</label>
                        <input type="text" name="title" class="form-control" required placeholder="Örn: Eğitim Sunumu v1">
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Dosya (PDF, Video, Sunum)</label>
                        <input type="file" name="file" class="form-control" required>
                        <small class="text-muted">Max 50MB</small>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-primary fw-bold">YÜKLE</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- 2. SORU EKLEME MODALI --}}
@if($training->has_exam)
<div class="modal fade" id="addQuestionModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.qms.trainings.questions.store', $training->id) }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h6 class="modal-title fw-bold text-dark">Soru Havuzuna Ekle</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="fw-bold small">Soru Metni</label>
                        <textarea name="question_text" class="form-control" rows="3" required placeholder="Soruyu buraya yazınız..."></textarea>
                    </div>
                    
                    <label class="fw-bold small mb-2">Cevap Şıkları (Doğru şıkkı işaretleyiniz)</label>
                    <div class="bg-light p-3 border rounded">
                        {{-- A Şıkkı --}}
                        <div class="input-group mb-2">
                            <div class="input-group-text">
                                <input class="form-check-input mt-0" type="radio" name="correct_option" value="0" required>
                            </div>
                            <span class="input-group-text fw-bold">A</span>
                            <input type="text" name="options[]" class="form-control" placeholder="A şıkkı metni" required>
                        </div>
                        {{-- B Şıkkı --}}
                        <div class="input-group mb-2">
                            <div class="input-group-text">
                                <input class="form-check-input mt-0" type="radio" name="correct_option" value="1">
                            </div>
                            <span class="input-group-text fw-bold">B</span>
                            <input type="text" name="options[]" class="form-control" placeholder="B şıkkı metni" required>
                        </div>
                        {{-- C Şıkkı --}}
                        <div class="input-group mb-2">
                            <div class="input-group-text">
                                <input class="form-check-input mt-0" type="radio" name="correct_option" value="2">
                            </div>
                            <span class="input-group-text fw-bold">C</span>
                            <input type="text" name="options[]" class="form-control" placeholder="C şıkkı metni" required>
                        </div>
                        {{-- D Şıkkı --}}
                        <div class="input-group mb-2">
                            <div class="input-group-text">
                                <input class="form-check-input mt-0" type="radio" name="correct_option" value="3">
                            </div>
                            <span class="input-group-text fw-bold">D</span>
                            <input type="text" name="options[]" class="form-control" placeholder="D şıkkı metni" required>
                        </div>
                    </div>
                    <div class="mt-2 text-end">
                        <label class="small fw-bold me-2">Puan Değeri:</label>
                        <input type="number" name="points" value="10" class="form-control form-control-sm d-inline-block text-center" style="width: 60px;">
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-warning text-dark fw-bold">KAYDET VE EKLE</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endif


{{-- SİSTEM İÇİ MATERYAL ÖNİZLEME MODALI (İNDİRME KORUMALI) --}}
<div class="modal fade" id="materialViewerModal" tabindex="-1" aria-hidden="true" oncontextmenu="return false;">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden;" oncontextmenu="return false;">
            <div class="modal-header text-white border-0" style="background: linear-gradient(135deg, #1e293b 0%, #334155 100%);">
                <div class="d-flex align-items-center gap-2">
                    <i class="fas fa-book-open text-warning fs-5" id="viewerModalIcon"></i>
                    <div>
                        <h5 class="modal-title fw-bold mb-0" id="viewerModalTitle">Eğitim Materyali</h5>
                        <small class="text-white-50" id="viewerModalSubtitle">Sistem İçi Güvenli Önizleme</small>
                    </div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-secondary bg-opacity-50 text-white border border-light border-opacity-25 px-3 py-2">
                        <i class="fas fa-shield-alt me-1 text-warning"></i> Salt Okunur
                    </span>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
                </div>
            </div>
            <div class="modal-body p-0 d-flex align-items-center justify-content-center" id="viewerModalBody" style="background: #0f172a; min-height: 75vh;" oncontextmenu="return false;"></div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    const modalEl = document.getElementById('materialViewerModal');
    const modalTitle = document.getElementById('viewerModalTitle');
    const modalSubtitle = document.getElementById('viewerModalSubtitle');
    const modalBody = document.getElementById('viewerModalBody');
    const modalIcon = document.getElementById('viewerModalIcon');
    let bsModal = (modalEl && typeof bootstrap !== 'undefined') ? new bootstrap.Modal(modalEl) : null;

    function openViewer(title, ext, url, directUrl) {
        ext = (ext || '').toLowerCase();
        modalTitle.textContent = title || 'Eğitim Materyali';
        modalSubtitle.textContent = ext ? ('Dosya Türü: ' + ext.toUpperCase() + ' · Salt Okunur Önizleme') : 'Sistem İçi Güvenli Önizleme';
        modalBody.innerHTML = '';

        const videoExts = ['mp4', 'webm', 'ogg', 'mov', 'avi'];
        const imageExts = ['png', 'jpg', 'jpeg', 'gif', 'webp'];
        const officeExts = ['ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx'];

        if (videoExts.includes(ext)) {
            modalIcon.className = 'fas fa-play-circle text-danger fs-5';
            modalBody.innerHTML = `<video style="width:100%;max-height:78vh;background:#000;" controls autoplay controlsList="nodownload noplaybackrate" disablePictureInPicture oncontextmenu="return false;"><source src="${url}" type="video/${ext === 'mov' ? 'mp4' : ext}">Tarayıcınız video oynatmayı desteklemiyor.</video>`;
        } else if (ext === 'pdf') {
            modalIcon.className = 'fas fa-file-pdf text-danger fs-5';
            modalBody.innerHTML = `<iframe src="${url}#toolbar=0&navpanes=0&scrollbar=1&view=FitH" style="width:100%;height:78vh;border:none;background:#fff;" oncontextmenu="return false;"></iframe>`;
        } else if (imageExts.includes(ext)) {
            modalIcon.className = 'fas fa-file-image text-info fs-5';
            modalBody.innerHTML = `<div class="p-3 text-center w-100" oncontextmenu="return false;"><img src="${url}" alt="${title}" style="max-width:100%;max-height:78vh;object-fit:contain;pointer-events:none;" class="rounded shadow" draggable="false"></div>`;
        } else if (officeExts.includes(ext)) {
            modalIcon.className = 'fas fa-file-powerpoint text-warning fs-5';
            const absoluteUrl = new URL(directUrl || url, window.location.origin).href;
            const isLocal = ['localhost', '127.0.0.1'].includes(window.location.hostname) || window.location.hostname.endsWith('.test') || window.location.hostname.endsWith('.local');
            if (!isLocal) {
                const officeEmbedUrl = 'https://view.officeapps.live.com/op/embed.aspx?src=' + encodeURIComponent(absoluteUrl) + '&wdDownloadButton=False&wdPrint=False';
                modalBody.innerHTML = `<iframe src="${officeEmbedUrl}" style="width:100%;height:78vh;border:none;background:#fff;" oncontextmenu="return false;"></iframe>`;
            } else {
                modalBody.innerHTML = `<div class="text-white text-center p-5" style="max-width:560px;"><i class="fas fa-file-powerpoint fa-4x text-warning mb-3"></i><h5 class="fw-bold mb-2">${title}</h5><p class="text-white-50 small mb-0">PowerPoint / Office dosyalarının (${ext.toUpperCase()}) tarayıcı içi canlı önizlemesi canlı sunucuda otomatik olarak bu pencerede açılır. (Güvenlik gereği indirme kapalıdır.)</p></div>`;
            }
        } else {
            modalIcon.className = 'fas fa-file-alt text-info fs-5';
            modalBody.innerHTML = `<iframe src="${url}#toolbar=0" style="width:100%;height:78vh;border:none;background:#fff;" oncontextmenu="return false;"></iframe>`;
        }
        if (bsModal) bsModal.show();
    }

    document.querySelectorAll('.open-material-modal').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            openViewer(this.dataset.title, this.dataset.ext, this.dataset.url, this.dataset.directUrl);
        });
    });

    if (modalEl) {
        modalEl.addEventListener('hidden.bs.modal', function () {
            modalBody.innerHTML = '';
        });
    }
});
</script>
@endpush
@endsection