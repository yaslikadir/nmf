@extends('layouts.admin')
@section('title', 'Eğitim Yönetimi')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800"><i class="fas fa-graduation-cap me-2 text-success"></i>Eğitim Yönetimi</h4>
            <div class="text-muted small">Personel yetkinlik, eğitim materyalleri ve online sınav yönetimi.</div>
        </div>
        <div>
            <a href="{{ route('admin.qms.plans.index') }}" class="btn btn-primary shadow-sm me-2">
                <i class="fas fa-calendar-alt me-1"></i> Eğitim Planla / Takvim
            </a>

            <a href="{{ route('admin.qms.trainings.create') }}" class="btn btn-success shadow-sm">
                <i class="fas fa-plus me-1"></i> Yeni Eğitim Tanımla
            </a>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Kod</th>
                            <th>Eğitim Başlığı</th>
                            <th>Tür</th>
                            <th>Personel Bölümü</th>
                            <th class="text-center" style="width: 140px;">Memnuniyet</th>
                            <th>Geçerlilik</th>
                            <th>Sınav</th>
                            <th>Materyal / Soru</th>
                            <th class="text-end">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($trainings as $training)
                        <tr>
                            <td class="fw-bold text-success font-monospace">{{ $training->code }}</td>
                            <td>
                                <div class="fw-bold">{{ $training->title }}</div>
                                <div class="small text-muted">{{ Str::limit($training->description, 50) }}</div>
                            </td>
                            <td>
                                @if($training->type == 'Online') <span class="badge bg-info text-dark"><i class="fas fa-laptop me-1"></i>Online</span>
                                @elseif($training->type == 'Internal') <span class="badge bg-secondary"><i class="fas fa-building me-1"></i>İç Eğitim</span>
                                @else <span class="badge bg-warning text-dark"><i class="fas fa-external-link-alt me-1"></i>Dış Kaynaklı</span> @endif
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border">{{ $training->profile_category_label }}</span>
                            </td>
                            
                            <td class="text-center">
                                @if(($training->rating_summary['count'] ?? 0) > 0)
                                    <div class="text-warning mb-1">
                                        <span class="fw-bold text-dark me-1">{{ $training->rating_summary['average'] ?? 0 }}</span>
                                        <i class="fas fa-star"></i>
                                    </div>
                                    <div class="small text-muted" style="font-size: 11px;">
                                        ({{ $training->rating_summary['count'] ?? 0 }} Değerlendirme)
                                    </div>
                                @else
                                    <span class="badge bg-light text-muted border fw-normal">Veri Yok</span>
                                @endif
                            </td>

                            <td>
                                @if($training->validity_months)
                                    <span class="badge bg-light text-dark border">{{ $training->validity_months }} Ay</span>
                                @else
                                    <span class="text-muted small">-</span>
                                @endif
                            </td>
                            <td>
                                @if($training->has_exam)
                                    <span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>Var ({{ $training->passing_score }})</span>
                                @else
                                    <span class="badge bg-light text-muted border">Yok</span>
                                @endif
                            </td>
                            <td class="small">
                                <i class="fas fa-file text-muted me-1"></i> {{ $training->materials->count() }} Dosya <br>
                                <i class="fas fa-question-circle text-muted me-1"></i> {{ $training->questions->count() }} Soru
                            </td>
                            <td class="text-end">
                                <a href="{{ route('admin.qms.trainings.show', $training->id) }}" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-cogs me-1"></i> Yönet
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="9" class="text-center py-4 text-muted">Henüz eğitim tanımı yapılmamış.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-2">
            {{ $trainings->links() }}
        </div>
    </div>
</div>
@endsection