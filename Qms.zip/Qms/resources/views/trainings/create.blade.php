@extends('layouts.admin')
@section('title', 'Yeni Eğitim Tanımla')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">Yeni Eğitim Tanımla</h4>
        <a href="{{ route('admin.qms.trainings.index') }}" class="btn btn-secondary shadow-sm">Geri</a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-success text-white">
            <h6 class="m-0"><i class="fas fa-graduation-cap me-2"></i>Eğitim Bilgileri</h6>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.qms.trainings.store') }}" method="POST">
                @csrf
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="fw-bold small">Eğitim Başlığı <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" required placeholder="Örn: ISO 17025 Temel Bilgilendirme Eğitimi">
                    </div>
                    <div class="col-md-4">
                        <label class="fw-bold small">Eğitim Türü <span class="text-danger">*</span></label>
                        <select name="type" class="form-select" required>
                            <option value="Internal">İç Eğitim (Kurum İçi)</option>
                            <option value="External">Dış Kaynaklı Eğitim</option>
                            <option value="Online">Online / Video Eğitim</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="fw-bold small">Personel Dosyasında Gösterileceği Bölüm <span class="text-danger">*</span></label>
                        <select name="profile_category" class="form-select" required>
                            <option value="general" {{ old('profile_category', 'general') === 'general' ? 'selected' : '' }}>Genel Eğitim (personel sekmelerine aktarılmaz)</option>
                            <option value="orientation" {{ old('profile_category') === 'orientation' ? 'selected' : '' }}>Oryantasyon</option>
                            <option value="authorization_training" {{ old('profile_category') === 'authorization_training' ? 'selected' : '' }}>Yetkilendirme Eğitimi (kanıt olarak gösterilir)</option>
                        </select>
                        <small class="text-muted">Bu amaç, eğitim türünden (iç/dış/online) farklıdır.</small>
                    </div>

                    <div class="col-12">
                        <label class="fw-bold small">Eğitim Açıklaması / İçerik Özeti</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>

                    <div class="col-md-4">
                        <label class="fw-bold small">Geçerlilik Süresi (Ay)</label>
                        <input type="number" name="validity_months" class="form-control" placeholder="Örn: 12 (Yıllık Tekrar)">
                        <small class="text-muted">Süresiz ise boş bırakın.</small>
                    </div>

                    {{-- SINAV AYARLARI --}}
                    <div class="col-md-8">
                        <div class="card bg-light border">
                            <div class="card-body py-2">
                                <div class="form-check form-switch mb-2">
                                    <input class="form-check-input" type="checkbox" id="hasExamCheck" name="has_exam" value="1">
                                    <label class="form-check-label fw-bold" for="hasExamCheck">Bu eğitim sonunda sınav yapılacak mı?</label>
                                </div>
                                
                                <div id="examSettings" style="display: none;">
                                    <div class="row align-items-center">
                                        <div class="col-auto">
                                            <label class="small fw-bold">Geçme Notu:</label>
                                        </div>
                                        <div class="col-auto">
                                            <input type="number" name="passing_score" class="form-control form-control-sm" value="70" style="width: 80px;">
                                        </div>
                                        <div class="col">
                                            <small class="text-muted">Online sınav modülü aktif edilecektir.</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-end mt-4">
                    <button type="submit" class="btn btn-success fw-bold px-4">KAYDET VE İÇERİK YÜKLE</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Sınav checkbox kontrolü
    document.getElementById('hasExamCheck').addEventListener('change', function() {
        document.getElementById('examSettings').style.display = this.checked ? 'block' : 'none';
    });
</script>
@endpush