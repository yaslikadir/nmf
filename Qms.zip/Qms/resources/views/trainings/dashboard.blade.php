@extends('layouts.admin')
@section('title', 'Eğitim Paneli')

@section('content')
<style>
    /* ========== CREATIVE DASHBOARD STYLES ========== */
    .edu-dashboard {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --success-gradient: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        --warning-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        --dark-gradient: linear-gradient(135deg, #0c0c0c 0%, #1a1a2e 100%);
        --glass-bg: rgba(255, 255, 255, 0.15);
        --glass-border: rgba(255, 255, 255, 0.2);
        min-height: 100vh;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        padding: 2rem 0;
        position: relative;
        overflow: hidden;
    }

    .edu-dashboard::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(102, 126, 234, 0.1) 0%, transparent 50%);
        animation: pulse-bg 15s ease-in-out infinite;
    }

    @keyframes pulse-bg {
        0%, 100% { transform: translate(0, 0) scale(1); }
        50% { transform: translate(10%, 10%) scale(1.1); }
    }

    /* Floating Particles */
    .particles {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        pointer-events: none;
        z-index: 0;
    }

    .particle {
        position: absolute;
        width: 6px;
        height: 6px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        animation: float-particle 20s infinite;
    }

    .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
    .particle:nth-child(2) { left: 20%; animation-delay: 2s; }
    .particle:nth-child(3) { left: 30%; animation-delay: 4s; }
    .particle:nth-child(4) { left: 40%; animation-delay: 6s; }
    .particle:nth-child(5) { left: 50%; animation-delay: 8s; }
    .particle:nth-child(6) { left: 60%; animation-delay: 10s; }
    .particle:nth-child(7) { left: 70%; animation-delay: 12s; }
    .particle:nth-child(8) { left: 80%; animation-delay: 14s; }
    .particle:nth-child(9) { left: 90%; animation-delay: 16s; }

    @keyframes float-particle {
        0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { transform: translateY(-100vh) rotate(720deg); opacity: 0; }
    }

    /* Header Section */
    .dashboard-header {
        position: relative;
        z-index: 1;
        margin-bottom: 2rem;
    }

    .dashboard-header h4 {
        font-size: 2rem;
        font-weight: 800;
        background: linear-gradient(135deg, #fff 0%, #a8edea 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: 0.5rem;
        text-shadow: 0 0 40px rgba(168, 237, 234, 0.3);
    }

    .dashboard-header .subtitle {
        color: rgba(255, 255, 255, 0.6);
        font-size: 0.95rem;
    }

    .btn-glow {
        background: var(--primary-gradient);
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: 50px;
        color: white;
        font-weight: 600;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .btn-glow::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        transition: left 0.5s;
    }

    .btn-glow:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.6);
        color: white;
    }

    .btn-glow:hover::before {
        left: 100%;
    }

    /* Stat Cards */
    .stat-card {
        position: relative;
        z-index: 1;
        border-radius: 24px;
        padding: 1.75rem;
        color: white;
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: 1px solid rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
    }

    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: inherit;
        border-radius: 24px;
        z-index: -1;
    }

    .stat-card::after {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle, rgba(255,255,255,0.15) 0%, transparent 70%);
        transition: all 0.5s ease;
    }

    .stat-card:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
    }

    .stat-card:hover::after {
        top: -30%;
        right: -30%;
    }

    .stat-card.primary { background: var(--primary-gradient); }
    .stat-card.warning { background: var(--warning-gradient); }
    .stat-card.success { background: var(--success-gradient); }
    .stat-card.info { background: var(--info-gradient); }

    .stat-card .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 16px;
        background: rgba(255, 255, 255, 0.2);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        animation: icon-float 3s ease-in-out infinite;
    }

    @keyframes icon-float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-8px); }
    }

    .stat-card .stat-value {
        font-size: 2.5rem;
        font-weight: 800;
        line-height: 1;
        margin: 1rem 0 0.25rem;
        text-shadow: 0 2px 10px rgba(0,0,0,0.2);
    }

    .stat-card .stat-label {
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 1px;
        opacity: 0.9;
    }

    .stat-card .stat-footer {
        margin-top: 1.25rem;
        padding-top: 1rem;
        border-top: 1px solid rgba(255,255,255,0.2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 0.85rem;
    }

    .stat-card .stat-footer a {
        color: white;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        transition: all 0.3s ease;
    }

    .stat-card .stat-footer a:hover {
        gap: 0.75rem;
    }

    /* Glass Cards */
    .glass-card {
        position: relative;
        z-index: 1;
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(20px);
        border-radius: 24px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .glass-card:hover {
        border-color: rgba(255, 255, 255, 0.2);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    }

    .glass-card .card-header {
        background: rgba(255, 255, 255, 0.05);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding: 1.25rem 1.5rem;
    }

    .glass-card .card-header h6 {
        color: white;
        font-weight: 700;
        font-size: 1rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin: 0;
    }

    .glass-card .card-header h6 i {
        width: 36px;
        height: 36px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.9rem;
    }

    .glass-card .card-header h6 i.bg-primary-soft {
        background: rgba(102, 126, 234, 0.3);
        color: #a8b4ff;
    }

    .glass-card .card-header h6 i.bg-success-soft {
        background: rgba(56, 239, 125, 0.2);
        color: #7dffb3;
    }

    .glass-card .card-header h6 i.bg-info-soft {
        background: rgba(79, 172, 254, 0.2);
        color: #7dd3ff;
    }

    /* Modern Table */
    .modern-table {
        width: 100%;
        color: rgba(255, 255, 255, 0.9);
    }

    .modern-table thead {
        background: rgba(255, 255, 255, 0.05);
    }

    .modern-table thead th {
        padding: 1rem 1.5rem;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: rgba(255, 255, 255, 0.6);
        font-weight: 600;
        border: none;
    }

    .modern-table tbody tr {
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        transition: all 0.3s ease;
    }

    .modern-table tbody tr:hover {
        background: rgba(255, 255, 255, 0.05);
    }

    .modern-table tbody td {
        padding: 1.25rem 1.5rem;
        vertical-align: middle;
        border: none;
    }

    .training-title {
        font-weight: 600;
        color: white;
        margin-bottom: 0.25rem;
    }

    .training-location {
        font-size: 0.8rem;
        color: rgba(255, 255, 255, 0.5);
        display: flex;
        align-items: center;
        gap: 0.35rem;
    }

    .date-badge {
        background: rgba(102, 126, 234, 0.2);
        border-radius: 12px;
        padding: 0.5rem 0.75rem;
        display: inline-block;
    }

    .date-badge .day {
        font-size: 1.1rem;
        font-weight: 700;
        color: #a8b4ff;
        display: block;
    }

    .date-badge .time {
        font-size: 0.75rem;
        color: rgba(255, 255, 255, 0.5);
    }

    .instructor-badge {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .instructor-avatar {
        width: 32px;
        height: 32px;
        border-radius: 10px;
        background: var(--success-gradient);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.75rem;
        font-weight: 700;
    }

    .count-badge {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50px;
        padding: 0.35rem 0.85rem;
        font-weight: 600;
        font-size: 0.85rem;
    }

    .btn-detail {
        background: rgba(102, 126, 234, 0.2);
        border: 1px solid rgba(102, 126, 234, 0.3);
        color: #a8b4ff;
        padding: 0.5rem 1rem;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-detail:hover {
        background: var(--primary-gradient);
        border-color: transparent;
        color: white;
        transform: scale(1.05);
    }

    /* Progress Section */
    .dept-item {
        margin-bottom: 1.25rem;
        padding-bottom: 1.25rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }

    .dept-item:last-child {
        margin-bottom: 0;
        padding-bottom: 0;
        border-bottom: none;
    }

    .dept-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.75rem;
    }

    .dept-name {
        color: white;
        font-weight: 600;
        font-size: 0.9rem;
    }

    .dept-count {
        background: rgba(56, 239, 125, 0.2);
        color: #7dffb3;
        padding: 0.25rem 0.75rem;
        border-radius: 50px;
        font-size: 0.75rem;
        font-weight: 700;
    }

    .progress-bar-container {
        height: 8px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50px;
        overflow: hidden;
    }

    .progress-bar-fill {
        height: 100%;
        background: var(--success-gradient);
        border-radius: 50px;
        transition: width 1s ease-out;
        position: relative;
    }

    .progress-bar-fill::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        animation: shimmer 2s infinite;
    }

    @keyframes shimmer {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
    }

    /* Activity List */
    .activity-item {
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        transition: all 0.3s ease;
        display: flex;
        gap: 1rem;
    }

    .activity-item:hover {
        background: rgba(255, 255, 255, 0.03);
    }

    .activity-item:last-child {
        border-bottom: none;
    }

    .activity-avatar {
        width: 44px;
        height: 44px;
        border-radius: 14px;
        background: var(--primary-gradient);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        color: white;
        font-size: 0.9rem;
        flex-shrink: 0;
    }

    .activity-content {
        flex: 1;
        min-width: 0;
    }

    .activity-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.35rem;
    }

    .activity-name {
        color: white;
        font-weight: 600;
        font-size: 0.9rem;
    }

    .activity-status {
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        padding: 0.25rem 0.6rem;
        border-radius: 50px;
    }

    .activity-status.passed {
        background: rgba(56, 239, 125, 0.2);
        color: #7dffb3;
    }

    .activity-status.failed {
        background: rgba(245, 87, 108, 0.2);
        color: #ff8fa3;
    }

    .activity-training {
        color: rgba(255, 255, 255, 0.5);
        font-size: 0.8rem;
        margin-bottom: 0.35rem;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .activity-time {
        color: rgba(255, 255, 255, 0.4);
        font-size: 0.75rem;
        display: flex;
        align-items: center;
        gap: 0.35rem;
    }

    /* Empty State */
    .empty-state {
        padding: 3rem;
        text-align: center;
        color: rgba(255, 255, 255, 0.4);
    }

    .empty-state i {
        font-size: 3rem;
        margin-bottom: 1rem;
        opacity: 0.5;
    }

    /* Animations on Load */
    .fade-in-up {
        animation: fadeInUp 0.6s ease-out forwards;
        opacity: 0;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .delay-1 { animation-delay: 0.1s; }
    .delay-2 { animation-delay: 0.2s; }
    .delay-3 { animation-delay: 0.3s; }
    .delay-4 { animation-delay: 0.4s; }
    .delay-5 { animation-delay: 0.5s; }
    .delay-6 { animation-delay: 0.6s; }

    /* Responsive */
    @media (max-width: 768px) {
        .dashboard-header h4 {
            font-size: 1.5rem;
        }
        .stat-card .stat-value {
            font-size: 2rem;
        }
    }
</style>

<div class="edu-dashboard">
    {{-- Floating Particles --}}
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <div class="container-fluid px-4">
        
        {{-- BAŞLIK VE BUTONLAR --}}
        <div class="dashboard-header d-flex justify-content-between align-items-center flex-wrap gap-3 fade-in-up">
            <div>
                <h4><i class="fas fa-graduation-cap me-2"></i>Eğitim & Yeterlilik Merkezi</h4>
                <div class="subtitle">Genel durum, istatistikler ve yaklaşan aktiviteler</div>
            </div>
            <div>
                {{-- YENİ EKLENEN: MANUEL TETİKLEME BUTONU --}}
            {{-- Localhost'ta çalıştığımızı unutmamak için bu buton hayat kurtarır --}}
            <form action="{{ route('admin.qms.trainings.run-daily-jobs') }}" method="POST" class="d-inline" onsubmit="return confirm('Günlük hatırlatma servisini manuel çalıştırmak üzeresiniz. Yarınki eğitimler için bildirim gidecek. Onaylıyor musunuz?');">
                @csrf
                <button type="submit" class="btn btn-warning shadow-sm me-2 text-dark">
                    <i class="fas fa-bolt me-1"></i> Sistemi Manuel Tetikle
                </button>
            </form>
                <a href="{{ route('admin.qms.plans.create') }}" class="btn btn-glow">
                    <i class="fas fa-plus me-2"></i> Yeni Eğitim Planla
                </a>
            </div>
        </div>

        {{-- 1. İSTATİSTİK KARTLARI --}}
        <div class="row g-4 mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="stat-card primary fade-in-up delay-1">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="stat-value">{{ $counts['planned_active'] }}</div>
                    <div class="stat-label">Gelecek Eğitimler</div>
                    <div class="stat-footer">
                        <a href="{{ route('admin.qms.plans.index') }}">
                            <span>Takvimi Görüntüle</span>
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="stat-card warning fade-in-up delay-2">
                    <div class="stat-icon">
                        <i class="fas fa-inbox"></i>
                    </div>
                    <div class="stat-value">{{ $counts['pending_requests'] }}</div>
                    <div class="stat-label">Bekleyen Talepler</div>
                    <div class="stat-footer">
                        <a href="{{ route('admin.qms.requests.index') }}">
                            <span>Talepleri Yönet</span>
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="stat-card success fade-in-up delay-3">
                    <div class="stat-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-value">{{ $counts['certified_users'] }}</div>
                    <div class="stat-label">Sertifikalı Personel</div>
                    <div class="stat-footer">
                        <span><i class="fas fa-check-circle me-1"></i> Toplam Yetkinlik</span>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="stat-card info fade-in-up delay-4">
                    <div class="stat-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="stat-value">{{ $counts['total_trainings'] }}</div>
                    <div class="stat-label">Eğitim Kütüphanesi</div>
                    <div class="stat-footer">
                        <a href="{{ route('admin.qms.trainings.index') }}">
                            <span>Tümünü Listele</span>
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            {{-- SOL KOLON: YAKLAŞAN EĞİTİMLER --}}
            <div class="col-lg-8">
                <div class="glass-card fade-in-up delay-5">
                    <div class="card-header">
                        <h6><i class="fas fa-clock bg-primary-soft"></i> Yaklaşan Eğitim Takvimi</h6>
                    </div>
                    <div class="table-responsive">
                        <table class="modern-table">
                            <thead>
                                <tr>
                                    <th>Eğitim</th>
                                    <th>Tarih</th>
                                    <th>Eğitmen</th>
                                    <th class="text-center">Katılımcı</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($upcomingPlans as $plan)
                                <tr>
                                    <td>
                                        <div class="training-title">{{ Str::limit($plan->training->title, 30) }}</div>
                                        <div class="training-location">
                                            <i class="fas fa-map-marker-alt"></i>
                                            {{ $plan->location }}
                                        </div>
                                    </td>
                                    <td>
                                        <div class="date-badge">
                                            <span class="day">{{ $plan->start_date->format('d M') }}</span>
                                            <span class="time">{{ $plan->start_date->format('H:i') }}</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="instructor-badge">
                                            <div class="instructor-avatar">
                                                {{ strtoupper(substr($plan->instructor, 0, 2)) }}
                                            </div>
                                            <span style="color: rgba(255,255,255,0.8); font-size: 0.85rem;">{{ $plan->instructor }}</span>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="count-badge">{{ $plan->records->count() }} kişi</span>
                                    </td>
                                    <td>
                                        <a href="{{ route('admin.qms.plans.show', $plan->id) }}" class="btn-detail">
                                            <i class="fas fa-eye me-1"></i> Detay
                                        </a>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="5">
                                        <div class="empty-state">
                                            <i class="fas fa-calendar-times d-block"></i>
                                            <div>Planlanmış aktif bir eğitim bulunmuyor.</div>
                                        </div>
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{-- SAĞ KOLON: DEPARTMAN BAŞARISI VE SON İŞLEMLER --}}
            <div class="col-lg-4">
                
                {{-- DEPARTMAN İSTATİSTİKLERİ --}}
                <div class="glass-card mb-4 fade-in-up delay-5">
                    <div class="card-header">
                        <h6><i class="fas fa-trophy bg-success-soft"></i> Sertifika Şampiyonları</h6>
                    </div>
                    <div class="card-body p-4">
                        @forelse($deptStats as $stat)
                            <div class="dept-item">
                                <div class="dept-header">
                                    <span class="dept-name">{{ $stat->name }}</span>
                                    <span class="dept-count">{{ $stat->total }} Belge</span>
                                </div>
                                <div class="progress-bar-container">
                                    <div class="progress-bar-fill" style="width: {{ min(($stat->total * 5), 100) }}%"></div>
                                </div>
                            </div>
                        @empty
                            <div class="empty-state py-4">
                                <i class="fas fa-chart-bar d-block"></i>
                                <div>Henüz veri oluşmadı.</div>
                            </div>
                        @endforelse
                    </div>
                </div>

                {{-- SON SINAV HAREKETLERİ --}}
                <div class="glass-card fade-in-up delay-6">
                    <div class="card-header">
                        <h6><i class="fas fa-history bg-info-soft"></i> Son Sınav Sonuçları</h6>
                    </div>
                    <div>
                        @forelse($latestRecords as $record)
                            <div class="activity-item">
                                <div class="activity-avatar">
                                    {{ strtoupper(substr($record->user->name, 0, 2)) }}
                                </div>
                                <div class="activity-content">
                                    <div class="activity-header">
                                        <span class="activity-name">{{ $record->user->name }}</span>
                                        <span class="activity-status {{ $record->result == 'Passed' ? 'passed' : 'failed' }}">
                                            {{ $record->result == 'Passed' ? 'GEÇTİ' : 'KALDI' }}
                                        </span>
                                    </div>
                                    <div class="activity-training">{{ Str::limit($record->plan->training->title, 30) }}</div>
                                    <div class="activity-time">
                                        <i class="fas fa-clock"></i>
                                        {{ $record->updated_at->diffForHumans() }}
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="empty-state">
                                <i class="fas fa-clipboard-check d-block"></i>
                                <div>Henüz sınav hareketi yok.</div>
                            </div>
                        @endforelse
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection
