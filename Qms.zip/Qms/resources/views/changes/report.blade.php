<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <title>Değişiklik Talep Formu - {{ $change->code }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 12px; color: #000; }
        .table-bordered th, .table-bordered td { border-color: #000 !important; padding: 6px; }
        .section-title { background-color: #eee; font-weight: bold; border: 1px solid #000; padding: 5px; margin-top: 15px; border-bottom: none; }
        .box { border: 1px solid #000; padding: 10px; }
        
        @media print {
            .no-print { display: none !important; }
            body { font-size: 11px; }
            .section-title { background-color: #ddd !important; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body class="p-4">

    <div class="no-print mb-4 text-end">
        <button onclick="window.print()" class="btn btn-dark btn-sm fw-bold">YAZDIR / PDF</button>
        <button onclick="window.close()" class="btn btn-secondary btn-sm">Kapat</button>
    </div>

    {{-- BAŞLIK --}}
    <table class="table table-bordered mb-0">
        <tr>
            <td width="20%" class="text-center align-middle fw-bold">
                {{ \App\Models\Setting::get('company_name', config('app.name')) }}
            </td>
            <td width="60%" class="text-center align-middle">
                <h4 class="mb-0 fw-bold">DEĞİŞİKLİK TALEP VE YÖNETİM FORMU</h4>
            </td>
            <td width="20%" class="small">
                <div><strong>Form No:</strong> FR-QMS-09</div>
                <div><strong>Tarih:</strong> {{ now()->format('d.m.Y') }}</div>
                <div><strong>No:</strong> {{ $change->code }}</div>
            </td>
        </tr>
    </table>

    {{-- 1. TALEP BİLGİLERİ --}}
    <div class="section-title">1. DEĞİŞİKLİK TALEBİ</div>
    <table class="table table-bordered mb-0">
        <tr>
            <td width="15%" class="fw-bold bg-light">Talep Eden:</td>
            <td width="35%">{{ $change->requester->name }}</td>
            <td width="15%" class="fw-bold bg-light">Talep Tarihi:</td>
            <td width="35%">{{ $change->created_at->format('d.m.Y') }}</td>
        </tr>
        <tr>
            <td class="fw-bold bg-light">Departman:</td>
            <td>{{ $change->department->name ?? 'Genel' }}</td>
            <td class="fw-bold bg-light">Değişiklik Türü:</td>
            <td>{{ $change->type_label }}</td>
        </tr>
        <tr>
            <td class="fw-bold bg-light">Konu:</td>
            <td colspan="3">{{ $change->title }}</td>
        </tr>
        <tr>
            <td class="fw-bold bg-light">Gerekçe:</td>
            <td colspan="3">{{ $change->reason }}</td>
        </tr>
        <tr>
            <td class="fw-bold bg-light">Mevcut vs Yeni:</td>
            <td colspan="3">{!! nl2br(e($change->description)) !!}</td>
        </tr>
    </table>

    {{-- 2. RİSK ANALİZİ --}}
    <div class="section-title">2. RİSK VE ETKİ ANALİZİ</div>
    <table class="table table-bordered mb-0 text-center">
        <thead class="bg-light">
            <tr>
                <th>Risk / Etki Tanımı</th>
                <th width="10%">Olasılık</th>
                <th width="10%">Şiddet</th>
                <th width="10%">Skor</th>
                <th>Önlem Planı</th>
            </tr>
        </thead>
        <tbody>
            @forelse($change->risks as $risk)
            <tr>
                <td class="text-start">{{ $risk->risk_description }}</td>
                <td>{{ $risk->probability }}</td>
                <td>{{ $risk->impact }}</td>
                <td class="fw-bold">{{ $risk->risk_score }}</td>
                <td class="text-start">{{ $risk->mitigation_plan }}</td>
            </tr>
            @empty
            <tr><td colspan="5">Risk analizi yapılmamış.</td></tr>
            @endforelse
        </tbody>
    </table>

    {{-- 3. ONAY --}}
    <div class="section-title">3. ONAY VE DEĞERLENDİRME</div>
    <table class="table table-bordered mb-0">
        <tr>
            <td width="50%">
                <strong>Yönetici Onayı:</strong><br>
                @if($change->status != 'Draft' && $change->status != 'Pending_Analysis' && $change->status != 'Pending_Approval')
                    <span class="text-success fw-bold">ONAYLANDI</span><br>
                    Tarih: {{ $change->approved_at ? $change->approved_at->format('d.m.Y') : '-' }}<br>
                    İmza: __________________
                @else
                    <br><br>İmza: __________________
                @endif
            </td>
            <td width="50%">
                <strong>Kalite Yöneticisi:</strong><br>
                <br><br>
                İmza: __________________
            </td>
        </tr>
    </table>

    {{-- 4. UYGULAMA PLANI --}}
    <div class="section-title">4. UYGULAMA VE AKSİYONLAR</div>
    <table class="table table-bordered mb-0 text-center">
        <thead class="bg-light">
            <tr>
                <th>Yapılacak İş</th>
                <th>Sorumlu</th>
                <th>Termin</th>
                <th>Tamamlanma</th>
                <th>Kanıt / Sonuç</th>
            </tr>
        </thead>
        <tbody>
            @forelse($change->actions as $action)
            <tr>
                <td class="text-start">{{ $action->description }}</td>
                <td>{{ $action->responsible->name }}</td>
                <td>{{ $action->due_date->format('d.m.Y') }}</td>
                <td>{{ $action->completed_at ? $action->completed_at->format('d.m.Y') : '-' }}</td>
                <td class="text-start small">{{ $action->completion_note ?? '-' }}</td>
            </tr>
            @empty
            <tr><td colspan="5">Aksiyon planlanmamış.</td></tr>
            @endforelse
        </tbody>
    </table>

    {{-- 5. KAPATMA --}}
    <div class="section-title">5. DOĞRULAMA VE KAPATMA</div>
    <div class="box">
        <strong>Etkinlik Doğrulama Sonucu:</strong><br>
        <p>{{ $change->verification_result ?? 'Henüz kapatılmadı.' }}</p>
        <br>
        <strong>Kapanış Tarihi:</strong> {{ $change->closed_date ? $change->closed_date->format('d.m.Y') : '-' }}
    </div>

    {{-- 6. EKLER LİSTESİ --}}
    <div class="section-title">6. EKLER VE DOKÜMANLAR</div>
    <table class="table table-bordered mb-0">
        <thead class="bg-light">
            <tr>
                <th width="50%">Dosya Adı</th>
                <th width="30%">Yükleyen</th>
                <th width="20%">Tarih</th>
            </tr>
        </thead>
        <tbody>
            @forelse($change->attachments as $file)
            <tr>
                <td>{{ $file->file_name }}</td>
                <td>{{ $file->uploader->name ?? '-' }}</td>
                <td>{{ $file->created_at->format('d.m.Y') }}</td>
            </tr>
            @empty
            <tr><td colspan="3" class="text-center">Bu kayıt için herhangi bir dosya yüklenmemiştir.</td></tr>
            @endforelse
        </tbody>
    </table>

</body>
</html>