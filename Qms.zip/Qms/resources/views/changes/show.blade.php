@extends('layouts.admin')
@section('title', $change->code . ' Detayı')

@section('content')
<div class="container-fluid px-4 mt-4">

    {{-- BAŞLIK VE DURUM --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800 mb-0">
                <i class="fas fa-exchange-alt me-2 text-primary"></i>{{ $change->code }}
            </h4>
            <div class="text-muted small mt-1">{{ $change->title }}</div>
        </div>
        <div>
            <span class="badge {{ $change->status_label['class'] }} fs-6 shadow-sm me-2">
                {{ $change->status_label['text'] }}
            </span>
            

@if($change->status == 'Approved' || $change->status == 'Completed' || $change->status == 'Closed')
    <button class="btn btn-info btn-sm shadow-sm text-white me-2" data-bs-toggle="modal" data-bs-target="#announceModal">
        <i class="fas fa-bullhorn me-1"></i> Duyuru Yayınla
    </button>
@endif
            <a href="{{ route('admin.qms.changes.report', $change->id) }}" target="_blank" class="btn btn-dark btn-sm shadow-sm me-2">
    <i class="fas fa-print me-1"></i> Formu Yazdır
</a>
            <a href="{{ route('admin.qms.changes.index') }}" class="btn btn-secondary btn-sm shadow-sm">Geri</a>
        </div>
    </div>

    <div class="row">
        {{-- SOL: TALEP BİLGİLERİ --}}
        <div class="col-lg-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-light fw-bold"><i class="fas fa-info-circle me-2"></i>1. Talep Bilgileri</div>
                <div class="card-body small">
                    <table class="table table-borderless mb-0">
                        <tr><td class="fw-bold text-muted w-25">Tür:</td><td>{{ $change->type_label }}</td></tr>
                        <tr><td class="fw-bold text-muted">Birim:</td><td>{{ $change->department->name ?? 'Genel' }}</td></tr>
                        <tr><td class="fw-bold text-muted">Talep Eden:</td><td>{{ $change->requester->name }}</td></tr>
                        <tr><td class="fw-bold text-muted">Tarih:</td><td>{{ $change->created_at->format('d.m.Y') }}</td></tr>
                        <tr>
                            <td class="fw-bold text-muted">Öncelik:</td>
                            <td>
                                @if($change->priority == 'Critical') <span class="text-danger fw-bold">KRİTİK</span>
                                @elseif($change->priority == 'High') <span class="text-warning fw-bold">YÜKSEK</span>
                                @else <span class="text-success fw-bold">{{ $change->priority }}</span> @endif
                            </td>
                        </tr>
                    </table>
                    <hr>
                    <div class="mb-2"><strong class="text-muted">Gerekçe:</strong><br>{{ $change->reason }}</div>
                    <div><strong class="text-muted">Tanım:</strong><br>{!! nl2br(e($change->description)) !!}</div>
                </div>
            </div>
        </div>

        {{-- SAĞ: RİSK VE ETKİ ANALİZİ --}}
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm h-100 border-top-lg border-warning">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-exclamation-triangle me-2 text-warning"></i>2. Risk ve Etki Analizi</span>
                    @if($change->status == 'Draft' || $change->status == 'Pending_Analysis')
                        <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#addRiskModal">
                            <i class="fas fa-plus me-1"></i> Risk Ekle
                        </button>
                    @endif
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead class="bg-light small">
                                <tr>
                                    <th>Olası Risk / Etki</th>
                                    <th class="text-center">Olasılık (P)</th>
                                    <th class="text-center">Şiddet (I)</th>
                                    <th class="text-center">Skor (PxI)</th>
                                    <th>Önlem Planı</th>
                                    @if($change->status == 'Draft' || $change->status == 'Pending_Analysis') <th class="text-end">İşlem</th> @endif
                                </tr>
                            </thead>
                            <tbody class="small align-middle">
                                @forelse($change->risks as $risk)
                                <tr>
                                    <td>{{ $risk->risk_description }}</td>
                                    <td class="text-center">{{ $risk->probability }}</td>
                                    <td class="text-center">{{ $risk->impact }}</td>
                                    <td class="text-center">
                                        <span class="badge {{ $risk->risk_level['class'] }}">
                                            {{ $risk->risk_score }} - {{ $risk->risk_level['text'] }}
                                        </span>
                                    </td>
                                    <td>{{ $risk->mitigation_plan ?? '-' }}</td>
                                    
                                    {{-- İŞLEM BUTONLARI (Edit / Delete) --}}
                                    @if($change->status == 'Draft' || $change->status == 'Pending_Analysis')
                                    <td class="text-end" style="min-width: 100px;">
                                        {{-- DÜZENLEME BUTONU --}}
                                        {{-- RİSK DÜZENLEME BUTONU --}}
<button class="btn btn-xs btn-outline-info me-1"
        data-id="{{ $risk->id }}"
        data-desc="{{ $risk->risk_description }}"
        data-prob="{{ $risk->probability }}"
        data-impact="{{ $risk->impact }}"
        data-plan="{{ $risk->mitigation_plan }}"
        onclick="openEditRiskModal(this)">
    <i class="fas fa-edit"></i>
</button>

                                        {{-- SİLME BUTONU --}}
                                        <form action="{{ route('admin.qms.changes.delete-risk', $risk->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Silinsin mi?')">
                                            @csrf @method('DELETE')
                                            <button class="btn btn-xs btn-outline-danger"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </td>
                                    @endif
                                </tr>
                                @empty
                                <tr><td colspan="6" class="text-center text-muted py-3">Henüz risk analizi yapılmamış.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>

                {{-- DOSYA VE EKLER KARTI --}}
        <div class="col-12 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-paperclip me-2 text-secondary"></i>Ekler ve Kanıt Dokümanları</span>
                    <button class="btn btn-sm btn-secondary" data-bs-toggle="modal" data-bs-target="#uploadModal">
                        <i class="fas fa-upload me-1"></i> Dosya Yükle
                    </button>
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light small">
                            <tr>
                                <th>Dosya Adı</th>
                                <th>Yükleyen</th>
                                <th>Tarih</th>
                                <th class="text-end">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="small">
                            @forelse($change->attachments as $file)
                            <tr>
                                <td>
                                    <a href="{{ asset('storage/'.$file->file_path) }}" target="_blank" class="text-decoration-none fw-bold">
                                        <i class="fas fa-file me-2"></i>{{ $file->file_name }}
                                    </a>
                                </td>
                                <td>{{ \App\Models\User::find($file->uploaded_by)->name ?? '-' }}</td>
                                <td>{{ $file->created_at->format('d.m.Y H:i') }}</td>
                                <td class="text-end">
                                    <form action="{{ route('admin.qms.changes.delete-attachment', $file->id) }}" method="POST" onsubmit="return confirm('Dosya silinsin mi?')">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-xs btn-outline-danger"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="4" class="text-center text-muted py-3">Henüz dosya eklenmemiş.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {{-- SAYFANIN ALTINA EKLENECEK MODAL --}}
        <div class="modal fade" id="uploadModal" tabindex="-1">
            <div class="modal-dialog">
                <form action="{{ route('admin.qms.changes.upload', $change->id) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6 class="modal-title">Dosya Yükle</h6>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <input type="file" name="file" class="form-control" required>
                            <small class="text-muted">PDF, Word, Excel, Resim (Max 10MB)</small>
                        </div>
                        <div class="modal-footer py-1">
                            <button type="submit" class="btn btn-primary">Yükle</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
                
                {{-- ONAYA GÖNDER BUTONU --}}
                @if(($change->status == 'Draft' || $change->status == 'Pending_Analysis') && $change->risks->count() > 0)
                    <div class="card-footer bg-white text-end">
                        <form action="{{ route('admin.qms.changes.submit-approval', $change->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="btn btn-success fw-bold">
                                <i class="fas fa-paper-plane me-1"></i> Analizi Tamamla ve Onaya Gönder
                            </button>
                        </form>
                    </div>
                @endif
            </div>
        </div>

        {{-- ALT: ONAY VE AKSİYONLAR --}}
        <div class="col-12">
            
            {{-- ONAY BEKLEME DURUMU --}}
            @if($change->status == 'Pending_Approval')
                <div class="alert alert-info shadow-sm d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-clock fa-2x me-3 float-start"></i>
                        <h6 class="fw-bold mb-0">Onay Bekleniyor</h6>
                        <small>Bu değişiklik talebi risk analiziyle birlikte onayınıza sunulmuştur.</small>
                    </div>
                    <div>
                        <button class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#approveModal">Onayla</button>
                        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">Reddet</button>
                    </div>
                </div>
            @endif

            {{-- ONAYLANDIYSA: UYGULAMA PLANI --}}
            @if($change->status == 'Approved' || $change->status == 'Completed' || $change->status == 'Closed')
                <div class="card shadow-sm mb-4 border-top-lg border-success">
                    <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-tasks me-2 text-success"></i>3. Uygulama Planı ve Aksiyonlar</span>
                        @if($change->status == 'Approved')
                            <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addActionModal">
                                <i class="fas fa-plus me-1"></i> Aksiyon Ekle
                            </button>
                        @endif
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="bg-light small">
                                    <tr>
                                        <th>Yapılacak İş</th>
                                        <th>Tip</th>
                                        <th>Sorumlu</th>
                                        <th>Termin</th>
                                        <th>Durum</th>
                                        <th class="text-end">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody class="small align-middle">
                                    @forelse($change->actions as $action)
                                    <tr>
                                        <td>{{ $action->description }}</td>
                                        <td>{{ $action->type_label }}</td>
                                        <td><span class="badge bg-light text-dark border">{{ $action->responsible->name }}</span></td>
                                        <td>{{ $action->due_date->format('d.m.Y') }}</td>
                                        <td>
                                            @if($action->status == 'Completed') <span class="badge bg-success">Tamamlandı</span>
                                            @else <span class="badge bg-secondary">Bekliyor</span> @endif
                                        </td>
                                        <td class="text-end">
                                            @if($change->status == 'Approved')
                                                
                                                {{-- DÜZENLEME BUTONU (Sadece tamamlanmamışsa) --}}
                                                @if($action->status != 'Completed')
                                                    {{-- RİSK DÜZENLEME BUTONU --}}
<button class="btn btn-xs btn-outline-info me-1"
        data-id="{{ $risk->id }}"
        data-desc="{{ $risk->risk_description }}"
        data-prob="{{ $risk->probability }}"
        data-impact="{{ $risk->impact }}"
        data-plan="{{ $risk->mitigation_plan }}"
        onclick="openEditRiskModal(this)">
    <i class="fas fa-edit"></i>
</button>
                                                
                                                    {{-- TAMAMLAMA BUTONU --}}
                                                    <button class="btn btn-xs btn-success" onclick="completeAction({{ $action->id }})"><i class="fas fa-check"></i></button>
                                                @endif

                                            @endif
                                        </td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="6" class="text-center text-muted py-3">Henüz aksiyon planlanmamış.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            @endif

            {{-- 4. DOĞRULAMA VE KAPATMA (FİNAL AŞAMA) --}}
            @if($change->status == 'Completed' || $change->status == 'Closed')
            <div class="card shadow-sm border-top-lg border-success mt-4">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-clipboard-check me-2 text-success"></i>4. Etkinlik Doğrulama ve Kapatma
                </div>
                <div class="card-body">
                    @if($change->status == 'Closed')
                        <div class="alert alert-success d-flex align-items-center mb-0">
                            <i class="fas fa-check-circle fa-2x me-3"></i>
                            <div>
                                <h6 class="fw-bold mb-0">DEĞİŞİKLİK KAPATILDI</h6>
                                <div class="small mt-1">
                                    Kapanış Tarihi: {{ $change->closed_date->format('d.m.Y') }} <br>
                                    Doğrulama Sonucu: {{ $change->verification_result }}
                                </div>
                            </div>
                        </div>
                    @else
                        {{-- KAPATMA FORMU --}}
                        <form action="{{ route('admin.qms.changes.verify-close', $change->id) }}" method="POST" onsubmit="return confirm('Değişikliği kalıcı olarak kapatmak üzeresiniz. Emin misiniz?');">
                            @csrf
                            <div class="alert alert-light border">
                                <i class="fas fa-info-circle me-2 text-primary"></i>
                                Tüm aksiyonlar tamamlandı. Değişikliğin hedeflenen sonucu verip vermediğini değerlendirerek süreci kapatabilirsiniz.
                            </div>
                            <div class="mb-3">
                                <label class="fw-bold small">Etkinlik Doğrulama Sonucu / Değerlendirme</label>
                                <textarea name="verification_result" class="form-control" rows="3" required placeholder="Örn: Yapılan değişiklik sonrası hatalarda %20 azalma görüldü, süreç stabil çalışıyor."></textarea>
                            </div>
                            <div class="text-end">
                                <button type="submit" class="btn btn-success fw-bold px-4">
                                    <i class="fas fa-check-double me-1"></i> DOĞRULA VE KAPAT
                                </button>
                            </div>
                        </form>
                    @endif
                </div>
            </div>
            @endif

            {{-- UYGULAMA BİTİRME BUTONU (Sadece Approved ise ve tüm aksiyonlar bittiyse görünür) --}}
            @php 
                $allActionsDone = $change->actions->count() > 0 && $change->actions->where('status', '!=', 'Completed')->count() == 0;
            @endphp
            
            @if($change->status == 'Approved' && $allActionsDone)
                <div class="mt-4 text-end">
                    <form action="{{ route('admin.qms.changes.complete-process', $change->id) }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-primary fw-bold p-3 shadow">
                            <i class="fas fa-flag-checkered me-2"></i> TÜM AKSİYONLAR TAMAMLANDI - DOĞRULAMAYA GEÇ
                        </button>
                    </form>
                </div>
            @endif

        </div>
    </div>
</div>

{{-- MODALLAR --}}

{{-- 1. RİSK EKLEME MODALI --}}
<div class="modal fade" id="addRiskModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('admin.qms.changes.add-risk', $change->id) }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h6 class="modal-title fw-bold text-dark">Risk Ekle</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold">Olası Risk / Etki Tanımı</label>
                        <input type="text" name="risk_description" class="form-control" required placeholder="Örn: Üretim duruşu riski">
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="small fw-bold">Olasılık (1-5)</label>
                            <select name="probability" class="form-select" required>
                                <option value="1">1 - Çok Düşük</option>
                                <option value="2">2 - Düşük</option>
                                <option value="3">3 - Orta</option>
                                <option value="4">4 - Yüksek</option>
                                <option value="5">5 - Çok Yüksek</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="small fw-bold">Şiddet/Etki (1-5)</label>
                            <select name="impact" class="form-select" required>
                                <option value="1">1 - Önemsiz</option>
                                <option value="2">2 - Hafif</option>
                                <option value="3">3 - Orta</option>
                                <option value="4">4 - Ciddi</option>
                                <option value="5">5 - Kritik</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Önlem Planı (Mitigation)</label>
                        <textarea name="mitigation_plan" class="form-control" rows="2" placeholder="Riski düşürmek için ne yapılacak?"></textarea>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-warning text-dark fw-bold">KAYDET</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- 2. AKSİYON EKLEME MODALI --}}
<div class="modal fade" id="addActionModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('admin.qms.changes.add-action', $change->id) }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h6 class="modal-title fw-bold">Aksiyon Ekle</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold">Aksiyon Tipi</label>
                        <select name="action_type" class="form-select">
                            <option value="Training">Eğitim</option>
                            <option value="Document_Revision">Doküman Revizyonu</option>
                            <option value="Purchase">Satın Alma</option>
                            <option value="Other">Diğer</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Yapılacak İş</label>
                        <input type="text" name="description" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Sorumlu</label>
                        <select name="responsible_user_id" class="form-select select2" style="width:100%">
                            @foreach($users as $user)
                                <option value="{{ $user->id }}">{{ $user->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Termin Tarihi</label>
                        <input type="date" name="due_date" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-success fw-bold">KAYDET</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- 3. ONAY MODALI --}}
<div class="modal fade" id="approveModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <form action="{{ route('admin.qms.changes.approve', $change->id) }}" method="POST">
            @csrf
            <input type="hidden" name="action" value="approve">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h6 class="modal-title fw-bold">Değişikliği Onayla</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    Bu değişikliği onaylıyor ve uygulama aşamasına geçilmesine izin veriyor musunuz?
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-success fw-bold w-100">EVET, ONAYLA</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- 4. RED MODALI --}}
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('admin.qms.changes.approve', $change->id) }}" method="POST">
            @csrf
            <input type="hidden" name="action" value="reject">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h6 class="modal-title fw-bold">Değişikliği Reddet</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold">Red Nedeni</label>
                        <textarea name="rejection_reason" class="form-control" rows="3" required placeholder="Neden uygun bulunmadı?"></textarea>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-danger fw-bold">REDDET</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- 5. AKSİYON TAMAMLAMA MODALI --}}
<div class="modal fade" id="completeActionModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="completeActionForm" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h6 class="modal-title">Aksiyonu Tamamla</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <label class="small fw-bold">Tamamlama Notu / Kanıt</label>
                    <textarea name="completion_note" class="form-control" rows="3"></textarea>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-success">Kaydet</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- 6. RİSK DÜZENLEME MODALI --}}
<div class="modal fade" id="editRiskModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="editRiskForm" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h6 class="modal-title fw-bold">Riski Düzenle</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold">Olası Risk / Etki Tanımı</label>
                        <input type="text" name="risk_description" id="edit_risk_desc" class="form-control" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="small fw-bold">Olasılık (1-5)</label>
                            <select name="probability" id="edit_risk_prob" class="form-select" required>
                                <option value="1">1 - Çok Düşük</option>
                                <option value="2">2 - Düşük</option>
                                <option value="3">3 - Orta</option>
                                <option value="4">4 - Yüksek</option>
                                <option value="5">5 - Çok Yüksek</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="small fw-bold">Şiddet/Etki (1-5)</label>
                            <select name="impact" id="edit_risk_impact" class="form-select" required>
                                <option value="1">1 - Önemsiz</option>
                                <option value="2">2 - Hafif</option>
                                <option value="3">3 - Orta</option>
                                <option value="4">4 - Ciddi</option>
                                <option value="5">5 - Kritik</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Önlem Planı</label>
                        <textarea name="mitigation_plan" id="edit_risk_mitigation" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-info text-white fw-bold">GÜNCELLE</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- 7. AKSİYON DÜZENLEME MODALI --}}
<div class="modal fade" id="editActionModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="editActionForm" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h6 class="modal-title fw-bold">Aksiyonu Düzenle</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold">Aksiyon Tipi</label>
                        <select name="action_type" id="edit_action_type" class="form-select">
                            <option value="Training">Eğitim</option>
                            <option value="Document_Revision">Doküman Revizyonu</option>
                            <option value="Purchase">Satın Alma</option>
                            <option value="Other">Diğer</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Yapılacak İş</label>
                        <input type="text" name="description" id="edit_action_desc" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Sorumlu</label>
                        <select name="responsible_user_id" id="edit_action_user" class="form-select">
                            @foreach($users as $user)
                                <option value="{{ $user->id }}">{{ $user->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">Termin Tarihi</label>
                        <input type="date" name="due_date" id="edit_action_date" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer py-1">
                    <button type="submit" class="btn btn-info text-white fw-bold">GÜNCELLE</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- DUYURU MODALI --}}
<div class="modal fade" id="announceModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('admin.qms.changes.announce', $change->id) }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h6 class="modal-title fw-bold"><i class="fas fa-bullhorn me-2"></i>Değişiklik Duyurusu Yayınla</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-light border small">
                        <i class="fas fa-info-circle me-1 text-info"></i>
                        Bu işlem, seçilen personel grubuna <strong>E-Posta</strong> ve <strong>Sistem Bildirimi</strong> gönderecektir.
                    </div>

                    <div class="mb-3">
                        <label class="small fw-bold">Hedef Kitle</label>
                        <select name="target_audience" class="form-select">
                            <option value="all">Tüm Şirket Personeli</option>
                            @if($change->department_id)
                                <option value="department" selected>Sadece İlgili Departman ({{ $change->department->name }})</option>
                            @endif
                        </select>
                    </div>

                    <div class="mb-3">
    <label class="small fw-bold">Duyuru Mesajı</label>
    <textarea name="message" class="form-control" rows="5" required>Sayın Çalışma Arkadaşlarımız,

Sistemimizde {{ $change->code }} referans numaralı ve "{{ $change->title }}" konulu değişiklik talebi onaylanarak yürürlüğe girmiştir.

İlgili süreçlerin yeni revizyonlara uygun şekilde yürütülmesi önemle rica olunur. Detaylara aşağıdaki bağlantıdan ulaşabilirsiniz.</textarea>
    <small class="text-muted">Mesajın başına otomatik olarak "Sayın [Ad Soyad]" eklenecektir.</small>
</div>
                <div class="modal-footer py-1">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-info text-white fw-bold">
                        <i class="fas fa-paper-plane me-1"></i> GÖNDER
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection

@push('scripts')
<script>
    // --- RİSK DÜZENLEME ---
    function openEditRiskModal(button) {
        // Butonun içindeki data özelliklerini al
        let id = button.getAttribute('data-id');
        let desc = button.getAttribute('data-desc');
        let prob = button.getAttribute('data-prob');
        let impact = button.getAttribute('data-impact');
        let plan = button.getAttribute('data-plan');

        // Form action URL'sini güncelle
        let url = "{{ route('admin.qms.changes.update-risk', ':id') }}";
        url = url.replace(':id', id);
        document.getElementById('editRiskForm').action = url;

        // Inputları doldur
        document.getElementById('edit_risk_desc').value = desc;
        document.getElementById('edit_risk_prob').value = prob;
        document.getElementById('edit_risk_impact').value = impact;
        document.getElementById('edit_risk_mitigation').value = plan;
        
        // Modalı aç
        new bootstrap.Modal(document.getElementById('editRiskModal')).show();
    }

    // --- AKSİYON DÜZENLEME ---
    function openEditActionModal(button) {
        // Butonun içindeki data özelliklerini al
        let id = button.getAttribute('data-id');
        let type = button.getAttribute('data-type');
        let desc = button.getAttribute('data-desc');
        let user = button.getAttribute('data-user');
        let date = button.getAttribute('data-date');

        // Form action URL'sini güncelle
        let url = "{{ route('admin.qms.changes.update-action', ':id') }}";
        url = url.replace(':id', id);
        document.getElementById('editActionForm').action = url;

        // Inputları doldur
        document.getElementById('edit_action_type').value = type;
        document.getElementById('edit_action_desc').value = desc;
        document.getElementById('edit_action_user').value = user; // Select2 kullanıyorsan tetiklemen gerekebilir
        document.getElementById('edit_action_date').value = date;
        
        // Modalı aç
        new bootstrap.Modal(document.getElementById('editActionModal')).show();
    }

    // --- AKSİYON TAMAMLAMA ---
    function completeAction(id) {
        let url = "{{ route('admin.qms.changes.actions.complete', ':id') }}";
        url = url.replace(':id', id);
        document.getElementById('completeActionForm').action = url;
        new bootstrap.Modal(document.getElementById('completeActionModal')).show();
    }
</script>
@endpush