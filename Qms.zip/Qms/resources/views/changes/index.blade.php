@extends('layouts.admin')
@section('title', 'Değişiklik Yönetimi')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800"><i class="fas fa-exchange-alt me-2 text-primary"></i>Değişiklik Yönetimi (MOC)</h4>
            <div class="text-muted small">Süreç, ekipman ve doküman değişikliklerinin kontrollü yönetimi.</div>
        </div>
        <a href="{{ route('admin.qms.changes.create') }}" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus me-1"></i> Yeni Değişiklik Talebi
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Kod</th>
                            <th>Konu / Başlık</th>
                            <th>Tür</th>
                            <th>Öncelik</th>
                            <th>Durum</th>
                            <th>Talep Eden</th>
                            <th>Tarih</th>
                            <th class="text-end">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($changes as $change)
                        <tr>
                            <td class="fw-bold text-primary font-monospace">{{ $change->code }}</td>
                            <td>
                                <div class="fw-bold text-dark">{{ Str::limit($change->title, 40) }}</div>
                                <div class="small text-muted">{{ $change->department->name ?? 'Genel' }}</div>
                            </td>
                            <td><span class="badge bg-light text-dark border">{{ $change->type_label }}</span></td>
                            <td>
                                @if($change->priority == 'Critical') <span class="badge bg-danger">Kritik</span>
                                @elseif($change->priority == 'High') <span class="badge bg-warning text-dark">Yüksek</span>
                                @elseif($change->priority == 'Medium') <span class="badge bg-info text-dark">Orta</span>
                                @else <span class="badge bg-secondary">Düşük</span> @endif
                            </td>
                            <td>
                                <span class="badge {{ $change->status_label['class'] }}">
                                    {{ $change->status_label['text'] }}
                                </span>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-xs bg-secondary text-white rounded-circle me-2 d-flex justify-content-center align-items-center" style="width:24px; height:24px; font-size:10px;">
                                        {{ substr($change->requester->name, 0, 1) }}
                                    </div>
                                    <span class="small">{{ $change->requester->name }}</span>
                                </div>
                            </td>
                            <td class="small">{{ $change->created_at->format('d.m.Y') }}</td>
                            <td class="text-end">
                                <a href="{{ route('admin.qms.changes.show', $change->id) }}" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-eye me-1"></i> Yönet
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="8" class="text-center py-4 text-muted">Henüz değişiklik kaydı bulunmuyor.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-2">
            {{ $changes->links() }}
        </div>
    </div>
</div>
@endsection