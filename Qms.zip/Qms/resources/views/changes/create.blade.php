@extends('layouts.admin')
@section('title', 'Yeni Değişiklik Talebi')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">Yeni Değişiklik Talebi</h4>
        <a href="{{ route('admin.qms.changes.index') }}" class="btn btn-secondary shadow-sm">Geri</a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white">
            <h6 class="m-0"><i class="fas fa-edit me-2"></i>Değişiklik Talep Formu</h6>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.qms.changes.store') }}" method="POST">
                @csrf
                <div class="row g-3">
                    {{-- Üst Bilgiler --}}
                    <div class="col-md-8">
                        <label class="fw-bold small">Değişiklik Konusu / Başlık <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" placeholder="Örn: X Cihazının Yazılım Güncellemesi" required>
                    </div>
                    <div class="col-md-4">
                        <label class="fw-bold small">Değişiklik Türü <span class="text-danger">*</span></label>
                        <select name="type" class="form-select" required>
                            <option value="">-- Seçiniz --</option>
                            <option value="Procedure">Prosedür / Doküman</option>
                            <option value="Equipment">Cihaz / Ekipman</option>
                            <option value="Software">Yazılım</option>
                            <option value="Personnel">Personel / Organizasyon</option>
                            <option value="Facility">Tesis / Altyapı</option>
                            <option value="Other">Diğer</option>
                        </select>
                    </div>

                    {{-- Detaylar --}}
                    <div class="col-12">
                        <label class="fw-bold small">Değişiklik Tanımı (Mevcut Durum vs. Yeni Durum) <span class="text-danger">*</span></label>
                        <textarea name="description" class="form-control" rows="5" placeholder="Şu an nasıl yapılıyor? Değişiklikten sonra nasıl yapılacak?" required></textarea>
                    </div>

                    <div class="col-12">
                        <label class="fw-bold small">Değişiklik Nedeni / Gerekçe <span class="text-danger">*</span></label>
                        <textarea name="reason" class="form-control" rows="3" placeholder="Yasal zorunluluk, Müşteri talebi, Verimlilik artışı vb." required></textarea>
                    </div>

                    {{-- Sınıflandırma --}}
                    <div class="col-md-6">
                        <label class="fw-bold small">İlgili Departman</label>
                        <select name="department_id" class="form-select select2">
                            <option value="">-- Genel / Tüm --</option>
                            @foreach($departments as $dept)
                                <option value="{{ $dept->id }}">{{ $dept->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold small">Öncelik Seviyesi</label>
                        <select name="priority" class="form-select">
                            <option value="Low">Düşük</option>
                            <option value="Medium" selected>Orta</option>
                            <option value="High">Yüksek</option>
                            <option value="Critical">Kritik</option>
                        </select>
                    </div>
                </div>

                <div class="alert alert-info mt-4 small">
                    <i class="fas fa-info-circle me-1"></i> 
                    Kaydettikten sonra, bir sonraki adımda bu değişikliğin <strong>Risk ve Etki Analizi</strong> yapılacaktır.
                </div>

                <div class="text-end mt-2">
                    <button type="submit" class="btn btn-primary fw-bold px-4">KAYDET VE İLERLE</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection