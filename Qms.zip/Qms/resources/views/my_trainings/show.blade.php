@extends('layouts.admin')
@section('title', 'Eğitim Detayı')

@push('css')
<style>
    .material-item {
        transition: all 0.2s ease;
        border-left: 4px solid transparent;
    }
    .material-item:hover {
        background-color: #f8fafc;
        border-left-color: #0d6efd;
        transform: translateX(3px);
    }
    .material-icon-box {
        width: 42px;
        height: 42px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        flex-shrink: 0;
    }
    #materialViewerModal .modal-content {
        border: 0;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.45);
        user-select: none;
        -webkit-user-select: none;
    }
    #materialViewerModal .modal-header {
        background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
        color: #fff;
        border-bottom: 0;
        padding: 1rem 1.5rem;
    }
    #materialViewerModal .modal-body {
        background: #0f172a;
        min-height: 75vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        position: relative;
    }
    .viewer-iframe {
        width: 100%;
        height: 78vh;
        border: none;
        background: #fff;
    }
    .viewer-video {
        width: 100%;
        max-height: 78vh;
        background: #000;
        outline: none;
    }
    .viewer-image {
        max-width: 100%;
        max-height: 78vh;
        object-fit: contain;
        pointer-events: none;
    }
    .viewer-fallback {
        color: #fff;
        text-align: center;
        padding: 3rem 2rem;
        max-width: 560px;
    }
    /* Eğitim Geri Sayım Kutusu Stili */
    .timer-box {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        border: 1px solid #cbd5e1;
        border-radius: 12px;
        padding: 1rem;
        transition: all 0.3s ease;
    }
    .timer-box.paused {
        background: #fff3cd;
        border-color: #ffecb5;
    }
    .timer-box.completed {
        background: #d1e7dd;
        border-color: #badbcc;
    }
    .timer-digits {
        font-family: 'Courier New', Courier, monospace;
        font-size: 1.75rem;
        font-weight: 800;
        letter-spacing: 2px;
    }
</style>
@endpush

@section('content')
@php
    $plan = $record->plan;
    $training = $plan->training;
    $calculatedRequiredSeconds = $requiredSeconds ?? 0;
    if ($calculatedRequiredSeconds <= 0 && $plan && $plan->start_date && $plan->end_date) {
        $diff = \Carbon\Carbon::parse($plan->start_date)->diffInSeconds(\Carbon\Carbon::parse($plan->end_date), false);
        if ($diff > 0 && $diff <= 86400) {
            $calculatedRequiredSeconds = $diff;
        } elseif (!empty($plan->duration_hours) && $plan->duration_hours > 0) {
            $calculatedRequiredSeconds = (int) $plan->duration_hours * 3600;
        } elseif ($diff > 0) {
            $calculatedRequiredSeconds = $diff;
        }
    }
@endphp

<div class="container-fluid px-4 mt-4">
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    @if(session('info'))
        <div class="alert alert-info alert-dismissible fade show shadow-sm" role="alert">
            <i class="fas fa-info-circle me-2"></i>{{ session('info') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    {{-- BAŞLIK --}}
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h4 class="fw-bold text-gray-800 mb-1">{{ $record->plan->training->title }}</h4>
            <div class="small text-muted">
                <span class="badge bg-light text-dark border me-2">{{ $record->plan->training->code }}</span>
                <i class="fas fa-calendar-alt me-1 text-primary"></i> Başlangıç: <strong>{{ optional($record->plan->start_date)->format('d.m.Y H:i') ?: '-' }}</strong>
                <span class="mx-2">|</span>
                <i class="fas fa-flag-checkered me-1 text-danger"></i> Bitiş: <strong>{{ optional($record->plan->end_date)->format('d.m.Y H:i') ?: '-' }}</strong>
                <span class="mx-2">|</span>
                <i class="fas fa-user-tie me-1 text-secondary"></i> Eğitmen: <strong>{{ $record->plan->instructor ?: '-' }}</strong>
            </div>
        </div>
        <a href="{{ route('admin.qms.my-trainings.index') }}" class="btn btn-secondary btn-sm shadow-sm">
            <i class="fas fa-arrow-left me-1"></i> Geri Dön
        </a>
    </div>

    <div class="row">
        {{-- SOL: MATERYALLER --}}
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white fw-bold py-3 d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-book-reader me-2 text-primary"></i>Eğitim İçeriği ve Belgeler</span>
                    <span class="badge bg-primary rounded-pill">{{ $record->plan->training->materials->count() }} Materyal</span>
                </div>
                <div class="card-body">
                    <p class="text-muted">{{ $record->plan->training->description ?? 'Eğitim açıklaması bulunmuyor.' }}</p>
                    
                    <h6 class="fw-bold mt-4 mb-3"><i class="fas fa-folder-open me-2 text-warning"></i>Dokümanlar, Sunumlar ve Videolar</h6>
                    <div class="list-group">
                        @forelse($record->plan->training->materials as $material)
                            @php
                                $ext = strtolower(pathinfo($material->file_path, PATHINFO_EXTENSION) ?: $material->file_type);
                                $viewUrl = route('admin.qms.my-trainings.material.view', $material->id);
                                $directUrl = asset('storage/'.$material->file_path);
                                $isVideo = in_array($ext, ['mp4', 'webm', 'ogg', 'mov', 'avi']);
                                $isPdf = ($ext === 'pdf');
                                $isImage = in_array($ext, ['png', 'jpg', 'jpeg', 'gif', 'webp']);

                                $iconClass = 'fa-file-alt text-secondary';
                                $bgSoft = 'rgba(108, 117, 125, 0.12)';
                                $typeBadge = strtoupper($ext ?: 'DOSYA');

                                if ($isVideo) {
                                    $iconClass = 'fa-play-circle text-danger';
                                    $bgSoft = 'rgba(220, 53, 69, 0.12)';
                                    $typeBadge = 'VİDEO (' . strtoupper($ext) . ')';
                                } elseif ($isPdf) {
                                    $iconClass = 'fa-file-pdf text-danger';
                                    $bgSoft = 'rgba(220, 53, 69, 0.12)';
                                    $typeBadge = 'PDF BELGESİ';
                                } elseif (in_array($ext, ['ppt', 'pptx'])) {
                                    $iconClass = 'fa-file-powerpoint text-warning';
                                    $bgSoft = 'rgba(255, 193, 7, 0.18)';
                                    $typeBadge = 'SUNUM (' . strtoupper($ext) . ')';
                                } elseif (in_array($ext, ['doc', 'docx'])) {
                                    $iconClass = 'fa-file-word text-primary';
                                    $bgSoft = 'rgba(13, 110, 253, 0.12)';
                                    $typeBadge = 'WORD (' . strtoupper($ext) . ')';
                                } elseif (in_array($ext, ['xls', 'xlsx'])) {
                                    $iconClass = 'fa-file-excel text-success';
                                    $bgSoft = 'rgba(25, 135, 84, 0.12)';
                                    $typeBadge = 'EXCEL (' . strtoupper($ext) . ')';
                                } elseif ($isImage) {
                                    $iconClass = 'fa-file-image text-info';
                                    $bgSoft = 'rgba(13, 202, 240, 0.15)';
                                    $typeBadge = 'GÖRSEL (' . strtoupper($ext) . ')';
                                }
                            @endphp
                            <button type="button"
                                    class="list-group-item list-group-item-action material-item d-flex justify-content-between align-items-center py-3 open-material-modal text-start"
                                    data-title="{{ $material->title }}"
                                    data-ext="{{ $ext }}"
                                    data-url="{{ $viewUrl }}"
                                    data-direct-url="{{ $directUrl }}">
                                <div class="d-flex align-items-center gap-3">
                                    <div class="material-icon-box" style="background: {{ $bgSoft }};">
                                        <i class="fas {{ $iconClass }}"></i>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark">{{ $material->title }}</div>
                                        <div class="small text-muted">
                                            <span class="badge bg-light text-dark border me-1">{{ $typeBadge }}</span>
                                            Sistem içi önizleme için tıklayın (İndirilemez)
                                        </div>
                                    </div>
                                </div>
                                <span class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                    <i class="fas fa-expand-alt me-1"></i> İncele / İzle
                                </span>
                            </button>
                        @empty
                            <div class="alert alert-warning mb-0">
                                <i class="fas fa-exclamation-triangle me-1"></i> Bu eğitim için materyal yüklenmemiştir.
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>

        {{-- SAĞ: SINAV, SÜRE SAYACI VE TAMAMLAMA DURUMU --}}
        <div class="col-lg-4">
            {{-- 1. KART: EĞİTİM / SINAV DURUMU --}}
            <div class="card shadow-sm border-0 border-top-lg border-warning mb-4">
                <div class="card-body text-center">
                    <h5 class="fw-bold">{{ $record->plan->training->has_exam ? 'Sınav Durumu' : 'Eğitim Tamamlama Durumu' }}</h5>
                    <hr>
                    
                    @if($record->result == 'Pending')
                        {{-- AKTİF EĞİTİM SÜRESİ VE GERİ SAYIM SAYACI --}}
                        @if($calculatedRequiredSeconds > 0)
                            <div class="timer-box mb-3 text-center" id="trainingTimerBox">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="small fw-bold text-uppercase text-muted">
                                        <i class="fas fa-stopwatch me-1 text-primary" id="timerIcon"></i>Kalan Eğitim Süresi
                                    </span>
                                    <span class="badge bg-success" id="timerStatusBadge">Sayaç Aktif</span>
                                </div>
                                <div class="timer-digits text-dark my-1" id="countdownDisplay">--:--:--</div>
                                <div class="progress my-2" style="height: 8px;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary" id="timerProgressBar" role="progressbar" style="width: 0%"></div>
                                </div>
                                <div class="small text-muted" id="timerHintText" style="font-size: 0.75rem;">
                                    Bu sayfada aktif kaldığınız süre hesaplanmaktadır. Başka sekmeye geçildiğinde veya pencere alta alındığında sayaç duraklatılır.
                                </div>
                            </div>
                        @endif

                        @if($record->plan->training->has_exam)
                            {{-- SINAVLI EĞİTİM: BEKLİYOR --}}
                            <div class="mb-3">
                                <p class="fw-semibold mb-1">Henüz sınava girmediniz.</p>
                                <p class="small text-muted mb-2">Eğitim materyallerini ve süresini tamamladıktan sonra online sınava başlayabilirsiniz.</p>
                            </div>
                            
                            <a href="{{ route('admin.qms.my-trainings.exam.start', $record->id) }}"
                               id="startExamBtn"
                               class="btn btn-lg btn-warning w-100 fw-bold shadow-sm {{ $calculatedRequiredSeconds > 0 ? 'disabled' : '' }}"
                               onclick="return confirm('Sınavı başlatmak istediğinize emin misiniz? Geri dönüşü olmayabilir.');">
                                <i class="fas fa-pencil-alt me-2"></i> SINAVI BAŞLAT
                            </a>
                        @else
                            {{-- SINAVSIZ EĞİTİM: OKUDUM İZLEDİM ANLADIM TAMAMLA --}}
                            <div class="mb-3">
                                <p class="fw-semibold mb-1">Bu eğitim için sınav zorunluluğu yoktur.</p>
                                <p class="small text-muted mb-2">Eğitim materyallerini inceleyip zorunlu eğitim süresini doldurduktan sonra aşağıdaki onay kutucuğunu işaretleyerek eğitimi tamamlayabilirsiniz.</p>
                            </div>

                            <form action="{{ route('admin.qms.my-trainings.complete', $record->id) }}" method="POST" id="completeNoExamForm">
                                @csrf
                                <input type="hidden" name="spent_seconds" id="spentSecondsInput" value="0">
                                <div class="form-check text-start bg-light p-3 rounded border mb-3">
                                    <input class="form-check-input" type="checkbox" id="confirmReadUnderstand" required {{ $calculatedRequiredSeconds > 0 ? 'disabled' : '' }}>
                                    <label class="form-check-label small fw-bold text-dark cursor-pointer" for="confirmReadUnderstand">
                                        Eğitim içeriğini ve materyallerini okudum, izledim ve anladım.
                                    </label>
                                </div>
                                <button type="submit" id="completeTrainingBtn" class="btn btn-lg btn-success w-100 fw-bold shadow-sm" {{ $calculatedRequiredSeconds > 0 ? 'disabled' : '' }}>
                                    <i class="fas {{ $calculatedRequiredSeconds > 0 ? 'fa-lock' : 'fa-check-double' }} me-2" id="completeBtnIcon"></i>
                                    <span id="completeBtnText">{{ $calculatedRequiredSeconds > 0 ? 'SÜRENİN DOLMASI BEKLENİYOR...' : 'OKUDUM, İZLEDİM, ANLADIM (TAMAMLA)' }}</span>
                                </button>
                            </form>
                        @endif

                    @elseif($record->result == 'Passed')
                        {{-- DURUM: BAŞARILI / TAMAMLANDI --}}
                        <div class="mb-3">
                            <i class="fas fa-check-circle fa-4x text-success mb-3"></i>
                            <h4 class="text-success fw-bold">{{ $record->plan->training->has_exam ? 'BAŞARILI' : 'EĞİTİM TAMAMLANDI' }}</h4>
                            @if($record->plan->training->has_exam)
                                <p class="display-6 fw-bold mb-0">{{ $record->exam_score }}</p>
                                <p class="text-muted small">Puan ile sınavı geçtiniz.</p>
                            @else
                                <p class="text-muted small mb-1">Eğitim içeriklerini okuyup onaylayarak başarıyla tamamladınız.</p>
                            @endif
                            @if($record->completed_at || $record->exam_date)
                                <div class="small text-muted mt-2">
                                    <i class="fas fa-clock me-1"></i> Tamamlanma: <strong>{{ optional($record->completed_at ?: $record->exam_date)->format('d.m.Y H:i') }}</strong>
                                </div>
                            @endif
                        </div>
                        
                        {{-- SERTİFİKA BUTONU --}}
                        @if($record->certificate_path)
                            <button type="button"
                                    class="btn btn-success w-100 fw-bold shadow-sm open-material-modal mb-2"
                                    data-title="{{ $record->plan->training->title }} - Başarı Sertifikası"
                                    data-ext="pdf"
                                    data-url="{{ asset('storage/'.$record->certificate_path) }}">
                                <i class="fas fa-award me-2"></i> SERTİFİKAYI GÖRÜNTÜLE
                            </button>
                        @endif

                    @elseif($record->result == 'Failed')
                        {{-- DURUM: BAŞARISIZ --}}
                        <div class="mb-3">
                            <i class="fas fa-times-circle fa-4x text-danger mb-3"></i>
                            <h4 class="text-danger fw-bold">BAŞARISIZ</h4>
                            <p class="display-6 fw-bold">{{ $record->exam_score }}</p>
                            <p class="text-muted">Geçme Notu: {{ $record->plan->training->passing_score }}</p>
                        </div>
                        <a href="{{ route('admin.qms.my-trainings.exam.start', $record->id) }}" class="btn btn-outline-danger w-100">
                            <i class="fas fa-redo me-1"></i> Tekrar Dene
                        </a>
                    @endif
                </div>
            </div>

            {{-- 2. KART: EĞİTİM DEĞERLENDİRME --}}
            @if($record->result == 'Passed')
                <div class="card shadow-sm border-0 border-top-lg border-primary">
                    <div class="card-header bg-white fw-bold">
                        <i class="fas fa-star me-2 text-warning"></i>Eğitim Değerlendirmesi
                    </div>
                    <div class="card-body">
                        
                        @if($record->evaluation)
                            {{-- DAHA ÖNCE DEĞERLENDİRMİŞSE --}}
                            <div class="text-center py-2">
                                <h6 class="text-muted mb-2">Verdiğiniz Puan</h6>
                                <div class="mb-2">
                                    @for($i=1; $i<=5; $i++)
                                        <i class="fas fa-star fa-lg {{ $i <= $record->evaluation->rating ? 'text-warning' : 'text-gray-300' }}"></i>
                                    @endfor
                                </div>
                                @if($record->evaluation->comment)
                                    <div class="p-2 bg-light rounded border text-muted small fst-italic">
                                        "{{ $record->evaluation->comment }}"
                                    </div>
                                @endif
                                <div class="alert alert-success mt-3 py-2 small mb-0">
                                    <i class="fas fa-check-circle me-1"></i> Teşekkürler, geri bildiriminiz alındı.
                                </div>
                            </div>
                        @else
                            {{-- HENÜZ DEĞERLENDİRMEMİŞSE --}}
                            <p class="small text-muted mb-3">Hizmet kalitemizi artırmak için lütfen bu eğitimi değerlendirin.</p>
                            
                            <form action="{{ route('admin.qms.my-trainings.evaluate.store', $record->id) }}" method="POST">
                                @csrf
                                
                                <div class="mb-3 text-center">
                                    <label class="form-label fw-bold d-block small">Puanınız</label>
                                    <div class="btn-group w-100" role="group">
                                        @for($i=1; $i<=5; $i++)
                                            <input type="radio" class="btn-check" name="rating" id="rating{{$i}}" value="{{$i}}" required>
                                            <label class="btn btn-outline-warning btn-sm" for="rating{{$i}}">{{$i}} <i class="fas fa-star"></i></label>
                                        @endfor
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Yorumunuz (Opsiyonel)</label>
                                    <textarea name="comment" class="form-control form-control-sm" rows="3" placeholder="Görüşleriniz..."></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary w-100 btn-sm">
                                    <i class="fas fa-paper-plane me-1"></i> Değerlendirmeyi Gönder
                                </button>
                            </form>
                        @endif

                    </div>
                </div>
            @endif

        </div>
    </div>
</div>

{{-- ŞIK SİSTEM İÇİ MATERYAL GÖRÜNTÜLEME MODALI (İNDİRME KORUMALI) --}}
<div class="modal fade" id="materialViewerModal" tabindex="-1" aria-hidden="true" oncontextmenu="return false;">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content" oncontextmenu="return false;">
            <div class="modal-header">
                <div class="d-flex align-items-center gap-2">
                    <i class="fas fa-book-open text-warning fs-5" id="viewerModalIcon"></i>
                    <div>
                        <h5 class="modal-title fw-bold mb-0" id="viewerModalTitle">Eğitim Materyali</h5>
                        <small class="text-white-50" id="viewerModalSubtitle">Sistem İçi Güvenli Önizleme (İndirilemez)</small>
                    </div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-secondary bg-opacity-50 text-white border border-light border-opacity-25 px-3 py-2">
                        <i class="fas fa-shield-alt me-1 text-warning"></i> Salt Okunur Mod
                    </span>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
                </div>
            </div>
            <div class="modal-body" id="viewerModalBody" oncontextmenu="return false;">
                {{-- Dinamik içerik buraya yüklenecek --}}
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    // 1. SİSTEM İÇİ MATERYAL GÖRÜNTÜLEYİCİ (İndirme Korumalı)
    const modalEl = document.getElementById('materialViewerModal');
    const modalTitle = document.getElementById('viewerModalTitle');
    const modalSubtitle = document.getElementById('viewerModalSubtitle');
    const modalBody = document.getElementById('viewerModalBody');
    const modalIcon = document.getElementById('viewerModalIcon');

    let bsModal = null;
    if (modalEl && typeof bootstrap !== 'undefined') {
        bsModal = new bootstrap.Modal(modalEl);
    }

    function renderMaterialInModal(title, ext, url, directUrl) {
        ext = (ext || '').toLowerCase();
        modalTitle.textContent = title || 'Eğitim Materyali';
        modalSubtitle.textContent = ext ? ('Dosya Türü: ' + ext.toUpperCase() + ' · Salt Okunur Önizleme') : 'Sistem İçi Güvenli Önizleme';
        modalBody.innerHTML = '';

        const videoExts = ['mp4', 'webm', 'ogg', 'mov', 'avi'];
        const imageExts = ['png', 'jpg', 'jpeg', 'gif', 'webp'];
        const officeExts = ['ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx'];

        if (videoExts.includes(ext)) {
            modalIcon.className = 'fas fa-play-circle text-danger fs-5';
            modalBody.innerHTML = `
                <video class="viewer-video" controls autoplay controlsList="nodownload noplaybackrate" disablePictureInPicture oncontextmenu="return false;">
                    <source src="${url}" type="video/${ext === 'mov' ? 'mp4' : ext}">
                    <source src="${directUrl || url}">
                    Tarayıcınız bu video formatını desteklemiyor.
                </video>
            `;
        } else if (ext === 'pdf') {
            modalIcon.className = 'fas fa-file-pdf text-danger fs-5';
            // #toolbar=0&navpanes=0&scrollbar=1 ile PDF üst barındaki İndir/Yazdır butonlarını gizler
            modalBody.innerHTML = `
                <iframe src="${url}#toolbar=0&navpanes=0&scrollbar=1&view=FitH" class="viewer-iframe" oncontextmenu="return false;"></iframe>
            `;
        } else if (imageExts.includes(ext)) {
            modalIcon.className = 'fas fa-file-image text-info fs-5';
            modalBody.innerHTML = `
                <div class="p-3 text-center w-100" oncontextmenu="return false;">
                    <img src="${url}" alt="${title}" class="viewer-image rounded shadow" draggable="false" oncontextmenu="return false;">
                </div>
            `;
        } else if (officeExts.includes(ext)) {
            modalIcon.className = 'fas fa-file-powerpoint text-warning fs-5';
            // ÖNEMLİ: Microsoft Office Online sunucusu auth middleware arkasındaki route'a erişemez,
            // bu yüzden sadece embed motoruna public storage URL'si (directUrl) verilir; ekranda indirme butonu gösterilmez.
            const publicSourceUrl = new URL(directUrl || url, window.location.origin).href;
            const isLocal = ['localhost', '127.0.0.1'].includes(window.location.hostname) || window.location.hostname.endsWith('.test') || window.location.hostname.endsWith('.local');

            if (!isLocal) {
                const officeEmbedUrl = 'https://view.officeapps.live.com/op/embed.aspx?src=' + encodeURIComponent(publicSourceUrl) + '&wdDownloadButton=False&wdPrint=False';
                modalBody.innerHTML = `
                    <iframe src="${officeEmbedUrl}" class="viewer-iframe" oncontextmenu="return false;"></iframe>
                `;
            } else {
                modalBody.innerHTML = `
                    <div class="viewer-fallback">
                        <i class="fas fa-file-powerpoint fa-4x text-warning mb-3"></i>
                        <h5 class="fw-bold mb-2">${title}</h5>
                        <p class="text-white-50 small mb-0">
                            PowerPoint / Office belgelerinin (${ext.toUpperCase()}) sistem içi gömülü önizlemesi canlı sunucuda otomatik olarak bu pencerede açılır. (Güvenlik gereği dosya indirme kapalıdır.)
                        </p>
                    </div>
                `;
            }
        } else {
            modalIcon.className = 'fas fa-file-alt text-info fs-5';
            modalBody.innerHTML = `
                <iframe src="${url}#toolbar=0" class="viewer-iframe" oncontextmenu="return false;"></iframe>
            `;
        }

        if (bsModal) {
            bsModal.show();
        }
    }

    document.querySelectorAll('.open-material-modal').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            renderMaterialInModal(
                this.dataset.title,
                this.dataset.ext,
                this.dataset.url,
                this.dataset.directUrl
            );
        });
    });

    if (modalEl) {
        modalEl.addEventListener('hidden.bs.modal', function () {
            modalBody.innerHTML = '';
        });
    }

    // 2. AKTİF SAYFA SÜRESİ HESAPLAYAN GERİ SAYIM SAYACI (Sekme Değişince / Alta Alınınca Durur)
    @if($record->result == 'Pending' && $calculatedRequiredSeconds > 0)
    (function () {
        const recordId = {{ (int) $record->id }};
        const userId = {{ (int) auth()->id() }};
        const requiredSeconds = {{ (int) $calculatedRequiredSeconds }};
        const storageKey = `qms_training_spent_seconds_${userId}_${recordId}`;

        let spentSeconds = parseInt(localStorage.getItem(storageKey) || '0', 10);
        if (isNaN(spentSeconds) || spentSeconds < 0) {
            spentSeconds = 0;
        }
        if (spentSeconds > requiredSeconds) {
            spentSeconds = requiredSeconds;
        }

        const timerBox = document.getElementById('trainingTimerBox');
        const countdownDisplay = document.getElementById('countdownDisplay');
        const progressBar = document.getElementById('timerProgressBar');
        const statusBadge = document.getElementById('timerStatusBadge');
        const hintText = document.getElementById('timerHintText');
        const spentInput = document.getElementById('spentSecondsInput');
        const confirmCheckbox = document.getElementById('confirmReadUnderstand');
        const completeBtn = document.getElementById('completeTrainingBtn');
        const completeBtnIcon = document.getElementById('completeBtnIcon');
        const completeBtnText = document.getElementById('completeBtnText');
        const startExamBtn = document.getElementById('startExamBtn');

        let isPaused = document.hidden;

        function formatTime(totalSec) {
            const hrs = Math.floor(totalSec / 3600);
            const mins = Math.floor((totalSec % 3600) / 60);
            const secs = totalSec % 60;
            return [
                String(hrs).padStart(2, '0'),
                String(mins).padStart(2, '0'),
                String(secs).padStart(2, '0')
            ].join(':');
        }

        function updateUI() {
            const remaining = Math.max(0, requiredSeconds - spentSeconds);
            const pct = requiredSeconds > 0 ? Math.min(100, Math.round((spentSeconds / requiredSeconds) * 100)) : 100;

            if (countdownDisplay) {
                countdownDisplay.textContent = formatTime(remaining);
            }
            if (progressBar) {
                progressBar.style.width = pct + '%';
            }
            if (spentInput) {
                spentInput.value = spentSeconds;
            }

            if (remaining <= 0) {
                // Süre Tamamlandı!
                if (timerBox) {
                    timerBox.classList.remove('paused');
                    timerBox.classList.add('completed');
                }
                if (statusBadge) {
                    statusBadge.className = 'badge bg-success';
                    statusBadge.innerHTML = '<i class="fas fa-check me-1"></i>Süre Tamamlandı';
                }
                if (progressBar) {
                    progressBar.classList.remove('progress-bar-animated', 'bg-primary', 'bg-warning');
                    progressBar.classList.add('bg-success');
                }
                if (hintText) {
                    hintText.innerHTML = '<strong class="text-success"><i class="fas fa-check-circle me-1"></i>Zorunlu eğitim süresini tamamladınız! Şimdi eğitimi onaylayıp tamamlayabilirsiniz.</strong>';
                }
                if (confirmCheckbox) {
                    confirmCheckbox.disabled = false;
                }
                if (completeBtn) {
                    completeBtn.disabled = false;
                }
                if (completeBtnIcon) {
                    completeBtnIcon.className = 'fas fa-check-double me-2';
                }
                if (completeBtnText) {
                    completeBtnText.textContent = 'OKUDUM, İZLEDİM, ANLADIM (TAMAMLA)';
                }
                if (startExamBtn) {
                    startExamBtn.classList.remove('disabled');
                }
            } else {
                // Süre Devam Ediyor
                if (isPaused) {
                    if (timerBox) timerBox.classList.add('paused');
                    if (statusBadge) {
                        statusBadge.className = 'badge bg-warning text-dark';
                        statusBadge.innerHTML = '<i class="fas fa-pause me-1"></i>Duraklatıldı (Sekme Pasif)';
                    }
                    if (progressBar) {
                        progressBar.classList.remove('bg-primary');
                        progressBar.classList.add('bg-warning');
                    }
                } else {
                    if (timerBox) timerBox.classList.remove('paused');
                    if (statusBadge) {
                        statusBadge.className = 'badge bg-success';
                        statusBadge.innerHTML = '<i class="fas fa-play me-1"></i>Sayaç Aktif';
                    }
                    if (progressBar) {
                        progressBar.classList.remove('bg-warning');
                        progressBar.classList.add('bg-primary');
                    }
                }
            }
        }

        // Sayfa görünürlüğü ve pencere odağı kontrolü
        // Not: Sayfa içindeki PDF/Sunum iframe'ine tıklandığında document.hidden false kalır, böylece materyal okurken sayaç çalışmaya devam eder;
        // ancak başka sekmeye geçildiğinde veya tarayıcı alta alındığında durur.
        function checkVisibility() {
            if (document.hidden) {
                isPaused = true;
            } else {
                isPaused = false;
            }
            updateUI();
        }

        document.addEventListener('visibilitychange', checkVisibility);
        window.addEventListener('blur', function () {
            // Eğer odak sayfa içindeki materyal modalı iframe'ine geçtiyse durdurma, pencere dışına çıktıysa durdur
            setTimeout(function () {
                const activeEl = document.activeElement;
                if (document.hidden || (!activeEl || activeEl.tagName !== 'IFRAME')) {
                    isPaused = true;
                    updateUI();
                }
            }, 100);
        });
        window.addEventListener('focus', function () {
            isPaused = false;
            updateUI();
        });

        updateUI();

        const intervalId = setInterval(function () {
            if (spentSeconds >= requiredSeconds) {
                updateUI();
                clearInterval(intervalId);
                return;
            }

            if (!isPaused && !document.hidden) {
                spentSeconds++;
                localStorage.setItem(storageKey, String(spentSeconds));
                updateUI();
            }
        }, 1000);
    })();
    @endif
});
</script>
@endpush
@endsection
