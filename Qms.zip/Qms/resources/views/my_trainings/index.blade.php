@extends('layouts.admin')
@section('title', 'Eğitimlerim')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">
            <i class="fas fa-chalkboard-teacher me-2 text-warning"></i>Eğitimlerim
        </h4>
        <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#requestModal">
            <i class="fas fa-plus-circle me-1"></i> Yeni Eğitim Talep Et
        </button>
    </div>

    <div class="row">
        @forelse($myTrainings as $record)
        <div class="col-md-6 col-xl-4 mb-4">
            <div class="card h-100 shadow-sm border-0 border-start-lg border-start-{{ $record->result == 'Passed' ? 'success' : ($record->result == 'Failed' ? 'danger' : 'primary') }}">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="badge bg-light text-dark border">{{ $record->plan->training->code }}</span>
                        @if($record->result == 'Passed') <span class="badge bg-success">BAŞARILI</span>
                        @elseif($record->result == 'Failed') <span class="badge bg-danger">BAŞARISIZ</span>
                        @else <span class="badge bg-warning text-dark">BEKLİYOR</span>
                        @endif
                    </div>
                    <h5 class="fw-bold text-dark mb-1">{{ $record->plan->training->title }}</h5>
                    <p class="text-muted small mb-3">
                        <i class="fas fa-calendar-alt me-1 text-primary"></i> Başlangıç: {{ optional($record->plan->start_date)->format('d.m.Y H:i') ?: '-' }} <br>
                        <i class="fas fa-flag-checkered me-1 text-danger"></i> Bitiş: {{ optional($record->plan->end_date)->format('d.m.Y H:i') ?: '-' }} <br>
                        <i class="fas fa-user-tie me-1 text-secondary"></i> {{ $record->plan->instructor }}
                    </p>
                    
                    @if($record->result == 'Passed')
                        <div class="alert alert-success py-1 small text-center mb-3">
                            <i class="fas fa-trophy me-1"></i> Puan: <strong>{{ $record->exam_score }}</strong>
                        </div>
                    @endif

                    <div class="d-grid">
                        <a href="{{ route('admin.qms.my-trainings.show', $record->id) }}" class="btn btn-primary">
                            <i class="fas fa-play-circle me-1"></i> Eğitime Git
                        </a>
                    </div>
                </div>
            </div>
        </div>
        @empty
            <div class="col-12">
                <div class="alert alert-light text-center">Henüz size atanmış bir eğitim bulunmuyor.</div>
            </div>
        @endforelse
    </div>
</div>

{{-- EĞİTİM TALEP MODALI --}}
<div class="modal fade" id="requestModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('admin.qms.my-trainings.request.store') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-hand-paper me-2"></i>Eğitim Talebi</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info small">
                        <i class="fas fa-info-circle me-1"></i> İhtiyaç duyduğunuz eğitimi buradan talep edebilirsiniz. Talebiniz Kalite Yöneticisi tarafından değerlendirilecektir.
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Talep Edilen Eğitim Konusu</label>
                        <input type="text" name="subject" class="form-control" placeholder="Örn: İleri Excel veya ISO 14001 Eğitimi" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Gerekçe / Açıklama</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Bu eğitime neden ihtiyaç duyuyorsunuz?"></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Öncelik Durumu</label>
                        <select name="priority" class="form-select">
                            <option value="Normal">Normal</option>
                            <option value="Acil">Acil (Denetim/Uygunsuzluk Kaynaklı)</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Vazgeç</button>
                    <button type="submit" class="btn btn-primary">Talebi Gönder</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection