@extends('layouts.admin')
@section('title', 'Online Sınav')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <form action="{{ route('admin.qms.my-trainings.exam.submit', $record->id) }}" method="POST" id="examForm">
                @csrf
                
                {{-- BAŞLIK KARTI --}}
                <div class="card shadow-sm border-warning border-top-lg mb-4">
                    <div class="card-body text-center">
                        <h4 class="fw-bold">{{ $record->plan->training->title }} - Sınavı</h4>
                        <div class="text-muted small">
                            Toplam Soru: <strong>{{ $questions->count() }}</strong> | 
                            Geçme Notu: <strong>{{ $record->plan->training->passing_score }}</strong>
                        </div>
                    </div>
                </div>

                {{-- SORULAR --}}
                @foreach($questions as $index => $question)
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-white fw-bold">
                            <span class="badge bg-secondary me-2">Soru {{ $index + 1 }}</span>
                            {{ $question->question_text }}
                        </div>
                        <div class="card-body">
                            @foreach($question->options as $option)
                                <div class="form-check mb-2 p-3 border rounded hover-shadow">
                                    <input class="form-check-input" type="radio" 
                                           name="answers[{{ $question->id }}]" 
                                           id="opt_{{ $option->id }}" 
                                           value="{{ $option->id }}" required>
                                    <label class="form-check-label w-100 cursor-pointer" for="opt_{{ $option->id }}">
                                        {{ $option->option_text }}
                                    </label>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endforeach

                {{-- BİTİR BUTONU --}}
                <div class="d-grid gap-2 mb-5">
                    <button type="submit" class="btn btn-success btn-lg fw-bold shadow" onclick="return confirm('Sınavı bitirmek ve cevapları göndermek istediğinize emin misiniz?')">
                        <i class="fas fa-check-double me-2"></i> SINAVI BİTİR VE GÖNDER
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    .hover-shadow:hover { background-color: #f8f9fa; cursor: pointer; }
    .cursor-pointer { cursor: pointer; }
</style>
@endpush