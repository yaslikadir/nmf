@extends('layouts.admin')
@section('title', 'Eğitim Planla')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">Yeni Eğitim Planla & Ata</h4>
        <a href="{{ route('admin.qms.plans.index') }}" class="btn btn-secondary shadow-sm">Geri</a>
    </div>

    {{-- TALEP ÜZERİNE GELDİYSE BİLGİ VER --}}
    @if(isset($preFilledNote) && $preFilledNote)
        <div class="alert alert-info border-left-info shadow-sm mb-3">
            <i class="fas fa-info-circle me-1"></i> Bu plan, bir <strong>Personel Talebi</strong> üzerine oluşturulmaktadır. İlgili personel ve notlar otomatik seçilmiştir.
        </div>
    @endif

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <form action="{{ route('admin.qms.plans.store') }}" method="POST">
                @csrf
                
                {{-- TALEP ID'si VARSA GİZLİ GÖNDER (Store Metodu İçin Şart) --}}
                @if(isset($requestId))
                    <input type="hidden" name="request_id" value="{{ $requestId }}">
                @endif

                <div class="row g-3">
                    {{-- 1. EĞİTİM SEÇİMİ --}}
                    <div class="col-md-12">
                        <label class="fw-bold small">Hangi Eğitim Verilecek?</label>
                        <select name="training_id" class="form-select" required>
                            <option value="">Seçiniz...</option>
                            @foreach($trainings as $training)
                                <option value="{{ $training->id }}" {{ old('training_id') == $training->id ? 'selected' : '' }}>
                                    [{{ $training->code }}] {{ $training->title }} 
                                    ({{ $training->type == 'Online' ? 'Online' : 'Yüz Yüze' }})
                                </option>
                            @endforeach
                        </select>
                    </div>

                    {{-- 2. TARİH VE EĞİTMEN --}}
                    <div class="col-md-6">
                        <label class="fw-bold small">Başlangıç Tarihi & Saati</label>
                        <input type="datetime-local" name="start_date" class="form-control" value="{{ old('start_date') }}" required>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold small">Bitiş Tarihi & Saati</label>
                        <input type="datetime-local" name="end_date" class="form-control" value="{{ old('end_date') }}" required>
                    </div>

                    <div class="col-md-6">
    <label class="fw-bold small">Eğitim Süresi (Saat)</label>
    <input type="number" name="duration_hours" class="form-control" value="{{ old('duration_hours', $plan->duration_hours ?? '') }}" placeholder="Örn: 8" required>
    <div class="form-text small">Sertifikada görünecek net eğitim süresi.</div>
</div>

                    <div class="col-md-6">
                        <label class="fw-bold small">Eğitmen / Sorumlu</label>
                        <input type="text" name="instructor" class="form-control" value="{{ old('instructor') }}" placeholder="Örn: Dr. Ayşe Yılmaz veya Online Sistem" required>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold small">Yer / Link</label>
                        <input type="text" name="location" class="form-control" value="{{ old('location') }}" placeholder="Örn: Toplantı Odası 1 veya Zoom Linki">
                    </div>

                    {{-- 3. KATILIMCILAR (Otomatik Seçim Özelliği Eklendi) --}}
                    <div class="col-12">
                        <label class="fw-bold small text-primary">Katılımcı Personel Seçimi</label>
                        <div class="alert alert-light border small mb-2">
                            <i class="fas fa-info-circle me-1"></i> Birden fazla personel seçmek için CTRL tuşuna basılı tutun veya listeden arayın.
                        </div>
                        <select name="participants[]" class="form-select" multiple size="8" required style="height: 200px;">
                            @foreach($users as $user)
                                <option value="{{ $user->id }}" 
                                    {{ (collect(old('participants'))->contains($user->id)) ? 'selected' : '' }}
                                    {{ (isset($preSelectedUser) && $preSelectedUser == $user->id) ? 'selected' : '' }}
                                >
                                    {{ $user->name }} - {{ $user->title ?? '-' }} ({{ $user->department->name ?? '-' }})
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="fw-bold small">Notlar</label>
                        {{-- Talep konusu buraya otomatik gelecek --}}
                        <textarea name="notes" class="form-control" rows="2">{{ old('notes', $preFilledNote ?? '') }}</textarea>
                    </div>
                </div>

                <div class="text-end mt-4">
                    <button type="submit" class="btn btn-primary fw-bold px-4">
                        <i class="fas fa-save me-1"></i> PLANI OLUŞTUR VE ATA
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection