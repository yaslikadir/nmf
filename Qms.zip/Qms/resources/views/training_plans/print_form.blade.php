<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Eğitim Katılım Formu</title>
    <style>
        @page { margin: 10mm; }
        body { font-family: 'Arial', sans-serif; font-size: 12px; color: #000; }
        
        /* Tablo Stilleri */
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        
        /* Başlık Alanı */
        .header-table td { border: 1px solid #000; padding: 10px; vertical-align: middle; }
        .logo-area { text-align: center; width: 150px; font-weight: bold; color: #555; }
        .title-area { text-align: center; font-size: 18px; font-weight: bold; }
        .info-table td { width: 25%; }
        
        /* İmza Satırları */
        .sign-row { height: 35px; } /* İmza için boşluk */
        
        /* Alt Bilgi */
        .footer-table td { border: 1px solid #000; font-size: 10px; vertical-align: top; }
        
        /* Yazdırma Ayarı */
        @media print {
            .no-print { display: none; }
            body { -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body onload="window.print()">

    <div class="no-print" style="text-align: center; margin-bottom: 20px; padding: 10px; background: #f0f0f0; border-bottom: 1px solid #ccc;">
        <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px; cursor: pointer; background: #333; color: #fff; border: none; border-radius: 5px;">
            Yazdır / PDF Olarak Kaydet
        </button>
    </div>

    <table class="header-table">
        <tr>
            <td class="logo-area">
                <img src="{{ asset('assets/img/logo.png') }}" style="max-width: 120px;">
            </td>
            <td class="title-area">EĞİTİM KATILIM FORMU</td>
            <td style="width: 150px; font-size: 10px;">
                <strong>Doküman No:</strong> FR-03-12<br>
                <strong>Yayın Tarihi:</strong> 18.01.2019<br>
                <strong>Rev. No/Tarihi:</strong> 01/{{ date('d.m.Y') }}<br>
                <strong>Sayfa No:</strong> 1/1
            </td>
        </tr>
    </table>

    <table class="info-table">
        <tr>
            <td style="background-color: #f0f0f0; font-weight: bold; width: 150px;">Eğitim Konusu:</td>
            <td colspan="3">{{ $plan->training->title }} ({{ $plan->training->code }})</td>
        </tr>
        <tr>
            <td style="background-color: #f0f0f0; font-weight: bold;">Eğitim Tarihi:</td>
            <td>{{ $plan->start_date->format('d.m.Y H:i') }}</td>
            <td style="background-color: #f0f0f0; font-weight: bold; width: 100px;">Eğitim Süresi:</td>
            <td>{{ $plan->duration_hours }} Saat</td>
        </tr>
        <tr>
            <td style="background-color: #f0f0f0; font-weight: bold;">Eğitim Yeri:</td>
            <td colspan="3">{{ $plan->location }}</td>
        </tr>
        <tr>
            <td style="background-color: #f0f0f0; font-weight: bold;">Eğitimci:</td>
            <td colspan="3">{{ $plan->instructor }}</td>
        </tr>
    </table>

    <table>
        <thead>
            <tr style="background-color: #f0f0f0;">
                <th style="width: 50px; text-align: center;">Sıra</th>
                <th>KATILIMCILAR (Adı Soyadı)</th>
                <th>BÖLÜMÜ / ÜNVANI</th>
                <th style="width: 150px;">KATILIMCI İMZA</th>
            </tr>
        </thead>
        <tbody>
            @foreach($plan->records as $index => $record)
            <tr class="sign-row">
                <td style="text-align: center;">{{ $index + 1 }}</td>
                <td>{{ $record->user->name }}</td>
                <td>{{ $record->user->department->name ?? '-' }} / {{ $record->user->title ?? '-' }}</td>
                <td></td> </tr>
            @endforeach
            
            {{-- Boş satırlar ekleyelim ki sayfa dolsun (Opsiyonel) --}}
            @for($i = 0; $i < (15 - $plan->records->count()); $i++)
            <tr class="sign-row">
                <td style="text-align: center;">{{ $plan->records->count() + $i + 1 }}</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            @endfor
        </tbody>
    </table>

    <table class="footer-table" style="margin-top: 30px;">
        <tr style="background-color: #f0f0f0;">
            <td style="width: 33%;"><strong>Hazırlayan</strong></td>
            <td style="width: 33%;"><strong>Gözden Geçiren</strong></td>
            <td style="width: 33%;"><strong>Onaylayan</strong></td>
        </tr>
        <tr style="height: 60px;">
            <td>
                Kalite Yönetim Temsilcisi<br>
                <br><br>
            </td>
            <td>
                Eğitim Sorumlusu<br>
                <br><br>
            </td>
            <td>
                Laboratuvar Müdürü<br>
                <br><br>
            </td>
        </tr>
    </table>

</body>
</html>