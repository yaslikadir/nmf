@extends('layouts.admin')
@section('title', 'Plan Düzenle')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">Eğitim Planını Düzenle</h4>
        <a href="{{ route('admin.qms.plans.index') }}" class="btn btn-secondary shadow-sm">İptal</a>
    </div>

    <div class="card shadow-sm border-0 border-top-lg border-warning">
        <div class="card-body">
            <form action="{{ route('admin.qms.plans.update', $plan->id) }}" method="POST">
                @csrf
                @method('PUT') {{-- GÜNCELLEME İÇİN ŞART --}}
                
                <div class="row g-3">
                    {{-- 1. EĞİTİM SEÇİMİ --}}
                    <div class="col-md-12">
                        <label class="fw-bold small">Hangi Eğitim?</label>
                        <select name="training_id" class="form-select" required>
                            @foreach($trainings as $training)
                                <option value="{{ $training->id }}" {{ $plan->training_id == $training->id ? 'selected' : '' }}>
                                    [{{ $training->code }}] {{ $training->title }} 
                                    ({{ $training->type == 'Online' ? 'Online' : 'Yüz Yüze' }})
                                </option>
                            @endforeach
                        </select>
                    </div>

                    {{-- 2. TARİH VE EĞİTMEN --}}
                    <div class="col-md-6">
                        <label class="fw-bold small">Başlangıç Tarihi & Saati</label>
                        {{-- datetime-local inputu için format: Y-m-d\TH:i --}}
                        <input type="datetime-local" name="start_date" class="form-control" 
                               value="{{ $plan->start_date->format('Y-m-d\TH:i') }}" required>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold small">Bitiş Tarihi & Saati</label>
                        <input type="datetime-local" name="end_date" class="form-control" 
                               value="{{ $plan->end_date->format('Y-m-d\TH:i') }}" required>
                    </div>

                    <div class="col-md-6">
    <label class="fw-bold small">Eğitim Süresi (Saat)</label>
    <input type="number" name="duration_hours" class="form-control" value="{{ old('duration_hours', $plan->duration_hours ?? '') }}" placeholder="Örn: 8" required>
    <div class="form-text small">Sertifikada görünecek net eğitim süresi.</div>
</div>

                    <div class="col-md-6">
                        <label class="fw-bold small">Eğitmen / Sorumlu</label>
                        <input type="text" name="instructor" class="form-control" value="{{ $plan->instructor }}" required>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold small">Yer / Link</label>
                        <input type="text" name="location" class="form-control" value="{{ $plan->location }}">
                    </div>

                    {{-- 3. KATILIMCILAR --}}
                    <div class="col-12">
                        <label class="fw-bold small text-primary">Katılımcı Personel Seçimi</label>
                        <div class="alert alert-warning border small mb-2">
                            <i class="fas fa-exclamation-triangle me-1"></i> Dikkat: Listeden çıkardığınız personellerin (eğer sınava girmemişlerse) eğitim atamaları silinecektir.
                        </div>
                        <select name="participants[]" class="form-select" multiple size="8" required style="height: 200px;">
                            @foreach($users as $user)
                                <option value="{{ $user->id }}" 
                                    {{-- Eğer bu kullanıcı mevcut listede varsa seçili yap --}}
                                    {{ in_array($user->id, $selectedParticipants) ? 'selected' : '' }}
                                >
                                    {{ $user->name }} - {{ $user->title ?? '-' }} ({{ $user->department->name ?? '-' }})
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="fw-bold small">Notlar</label>
                        <textarea name="notes" class="form-control" rows="2">{{ $plan->notes }}</textarea>
                    </div>
                </div>

                <div class="text-end mt-4">
                    <button type="submit" class="btn btn-warning text-dark fw-bold px-4">
                        <i class="fas fa-sync-alt me-1"></i> GÜNCELLE
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection