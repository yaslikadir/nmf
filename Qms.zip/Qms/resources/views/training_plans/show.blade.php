@extends('layouts.admin')
@section('title', 'Eğitim Detayı')

@section('content')
<div class="container-fluid px-4 mt-4">
    {{-- BAŞLIK --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800 mb-0">Eğitim Plan Detayı</h4>
            <div class="small text-muted">{{ $plan->training->title }} ({{ $plan->training->code }})</div>
        </div>
        <div>
            @if($plan->status == 'Planned')
            <form action="{{ route('admin.qms.plans.cancel', $plan->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Bu eğitimi iptal etmek istediğinize emin misiniz?');">
                @csrf
                <button class="btn btn-danger btn-sm shadow-sm me-2">İptal Et</button>
            </form>
            @endif
            <a href="{{ route('admin.qms.plans.print-form', $plan->id) }}" target="_blank" class="btn btn-primary btn-sm shadow-sm me-2">
    <i class="fas fa-print me-1"></i> Katılım Formu Yazdır
</a>
            <a href="{{ route('admin.qms.plans.index') }}" class="btn btn-secondary btn-sm shadow-sm">Geri Dön</a>
        </div>
    </div>

    <div class="row">
        {{-- SOL: BİLGİ KARTI --}}
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-light fw-bold">Plan Bilgileri</div>
                <div class="card-body">
                    <table class="table table-borderless mb-0 small">
                        <tr>
                            <td class="fw-bold text-muted w-50">Eğitmen:</td>
                            <td>{{ $plan->instructor }}</td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-muted">Başlangıç:</td>
                            <td>{{ $plan->start_date->format('d.m.Y H:i') }}</td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-muted">Bitiş:</td>
                            <td>{{ $plan->end_date->format('d.m.Y H:i') }}</td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-muted">Konum:</td>
                            <td>{{ $plan->location }}</td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-muted">Durum:</td>
                            <td><span class="badge {{ $plan->status_label['class'] }}">{{ $plan->status_label['text'] }}</span></td>
                        </tr>
                    </table>
                    @if($plan->notes)
                        <hr>
                        <div class="small text-muted"><strong>Notlar:</strong><br>{{ $plan->notes }}</div>
                    @endif
                </div>
            </div>
        </div>

        {{-- SAĞ: KATILIMCI LİSTESİ --}}
        <div class="col-md-8 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-users me-2 text-primary"></i>Katılımcı Listesi</span>
                    <span class="badge bg-secondary">{{ $plan->records->count() }} Kişi</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light small">
                                <tr>
                                    <th>Personel</th>
                                    <th>Katılım</th>
                                    <th>Sınav Durumu</th>
                                    <th>Puan</th>
                                    <th class="text-end">Sertifika</th>
                                </tr>
                            </thead>
                            <tbody class="small align-middle">
                                @foreach($plan->records as $record)
                                <tr>
                                    <td>
                                        <div class="fw-bold">{{ $record->user->name }}</div>
                                        <div class="text-muted small">{{ $record->user->department->name ?? '-' }}</div>
                                    </td>
                                    <td>
                                        @if($record->attended)
                                            <span class="text-success"><i class="fas fa-check-circle"></i> Katıldı</span>
                                        @else
                                            <span class="text-muted"><i class="far fa-circle"></i> Bekliyor</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($record->result == 'Passed') <span class="badge bg-success">Geçti</span>
                                        @elseif($record->result == 'Failed') <span class="badge bg-danger">Kaldı</span>
                                        @else <span class="badge bg-light text-dark border">Girmedi</span>
                                        @endif
                                    </td>
                                    <td>{{ $record->exam_score ?? '-' }}</td>
                                    <td class="text-end">
                                        @if($record->certificate_path)
                                            <a href="#" class="btn btn-xs btn-outline-success"><i class="fas fa-certificate"></i></a>
                                        @else
                                            <span class="text-muted">-</span>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection