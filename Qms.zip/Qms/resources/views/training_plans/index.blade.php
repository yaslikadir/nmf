@extends('layouts.admin')
@section('title', 'Eğitim Takvimi')

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800"><i class="fas fa-calendar-alt me-2 text-primary"></i>Eğitim Planlama</h4>
            <div class="text-muted small">Personel eğitim atamaları ve takvim yönetimi.</div>
        </div>
        <a href="{{ route('admin.qms.plans.create') }}" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus me-1"></i> Yeni Eğitim Planla
        </a>
    </div>

    {{-- GELECEK EĞİTİMLER --}}
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white fw-bold text-primary">
            <i class="fas fa-clock me-1"></i> Yaklaşan Eğitimler
        </div>
        <div class="card-body p-0">
            <table class="table table-hover mb-0">
                <thead class="bg-light small">
                    <tr>
                        <th>Tarih</th>
                        <th>Eğitim Adı</th>
                        <th>Eğitmen</th>
                        <th>Konum</th>
                        <th>Katılımcı</th>
                        <th>Durum</th>
                        <th class="text-end">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($upcomingPlans as $plan)
                    <tr>
                        <td>
                            <div class="fw-bold text-dark">{{ $plan->start_date->format('d.m.Y') }}</div>
                            <div class="small text-muted">{{ $plan->start_date->format('H:i') }}</div>
                        </td>
                        <td>
                            <a href="{{ route('admin.qms.plans.show', $plan->id) }}" class="fw-bold text-decoration-none">
                                {{ $plan->training->title }}
                            </a>
                            <div class="small text-muted">{{ $plan->training->code }}</div>
                        </td>
                        <td>{{ $plan->instructor }}</td>
                        <td>{{ $plan->location }}</td>
                        <td>
                            <span class="badge bg-light text-dark border">
                                <i class="fas fa-users me-1"></i> {{ $plan->records->count() }} Kişi
                            </span>
                        </td>
                        <td>
                            <span class="badge {{ $plan->status_label['class'] }}">{{ $plan->status_label['text'] }}</span>
                        </td>
                        <td class="text-end">
    <div class="btn-group" role="group">
        
        {{-- 1. İNCELE / DETAY (Mevcut Buton) --}}
        <a href="{{ route('admin.qms.plans.show', $plan->id) }}" class="btn btn-sm btn-info text-white" title="Detaylar ve Katılım Listesi">
            <i class="fas fa-eye"></i>
        </a>

        {{-- 2. DÜZENLE (YENİ EKLENEN) --}}
        {{-- Sadece planlanmış veya tamamlanmamışsa düzenlensin --}}
        @if($plan->status != 'Cancelled')
            <a href="{{ route('admin.qms.plans.edit', $plan->id) }}" class="btn btn-sm btn-warning text-dark" title="Planı Düzenle">
                <i class="fas fa-edit"></i>
            </a>
        @endif

        {{-- 3. İPTAL ET (Opsiyonel, Show sayfasında da var ama buraya da koyabilirsin) --}}
        @if($plan->status == 'Planned')
            <form action="{{ route('admin.qms.plans.cancel', $plan->id) }}" method="POST" class="d-inline" onsubmit="return confirm('İptal etmek istediğinize emin misiniz?');">
                @csrf
                <button type="submit" class="btn btn-sm btn-danger" title="İptal Et">
                    <i class="fas fa-times"></i>
                </button>
            </form>
        @endif

    </div>
</td>
                    </tr>
                    @empty
                    <tr><td colspan="7" class="text-center py-3 text-muted">Planlanmış gelecek eğitim bulunmuyor.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- GEÇMİŞ EĞİTİMLER --}}
    <div class="card shadow-sm">
        <div class="card-header bg-light fw-bold text-secondary">
            <i class="fas fa-history me-1"></i> Tamamlanan / Geçmiş Eğitimler
        </div>
        <div class="card-body p-0">
            {{-- Buraya aynı tablo yapısının geçmiş versiyonu gelebilir, sadelik için kısa tuttum --}}
            <div class="table-responsive">
                <table class="table table-sm table-hover mb-0">
                    <tbody class="small text-muted">
                        @foreach($pastPlans as $plan)
                        <tr>
                            <td class="ps-3">{{ $plan->start_date->format('d.m.Y') }}</td>
                            <td>{{ $plan->training->title }}</td>
                            <td>{{ $plan->instructor }}</td>
                            <td><span class="badge bg-secondary">Tamamlandı</span></td>
                            <td class="text-end pe-3">
                                <a href="{{ route('admin.qms.plans.show', $plan->id) }}" class="btn btn-xs btn-light border">İncele</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer py-1">
            {{ $pastPlans->links() }}
        </div>
    </div>
</div>
@endsection