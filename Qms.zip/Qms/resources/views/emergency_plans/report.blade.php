<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tatbikat Raporu - {{ $drill->plan->title }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0; /* Ekranda gri arka plan */
            font-family: 'Times New Roman', Times, serif;
        }
        .report-container {
            width: 210mm; /* A4 Genişliği */
            min-height: 297mm; /* A4 Yüksekliği */
            background: white;
            margin: 20px auto;
            padding: 15mm;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            position: relative;
        }
        .report-header-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .report-header-table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
            vertical-align: middle;
        }
        .logo { max-height: 60px; }
        .section-title {
            background-color: #e9ecef;
            border: 1px solid #000;
            padding: 5px 10px;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 0.9rem;
            margin-top: 15px;
            margin-bottom: 5px;
        }
        .info-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        .info-table th, .info-table td {
            border: 1px solid #000;
            padding: 6px;
            vertical-align: top;
        }
        .info-table th { width: 25%; background-color: #f8f9fa; text-align: left; }
        
        .checklist-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
            margin-top: 5px;
        }
        .checklist-table th, .checklist-table td {
            border: 1px solid #000;
            padding: 5px;
        }
        
        /* Baskı Ayarları */
        @media print {
            body { background: white; margin: 0; }
            .report-container { 
                box-shadow: none; 
                margin: 0; 
                width: 100%; 
                padding: 10mm; /* Yazıcı marjı */
            }
            .no-print { display: none !important; }
            .page-break { page-break-after: always; }
        }
    </style>
</head>
<body>

    {{-- YAZDIR BUTONU --}}
    <div class="text-center my-3 no-print">
        <button onclick="window.print()" class="btn btn-primary fw-bold">
            🖨️ Raporu Yazdır / PDF Olarak Kaydet
        </button>
        <button onclick="window.close()" class="btn btn-secondary">Pencereyi Kapat</button>
    </div>

    <div class="report-container">
        
        {{-- ÜST BİLGİ (HEADER) --}}
        <table class="report-header-table">
            <tr>
                <td width="20%">
                    {{-- Logo --}}
                    <img src="{{ asset('assets/img/logo.png') }}" alt="Logo" class="logo"> 
                    <br><small class="fw-bold">LABORATUVAR A.Ş.</small>
                </td>
                <td width="55%">
                    <h4 class="mb-0 fw-bold">ACİL DURUM TATBİKAT RAPORU</h4>
                    <small>ISO 17025:2017 Kalite Yönetim Sistemi</small>
                </td>
                <td width="25%" class="text-start" style="font-size: 0.75rem;">
                    <div><strong>Doküman No:</strong> FR-ISG-08</div>
                    <div><strong>Yayın Tarihi:</strong> 01.01.2024</div>
                    <div><strong>Revizyon No:</strong> 02</div>
                    <div><strong>Sayfa:</strong> 1 / 1</div>
                </td>
            </tr>
        </table>

        {{-- BÖLÜM 1: GENEL BİLGİLER --}}
        <div class="section-title">1. GENEL BİLGİLER</div>
        <table class="info-table">
            <tr>
                <th>Tatbikat Konusu / Plan Adı</th>
                <td colspan="3">{{ $drill->plan->title }}</td>
            </tr>
            <tr>
                <th>Tatbikat Tarihi</th>
                <td>{{ $drill->drill_date->format('d.m.Y') }}</td>
                <th>Tatbikat Saati</th>
                {{-- DÜZELTME: drill_time alanını kullanıyoruz --}}
                <td>{{ $drill->drill_time ? \Carbon\Carbon::parse($drill->drill_time)->format('H:i') : '-' }}</td>
            </tr>
            <tr>
                <th>Toplam Süre (Dk)</th>
                <td>{{ $drill->duration_minutes }} Dakika</td>
                <th>Değerlendiren</th>
                <td>{{ $drill->conductor->name ?? 'Sistem Yöneticisi' }}</td>
            </tr>
            <tr>
                <th>Tatbikat Türü</th>
                <td colspan="3">
                    {{-- DÜZELTME: Checkbox mantığı ile seçimi gösteriyoruz --}}
                    <span style="font-family: DejaVu Sans, sans-serif;">
                        {{ $drill->drill_type == 'Haberli' ? '☑' : '☐' }} Haberli &nbsp;&nbsp; 
                        {{ $drill->drill_type == 'Habersiz' ? '☑' : '☐' }} Habersiz &nbsp;&nbsp; 
                        {{ $drill->drill_type == 'Masa Başı' ? '☑' : '☐' }} Masa Başı &nbsp;&nbsp; 
                        {{ $drill->drill_type == 'Saha Uygulaması' ? '☑' : '☐' }} Saha Uygulaması
                    </span>
                </td>
            </tr>
        </table>

        {{-- BÖLÜM 2: SENARYO --}}
        <div class="section-title">2. SENARYO VE KAPSAM</div>
        <div class="border border-black p-2" style="font-size: 0.9rem; min-height: 60px;">
            <strong>Olası Senaryo:</strong> {{ $drill->plan->scenario }}
            <br><br>
            <strong>Amaç:</strong> Personelin acil duruma müdahale refleksini ölçmek ve prosedüre uygun hareket edilip edilmediğini doğrulamak.
        </div>

        {{-- BÖLÜM 3: KONTROL LİSTESİ SONUÇLARI --}}
        <div class="section-title">3. TATBİKAT DEĞERLENDİRME KRİTERLERİ</div>
        <table class="checklist-table">
            <thead style="background-color: #f8f9fa;">
                <tr>
                    <th width="5%">No</th>
                    <th>Kontrol Kriteri</th>
                    <th width="15%" class="text-center">Durum</th>
                </tr>
            </thead>
            <tbody>
                @if($drill->checklist_results)
                    @foreach($drill->checklist_results as $index => $res)
                        <tr>
                            <td class="text-center">{{ $loop->iteration }}</td>
                            <td>{{ $res['item'] ?? '-' }}</td>
                            <td class="text-center fw-bold">
                                @if(isset($res['status']) && $res['status'] == 'Pass')
                                    <span style="color: green;">✔ BAŞARILI</span>
                                @else
                                    <span style="color: red;">✘ BAŞARISIZ</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                @else
                    <tr>
                        <td colspan="3" class="text-center">Kontrol listesi verisi bulunamadı.</td>
                    </tr>
                @endif
            </tbody>
        </table>

        {{-- BÖLÜM 4: GÖZLEMLER VE NOTLAR --}}
        <div class="section-title">4. GÖZLEMLER, EKSİKLİKLER VE ÖNERİLER</div>
        <div class="border border-black p-2" style="font-size: 0.9rem; min-height: 80px;">
            {{ $drill->notes ?? 'Herhangi bir olumsuzluk gözlemlenmemiştir.' }}
        </div>

        {{-- BÖLÜM 5: TATBİKATA KATILAN EKİP --}}
        <div class="section-title">5. TATBİKATA KATILAN ACİL MÜDAHALE EKİBİ</div>
        <table class="checklist-table">
            <thead>
                <tr>
                    <th>Adı Soyadı</th>
                    <th>Departmanı</th>
                    <th width="20%">İmza</th>
                </tr>
            </thead>
            <tbody>
                @foreach($drill->plan->teamMembers as $member)
                    <tr>
                        <td>{{ $member->name }}</td>
                        <td>{{ $member->department->name ?? '-' }}</td>
                        <td></td> {{-- İmza boş kalacak --}}
                    </tr>
                @endforeach
                {{-- Boş satırlar ekleyelim ki diğer personel de imza atabilsin --}}
                <tr><td>&nbsp;</td><td></td><td></td></tr>
                <tr><td>&nbsp;</td><td></td><td></td></tr>
            </tbody>
        </table>

        {{-- BÖLÜM 6: SONUÇ VE ONAY --}}
        <div class="section-title">6. SONUÇ VE ONAY</div>
        <table class="info-table" style="margin-top: 10px; border: none;">
            <tr style="border: none;">
                <td style="border: none; text-align: center; width: 50%;">
                    <div><strong>Tatbikatı Yöneten / Hazırlayan</strong></div>
                    <div style="margin-top: 40px;">{{ $drill->conductor->name ?? 'Yetkili' }}</div>
                    <div style="border-top: 1px solid #000; width: 60%; margin: 5px auto;">İmza</div>
                </td>
                <td style="border: none; text-align: center; width: 50%;">
                    <div><strong>Kalite / İş Güvenliği Yöneticisi</strong></div>
                    <div style="margin-top: 40px;">ONAY</div>
                    <div style="border-top: 1px solid #000; width: 60%; margin: 5px auto;">İmza</div>
                </td>
            </tr>
        </table>

        <div style="font-size: 0.7rem; text-align: center; margin-top: 20px; color: #666;">
            Bu rapor, ISO/IEC 17025:2017 Madde 8.5 ve yerel İSG mevzuatına uygun olarak elektronik ortamda oluşturulmuştur.
        </div>

    </div>

</body>
</html>