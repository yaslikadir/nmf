@extends('layouts.admin')
@section('title', 'Acil Durum Planları')

@push('css')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
<style>
    /* Tablo ve Kart Stilleri */
    .bg-soft-danger { background-color: #ffe6e6; }
    .bg-soft-warning { background-color: #fff9e6; }
    .bg-soft-success { background-color: #e3f9ed; }
    
    .table-hover tbody tr:hover { background-color: #f8f9fa; cursor: pointer; }
    #plansTable_wrapper .dataTables_filter { float: right; }
    #plansTable_wrapper .dataTables_length { float: left; }
    
    .btn-export { font-size: 0.75rem; padding: 4px 12px; font-weight: bold; }
    .dt-buttons { display: none; } /* Butonları biz özel yerleştireceğiz */
</style>
@endpush

@section('content')
<div class="container-fluid px-4 mt-4">
    
    {{-- ÜST AKSİYON ÇUBUĞU --}}
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="text-danger fw-bold mb-0 text-uppercase">
            <i class="fas fa-shield-alt me-2"></i>ACİL DURUM PLANLARI
        </h5>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.qms.emergency-plans.create') }}" class="btn btn-sm btn-danger px-4 fw-bold shadow-sm">
                <i class="fas fa-plus me-1"></i> YENİ PLAN OLUŞTUR
            </a>
            <button type="button" class="btn btn-sm btn-dark px-4 fw-bold shadow-sm" onclick="location.reload();">
                <i class="fas fa-sync me-1"></i> YENİLE
            </button>
        </div>
    </div>

    {{-- FİLTRE VE BUTONLAR --}}
    <div class="card shadow-none border mb-3">
        <div class="card-header bg-light py-2 border-bottom">
            <div class="row align-items-center g-2">
                <div class="col-md-6">
                    <div class="d-flex gap-2 align-items-center">
                        <select class="form-select form-select-sm" id="durumFiltre" style="width: auto;">
                            <option value="">Tüm Durumlar</option>
                            <option value="Gecikti">🚨 Geciken Tatbikatlar</option>
                            <option value="Yaklaşıyor">⚠️ Yaklaşanlar</option>
                            <option value="Güncel">✅ Güncel Olanlar</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-sm btn-success btn-export" id="btnExportXLS">
                            <i class="fas fa-file-excel me-1"></i> XLS
                        </button>
                        <button type="button" class="btn btn-sm btn-danger btn-export" id="btnExportPDF">
                            <i class="fas fa-file-pdf me-1"></i> PDF
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card-body p-2">
            <div class="table-responsive">
                <table class="table table-sm table-hover table-bordered mb-0 align-middle" id="plansTable" style="font-size: 0.85rem;">
                    <thead class="bg-danger text-white">
                        <tr>
                            <th width="30">#</th>
                            <th>Plan Adı / Senaryo</th>
                            <th>Müdahale Ekibi</th>
                            <th>Sıklık</th>
                            <th>Son Tatbikat</th>
                            <th>Sıradaki Tatbikat</th>
                            <th>Durum</th>
                            <th width="100" class="text-center">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($plans as $index => $plan)
                            @php
                                $nextDate = $plan->next_drill_date;
                                $isOverdue = $nextDate && now()->gt($nextDate);
                                $isUpcoming = $nextDate && now()->diffInDays($nextDate, false) < 30 && !$isOverdue;
                                
                                // Durum metni (Filtreleme için)
                                $statusText = $isOverdue ? 'Gecikti' : ($isUpcoming ? 'Yaklaşıyor' : 'Güncel');
                            @endphp
                            <tr data-id="{{ $plan->id }}">
                                <td class="text-center">{{ $index + 1 }}</td>
                                <td>
                                    <div class="fw-bold text-dark">{{ $plan->title }}</div>
                                    <div class="text-muted small text-truncate" style="max-width: 300px;">{{ $plan->scenario }}</div>
                                </td>
                                <td>
                                    @if($plan->teamMembers->count() > 0)
                                        <div class="d-flex align-items-center">
                                            <span class="badge bg-secondary me-2">{{ $plan->teamMembers->count() }} Kişi</span>
                                            
                                            {{-- İlk 2 kişinin ismini göster, gerisine +X de --}}
                                            <small class="text-muted">
                                                {{ $plan->teamMembers->take(2)->pluck('name')->implode(', ') }}
                                                @if($plan->teamMembers->count() > 2)
                                                    +{{ $plan->teamMembers->count() - 2 }} diğer
                                                @endif
                                            </small>
                                        </div>
                                    @else
                                        <span class="text-danger small"><i class="fas fa-exclamation-circle"></i> Ekip Yok</span>
                                    @endif
                                </td>
                                <td><span class="badge bg-light text-dark border">{{ $plan->drill_frequency_months }} Ay</span></td>
                                <td>{{ $plan->last_drill_date ? $plan->last_drill_date->format('d.m.Y') : '-' }}</td>
                                <td>
                                    @if($isOverdue)
                                        <span class="text-danger fw-bold"><i class="fas fa-exclamation-circle"></i> {{ $nextDate->format('d.m.Y') }}</span>
                                    @elseif($isUpcoming)
                                        <span class="text-warning fw-bold"><i class="fas fa-clock"></i> {{ $nextDate->format('d.m.Y') }}</span>
                                    @else
                                        <span class="text-success">{{ $nextDate->format('d.m.Y') }}</span>
                                    @endif
                                </td>
                                <td>
                                    @if($isOverdue)
                                        <span class="badge bg-danger">Gecikti</span>
                                    @elseif($isUpcoming)
                                        <span class="badge bg-warning text-dark">Yaklaşıyor</span>
                                    @else
                                        <span class="badge bg-success">Güncel</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    <a href="{{ route('admin.qms.emergency-plans.show', $plan->id) }}" class="btn btn-xs btn-outline-dark shadow-sm">
                                        <i class="fas fa-eye me-1"></i> Yönet
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- İSTATİSTİK KARTLARI --}}
    <div class="row g-3 mt-3">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-soft-success">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Toplam Plan</h6>
                            <h3 class="fw-bold mb-0 text-success">{{ $plans->count() }}</h3>
                        </div>
                        <div class="fs-1 text-success opacity-50"><i class="fas fa-file-contract"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-soft-danger">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Geciken Tatbikat</h6>
                            @php 
                                $overdueCount = $plans->filter(fn($p) => $p->next_drill_date && now()->gt($p->next_drill_date))->count();
                            @endphp
                            <h3 class="fw-bold mb-0 text-danger">{{ $overdueCount }}</h3>
                        </div>
                        <div class="fs-1 text-danger opacity-50"><i class="fas fa-exclamation-triangle"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-soft-warning">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Yaklaşan Tatbikat</h6>
                            @php 
                                $upcomingCount = $plans->filter(fn($p) => $p->next_drill_date && now()->diffInDays($p->next_drill_date, false) < 30 && now()->lte($p->next_drill_date))->count();
                            @endphp
                            <h3 class="fw-bold mb-0 text-warning">{{ $upcomingCount }}</h3>
                        </div>
                        <div class="fs-1 text-warning opacity-50"><i class="fas fa-stopwatch"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-white border">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1 small">Ekip Üyesi Sayısı</h6>
                            {{-- Toplam benzersiz personel sayısı (İsteğe bağlı) --}}
                            <h3 class="fw-bold mb-0 text-dark">-</h3>
                        </div>
                        <div class="fs-1 text-secondary opacity-25"><i class="fas fa-users"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
$(document).ready(function() {
    // DataTables Başlat
    const table = $('#plansTable').DataTable({
        language: { "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json" },
        pageLength: 25,
        dom: 'Bfrtip',
        buttons: [
            { extend: 'excelHtml5', className: 'buttons-excel d-none' },
            { extend: 'pdfHtml5', className: 'buttons-pdf d-none' }
        ],
        columnDefs: [ { orderable: false, targets: [7] } ] // İşlem sütunu sıralanmaz
    });

    // Satıra Tıklama -> Detay Sayfası
    $('#plansTable tbody').on('click', 'tr', function(e) {
        if (!$(e.target).closest('a, button').length) {
            const id = $(this).data('id');
            if (id) window.location.href = `/admin/qms/emergency-plans/${id}`;
        }
    });

    // Durum Filtresi
    $('#durumFiltre').on('change', function() {
        const val = $(this).val();
        table.column(6).search(val).draw(); // 6. sütun (Durum) üzerinde arama yap
    });

    // Harici Export Butonları
    $('#btnExportXLS').click(function(){ table.button('.buttons-excel').trigger(); });
    $('#btnExportPDF').click(function(){ table.button('.buttons-pdf').trigger(); });
});
</script>
@endpush