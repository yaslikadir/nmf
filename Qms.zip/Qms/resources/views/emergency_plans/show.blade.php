@extends('layouts.admin')
@section('title', $plan->title)

@section('content')
<div class="container-fluid px-4 mt-4">

    {{-- BAŞLIK VE BUTONLAR --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-gray-800 mb-0">
                <i class="fas fa-shield-alt text-danger me-2"></i>{{ $plan->title }}
            </h4>
            <div class="text-muted small">Son Tatbikat: {{ $plan->last_drill_date ? $plan->last_drill_date->format('d.m.Y') : 'Henüz Yapılmadı' }}</div>
        </div>
        <div>
            <a href="{{ route('admin.qms.emergency-plans.index') }}" class="btn btn-secondary btn-sm shadow-sm">Geri Dön</a>
            
            <form action="{{ route('admin.qms.emergency-plans.destroy', $plan->id) }}" method="POST" class="d-inline-block ms-2" onsubmit="return confirm('Silmek istediğinize emin misiniz?');">
                @csrf @method('DELETE')
                <button class="btn btn-outline-danger btn-sm"><i class="fas fa-trash"></i></button>
            </form>
        </div>
    </div>

    <div class="row">
        {{-- SOL KOLON: SENARYO, PROSEDÜR VE GEÇMİŞ --}}
        <div class="col-lg-8">
            
            {{-- 1. SENARYO VE PROSEDÜR --}}
            <div class="card shadow-sm border-0 border-top-lg border-danger mb-4">
                <div class="card-body">
                    <h6 class="fw-bold text-uppercase text-muted border-bottom pb-2">Senaryo</h6>
                    <p class="text-dark bg-light p-3 rounded border">{{ $plan->scenario }}</p>

                    <h6 class="fw-bold text-uppercase text-muted border-bottom pb-2 mt-4">Müdahale Prosedürü</h6>
                    <div class="p-3 border rounded bg-white">
                        {{-- CKEditor HTML Çıktısı --}}
                        {!! $plan->procedure !!}
                    </div>
                </div>
            </div>

            {{-- 2. GEÇMİŞ TATBİKAT RAPORLARI --}}
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-history me-2 text-secondary"></i>Tatbikat Geçmişi ve Raporlar
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Tarih</th>
                                    <th>Tür</th>
                                    <th>Süre</th>
                                    <th>Yöneten</th>
                                    <th class="text-end">İşlem</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($plan->drills as $drill)
                                    <tr>
                                        <td>
                                            <div class="fw-bold text-dark">{{ $drill->drill_date->format('d.m.Y') }}</div>
                                            <div class="small text-muted">{{ \Carbon\Carbon::parse($drill->drill_time)->format('H:i') }}</div>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary">{{ $drill->drill_type ?? 'Belirtilmedi' }}</span>
                                        </td>
                                        <td><span class="badge bg-light text-dark border">{{ $drill->duration_minutes }} Dk</span></td>
                                        <td>{{ $drill->conductor->name ?? '-' }}</td>
                                        <td class="text-end">
                                            <a href="{{ route('admin.qms.emergency-drills.report', $drill->id) }}" target="_blank" class="btn btn-sm btn-outline-dark" title="Raporu Yazdır">
                                                <i class="fas fa-print me-1"></i> Rapor
                                            </a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="text-center py-3 text-muted">Bu plan için henüz kayıtlı tatbikat raporu yok.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        {{-- SAĞ KOLON: EKİP VE TATBİKAT YÖNETİMİ --}}
        <div class="col-lg-4">
            
            {{-- TATBİKAT DURUM KARTI --}}
            <div class="card shadow-sm border-0 mb-4 text-center">
                <div class="card-header bg-white fw-bold">Tatbikat Durumu</div>
                <div class="card-body">
                    @php
                        $daysLeft = $plan->next_drill_date ? now()->diffInDays($plan->next_drill_date, false) : 0;
                        $statusClass = $daysLeft < 0 ? 'danger' : ($daysLeft < 30 ? 'warning' : 'success');
                        $statusText = $daysLeft < 0 ? abs(intval($daysLeft)) . ' Gün Gecikti!' : intval($daysLeft) . ' Gün Kaldı';
                    @endphp

                    <h2 class="fw-bold text-{{ $statusClass }} mb-0">
                        {{ $plan->next_drill_date ? $plan->next_drill_date->format('d.m.Y') : '-' }}
                    </h2>
                    <div class="small text-muted mb-3">Bir Sonraki Planlı Tatbikat</div>
                    
                    <span class="badge bg-{{ $statusClass }} fs-6 mb-4">{{ $statusText }}</span>

                    <hr>

                    {{-- BUTON: Modalı Tetikler --}}
                    <div class="d-grid">
                        <button type="button" class="btn btn-outline-danger fw-bold py-2" data-bs-toggle="modal" data-bs-target="#drillModal">
                            <i class="fas fa-clipboard-check me-1"></i> TATBİKATI BAŞLAT / RAPORLA
                        </button>
                    </div>
                    <div class="form-text small mt-2">
                        Tatbikatı tamamladığınızda buradan kayıt altına alıp rapor oluşturabilirsiniz.
                    </div>
                </div>
            </div>

            {{-- EKİP LİSTESİ --}}
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-users me-2 text-primary"></i>Acil Müdahale Ekibi</span>
                    <a href="{{ route('admin.qms.emergency-plans.edit', $plan->id) }}" class="btn btn-sm btn-link text-decoration-none p-0">Düzenle</a>
                </div>
                
                <ul class="list-group list-group-flush">
                    @forelse($plan->teamMembers as $member)
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <i class="fas fa-user-shield text-success me-2"></i>
                                <span class="fw-bold text-dark">{{ $member->name }}</span>
                                <div class="small text-muted ps-4" style="font-size: 0.75rem;">
                                    {{ $member->department->name ?? 'Departman Yok' }}
                                </div>
                            </div>
                            <span class="badge bg-light text-dark border">Görevli</span>
                        </li>
                    @empty
                        <li class="list-group-item text-center text-muted py-4">
                            <i class="fas fa-users-slash fa-2x mb-2 text-gray-300"></i><br>
                            Henüz ekip üyesi atanmamış.
                        </li>
                    @endforelse
                </ul>
            </div>

        </div>
    </div>
</div>

{{-- MODAL: Tatbikat Değerlendirme Formu --}}
<div class="modal fade" id="drillModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.qms.emergency-plans.store-drill', $plan->id) }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-fire-extinguisher me-2"></i>Tatbikat Değerlendirme Formu</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
                </div>
                <div class="modal-body text-start">
                    
                    {{-- 1. SATIR: SAAT, SÜRE VE DEĞERLENDİREN --}}
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="fw-bold small required">Tatbikat Saati</label>
                            <input type="time" name="drill_time" class="form-control" value="{{ now()->format('H:i') }}" required>
                        </div>
                        <div class="col-md-4">
                            <label class="fw-bold small required">Süre (Dakika)</label>
                            <input type="number" name="duration_minutes" class="form-control" required placeholder="Örn: 15">
                        </div>
                        <div class="col-md-4">
                            <label class="fw-bold small">Değerlendiren</label>
                            <input type="text" class="form-control" value="{{ auth()->user()->name }}" disabled>
                        </div>
                    </div>

                    {{-- 2. SATIR: TATBİKAT TÜRÜ --}}
                    <div class="mb-4">
                        <label class="fw-bold small required d-block mb-2">Tatbikat Türü</label>
                        <div class="btn-group w-100" role="group">
                            <input type="radio" class="btn-check" name="drill_type" id="type1" value="Haberli" checked>
                            <label class="btn btn-outline-secondary" for="type1">Haberli</label>

                            <input type="radio" class="btn-check" name="drill_type" id="type2" value="Habersiz">
                            <label class="btn btn-outline-secondary" for="type2">Habersiz</label>

                            <input type="radio" class="btn-check" name="drill_type" id="type3" value="Masa Başı">
                            <label class="btn btn-outline-secondary" for="type3">Masa Başı</label>

                            <input type="radio" class="btn-check" name="drill_type" id="type4" value="Saha Uygulaması">
                            <label class="btn btn-outline-secondary" for="type4">Saha Uygulaması</label>
                        </div>
                    </div>

                    <h6 class="border-bottom pb-2 mb-3 fw-bold text-primary">Kontrol Listesi (Checklist)</h6>
                    
                    @if(!empty($plan->checklist_items))
                        <div class="table-responsive mb-3 border rounded">
                            <table class="table table-sm align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Kontrol Kriteri</th>
                                        <th width="100" class="text-center text-success">Başarılı</th>
                                        <th width="100" class="text-center text-danger">Başarısız</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($plan->checklist_items as $index => $item)
                                        <tr>
                                            <td class="ps-3">
                                                {{ $loop->iteration }}. {{ $item }}
                                                <input type="hidden" name="checklist_results[{{ $index }}][item]" value="{{ $item }}">
                                            </td>
                                            <td class="text-center">
                                                <input class="form-check-input bg-success border-success" type="radio" name="checklist_results[{{ $index }}][status]" value="Pass" required checked>
                                            </td>
                                            <td class="text-center">
                                                <input class="form-check-input bg-danger border-danger" type="radio" name="checklist_results[{{ $index }}][status]" value="Fail">
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="alert alert-warning small">
                            <i class="fas fa-exclamation-triangle me-1"></i>
                            Bu plan için kontrol listesi tanımlanmamış. "Düzenle" sayfasından ekleyebilirsiniz.
                        </div>
                    @endif

                    <div class="mb-3">
                        <label class="fw-bold small">Genel Değerlendirme / Notlar</label>
                        <textarea name="notes" class="form-control" rows="3" placeholder="Tatbikat sırasında gözlemlenen aksaklıklar, iyileştirme önerileri veya başarılar..."></textarea>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-danger fw-bold">
                        <i class="fas fa-save me-1"></i> KAYDET VE KAPAT
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection