@extends('layouts.admin')
@section('title', 'Planı Düzenle: ' . $plan->title)

{{-- CKEditor CDN --}}
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">Acil Durum Planını Düzenle</h4>
        <a href="{{ route('admin.qms.emergency-plans.index') }}" class="btn btn-secondary shadow-sm">İptal</a>
    </div>

    <form action="{{ route('admin.qms.emergency-plans.update', $plan->id) }}" method="POST">
        @csrf
        @method('PUT')
        
        <div class="row">
            {{-- SOL KOLON --}}
            <div class="col-lg-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-white fw-bold">Plan Detayları</div>
                    <div class="card-body">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold required">Plan Başlığı</label>
                            <input type="text" name="title" class="form-control" value="{{ old('title', $plan->title) }}" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold required">Olası Senaryo</label>
                            <textarea name="scenario" class="form-control" rows="3" required>{{ old('scenario', $plan->scenario) }}</textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold required">Müdahale ve Tahliye Prosedürü</label>
                            <textarea name="procedure" id="procedure-editor" class="form-control" rows="10">{{ old('procedure', $plan->procedure) }}</textarea>
                        </div>

                    </div>
                </div>

                {{-- DİNAMİK KONTROL LİSTESİ (CHECKLIST) - YENİ EKLENEN KISIM --}}
                <div class="card shadow-sm mb-4 border-start border-4 border-info">
                    <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-list-check me-2 text-info"></i>Tatbikat Kontrol Kriterleri</span>
                        <button type="button" class="btn btn-sm btn-info text-white" id="addChecklistItem">
                            <i class="fas fa-plus"></i> Madde Ekle
                        </button>
                    </div>
                    <div class="card-body bg-light">
                        <div id="checklist-container">
                            {{-- Mevcut maddeleri listele --}}
                            @if(!empty($plan->checklist_items))
                                @foreach($plan->checklist_items as $item)
                                    <div class="input-group mb-2">
                                        <span class="input-group-text bg-white">{{ $loop->iteration }}</span>
                                        <input type="text" name="checklist_items[]" class="form-control" value="{{ $item }}" required>
                                        <button type="button" class="btn btn-outline-danger remove-item" onclick="this.parentElement.remove()"><i class="fas fa-trash"></i></button>
                                    </div>
                                @endforeach
                            @else
                                {{-- Hiç yoksa boş bir tane göster --}}
                                <div class="input-group mb-2">
                                    <span class="input-group-text bg-white">1</span>
                                    <input type="text" name="checklist_items[]" class="form-control" placeholder="Örn: Alarm tüm binada duyuldu mu?">
                                    <button type="button" class="btn btn-outline-danger remove-item" onclick="this.parentElement.remove()"><i class="fas fa-trash"></i></button>
                                </div>
                            @endif
                        </div>
                        <div class="form-text">Tatbikat sırasında kontrol edilecek maddeleri buradan güncelleyebilirsiniz.</div>
                    </div>
                </div>
            </div>

            {{-- SAĞ KOLON --}}
            <div class="col-lg-4">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-white fw-bold">Yönetim ve Tatbikat</div>
                    <div class="card-body">
                        
                        {{-- DURUM --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold">Plan Durumu</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_active" id="isActiveSwitch" value="1" {{ $plan->is_active ? 'checked' : '' }}>
                                <label class="form-check-label" for="isActiveSwitch">Aktif Plan</label>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold required">Tatbikat Sıklığı (Ay)</label>
                            <input type="number" name="drill_frequency_months" class="form-control" value="{{ old('drill_frequency_months', $plan->drill_frequency_months) }}" min="1" required>
                        </div>

                        {{-- EKİP SEÇİMİ --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold required">Acil Müdahale Ekibi</label>
                            <select name="team_members[]" class="form-select" multiple required style="height: 200px;">
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" 
                                        {{ $plan->teamMembers->contains($user->id) ? 'selected' : '' }}>
                                        {{ $user->name }} ({{ $user->department->name ?? 'Dep. Yok' }})
                                    </option>
                                @endforeach
                            </select>
                            <div class="form-text text-primary">
                                <i class="fas fa-info-circle"></i> Birden fazla kişi seçmek için CTRL/CMD tuşuna basılı tutun.
                            </div>
                        </div>

                        <hr>
                        <button type="submit" class="btn btn-primary w-100 fw-bold py-2">
                            <i class="fas fa-save me-1"></i> DEĞİŞİKLİKLERİ KAYDET
                        </button>

                    </div>
                </div>
                
                <div class="card bg-light border-0">
                    <div class="card-body small text-muted">
                        <i class="fas fa-history me-1"></i> Son Güncelleme: {{ $plan->updated_at->format('d.m.Y H:i') }}
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<style>
    .ck-editor__editable_inline {
        min-height: 300px;
    }
</style>

<script>
    // CKEditor Başlatma
    document.addEventListener("DOMContentLoaded", function() {
        ClassicEditor
            .create(document.querySelector('#procedure-editor'), {
                toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', 'undo', 'redo' ],
                language: 'tr'
            })
            .catch(error => {
                console.error(error);
            });
    });

    // Checklist Ekleme Scripti
    document.getElementById('addChecklistItem').addEventListener('click', function() {
        let container = document.getElementById('checklist-container');
        // Mevcut sayıyı bul (görsel sıra no için)
        let count = container.querySelectorAll('.input-group').length + 1;
        
        let div = document.createElement('div');
        div.className = 'input-group mb-2';
        div.innerHTML = `
            <span class="input-group-text bg-white">${count}</span>
            <input type="text" name="checklist_items[]" class="form-control" placeholder="Yeni kriter giriniz...">
            <button type="button" class="btn btn-outline-danger remove-item" onclick="this.parentElement.remove()"><i class="fas fa-trash"></i></button>
        `;
        container.appendChild(div);
    });
</script>

@endsection