@extends('layouts.admin')
@section('title', 'Yeni Acil Durum Planı')

{{-- CKEditor CDN (Head kısmına veya buraya eklenebilir) --}}
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>

@section('content')
<div class="container-fluid px-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-gray-800">Yeni Acil Durum Senaryosu</h4>
        <a href="{{ route('admin.qms.emergency-plans.index') }}" class="btn btn-secondary shadow-sm">İptal</a>
    </div>

    <form action="{{ route('admin.qms.emergency-plans.store') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-white fw-bold">Plan Detayları</div>
                    <div class="card-body">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold required">Plan Başlığı</label>
                            <input type="text" name="title" class="form-control" placeholder="Örn: Kimyasal Dökülme Acil Müdahale Planı" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold required">Olası Senaryo</label>
                            <textarea name="scenario" class="form-control" rows="3" placeholder="Bu plan hangi durumda devreye girecek? (Örn: Asit dolabında şişe kırılması...)" required></textarea>
                        </div>

                        {{-- CKEDITOR UYGULANACAK ALAN --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold required">Müdahale ve Tahliye Prosedürü</label>
                            <textarea name="procedure" id="procedure-editor" class="form-control" rows="10" placeholder="Adım adım yapılacaklar..."></textarea>
                            <div class="form-text">
                                <i class="fas fa-pen-fancy me-1"></i> Maddeli liste, kalın yazı ve vurgulama özelliklerini kullanabilirsiniz.
                            </div>
                        </div>

                        {{-- DİNAMİK KONTROL LİSTESİ --}}
<div class="card shadow-sm mb-4 border-start border-4 border-info">
    <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
        <span><i class="fas fa-list-check me-2 text-info"></i>Tatbikat Kontrol Kriterleri</span>
        <button type="button" class="btn btn-sm btn-info text-white" id="addChecklistItem">
            <i class="fas fa-plus"></i> Madde Ekle
        </button>
    </div>
    <div class="card-body bg-light">
        <div id="checklist-container">
            {{-- Maddeler buraya gelecek --}}
            <div class="input-group mb-2">
                <span class="input-group-text bg-white">1</span>
                <input type="text" name="checklist_items[]" class="form-control" placeholder="Örn: Alarm tüm binada duyuldu mu?" required>
                <button type="button" class="btn btn-outline-danger remove-item"><i class="fas fa-trash"></i></button>
            </div>
        </div>
        <div class="form-text">Tatbikat sırasında kontrol edilecek maddeleri tanımlayınız.</div>
    </div>
</div>

{{-- Script --}}
<script>
    document.getElementById('addChecklistItem').addEventListener('click', function() {
        let container = document.getElementById('checklist-container');
        let count = container.children.length + 1;
        
        let div = document.createElement('div');
        div.className = 'input-group mb-2';
        div.innerHTML = `
            <span class="input-group-text bg-white">${count}</span>
            <input type="text" name="checklist_items[]" class="form-control" placeholder="Kriter giriniz...">
            <button type="button" class="btn btn-outline-danger remove-item" onclick="this.parentElement.remove()"><i class="fas fa-trash"></i></button>
        `;
        container.appendChild(div);
    });
</script>

                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-white fw-bold">Yönetim ve Tatbikat</div>
                    <div class="card-body">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold required">Tatbikat Sıklığı (Ay)</label>
                            <input type="number" name="drill_frequency_months" class="form-control" value="12" min="1" required>
                            <div class="form-text">Kaç ayda bir tatbikat yapılmalı?</div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold required">Acil Müdahale Ekibi</label>
                            {{-- Çoklu Seçim (Select Multiple) --}}
                            <select name="team_members[]" class="form-select" multiple required style="height: 150px;">
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}">
                                        {{ $user->name }} ({{ $user->department->name ?? 'Dep. Yok' }})
                                    </option>
                                @endforeach
                            </select>
                            <div class="form-text text-primary">
                                <i class="fas fa-info-circle"></i> Birden fazla kişi seçmek için CTRL (Windows) veya CMD (Mac) tuşuna basılı tutarak tıklayınız.
                            </div>
                        </div>

                        <hr>
                        <button type="submit" class="btn btn-danger w-100 fw-bold py-2">
                            <i class="fas fa-save me-1"></i> PLANI KAYDET VE BİLDİR
                        </button>

                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

{{-- CKEditor Başlatma Scripti --}}
<style>
    /* Editörün yüksekliğini ayarlayalım */
    .ck-editor__editable_inline {
        min-height: 300px;
    }
</style>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        ClassicEditor
            .create(document.querySelector('#procedure-editor'), {
                toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', 'undo', 'redo' ],
                language: 'tr' // Eğer dil paketi yüklüyse, yoksa varsayılan en
            })
            .catch(error => {
                console.error(error);
            });
    });
</script>

@endsection