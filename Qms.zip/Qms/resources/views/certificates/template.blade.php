<!DOCTYPE html>
<html lang="tr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Sertifika</title>
    <style>
        @page { margin: 0; }
        body { 
            font-family: 'DejaVu Sans', sans-serif; 
            margin: 0; padding: 0; 
            background: #fff;
            color: #333;
        }
        .border-pattern {
            position: absolute;
            top: 20px; left: 20px; right: 20px; bottom: 20px;
            border: 10px double #10b981; /* Yeşil Çerçeve */
            background: #fff;
            z-index: -1;
        }
        .content {
            padding: 60px;
            text-align: center;
        }
        .logo {
            height: 80px;
            margin-bottom: 20px;
        }
        .title {
            font-size: 42px;
            font-weight: bold;
            color: #065f46;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 10px;
        }
        .subtitle {
            font-size: 16px;
            color: #666;
            margin-bottom: 30px;
        }
        .person-name {
            font-size: 32px;
            font-weight: bold;
            color: #111;
            margin: 20px 0;
            border-bottom: 2px solid #ddd;
            display: inline-block;
            padding: 0 40px 10px 40px;
        }
        .training-title {
            font-size: 22px;
            font-weight: bold;
            color: #047857;
            margin-top: 20px;
        }
        .training-info {
            font-size: 14px;
            color: #555;
            margin-top: 5px;
        }
        .footer-table {
            width: 100%;
            margin-top: 60px;
            border-collapse: collapse;
        }
        .footer-table td {
            vertical-align: bottom;
        }
        .sign-area { text-align: left; width: 33%; }
        .qr-area { text-align: right; width: 33%; }
        .center-area { text-align: center; width: 33%; }
        
        .sign-line {
            border-top: 1px solid #333;
            width: 150px;
            padding-top: 5px;
            margin-top: 40px;
            font-weight: bold;
        }
        .qr-img {
            width: 90px;
            height: 90px;
        }
        .verify-text {
            font-size: 10px;
            color: #555;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="border-pattern"></div>

    <div class="content">
        @if(!empty($logoBase64))
            <img src="{{ $logoBase64 }}" class="logo" alt="Logo">
        @else
            <div style="font-size: 30px; font-weight: bold; color: #10b981; margin-bottom: 30px;">ŞİRKET LOGOSU</div>
        @endif

        <div class="title">BAŞARI SERTİFİKASI</div>
        <div class="subtitle">Bu belge, aşağıda ismi belirtilen personelin eğitim sürecini<br>başarıyla tamamladığını ve yetkinlik kazandığını belgeler.</div>

        <div class="person-name">{{ $record->user->name }}</div>

        <div style="font-size: 14px; color: #666;">Tamamlanan Eğitim:</div>
        <div class="training-title">{{ $record->plan->training->title }}</div>
        
        <div class="training-info">
            Eğitim Kodu: {{ $record->plan->training->code }} &nbsp;|&nbsp; 
            Başarı Puanı: <strong>{{ $record->exam_score }}</strong> &nbsp;|&nbsp;
            Tarih: {{ \Carbon\Carbon::parse($record->exam_date)->format('d.m.Y') }}
        </div>

        <table class="footer-table">
            <tr>
                <td class="sign-area">
                    <div class="sign-line">
                        {{ $record->plan->instructor }}<br>
                        <span style="font-weight: normal; font-size: 12px;">Eğitim Sorumlusu</span>
                    </div>
                </td>
                <td class="center-area"></td>
                <td class="qr-area">
                    {{-- REVİZE EDİLEN KISIM: DOĞRUDAN API LİNKİ --}}
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data={{ $verifyUrl }}" class="qr-img">
                    
                    <div class="verify-text">
                        Doğrulama Kodu:<br>
                        <strong>{{ $record->verification_code }}</strong>
                    </div>
                </td>
            </tr>
        </table>
        
        <div style="position: absolute; bottom: 30px; left:0; right:0; text-align: center; font-size: 10px; color: #aaa;">
            Bu belge elektronik ortamda oluşturulmuştur. QR kodu taratarak geçerliliğini sorgulayabilirsiniz.
        </div>
    </div>
</body>
</html>