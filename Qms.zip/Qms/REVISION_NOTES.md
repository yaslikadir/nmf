# QMS Revizyon Notları

## Güvenlik ve bütünlük

QMS modellerinin tamamına aktif şube global scope’u ve kayıt oluşturma/güncelleme koruması eklendi. Aktif şube seçilmeden kayıtlar listelenmez veya oluşturulamaz. QMS route’ları HTTP işlemine göre view, create, update ve delete seviyelerini denetleyen ortak middleware ile korundu.

Modellerdeki boş guarded yapılandırmaları `branch_id` alanını kullanıcı request’lerinden koruyacak şekilde değiştirildi. İlişkili alt kayıtlar da branch scope kullandığı için farklı şubeye ait child ID’leri doğrudan kullanılamaz.

## Eksik sınıf ve migration düzeltmeleri

Eksik `QmsDocumentService` modül içine taşındı. Doküman oluşturma, versiyon oluşturma, onay ve log işlemleri eklendi. Doküman onay ve audit log tablolarını oluşturan migration eklendi. QMS tablolarına branch_id ekleyen migration da modül migration dizinindedir.

## Deployment

```bash
composer dump-autoload -o
php artisan migrate --force
php artisan optimize:clear
```

Mevcut üretim kayıtlarının `branch_id` değerleri nullable migration nedeniyle otomatik olarak tahmin edilmez. Canlı veriler için işletme kuralına uygun kontrollü backfill yapılmalıdır. Backfill tamamlanmadan aktif şube scope’u eski kayıtlarda kayıtları göstermeyebilir; bu güvenlik gereği fail-closed davranıştır.

Dosya yüklemeleri izinli uzantı ve boyut doğrulamasından geçirilir. Doküman dosyaları local diskte tutulur ve indirme işlemi controller üzerinden yapılmalıdır; public doğrudan dosya URL’si kullanılmamalıdır.
