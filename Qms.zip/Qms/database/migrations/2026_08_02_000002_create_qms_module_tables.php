<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // ==================================================
        // 1. DOKÜMAN YÖNETİMİ (Document Management)
        // ==================================================
        if (!Schema::hasTable('qms_document_folders')) {
            Schema::create('qms_document_folders', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->unsignedBigInteger('parent_id')->nullable();
                $table->string('code_prefix')->nullable();
                $table->longText('access_rules')->nullable();
                $table->timestamps();

                $table->foreign('parent_id')->references('id')->on('qms_document_folders')->onDelete('cascade');
            });
        }

        if (!Schema::hasTable('qms_documents')) {
            Schema::create('qms_documents', function (Blueprint $table) {
                $table->id();
                $table->string('document_code')->unique();
                $table->string('name');
                $table->unsignedBigInteger('folder_id');
                $table->enum('security_level', ['Public','Internal','Confidential','Restricted'])->default('Internal');
                $table->integer('retention_period_years')->default(5);
                $table->boolean('auto_archive')->default(true);
                $table->enum('status', ['Draft','InReview','Published','Archived','Obsolete'])->default('Draft');
                $table->unsignedBigInteger('owner_id');
                $table->timestamps();
                $table->softDeletes();

                $table->foreign('folder_id')->references('id')->on('qms_document_folders');
                $table->foreign('owner_id')->references('id')->on('users');
            });
        }

        if (!Schema::hasTable('qms_document_versions')) {
            Schema::create('qms_document_versions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('document_id');
                $table->string('version_no');
                $table->string('file_path');
                $table->string('file_hash');
                $table->enum('status', ['Draft','InReview','Approved','Published','Obsolete'])->default('Draft');
                $table->text('revision_reason')->nullable();
                $table->longText('change_logs')->nullable();
                $table->date('valid_from')->nullable();
                $table->date('valid_until')->nullable();
                $table->timestamp('published_at')->nullable();
                $table->unsignedBigInteger('created_by');
                $table->unsignedBigInteger('approved_by')->nullable();
                $table->boolean('is_current')->default(false);
                $table->timestamps();

                $table->foreign('document_id')->references('id')->on('qms_documents')->onDelete('cascade');
                $table->foreign('created_by')->references('id')->on('users');
                $table->foreign('approved_by')->references('id')->on('users');
            });
        }

        if (!Schema::hasTable('qms_document_distributions')) {
            Schema::create('qms_document_distributions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('document_version_id');
                $table->unsignedBigInteger('user_id')->nullable();
                $table->unsignedBigInteger('department_id')->nullable();
                $table->boolean('is_read_required')->default(true);
                $table->boolean('is_read')->default(false);
                $table->timestamp('read_at')->nullable();
                $table->timestamps();

                $table->foreign('document_version_id')->references('id')->on('qms_document_versions')->onDelete('cascade');
                $table->foreign('user_id')->references('id')->on('users');
                $table->foreign('department_id')->references('id')->on('departments');
            });
        }

        // ==================================================
        // 2. DEĞİŞİKLİK YÖNETİMİ (Change Management)
        // ==================================================
        if (!Schema::hasTable('qms_changes')) {
            Schema::create('qms_changes', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->string('title');
                $table->text('description');
                $table->text('reason');
                $table->enum('type', ['Procedure','Equipment','Software','Personnel','Facility','Other']);
                $table->enum('priority', ['Low','Medium','High','Critical']);
                $table->unsignedBigInteger('request_user_id');
                $table->unsignedBigInteger('department_id')->nullable();
                $table->enum('status', ['Draft','Pending_Analysis','Pending_Approval','Approved','Rejected','Completed','Closed'])->default('Draft');
                $table->unsignedBigInteger('approved_by')->nullable();
                $table->dateTime('approved_at')->nullable();
                $table->text('rejection_reason')->nullable();
                $table->text('verification_result')->nullable();
                $table->date('closed_date')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (!Schema::hasTable('qms_change_risks')) {
            Schema::create('qms_change_risks', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('change_id');
                $table->string('risk_description');
                $table->integer('probability');
                $table->integer('impact');
                $table->integer('risk_score');
                $table->text('mitigation_plan')->nullable();
                $table->timestamps();

                $table->foreign('change_id')->references('id')->on('qms_changes')->onDelete('cascade');
            });
        }

        if (!Schema::hasTable('qms_change_actions')) {
            Schema::create('qms_change_actions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('change_id');
                $table->string('action_type');
                $table->string('description');
                $table->unsignedBigInteger('responsible_user_id');
                $table->date('due_date');
                $table->enum('status', ['Pending','In_Progress','Completed'])->default('Pending');
                $table->dateTime('completed_at')->nullable();
                $table->text('completion_note')->nullable();
                $table->timestamps();

                $table->foreign('change_id')->references('id')->on('qms_changes')->onDelete('cascade');
            });
        }

        if (!Schema::hasTable('qms_change_attachments')) {
            Schema::create('qms_change_attachments', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('change_id');
                $table->string('file_name');
                $table->string('file_path');
                $table->string('file_type')->nullable();
                $table->unsignedBigInteger('uploaded_by');
                $table->timestamps();

                $table->foreign('change_id')->references('id')->on('qms_changes')->onDelete('cascade');
            });
        }

        // ==================================================
        // 3. EĞİTİM YÖNETİMİ (Training Management)
        // ==================================================
        if (!Schema::hasTable('trainings')) {
            Schema::create('trainings', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->string('title');
                $table->text('description')->nullable();
                $table->enum('type', ['Internal','External','Online']);
                $table->integer('validity_months')->nullable();
                $table->boolean('has_exam')->default(false);
                $table->integer('passing_score')->default(70);
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (!Schema::hasTable('training_materials')) {
            Schema::create('training_materials', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('training_id');
                $table->string('title');
                $table->string('file_path');
                $table->string('file_type');
                $table->timestamps();

                $table->foreign('training_id')->references('id')->on('trainings')->onDelete('cascade');
            });
        }

        if (!Schema::hasTable('training_plans')) {
            Schema::create('training_plans', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('training_id');
                $table->dateTime('start_date');
                $table->dateTime('end_date');
                $table->integer('duration_hours')->nullable();
                $table->string('location')->nullable();
                $table->string('instructor');
                $table->enum('status', ['Planned','Completed','Cancelled'])->default('Planned');
                $table->text('notes')->nullable();
                $table->timestamps();

                $table->foreign('training_id')->references('id')->on('trainings')->onDelete('cascade');
            });
        }

        if (!Schema::hasTable('training_requests')) {
            Schema::create('training_requests', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id');
                $table->string('subject');
                $table->text('description')->nullable();
                $table->enum('priority', ['Normal','Acil'])->default('Normal');
                $table->enum('status', ['Pending','Approved','Planned','Rejected'])->default('Pending');
                $table->text('admin_note')->nullable();
                $table->timestamps();

                $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            });
        }

        if (!Schema::hasTable('training_evaluations')) {
            Schema::create('training_evaluations', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('training_record_id');
                $table->tinyInteger('rating');
                $table->text('comment')->nullable();
                $table->timestamps();
            });
        }

        // ==================================================
        // 4. DENETİM YÖNETİMİ (Audit Management)
        // ==================================================
        if (!Schema::hasTable('qms_audit_plans')) {
            Schema::create('qms_audit_plans', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('year', 4);
                $table->enum('status', ['Draft','Published','Closed'])->default('Draft');
                $table->unsignedBigInteger('created_by');
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (!Schema::hasTable('qms_audits')) {
            Schema::create('qms_audits', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('audit_plan_id');
                $table->enum('type', ['Internal','External','Supplier']);
                $table->string('code')->unique();
                $table->string('title');
                $table->date('planned_date');
                $table->date('performed_date')->nullable();
                $table->unsignedBigInteger('department_id')->nullable();
                $table->unsignedBigInteger('supplier_id')->nullable();
                $table->unsignedBigInteger('lead_auditor_id');
                $table->enum('status', ['Planned','In_Progress','Completed','Cancelled'])->default('Planned');
                $table->text('scope')->nullable();
                $table->text('summary')->nullable();
                $table->timestamps();
                $table->softDeletes();

                $table->foreign('audit_plan_id')->references('id')->on('qms_audit_plans')->onDelete('cascade');
            });
        }

        if (!Schema::hasTable('qms_audit_checklists')) {
            Schema::create('qms_audit_checklists', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('type')->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('qms_audit_questions')) {
            Schema::create('qms_audit_questions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('checklist_id');
                $table->text('question');
                $table->string('reference_standard')->nullable();
                $table->integer('order')->default(0);
                $table->timestamps();

                $table->foreign('checklist_id')->references('id')->on('qms_audit_checklists')->onDelete('cascade');
            });
        }

        if (!Schema::hasTable('qms_audit_findings')) {
            Schema::create('qms_audit_findings', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('audit_id');
                $table->unsignedBigInteger('question_id')->nullable();
                $table->enum('type', ['Conformity','NonConformity','Opportunity','Observation']);
                $table->enum('severity', ['Major','Minor','Critical'])->nullable();
                $table->text('finding_details');
                $table->text('evidence')->nullable();
                $table->string('attachment_path')->nullable();
                $table->timestamps();

                $table->foreign('audit_id')->references('id')->on('qms_audits')->onDelete('cascade');
                $table->foreign('question_id')->references('id')->on('qms_audit_questions');
            });
        }

        // ==================================================
        // 5. RİSK VE FIRSAT YÖNETİMİ (Risk Management)
        // ==================================================
        if (!Schema::hasTable('risks')) {
            Schema::create('risks', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->enum('type', ['Risk','Opportunity'])->default('Risk');
                $table->string('category');
                $table->text('description');
                $table->text('source')->nullable();
                $table->text('potential_impact');
                $table->unsignedBigInteger('department_id')->nullable();
                $table->integer('probability')->default(1);
                $table->integer('impact')->default(1);
                $table->integer('risk_score')->default(1);
                $table->string('risk_level')->default('Low');
                $table->enum('status', ['Open','In_Progress','Monitoring','Closed','Cancelled'])->default('Open');
                $table->unsignedBigInteger('owner_id');
                $table->unsignedBigInteger('created_by');
                $table->date('review_date')->nullable();
                $table->timestamps();
                $table->softDeletes();

                $table->foreign('department_id')->references('id')->on('departments');
                $table->foreign('owner_id')->references('id')->on('users');
                $table->foreign('created_by')->references('id')->on('users');
            });
        }

        if (!Schema::hasTable('risk_actions')) {
            Schema::create('risk_actions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('risk_id');
                $table->text('action_description');
                $table->enum('type', ['Preventive','Corrective','Improvement']);
                $table->unsignedBigInteger('assigned_to');
                $table->date('due_date')->nullable();
                $table->dateTime('completed_at')->nullable();
                $table->text('result_notes')->nullable();
                $table->timestamps();
                $table->softDeletes();

                $table->foreign('risk_id')->references('id')->on('risks')->onDelete('cascade');
                $table->foreign('assigned_to')->references('id')->on('users');
            });
        }

        // ==================================================
        // 6. DÖF / CAPA (Corrective & Preventive Actions)
        // ==================================================
        if (!Schema::hasTable('qms_capas')) {
            Schema::create('qms_capas', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->enum('source', ['Audit','Complaint','Risk','Incident','Other']);
                $table->unsignedBigInteger('audit_finding_id')->nullable();
                $table->unsignedBigInteger('feedback_id')->nullable();
                $table->unsignedBigInteger('risk_id')->nullable();
                $table->string('subject');
                $table->text('description');
                $table->unsignedBigInteger('department_id')->nullable();
                $table->text('root_cause')->nullable();
                $table->text('immediate_action')->nullable();
                $table->unsignedBigInteger('lead_user_id');
                $table->enum('priority', ['Low','Medium','High','Critical'])->default('Medium');
                $table->enum('status', ['Opened','Root_Cause_Analysis','Action_Planning','Verification','Closed','Cancelled'])->default('Opened');
                $table->date('target_date')->nullable();
                $table->date('closed_date')->nullable();
                $table->timestamps();
                $table->softDeletes();

                $table->foreign('risk_id')->references('id')->on('risks')->onDelete('set null');
            });
        }

        if (!Schema::hasTable('qms_capa_actions')) {
            Schema::create('qms_capa_actions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('capa_id');
                $table->text('action_description');
                $table->unsignedBigInteger('responsible_user_id');
                $table->date('due_date');
                $table->enum('status', ['Pending','In_Progress','Completed'])->default('Pending');
                $table->date('completed_at')->nullable();
                $table->text('completion_note')->nullable();
                $table->timestamps();

                $table->foreign('capa_id')->references('id')->on('qms_capas')->onDelete('cascade');
            });
        }

        // ==================================================
        // 7. GERİ BİLDİRİMLER (Feedbacks)
        // ==================================================
        if (!Schema::hasTable('feedbacks')) {
            Schema::create('feedbacks', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('feedback_form_id');
                $table->string('tracking_code')->unique();
                $table->string('guest_name')->nullable();
                $table->string('guest_email')->nullable();
                $table->string('guest_phone')->nullable();
                $table->longText('data');
                $table->string('status')->default('Pending');
                $table->string('priority')->default('Normal');
                $table->unsignedBigInteger('assigned_user_id')->nullable();
                $table->timestamps();
                $table->softDeletes();

                $table->foreign('assigned_user_id')->references('id')->on('users');
            });
        }

        // ==================================================
        // 8. ACİL DURUM YÖNETİMİ (Emergency Management)
        // ==================================================
        if (!Schema::hasTable('emergency_plans')) {
            Schema::create('emergency_plans', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->text('scenario');
                $table->text('procedure');
                $table->longText('checklist_items')->nullable();
                $table->text('response_team')->nullable();
                $table->integer('drill_frequency_months')->default(12);
                $table->date('last_drill_date')->nullable();
                $table->date('next_drill_date')->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (!Schema::hasTable('emergency_drills')) {
            Schema::create('emergency_drills', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('emergency_plan_id');
                $table->date('drill_date');
                $table->time('drill_time')->nullable();
                $table->string('drill_type')->nullable();
                $table->integer('duration_minutes')->nullable();
                $table->text('notes')->nullable();
                $table->longText('checklist_results')->nullable();
                $table->unsignedBigInteger('conducted_by');
                $table->timestamps();

                $table->foreign('emergency_plan_id')->references('id')->on('emergency_plans')->onDelete('cascade');
                $table->foreign('conducted_by')->references('id')->on('users');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('emergency_drills');
        Schema::dropIfExists('emergency_plans');
        Schema::dropIfExists('feedbacks');
        Schema::dropIfExists('qms_capa_actions');
        Schema::dropIfExists('qms_capas');
        Schema::dropIfExists('risk_actions');
        Schema::dropIfExists('risks');
        Schema::dropIfExists('qms_audit_findings');
        Schema::dropIfExists('qms_audit_questions');
        Schema::dropIfExists('qms_audit_checklists');
        Schema::dropIfExists('qms_audits');
        Schema::dropIfExists('qms_audit_plans');
        Schema::dropIfExists('training_evaluations');
        Schema::dropIfExists('training_requests');
        Schema::dropIfExists('training_plans');
        Schema::dropIfExists('training_materials');
        Schema::dropIfExists('trainings');
        Schema::dropIfExists('qms_change_attachments');
        Schema::dropIfExists('qms_change_actions');
        Schema::dropIfExists('qms_change_risks');
        Schema::dropIfExists('qms_changes');
        Schema::dropIfExists('qms_document_distributions');
        Schema::dropIfExists('qms_document_versions');
        Schema::dropIfExists('qms_documents');
        Schema::dropIfExists('qms_document_folders');
        Schema::enableForeignKeyConstraints();
    }
};