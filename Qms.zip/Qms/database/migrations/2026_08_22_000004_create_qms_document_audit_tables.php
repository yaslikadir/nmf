<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('qms_document_approvals')) {
            Schema::create('qms_document_approvals', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('branch_id')->nullable()->index();
                $table->unsignedBigInteger('document_version_id');
                $table->unsignedBigInteger('user_id');
                $table->unsignedInteger('order')->default(1);
                $table->enum('status', ['Pending', 'Approved', 'Rejected'])->default('Pending');
                $table->text('comments')->nullable();
                $table->dateTime('action_date')->nullable();
                $table->timestamps();

                $table->foreign('document_version_id')->references('id')->on('qms_document_versions')->onDelete('cascade');
                $table->foreign('user_id')->references('id')->on('users');
            });
        }

        if (!Schema::hasTable('qms_document_logs')) {
            Schema::create('qms_document_logs', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('branch_id')->nullable()->index();
                $table->unsignedBigInteger('document_id');
                $table->unsignedBigInteger('user_id')->nullable();
                $table->string('action', 50);
                $table->text('description')->nullable();
                $table->timestamp('created_at')->useCurrent();

                $table->foreign('document_id')->references('id')->on('qms_documents')->onDelete('cascade');
                $table->foreign('user_id')->references('id')->on('users')->nullOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('qms_document_logs');
        Schema::dropIfExists('qms_document_approvals');
    }
};
