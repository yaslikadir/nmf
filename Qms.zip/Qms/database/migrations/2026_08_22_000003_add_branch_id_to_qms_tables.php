<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * QMS kayıtlarını aktif şube izolasyonuna hazırlar.
     * Mevcut kayıtlar için branch_id nullable bırakılır; deployment sonrası
     * işletme verilerine göre kontrollü backfill yapılmalıdır.
     */
    public function up(): void
    {
        $tables = [
            'qms_document_folders', 'qms_documents', 'qms_document_versions',
            'qms_document_distributions', 'qms_changes', 'qms_change_risks',
            'qms_change_actions', 'qms_change_attachments', 'trainings',
            'training_materials', 'training_plans', 'training_requests',
            'training_evaluations', 'qms_audit_plans', 'qms_audits',
            'qms_audit_checklists', 'qms_audit_questions', 'qms_audit_findings',
            'risks', 'risk_actions', 'qms_capas', 'qms_capa_actions',
            'feedbacks', 'emergency_plans', 'emergency_drills',
        ];

        foreach ($tables as $tableName) {
            if (!Schema::hasTable($tableName) || Schema::hasColumn($tableName, 'branch_id')) {
                continue;
            }

            Schema::table($tableName, function (Blueprint $table) {
                $table->unsignedBigInteger('branch_id')->nullable()->index()->after('id');
            });
        }
    }

    public function down(): void
    {
        $tables = [
            'qms_document_folders', 'qms_documents', 'qms_document_versions',
            'qms_document_distributions', 'qms_changes', 'qms_change_risks',
            'qms_change_actions', 'qms_change_attachments', 'trainings',
            'training_materials', 'training_plans', 'training_requests',
            'training_evaluations', 'qms_audit_plans', 'qms_audits',
            'qms_audit_checklists', 'qms_audit_questions', 'qms_audit_findings',
            'risks', 'risk_actions', 'qms_capas', 'qms_capa_actions',
            'feedbacks', 'emergency_plans', 'emergency_drills',
        ];

        foreach ($tables as $tableName) {
            if (Schema::hasTable($tableName) && Schema::hasColumn($tableName, 'branch_id')) {
                Schema::table($tableName, function (Blueprint $table) {
                    $table->dropColumn('branch_id');
                });
            }
        }
    }
};
